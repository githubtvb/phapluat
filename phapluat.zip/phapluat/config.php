<?php

/**
 * @Project NUKEVIET 3.0
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2010 VINADES.,JSC. All rights reserved
 * @Createdate Fri, 26 Oct 2012 11:07:14 GMT
 */

if ( ! defined( 'NV_MAINFILE' ) )
{
    die( 'Stop!!!' );
}

$db_config['dbhost'] = "localhost";
$db_config['dbport'] = "";
$db_config['dbname'] = "db_phapluat2";
$db_config['dbuname'] = "root";
$db_config['dbpass'] = "";
$db_config['prefix'] = "nv3";

$global_config['sitekey'] = "2f5519bd89e1520e110ba7150f18d1c2";// Do not change sitekey!

?>