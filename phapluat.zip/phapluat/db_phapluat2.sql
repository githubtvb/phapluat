-- phpMyAdmin SQL Dump
-- version 3.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 14, 2012 at 07:55 AM
-- Server version: 5.5.25a
-- PHP Version: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_phapluat2`
--

-- --------------------------------------------------------

--
-- Table structure for table `nv3_authors`
--

CREATE TABLE IF NOT EXISTS `nv3_authors` (
  `admin_id` mediumint(8) unsigned NOT NULL,
  `editor` varchar(100) NOT NULL,
  `lev` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `files_level` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `is_suspend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `susp_reason` mediumtext NOT NULL,
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_authors`
--

INSERT INTO `nv3_authors` (`admin_id`, `editor`, `lev`, `files_level`, `position`, `addtime`, `edittime`, `is_suspend`, `susp_reason`, `check_num`, `last_login`, `last_ip`, `last_agent`) VALUES
(1, 'ckeditor', 1, 'adobe,archives,audio,documents,flash,images,real,video|1|1|1', 'Administrator', 0, 0, 0, '', '07a6eb1777073f0dd6479dcc5e50606181fa28f9', 1352719487, '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; rv:16.0) Gecko/20100101 Firefox/16.0');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_authors_config`
--

CREATE TABLE IF NOT EXISTS `nv3_authors_config` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `keyname` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyname` (`keyname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_banip`
--

CREATE TABLE IF NOT EXISTS `nv3_banip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `area` tinyint(3) NOT NULL,
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_banners_click`
--

CREATE TABLE IF NOT EXISTS `nv3_banners_click` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `click_time` int(11) unsigned NOT NULL DEFAULT '0',
  `click_day` int(2) NOT NULL,
  `click_ip` varchar(15) NOT NULL,
  `click_country` varchar(10) NOT NULL,
  `click_browse_key` varchar(100) NOT NULL,
  `click_browse_name` varchar(100) NOT NULL,
  `click_os_key` varchar(100) NOT NULL,
  `click_os_name` varchar(100) NOT NULL,
  `click_ref` varchar(255) NOT NULL,
  KEY `bid` (`bid`),
  KEY `click_day` (`click_day`),
  KEY `click_ip` (`click_ip`),
  KEY `click_country` (`click_country`),
  KEY `click_browse_key` (`click_browse_key`),
  KEY `click_os_key` (`click_os_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_banners_clients`
--

CREATE TABLE IF NOT EXISTS `nv3_banners_clients` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(60) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `reg_time` int(11) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `fax` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(15) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  `uploadtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `email` (`email`),
  KEY `full_name` (`full_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_banners_plans`
--

CREATE TABLE IF NOT EXISTS `nv3_banners_plans` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `blang` char(2) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `form` varchar(100) NOT NULL,
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `nv3_banners_plans`
--

INSERT INTO `nv3_banners_plans` (`id`, `blang`, `title`, `description`, `form`, `width`, `height`, `act`) VALUES
(1, '', 'Quang cao giua trang', '', 'sequential', 510, 100, 1),
(2, '', 'Quang cao trai', '', 'sequential', 190, 500, 1);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_banners_rows`
--

CREATE TABLE IF NOT EXISTS `nv3_banners_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `clid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `file_name` varchar(255) NOT NULL,
  `file_ext` varchar(100) NOT NULL,
  `file_mime` varchar(100) NOT NULL,
  `width` int(4) unsigned NOT NULL DEFAULT '0',
  `height` int(4) unsigned NOT NULL DEFAULT '0',
  `file_alt` varchar(255) NOT NULL,
  `click_url` varchar(255) NOT NULL,
  `file_name_tmp` varchar(255) NOT NULL,
  `file_alt_tmp` varchar(255) NOT NULL,
  `click_url_tmp` varchar(255) NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `clid` (`clid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `nv3_banners_rows`
--

INSERT INTO `nv3_banners_rows` (`id`, `title`, `pid`, `clid`, `file_name`, `file_ext`, `file_mime`, `width`, `height`, `file_alt`, `click_url`, `file_name_tmp`, `file_alt_tmp`, `click_url_tmp`, `add_time`, `publ_time`, `exp_time`, `hits_total`, `act`, `weight`) VALUES
(1, 'Bo ngoai giao', 2, 0, 'bongoaigiao.jpg', 'jpg', 'image/jpeg', 160, 54, '', 'http://www.mofa.gov.vn', '', '', '', 1351249594, 1351249594, 0, 0, 1, 1),
(2, 'vinades', 2, 0, 'vinades.jpg', 'jpg', 'image/jpeg', 190, 454, '', 'http://vinades.vn', '', '', '', 1351249594, 1351249594, 0, 0, 1, 2),
(3, 'Quang cao giua trang', 1, 0, 'webnhanh_vn.gif', 'gif', 'image/gif', 510, 65, '', 'http://webnhanh.vn', '', '', '', 1351249594, 1351249594, 0, 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_config`
--

CREATE TABLE IF NOT EXISTS `nv3_config` (
  `lang` char(3) NOT NULL DEFAULT 'sys',
  `module` varchar(25) NOT NULL DEFAULT 'global',
  `config_name` varchar(30) NOT NULL DEFAULT '',
  `config_value` mediumtext NOT NULL,
  UNIQUE KEY `lang` (`lang`,`module`,`config_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_config`
--

INSERT INTO `nv3_config` (`lang`, `module`, `config_name`, `config_value`) VALUES
('sys', 'global', 'closed_site', '0'),
('sys', 'global', 'site_keywords', 'NukeViet, portal, mysql, php'),
('sys', 'global', 'site_phone', ''),
('sys', 'global', 'site_lang', 'vi'),
('sys', 'global', 'admin_theme', 'admin_full'),
('sys', 'global', 'date_pattern', 'l, d-m-Y'),
('sys', 'global', 'time_pattern', 'H&#x3A;i'),
('sys', 'global', 'block_admin_ip', '0'),
('sys', 'global', 'admfirewall', '0'),
('sys', 'global', 'online_upd', '1'),
('sys', 'global', 'statistic', '1'),
('sys', 'global', 'dump_autobackup', '1'),
('sys', 'global', 'dump_backup_ext', 'gz'),
('sys', 'global', 'dump_backup_day', '30'),
('sys', 'global', 'gfx_chk', '3'),
('sys', 'global', 'file_allowed_ext', 'adobe,application,archives,audio,documents,flash,images,real,text,video,xml'),
('sys', 'global', 'forbid_extensions', 'php,php3,php4,php5,phtml,inc'),
('sys', 'global', 'forbid_mimes', ''),
('sys', 'global', 'nv_max_size', '2097152'),
('sys', 'global', 'upload_checking_mode', 'lite'),
('sys', 'global', 'upload_logo', 'images/logo.png'),
('sys', 'global', 'str_referer_blocker', '0'),
('sys', 'global', 'getloadavg', '0'),
('sys', 'global', 'mailer_mode', ''),
('sys', 'global', 'smtp_host', 'smtp.gmail.com'),
('sys', 'global', 'smtp_ssl', '1'),
('sys', 'global', 'smtp_port', '465'),
('sys', 'global', 'smtp_username', 'user@gmail.com'),
('sys', 'global', 'smtp_password', 'userpass'),
('sys', 'global', 'allowuserreg', '1'),
('sys', 'global', 'allowuserlogin', '1'),
('sys', 'global', 'allowloginchange', '0'),
('sys', 'global', 'allowquestion', '1'),
('sys', 'global', 'allowuserpublic', '0'),
('sys', 'global', 'useactivate', '2'),
('sys', 'global', 'allowmailchange', '1'),
('sys', 'global', 'allow_sitelangs', 'vi'),
('sys', 'global', 'allow_adminlangs', 'en,vi'),
('sys', 'global', 'read_type', '0'),
('sys', 'global', 'is_url_rewrite', '1'),
('sys', 'global', 'rewrite_optional', '0'),
('sys', 'global', 'rewrite_endurl', '/'),
('sys', 'global', 'rewrite_exturl', '.html'),
('sys', 'global', 'autocheckupdate', '1'),
('sys', 'global', 'autologomod', ''),
('sys', 'global', 'autologosize1', '50'),
('sys', 'global', 'autologosize2', '40'),
('sys', 'global', 'autologosize3', '30'),
('sys', 'global', 'autoupdatetime', '24'),
('sys', 'global', 'gzip_method', '1'),
('sys', 'global', 'is_user_forum', '0'),
('sys', 'global', 'openid_mode', '1'),
('sys', 'global', 'authors_detail_main', '0'),
('sys', 'global', 'spadmin_add_admin', '1'),
('sys', 'global', 'openid_servers', 'yahoo,google,myopenid'),
('sys', 'global', 'optActive', '0'),
('sys', 'global', 'googleAnalyticsID', ''),
('sys', 'global', 'googleAnalyticsSetDomainName', '0'),
('sys', 'global', 'searchEngineUniqueID', ''),
('sys', 'global', 'captcha_type', '0'),
('sys', 'global', 'revision', '1758'),
('sys', 'global', 'version', '3.4.01'),
('vi', 'global', 'site_name', 'Pháp Luật'),
('vi', 'global', 'site_logo', 'images/logo.png'),
('vi', 'global', 'site_description', 'NukeViet CMS 3.x Developed by VINADES.,JSC'),
('vi', 'global', 'site_keywords', ''),
('vi', 'global', 'site_theme', 'phapluat2'),
('vi', 'global', 'site_home_module', 'news'),
('vi', 'global', 'switch_mobi_des', '1'),
('vi', 'global', 'disable_site_content', 'Vì lý do kỹ thuật website tạm ngưng hoạt động. Thành thật xin lỗi các bạn vì sự bất tiện này!'),
('vi', 'news', 'indexfile', 'viewcat_main_right'),
('vi', 'news', 'per_page', '20'),
('vi', 'news', 'st_links', '10'),
('vi', 'news', 'auto_postcomm', '1'),
('vi', 'news', 'homewidth', '100'),
('vi', 'news', 'homeheight', '150'),
('vi', 'news', 'blockwidth', '52'),
('vi', 'news', 'blockheight', '75'),
('vi', 'news', 'imagefull', '460'),
('vi', 'news', 'setcomm', '2'),
('vi', 'news', 'copyright', 'Chú ý: Việc đăng lại bài viết trên ở website hoặc các phương tiện truyền thông khác mà không ghi rõ nguồn http://nukeviet.vn là vi phạm bản quyền'),
('vi', 'news', 'showhometext', '1'),
('vi', 'news', 'activecomm', '1'),
('vi', 'news', 'emailcomm', '1'),
('vi', 'news', 'timecheckstatus', '0'),
('vi', 'news', 'config_source', '0'),
('sys', 'global', 'site_email', 'tvthanh88hp@gmail.com'),
('sys', 'global', 'error_send_email', 'tvthanh88hp@gmail.com'),
('sys', 'global', 'my_domains', 'localhost'),
('sys', 'global', 'cookie_prefix', 'nv3c_Bxxcg'),
('sys', 'global', 'session_prefix', 'nv3s_Ef1qcy'),
('sys', 'global', 'site_timezone', 'byCountry'),
('sys', 'global', 'statistics_timezone', 'Asia/Bangkok'),
('sys', 'global', 'proxy_blocker', '0'),
('sys', 'global', 'lang_multi', '1'),
('sys', 'global', 'lang_geo', '0'),
('sys', 'global', 'ftp_server', 'localhost'),
('sys', 'global', 'ftp_port', '21'),
('sys', 'global', 'ftp_user_name', ''),
('sys', 'global', 'ftp_user_pass', ''),
('sys', 'global', 'ftp_path', '/'),
('sys', 'global', 'ftp_check_login', '0'),
('vi', 'archives', 'view_type', 'view_listall'),
('vi', 'archives', 'view_num', '30'),
('vi', 'archives', 'who_upload', '0'),
('vi', 'archives', 'groups_view', ''),
('vi', 'archives', 'status', '0');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_cronjobs`
--

CREATE TABLE IF NOT EXISTS `nv3_cronjobs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `start_time` int(11) unsigned NOT NULL DEFAULT '0',
  `interval` int(11) unsigned NOT NULL DEFAULT '0',
  `run_file` varchar(255) NOT NULL,
  `run_func` varchar(255) NOT NULL,
  `params` varchar(255) NOT NULL,
  `del` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_sys` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `last_time` int(11) unsigned NOT NULL DEFAULT '0',
  `last_result` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vi_cron_name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `is_sys` (`is_sys`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `nv3_cronjobs`
--

INSERT INTO `nv3_cronjobs` (`id`, `start_time`, `interval`, `run_file`, `run_func`, `params`, `del`, `is_sys`, `act`, `last_time`, `last_result`, `vi_cron_name`) VALUES
(1, 1351249594, 5, 'online_expired_del.php', 'cron_online_expired_del', '', 0, 1, 1, 1352719492, 1, 'Xóa các dòng ghi trạng thái online đã cũ trong CSDL'),
(2, 1351249594, 1440, 'dump_autobackup.php', 'cron_dump_autobackup', '', 0, 1, 1, 1352719492, 1, 'Tự động lưu CSDL'),
(3, 1351249594, 60, 'temp_download_destroy.php', 'cron_auto_del_temp_download', '', 0, 1, 1, 1352719492, 1, 'Xóa các file tạm trong thư mục tmp'),
(4, 1351249594, 30, 'ip_logs_destroy.php', 'cron_del_ip_logs', '', 0, 1, 1, 1352719492, 1, 'Xóa IP log files Xóa các file logo truy cập'),
(5, 1351249594, 1440, 'error_log_destroy.php', 'cron_auto_del_error_log', '', 0, 1, 1, 1352719492, 1, 'Xóa các file error_log quá hạn'),
(6, 1351249594, 360, 'error_log_sendmail.php', 'cron_auto_sendmail_error_log', '', 0, 1, 0, 0, 0, 'Gửi email các thông báo lỗi cho admin'),
(7, 1351249594, 60, 'ref_expired_del.php', 'cron_ref_expired_del', '', 0, 1, 1, 1352719492, 1, 'Xóa các referer quá hạn'),
(8, 1351249594, 1440, 'siteDiagnostic_update.php', 'cron_siteDiagnostic_update', '', 0, 1, 1, 1352719492, 1, 'Cập nhật đánh giá site từ các máy chủ tìm kiếm'),
(9, 1351249594, 60, 'check_version.php', 'cron_auto_check_version', '', 0, 1, 1, 1352454497, 1, 'Kiểm tra phiên bản NukeViet');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_groups`
--

CREATE TABLE IF NOT EXISTS `nv3_groups` (
  `group_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL,
  `exp_time` int(11) NOT NULL,
  `users` mediumtext NOT NULL,
  `public` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `title` (`title`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_ipcountry`
--

CREATE TABLE IF NOT EXISTS `nv3_ipcountry` (
  `ip_from` int(11) unsigned NOT NULL,
  `ip_to` int(11) unsigned NOT NULL,
  `country` char(2) NOT NULL,
  `ip_file` smallint(5) unsigned NOT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `ip_from` (`ip_from`,`ip_to`),
  KEY `ip_file` (`ip_file`),
  KEY `country` (`country`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_ipcountry`
--

INSERT INTO `nv3_ipcountry` (`ip_from`, `ip_to`, `country`, `ip_file`, `time`) VALUES
(2130706432, 2130771967, 'ZZ', 127, 1351249640);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_language`
--

CREATE TABLE IF NOT EXISTS `nv3_language` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `idfile` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lang_key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filelang` (`idfile`,`lang_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_language_file`
--

CREATE TABLE IF NOT EXISTS `nv3_language_file` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL,
  `admin_file` varchar(255) NOT NULL DEFAULT '0',
  `langtype` varchar(50) NOT NULL,
  PRIMARY KEY (`idfile`),
  UNIQUE KEY `module` (`module`,`admin_file`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_logs`
--

CREATE TABLE IF NOT EXISTS `nv3_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` varchar(10) NOT NULL,
  `module_name` varchar(150) NOT NULL,
  `name_key` varchar(255) NOT NULL,
  `note_action` text NOT NULL,
  `link_acess` varchar(255) NOT NULL,
  `userid` int(11) NOT NULL,
  `log_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=288 ;

--
-- Dumping data for table `nv3_logs`
--

INSERT INTO `nv3_logs` (`id`, `lang`, `module_name`, `name_key`, `note_action`, `link_acess`, `userid`, `log_time`) VALUES
(1, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351249645),
(2, 'vi', 'themes', 'Thiết lập layout theme: "phapluat2"', '', '', 1, 1351249716),
(3, 'vi', 'themes', 'Kích hoạt theme: "phapluat2"', '', '', 1, 1351249727),
(4, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351263515),
(5, 'vi', 'themes', 'Kích hoạt theme: "default"', '', '', 1, 1351263557),
(6, 'vi', 'themes', 'Kích hoạt theme: "phapluat2"', '', '', 1, 1351263626),
(7, 'vi', 'themes', 'Kích hoạt theme: "phapluat2"', '', '', 1, 1351263627),
(8, 'vi', 'themes', 'Kích hoạt theme: "default"', '', '', 1, 1351263662),
(9, 'vi', 'themes', 'Kích hoạt theme: "phapluat2"', '', '', 1, 1351264083),
(10, 'vi', 'themes', 'Thêm block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1351264321),
(11, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1351264340),
(12, 'vi', 'themes', 'Kích hoạt theme: "default"', '', '', 1, 1351264350),
(13, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1351264417),
(14, 'vi', 'themes', 'Kích hoạt theme: "phapluat2"', '', '', 1, 1351264434),
(15, 'vi', 'themes', 'Sửa block', 'Name : Menu', 'Name : Menu', 1, 1351264498),
(16, 'vi', 'themes', 'Kích hoạt theme: "default"', '', '', 1, 1351264758),
(17, 'vi', 'themes', 'Kích hoạt theme: "phapluat2"', '', '', 1, 1351264868),
(18, 'vi', 'themes', 'Kích hoạt theme: "default"', '', '', 1, 1351265067),
(19, 'vi', 'themes', 'Kích hoạt theme: "phapluat2"', '', '', 1, 1351265389),
(20, 'vi', 'themes', 'Kích hoạt theme: "default"', '', '', 1, 1351267347),
(21, 'vi', 'themes', 'Kích hoạt theme: "phapluat2"', '', '', 1, 1351267377),
(22, 'vi', 'themes', 'Thêm block', 'Name : module block headline', 'Name : module block headline', 1, 1351267429),
(23, 'vi', 'themes', 'Sửa block', 'Name : module block headline', 'Name : module block headline', 1, 1351267659),
(24, 'vi', 'themes', 'Thêm block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1351270349),
(25, 'vi', 'themes', 'Sửa block', 'Name : global menu theme default', 'Name : global menu theme default', 1, 1351270362),
(26, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351304992),
(27, 'vi', 'themes', 'Sửa block', 'Name : Menu', 'Name : Menu', 1, 1351305051),
(28, 'vi', 'themes', 'Thêm block', 'Name : global block category', 'Name : global block category', 1, 1351305191),
(29, 'vi', 'themes', 'Kích hoạt theme: "default"', '', '', 1, 1351306295),
(30, 'vi', 'themes', 'Kích hoạt theme: "phapluat2"', '', '', 1, 1351306548),
(31, 'vi', 'themes', 'Thêm block', 'Name : global block topnews', 'Name : global block topnews', 1, 1351307263),
(32, 'vi', 'themes', 'Kích hoạt theme: "default"', '', '', 1, 1351307891),
(33, 'vi', 'themes', 'Kích hoạt theme: "phapluat2"', '', '', 1, 1351307979),
(34, 'vi', 'themes', 'Thêm block', 'Name : global voting', 'Name : global voting', 1, 1351308143),
(35, 'vi', 'themes', 'Thêm block', 'Name : global counter', 'Name : global counter', 1, 1351309000),
(36, 'vi', 'themes', 'Kích hoạt theme: "default"', '', '', 1, 1351311914),
(37, 'vi', 'themes', 'Kích hoạt theme: "phapluat2"', '', '', 1, 1351311931),
(38, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351331211),
(39, 'vi', 'modules', 'Thiết lập module mới shops"', '', '', 1, 1351331256),
(40, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1351331358),
(41, 'vi', 'modules', 'Thứ tự module "shops"', '11 -> 3', '11 -> 3', 1, 1351331444),
(42, 'vi', 'shops', 'log_add_catalog', 'id 1', 'id 1', 1, 1351331584),
(43, 'vi', 'shops', 'log_add_catalog', 'id 2', 'id 2', 1, 1351331603),
(44, 'vi', 'shops', 'log_add_catalog', 'id 3', 'id 3', 1, 1351331622),
(45, 'vi', 'themes', 'Thêm block', 'Name : global block blocknews', 'Name : global block blocknews', 1, 1351333449),
(46, 'vi', 'themes', 'Kích hoạt theme: "default"', '', '', 1, 1351333469),
(47, 'vi', 'themes', 'Kích hoạt theme: "phapluat2"', '', '', 1, 1351333760),
(48, 'vi', 'news', 'Thêm chuyên mục', 'Sản phẩm A', 'Sản phẩm A', 1, 1351336138),
(49, 'vi', 'news', 'Thêm chuyên mục', 'Sản phẩm B', 'Sản phẩm B', 1, 1351336148),
(50, 'vi', 'news', 'Thêm chuyên mục', 'Sản phẩm C', 'Sản phẩm C', 1, 1351336157),
(51, 'vi', 'news', 'Thêm chuyên mục', 'Đối tác  A', 'Đối tác  A', 1, 1351344537),
(52, 'vi', 'news', 'Thêm chuyên mục', 'Đối tác  B', 'Đối tác  B', 1, 1351344546),
(53, 'vi', 'news', 'Thêm chuyên mục', 'Tuyển dụng  A', 'Tuyển dụng  A', 1, 1351344582),
(54, 'vi', 'news', 'Thêm chuyên mục', 'Tuyển dụng  B', 'Tuyển dụng  B', 1, 1351344592),
(55, 'vi', 'news', 'Thêm chuyên mục', 'Tuyển dụng  C', 'Tuyển dụng  C', 1, 1351344629),
(56, 'vi', 'news', 'Thêm chuyên mục', 'Tuyển dụng  D', 'Tuyển dụng  D', 1, 1351344639),
(57, 'vi', 'news', 'Thêm chuyên mục', 'Tuyển dụng  E', 'Tuyển dụng  E', 1, 1351344652),
(58, 'vi', 'themes', 'Kích hoạt theme: "default"', '', '', 1, 1351344867),
(59, 'vi', 'themes', 'Kích hoạt theme: "phapluat2"', '', '', 1, 1351344887),
(60, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351394143),
(61, 'vi', 'modules', 'Sửa module &ldquo;news&rdquo;', '', '', 1, 1351394927),
(62, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1351394967),
(63, 'vi', 'modules', 'Thứ tự module "about"', '11 -> 3', '11 -> 3', 1, 1351396596),
(64, 'vi', 'modules', 'Thứ tự module "about"', '11 -> 1', '11 -> 1', 1, 1351396627),
(65, 'vi', 'themes', 'Kích hoạt theme: "default"', '', '', 1, 1351399862),
(66, 'vi', 'themes', 'Kích hoạt theme: "phapluat2"', '', '', 1, 1351399916),
(67, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351400601),
(68, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351400762),
(69, 'vi', 'shops', 'log_edit_catalog', 'id 1', 'id 1', 1, 1351404894),
(70, 'vi', 'shops', 'log_edit_catalog', 'id 2', 'id 2', 1, 1351405016),
(71, 'vi', 'shops', 'log_edit_catalog', 'id 3', 'id 3', 1, 1351405052),
(72, 'vi', 'shops', 'log_add_catalog', 'id 4', 'id 4', 1, 1351405323),
(73, 'vi', 'shops', 'log_add_catalog', 'id 5', 'id 5', 1, 1351405353),
(74, 'vi', 'shops', 'log_add_catalog', 'id 6', 'id 6', 1, 1351405369),
(75, 'vi', 'shops', 'log_edit_catalog', 'id 3', 'id 3', 1, 1351405415),
(76, 'vi', 'shops', 'log_edit_catalog', 'id 2', 'id 2', 1, 1351405429),
(77, 'vi', 'shops', 'log_edit_catalog', 'id 6', 'id 6', 1, 1351405450),
(78, 'vi', 'shops', 'log_add_catalog', 'id 7', 'id 7', 1, 1351405478),
(79, 'vi', 'shops', 'log_add_catalog', 'id 8', 'id 8', 1, 1351405488),
(80, 'vi', 'themes', 'Sửa block', 'Name : Lĩnh vực hoạt động', 'Name : Lĩnh vực hoạt động', 1, 1351405610),
(81, 'vi', 'themes', 'Sửa block', 'Name : Thành viên', 'Name : Thành viên', 1, 1351405636),
(82, 'vi', 'themes', 'Sửa block', 'Name : Thống kê', 'Name : Thống kê', 1, 1351405659),
(83, 'vi', 'themes', 'Sửa block', 'Name : Thăm dò ý kiến', 'Name : Thăm dò ý kiến', 1, 1351405685),
(84, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Sản phẩm C', 'Sản phẩm C', 1, 1351405946),
(85, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Sản phẩm B', 'Sản phẩm B', 1, 1351405950),
(86, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Sản phẩm A', 'Sản phẩm A', 1, 1351405954),
(87, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Sản phẩm', 'Sản phẩm', 1, 1351405980),
(88, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tuyển dụng  E', 'Tuyển dụng  E', 1, 1351405999),
(89, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tuyển dụng  D', 'Tuyển dụng  D', 1, 1351406004),
(90, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tuyển dụng  C', 'Tuyển dụng  C', 1, 1351406011),
(91, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tuyển dụng  B', 'Tuyển dụng  B', 1, 1351406015),
(92, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tuyển dụng  A', 'Tuyển dụng  A', 1, 1351406020),
(93, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tuyển dụng', 'Tuyển dụng', 1, 1351406028),
(94, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Đối tác  B', 'Đối tác  B', 1, 1351406044),
(95, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Đối tác  A', 'Đối tác  A', 1, 1351406051),
(96, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Đối tác', 'Đối tác', 1, 1351406063),
(97, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tin công nghệ', 'Tin công nghệ', 1, 1351406071),
(98, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Bản tin nội bộ', 'Bản tin nội bộ', 1, 1351406078),
(99, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Thông cáo báo chí', 'Thông cáo báo chí', 1, 1351406083),
(100, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tin tức', 'Tin tức', 1, 1351406102),
(101, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ doanh nghiệp', 'Dịch vụ doanh nghiệp', 1, 1351406129),
(102, 'vi', 'news', 'Thêm chuyên mục', 'Sở hữu trí tuệ', 'Sở hữu trí tuệ', 1, 1351406149),
(103, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ tư vấn', 'Dịch vụ tư vấn', 1, 1351406165),
(104, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ tài chính', 'Dịch vụ tài chính', 1, 1351406210),
(105, 'vi', 'news', 'Thêm chuyên mục', 'Thông tin pháp luật', 'Thông tin pháp luật', 1, 1351406248),
(106, 'vi', 'news', 'Thêm chuyên mục', 'Hỏi đáp pháp luật', 'Hỏi đáp pháp luật', 1, 1351406266),
(107, 'vi', 'news', 'Thêm chuyên mục', 'Kiến thức', 'Kiến thức', 1, 1351406336),
(108, 'vi', 'news', 'Thêm chuyên mục', 'Thư giãn', 'Thư giãn', 1, 1351406347),
(109, 'vi', 'news', 'Thêm chuyên mục', 'Đăng ký kinh doanh', 'Đăng ký kinh doanh', 1, 1351406440),
(110, 'vi', 'news', 'Thêm chuyên mục', 'Đăng ký đầu tư', 'Đăng ký đầu tư', 1, 1351406475),
(111, 'vi', 'news', 'Thêm chuyên mục', 'Tổ chức doanh nghệp', 'Tổ chức doanh nghệp', 1, 1351406499),
(112, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ đăng ký bảo hộ', 'Dịch vụ đăng ký bảo hộ', 1, 1351406544),
(113, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ xử lý vi phạm SHTT', 'Dịch vụ xử lý vi phạm SHTT', 1, 1351406576),
(114, 'vi', 'news', 'Thêm chuyên mục', 'Li xăng và nhượng quyền', 'Li xăng và nhượng quyền', 1, 1351406623),
(115, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ luật sư', 'Dịch vụ luật sư', 1, 1351406748),
(116, 'vi', 'news', 'Thêm chuyên mục', 'Dịch vụ xin giấy phép', 'Dịch vụ xin giấy phép', 1, 1351406773),
(117, 'vi', 'news', 'Thêm chuyên mục', 'Hướng dẫn thủ tục', 'Hướng dẫn thủ tục', 1, 1351406792),
(118, 'vi', 'news', 'Thêm chuyên mục', 'Văn bản mới', 'Văn bản mới', 1, 1351406827),
(119, 'vi', 'news', 'Thêm chuyên mục', 'Tin tức pháp luật', 'Tin tức pháp luật', 1, 1351406848),
(120, 'vi', 'modules', 'Thêm module ảo "shop"', '', '', 1, 1351406929),
(121, 'vi', 'modules', 'Thiết lập module mới shop"', '', '', 1, 1351406940),
(122, 'vi', 'modules', 'Sửa module &ldquo;shop&rdquo;', '', '', 1, 1351406956),
(123, 'vi', 'modules', 'Xóa module "shop"', '', '', 1, 1351406981),
(124, 'vi', 'users', 'log_add_user', 'userid 2', 'userid 2', 1, 1351407241),
(125, 'vi', 'shops', 'log_del_catalog', 'id 1', 'id 1', 1, 1351407467),
(126, 'vi', 'shops', 'log_del_catalog', 'id 8', 'id 8', 1, 1351407471),
(127, 'vi', 'shops', 'log_del_catalog', 'id 7', 'id 7', 1, 1351407474),
(128, 'vi', 'shops', 'log_del_catalog', 'id 6', 'id 6', 1, 1351407476),
(129, 'vi', 'shops', 'log_del_catalog', 'id 5', 'id 5', 1, 1351407477),
(130, 'vi', 'shops', 'log_del_catalog', 'id 4', 'id 4', 1, 1351407478),
(131, 'vi', 'shops', 'log_del_catalog', 'id 3', 'id 3', 1, 1351407479),
(132, 'vi', 'shops', 'log_del_catalog', 'id 2', 'id 2', 1, 1351407479),
(133, 'vi', 'modules', 'Xóa module "shops"', '', '', 1, 1351407508),
(134, 'vi', 'modules', 'Thêm module ảo "thu_vien_van_ban"', '', '', 1, 1351407578),
(135, 'vi', 'modules', 'Thiết lập module mới thu-vien-van-ban"', '', '', 1, 1351407590),
(136, 'vi', 'modules', 'Sửa module &ldquo;thu-vien-van-ban&rdquo;', '', '', 1, 1351407614),
(137, 'vi', 'modules', 'Thứ tự module "thu-vien-van-ban"', '11 -> 3', '11 -> 3', 1, 1351407641),
(138, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật kinh doanh', 'Pháp luật kinh doanh', 1, 1351407732),
(139, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật Sở hữu trí tuệ', 'Pháp luật Sở hữu trí tuệ', 1, 1351407751),
(140, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật dân sự', 'Pháp luật dân sự', 1, 1351407774),
(141, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật đất đai', 'Pháp luật đất đai', 1, 1351407797),
(142, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật Hình sự', 'Pháp luật Hình sự', 1, 1351407847),
(143, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật Hành chính', 'Pháp luật Hành chính', 1, 1351407858),
(144, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Pháp luật Lao động', 'Pháp luật Lao động', 1, 1351407870),
(145, 'vi', 'thu-vien-van-ban', 'Thêm chuyên mục', 'Điều ước Quốc tế', 'Điều ước Quốc tế', 1, 1351407879),
(146, 'vi', 'themes', 'Sửa block', 'Name : Lĩnh vực hoạt động', 'Name : Lĩnh vực hoạt động', 1, 1351407947),
(147, 'vi', 'themes', 'Thêm block', 'Name : global block category', 'Name : global block category', 1, 1351407977),
(148, 'vi', 'themes', 'Sửa block', 'Name : Thư viện văn bản', 'Name : Thư viện văn bản', 1, 1351408049),
(149, 'vi', 'themes', 'Sửa block', 'Name : Lĩnh vực hoạt động', 'Name : Lĩnh vực hoạt động', 1, 1351408093),
(150, 'vi', 'news', 'Thêm bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351408478),
(151, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351408529),
(152, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351408662),
(153, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351408768),
(154, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/logo1.jpg', 'uploads/news/2012_10/logo1.jpg', 1, 1351416669),
(155, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/dkkd.jpeg', 'uploads/news/2012_10/dkkd.jpeg', 1, 1351417471),
(156, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351417512),
(157, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351419218),
(158, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351419254),
(159, 'vi', 'themes', 'Kích hoạt theme: "default"', '', '', 1, 1351419579),
(160, 'vi', 'themes', 'Kích hoạt theme: "phapluat2"', '', '', 1, 1351419612),
(161, 'vi', 'login', '[admin] thoát khỏi tài khoản quản trị', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351419775),
(162, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351419913),
(163, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/thanhlapdoanhnghiep.jpeg', 'uploads/news/2012_10/thanhlapdoanhnghiep.jpeg', 1, 1351421000),
(164, 'vi', 'news', 'Thêm bài viết', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 1, 1351421031),
(165, 'vi', 'news', 'Sửa bài viết', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 1, 1351421089),
(166, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/doanh-nghiep.jpeg', 'uploads/news/2012_10/doanh-nghiep.jpeg', 1, 1351421217),
(167, 'vi', 'news', 'Thêm bài viết', 'Công ty luật Brandco&#x3A; Đặc điểm của các loại hình các loại hình doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Đặc điểm của các loại hình các loại hình doanh nghiệp&#33;', 1, 1351421252),
(168, 'vi', 'news', 'Sửa bài viết', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 1, 1351421316),
(169, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351421331),
(170, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/dau-tu.jpg', 'uploads/news/2012_10/dau-tu.jpg', 1, 1351421481),
(171, 'vi', 'news', 'Thêm bài viết', 'Công ty luật Brandco&#x3A; Xin giấy phép đầu tư&#33;', 'Công ty luật Brandco&#x3A; Xin giấy phép đầu tư&#33;', 1, 1351421497),
(172, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351421538),
(173, 'vi', 'news', 'Sửa bài viết', 'Công ty luật Brandco&#x3A; Xin giấy phép đầu tư&#33;', 'Công ty luật Brandco&#x3A; Xin giấy phép đầu tư&#33;', 1, 1351421553),
(174, 'vi', 'news', 'Sửa bài viết', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 1, 1351421611),
(175, 'vi', 'news', 'Sửa bài viết', 'Công ty luật Brandco&#x3A; Đặc điểm của các loại hình các loại hình doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Đặc điểm của các loại hình các loại hình doanh nghiệp&#33;', 1, 1351421640),
(176, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/vanphongdaidien.jpg', 'uploads/news/2012_10/vanphongdaidien.jpg', 1, 1351421726),
(177, 'vi', 'news', 'Thêm bài viết', 'Thành lập văn phòng đại diên của doanh nghiệp nước ngoài&#33;&#33;&#33;', 'Thành lập văn phòng đại diên của doanh nghiệp nước ngoài&#33;&#33;&#33;', 1, 1351421742),
(178, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/dau-tu.jpeg', 'uploads/news/2012_10/dau-tu.jpeg', 1, 1351421845),
(179, 'vi', 'news', 'Thêm bài viết', 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 1, 1351421861),
(180, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351436505),
(181, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/to-chuc-doanh-nghiep.jpg', 'uploads/news/2012_10/to-chuc-doanh-nghiep.jpg', 1, 1351436696),
(182, 'vi', 'news', 'Thêm bài viết', 'Tư vấn thành lập, tổ chức, quản lý doanh nghiệp theo mô hình tập đoàn kinh tế', 'Tư vấn thành lập, tổ chức, quản lý doanh nghiệp theo mô hình tập đoàn kinh tế', 1, 1351436724),
(183, 'vi', 'news', 'Thêm bài viết', 'Tái cơ cấu&#x3A; Sáng tạo để tiếp tục đổi mới', 'Tái cơ cấu&#x3A; Sáng tạo để tiếp tục đổi mới', 1, 1351436786),
(184, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351436835),
(185, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351436853),
(186, 'vi', 'news', 'Sửa bài viết', 'Tái cơ cấu&#x3A; Sáng tạo để tiếp tục đổi mới', 'Tái cơ cấu&#x3A; Sáng tạo để tiếp tục đổi mới', 1, 1351436888),
(187, 'vi', 'news', 'Sửa bài viết', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 1, 1351436953),
(188, 'vi', 'news', 'Sửa bài viết', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 1, 1351437154),
(189, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/hanggia.jpg', 'uploads/news/2012_10/hanggia.jpg', 1, 1351437264),
(190, 'vi', 'news', 'Thêm bài viết', 'Công ty luật Brandco&#x3A; Dịch vụ đăng ký bảo hộ quyền tác giả.', 'Công ty luật Brandco&#x3A; Dịch vụ đăng ký bảo hộ quyền tác giả.', 1, 1351437291),
(191, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/sang-che.jpg', 'uploads/news/2012_10/sang-che.jpg', 1, 1351437397),
(192, 'vi', 'news', 'Thêm bài viết', 'Công ty luật Brandco&#x3A; Đăng ký bảo hộ độc quyền sáng chế&#33;', 'Công ty luật Brandco&#x3A; Đăng ký bảo hộ độc quyền sáng chế&#33;', 1, 1351437427),
(193, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/xemay.jpg', 'uploads/news/2012_10/xemay.jpg', 1, 1351437496),
(194, 'vi', 'news', 'Thêm bài viết', 'Công ty luật Brandco&#x3A; Dịch vụ Bảo hộ Kiểu dáng công nghiệp', 'Công ty luật Brandco&#x3A; Dịch vụ Bảo hộ Kiểu dáng công nghiệp', 1, 1351437554),
(195, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/xulyviphamshtt.jpg', 'uploads/news/2012_10/xulyviphamshtt.jpg', 1, 1351437906),
(196, 'vi', 'news', 'Thêm bài viết', 'Khiếu nại &amp; xử lý vi phạm quyền sở hữu trí tuệ', 'Khiếu nại &amp; xử lý vi phạm quyền sở hữu trí tuệ', 1, 1351437917),
(197, 'vi', 'news', 'Sửa bài viết', 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 1, 1351437970),
(198, 'vi', 'news', 'Sửa bài viết', 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 1, 1351438126),
(199, 'vi', 'news', 'Sửa bài viết', 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 1, 1351438316),
(200, 'vi', 'news', 'Thêm bài viết', 'Tư vấn soạn thảo quy chế, nội quy lao động của doanh nghiệp', 'Tư vấn soạn thảo quy chế, nội quy lao động của doanh nghiệp', 1, 1351438502),
(201, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351484422),
(202, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/tu-van-hop-dong.jpeg', 'uploads/news/2012_10/tu-van-hop-dong.jpeg', 1, 1351484586),
(203, 'vi', 'news', 'Thêm bài viết', 'Công ty Luật Brandco&#x3A; Dịch vụ tư vấn hợp đồng', 'Công ty Luật Brandco&#x3A; Dịch vụ tư vấn hợp đồng', 1, 1351484608),
(204, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/dich-vu-thua-ke.jpg', 'uploads/news/2012_10/dich-vu-thua-ke.jpg', 1, 1351484677),
(205, 'vi', 'news', 'Thêm bài viết', 'Tư vấn về thừa kế tài sản theo quy định của bộ luật dân sự', 'Tư vấn về thừa kế tài sản theo quy định của bộ luật dân sự', 1, 1351484700),
(206, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/thuocla.jpg', 'uploads/news/2012_10/thuocla.jpg', 1, 1351484790),
(207, 'vi', 'news', 'Thêm bài viết', 'Tư vấn xin giấy phép sản xuất thuốc lá', 'Tư vấn xin giấy phép sản xuất thuốc lá', 1, 1351484820),
(208, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/dien1.jpg', 'uploads/news/2012_10/dien1.jpg', 1, 1351484881),
(209, 'vi', 'news', 'Thêm bài viết', 'Tư vấn xin giấy phép hoạt động điện lực', 'Tư vấn xin giấy phép hoạt động điện lực', 1, 1351484905),
(210, 'vi', 'news', 'Sửa bài viết', 'Tư vấn xin giấy phép hoạt động điện lực', 'Tư vấn xin giấy phép hoạt động điện lực', 1, 1351485525),
(211, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/2004.bmp', 'uploads/news/2012_10/2004.bmp', 1, 1351485598),
(212, 'vi', 'news', 'Thêm bài viết', 'Quy định về việc thu, nộp, quản lý và sử dụng phí bán đấu giá cổ phần', 'Quy định về việc thu, nộp, quản lý và sử dụng phí bán đấu giá cổ phần', 1, 1351485646),
(213, 'vi', 'news', 'Thêm bài viết', 'Thủ tục thanh toán chi phí khám bệnh, chữa bệnh đối với người tham gia bảo hiểm y tế bị tai nạn giao thông', 'Thủ tục thanh toán chi phí khám bệnh, chữa bệnh đối với người tham gia bảo hiểm y tế bị tai nạn giao thông', 1, 1351485834),
(214, 'vi', 'news', 'Thêm bài viết', 'Rút ngắn thời gian cấp Giấy miễn thị thực xuống 5 ngày', 'Rút ngắn thời gian cấp Giấy miễn thị thực xuống 5 ngày', 1, 1351485905),
(215, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/1394335.jpg', 'uploads/news/2012_10/1394335.jpg', 1, 1351485962),
(216, 'vi', 'news', 'Thêm bài viết', 'Hướng dẫn quyết toán thuế thu nhập cá nhân năm 2011', 'Hướng dẫn quyết toán thuế thu nhập cá nhân năm 2011', 1, 1351485981),
(217, 'vi', 'news', 'Thêm bài viết', 'Phân biệt về dịch vụ Kê khai thuế qua mạng và Chữ ký số', 'Phân biệt về dịch vụ Kê khai thuế qua mạng và Chữ ký số', 1, 1351486200),
(218, 'vi', 'news', 'Thêm bài viết', 'Khấu trừ, hoàn thuế GTGT đối với trường hợp Gđốc hoặc Tổng gđốc của Cty không được đồng thời làm Gđốc hoặc Tổng gđốc của DN khác', 'Khấu trừ, hoàn thuế GTGT đối với trường hợp Gđốc hoặc Tổng gđốc của Cty không được đồng thời làm Gđốc hoặc Tổng gđốc của DN khác', 1, 1351486248),
(219, 'vi', 'news', 'Thêm bài viết', 'Từ 1&#x002F;1&#x002F;2012&#x3A; Cơ quan Thuế không bán hóa đơn cho doanh nghiệp', 'Từ 1&#x002F;1&#x002F;2012&#x3A; Cơ quan Thuế không bán hóa đơn cho doanh nghiệp', 1, 1351486288),
(220, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/luongtoithieu.jpg', 'uploads/news/2012_10/luongtoithieu.jpg', 1, 1351497532),
(221, 'vi', 'news', 'Thêm bài viết', 'Lương tối thiểu dự kiến tăng 35&#x25;', 'Lương tối thiểu dự kiến tăng 35&#x25;', 1, 1351498289),
(222, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/03_dool_tt_091203_p4_1.jpg', 'uploads/news/2012_10/03_dool_tt_091203_p4_1.jpg', 1, 1351498350),
(223, 'vi', 'news', 'Thêm bài viết', 'Miễn, giảm thuế sử dụng đất phi nông nghiệp', 'Miễn, giảm thuế sử dụng đất phi nông nghiệp', 1, 1351498364),
(224, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/bat_dong_.jpg', 'uploads/news/2012_10/bat_dong_.jpg', 1, 1351498418),
(225, 'vi', 'news', 'Thêm bài viết', 'Thuế TNDN từ chuyển nhượng bất động sản được xác định theo giá hợp đồng', 'Thuế TNDN từ chuyển nhượng bất động sản được xác định theo giá hợp đồng', 1, 1351498432),
(226, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/htx.jpg', 'uploads/news/2012_10/htx.jpg', 1, 1351499026),
(227, 'vi', 'news', 'Thêm bài viết', 'Không biến hợp tác xã thành mô hình tự cung tự cấp', 'Không biến hợp tác xã thành mô hình tự cung tự cấp', 1, 1351499047),
(228, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/imagesca8lezqn.jpg', 'uploads/news/2012_10/imagesca8lezqn.jpg', 1, 1351499107),
(229, 'vi', 'news', 'Thêm bài viết', 'Cơ chế giải quyết tranh chấp không rõ sẽ rất phức tạp', 'Cơ chế giải quyết tranh chấp không rõ sẽ rất phức tạp', 1, 1351499127),
(230, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/images663125_ngan_hang_480.jpg', 'uploads/news/2012_10/images663125_ngan_hang_480.jpg', 1, 1351499199),
(231, 'vi', 'news', 'Thêm bài viết', 'Lấp “lỗ hổng” lớn trong xử lý tội phạm thuế, tài chính', 'Lấp “lỗ hổng” lớn trong xử lý tội phạm thuế, tài chính', 1, 1351499221),
(232, 'vi', 'news', 'Thêm bài viết', 'Doanh nghiệp nước ngoài tiếp tục than phiền về Nghị định 46', 'Doanh nghiệp nước ngoài tiếp tục than phiền về Nghị định 46', 1, 1351499374),
(233, 'vi', 'news', 'Thêm bài viết', 'Nghị định 70&#x002F;2011&#x002F;NĐ-CP quy định mức lương tối thiểu vùng đối với người lao động', 'Nghị định 70&#x002F;2011&#x002F;NĐ-CP quy định mức lương tối thiểu vùng đối với người lao động', 1, 1351499425),
(234, 'vi', 'news', 'Thêm bài viết', 'Cơ quan Thuế không bán hóa đơn cho doanh nghiệp', 'Cơ quan Thuế không bán hóa đơn cho doanh nghiệp', 1, 1351499616),
(235, 'vi', 'news', 'Thêm bài viết', 'Dự thảo Luật Hợp tác xã &#40;sửa đổi&#41; - Băn khoăn về mức góp vốn và giới hạn quyền cung ứng sản phẩm, dịch vụ', 'Dự thảo Luật Hợp tác xã &#40;sửa đổi&#41; - Băn khoăn về mức góp vốn và giới hạn quyền cung ứng sản phẩm, dịch vụ', 1, 1351499674),
(236, 'vi', 'news', 'Thêm bài viết', 'Trao đổi về phạm vi hòa giải ở cơ sở', 'Trao đổi về phạm vi hòa giải ở cơ sở', 1, 1351499772),
(237, 'vi', 'upload', 'Upload file', 'uploads/news/2012_10/hang-20f1d.jpg', 'uploads/news/2012_10/hang-20f1d.jpg', 1, 1351499836),
(238, 'vi', 'news', 'Thêm bài viết', 'Dựng lại tường lửa ngăn sở hữu chéo ngân hàng', 'Dựng lại tường lửa ngăn sở hữu chéo ngân hàng', 1, 1351499846),
(239, 'vi', 'news', 'log_del_topic', 'topicid 1', 'topicid 1', 1, 1351500465),
(240, 'vi', 'news', 'Thêm bài viết', 'Luật sư và người chăn lừa', 'Luật sư và người chăn lừa', 1, 1351501275),
(241, 'vi', 'news', 'Thêm bài viết', 'Lý luận của luật sư', 'Lý luận của luật sư', 1, 1351501314),
(242, 'vi', 'news', 'Thêm bài viết', 'Từ thị trường USD tự do nghĩ về chính sách tỷ giá', 'Từ thị trường USD tự do nghĩ về chính sách tỷ giá', 1, 1351501355),
(243, 'vi', 'upload', 'Upload file', 'uploads/thu-vien-van-ban/2012_10/hoi-thao-thue.jpg', 'uploads/thu-vien-van-ban/2012_10/hoi-thao-thue.jpg', 1, 1351501561),
(244, 'vi', 'thu-vien-van-ban', 'Thêm bài viết', 'Một số khoản chi được trừ khi xác định thu nhập chịu thuế Thu nhập doanh nghiệp theo nghị định 122&#x002F;2011&#x002F;NĐ-CP', 'Một số khoản chi được trừ khi xác định thu nhập chịu thuế Thu nhập doanh nghiệp theo nghị định 122&#x002F;2011&#x002F;NĐ-CP', 1, 1351501593),
(245, 'vi', 'modules', 'Cài đặt gói Module + Block', 'nv3_module_home.zip', 'nv3_module_home.zip', 1, 1351505326),
(246, 'vi', 'modules', 'Thiết lập module mới home"', '', '', 1, 1351505334),
(247, 'vi', 'modules', 'Sửa module &ldquo;home&rdquo;', '', '', 1, 1351505339),
(248, 'vi', 'modules', 'Thứ tự module "home"', '12 -> 1', '12 -> 1', 1, 1351505347),
(249, 'vi', 'modules', 'Sửa module &ldquo;home&rdquo;', '', '', 1, 1351505368),
(250, 'vi', 'modules', 'Kích hoạt module "home"', 'Không', 'Không', 1, 1351505514),
(251, 'vi', 'modules', 'Sửa module &ldquo;rss&rdquo;', '', '', 1, 1351506647),
(252, 'vi', 'modules', 'Sửa module &ldquo;news&rdquo;', '', '', 1, 1351506780),
(253, 'vi', 'modules', 'Thứ tự module "news"', '12 -> 1', '12 -> 1', 1, 1351506795),
(254, 'vi', 'modules', 'Cài đặt gói Module + Block', 'nv3_module_archives.zip', 'nv3_module_archives.zip', 1, 1351506908),
(255, 'vi', 'modules', 'Thiết lập module mới archives"', '', '', 1, 1351506920),
(256, 'vi', 'modules', 'Sửa module &ldquo;archives&rdquo;', '', '', 1, 1351506944),
(257, 'vi', 'themes', 'Sửa block', 'Name : Xem nhiều nhất', 'Name : Xem nhiều nhất', 1, 1351507055),
(258, 'vi', 'modules', 'Thứ tự module "archives"', '13 -> 3', '13 -> 3', 1, 1351507916),
(259, 'vi', 'modules', 'Xóa module "home"', '', '', 1, 1351507998),
(260, 'vi', 'modules', 'Thứ tự module "about"', '12 -> 2', '12 -> 2', 1, 1351508007),
(261, 'vi', 'about', 'De-lete about', 'ID:  2', 'ID:  2', 1, 1351508023),
(262, 'vi', 'about', 'Edit about', 'ID:  1', 'ID:  1', 1, 1351508155),
(263, 'vi', 'about', 'Edit about', 'ID:  1', 'ID:  1', 1, 1351508229),
(264, 'vi', 'archives', 'Thêm loại văn bản', 'Pháp luật kinh doanh', 'Pháp luật kinh doanh', 1, 1351509858),
(265, 'vi', 'archives', 'Thêm văn bản', 'Thông tư số 05/2012/TT-BTC', 'Thông tư số 05/2012/TT-BTC', 1, 1351513411),
(266, 'vi', 'archives', 'Thêm loại văn bản', 'Pháp luật Sở hữu trí tuệ', 'Pháp luật Sở hữu trí tuệ', 1, 1351513844),
(267, 'vi', 'archives', 'Thêm loại văn bản', 'Pháp luật Hình sự', 'Pháp luật Hình sự', 1, 1351513861),
(268, 'vi', 'archives', 'Thêm loại văn bản', 'Pháp luật dân sự', 'Pháp luật dân sự', 1, 1351513894),
(269, 'vi', 'archives', 'Thêm loại văn bản', 'Pháp luật Lao động', 'Pháp luật Lao động', 1, 1351513913),
(270, 'vi', 'archives', 'Thêm loại văn bản', 'Văn bản pháp luật khác', 'Văn bản pháp luật khác', 1, 1351513967),
(271, 'vi', 'upload', 'Upload file', 'uploads/archives/2012_10/luat-canh-tranh-2004.doc', 'uploads/archives/2012_10/luat-canh-tranh-2004.doc', 1, 1351514680),
(272, 'vi', 'archives', 'Thêm văn bản', 'LUAT CANH TRANH 2004', 'LUAT CANH TRANH 2004', 1, 1351515090),
(273, 'vi', 'archives', '', '1', '1', 1, 1351515235),
(274, 'vi', 'upload', 'Upload file', 'uploads/archives/2012_10/kinh-doanh-bat-dong-san.doc', 'uploads/archives/2012_10/kinh-doanh-bat-dong-san.doc', 1, 1351515429),
(275, 'vi', 'archives', 'Thêm văn bản', 'KINH DOANH BẤT ĐỘNG SẢN', 'KINH DOANH BẤT ĐỘNG SẢN', 1, 1351515527),
(276, 'vi', 'upload', 'Upload file', 'uploads/archives/2012_10/luat-dau-tu.doc', 'uploads/archives/2012_10/luat-dau-tu.doc', 1, 1351515818),
(277, 'vi', 'archives', 'Thêm văn bản', 'LUẬT ĐẦU TƯ', 'LUẬT ĐẦU TƯ', 1, 1351515875),
(278, 'vi', 'upload', 'Upload file', 'uploads/archives/2012_10/luat-so-huu-tri-tue-2005.doc', 'uploads/archives/2012_10/luat-so-huu-tri-tue-2005.doc', 1, 1351516231),
(279, 'vi', 'archives', 'Thêm văn bản', 'Sở hữu trí tuệ', 'Sở hữu trí tuệ', 1, 1351516282),
(280, 'vi', 'modules', 'Xóa module "thu-vien-van-ban"', '', '', 1, 1351516318),
(281, 'vi', 'themes', 'Sửa block', 'Name : Lĩnh vực hoạt động', 'Name : Lĩnh vực hoạt động', 1, 1351516363),
(282, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351517409),
(283, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1351842326),
(284, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1352453861),
(285, 'vi', 'themes', 'Thêm block', 'Name : global about', 'Name : global about', 1, 1352453972),
(286, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1352622821),
(287, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', ' Client IP:127.0.0.1', 0, 1352719487);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_sessions`
--

CREATE TABLE IF NOT EXISTS `nv3_sessions` (
  `session_id` varchar(50) DEFAULT NULL,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(100) NOT NULL,
  `onl_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `session_id` (`session_id`),
  KEY `onl_time` (`onl_time`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_sessions`
--

INSERT INTO `nv3_sessions` (`session_id`, `uid`, `full_name`, `onl_time`) VALUES
('e02cb93e078359ec6ffb1ec5394386182130706433', 0, 'guest', 1352876041);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_setup`
--

CREATE TABLE IF NOT EXISTS `nv3_setup` (
  `lang` char(2) NOT NULL,
  `module` varchar(50) NOT NULL,
  `tables` varchar(255) NOT NULL,
  `version` varchar(100) NOT NULL,
  `setup_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `lang` (`lang`,`module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_setup_language`
--

CREATE TABLE IF NOT EXISTS `nv3_setup_language` (
  `lang` char(2) NOT NULL,
  `setup` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_setup_language`
--

INSERT INTO `nv3_setup_language` (`lang`, `setup`) VALUES
('vi', 1);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_setup_modules`
--

CREATE TABLE IF NOT EXISTS `nv3_setup_modules` (
  `title` varchar(55) NOT NULL,
  `is_sysmod` tinyint(1) NOT NULL DEFAULT '0',
  `virtual` tinyint(1) NOT NULL DEFAULT '0',
  `module_file` varchar(50) NOT NULL DEFAULT '',
  `module_data` varchar(55) NOT NULL DEFAULT '',
  `mod_version` varchar(50) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `author` text NOT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_setup_modules`
--

INSERT INTO `nv3_setup_modules` (`title`, `is_sysmod`, `virtual`, `module_file`, `module_data`, `mod_version`, `addtime`, `author`, `note`) VALUES
('about', 0, 1, 'about', 'about', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''),
('banners', 1, 0, 'banners', 'banners', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''),
('contact', 0, 1, 'contact', 'contact', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''),
('news', 0, 1, 'news', 'news', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''),
('voting', 0, 0, 'voting', 'voting', '3.1.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''),
('forum', 0, 0, 'forum', 'forum', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''),
('search', 1, 0, 'search', 'search', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''),
('users', 1, 0, 'users', 'users', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''),
('download', 0, 1, 'download', 'download', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''),
('weblinks', 0, 1, 'weblinks', 'weblinks', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''),
('statistics', 0, 0, 'statistics', 'statistics', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''),
('faq', 0, 1, 'faq', 'faq', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''),
('menu', 0, 1, 'menu', 'menu', '3.1.00 1273225635', 1351249594, 'VINADES (contact@vinades.vn)', ''),
('rss', 1, 0, 'rss', 'rss', '3.0.01 1287532800', 1351249594, 'VINADES (contact@vinades.vn)', ''),
('shops', 0, 1, 'shops', 'shops', '3.3.00 1273830435', 1351331249, 'VINADES (contact@vinades.vn)', ''),
('home', 0, 1, 'home', 'home', '3.0.01 1287532800', 1351505331, 'PCD-GROUP (dinhpc.it@gmail.com)', ''),
('archives', 0, 1, 'archives', 'archives', '3.2.0.0 1273225635', 1351506914, 'PCD-GROUP (contact@dinhpc.com)', '');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_users`
--

CREATE TABLE IF NOT EXISTS `nv3_users` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `full_name` varchar(255) NOT NULL DEFAULT '',
  `gender` char(1) NOT NULL,
  `photo` varchar(255) NOT NULL DEFAULT '',
  `birthday` int(11) NOT NULL,
  `sig` text,
  `regdate` int(11) NOT NULL DEFAULT '0',
  `website` varchar(255) NOT NULL DEFAULT '',
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL DEFAULT '',
  `telephone` varchar(100) NOT NULL DEFAULT '',
  `fax` varchar(100) NOT NULL DEFAULT '',
  `mobile` varchar(100) NOT NULL DEFAULT '',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `passlostkey` varchar(40) NOT NULL DEFAULT '',
  `view_mail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remember` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `in_groups` varchar(255) NOT NULL DEFAULT '',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checknum` varchar(40) NOT NULL DEFAULT '',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) NOT NULL DEFAULT '',
  `last_agent` varchar(255) NOT NULL DEFAULT '',
  `last_openid` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `nv3_users`
--

INSERT INTO `nv3_users` (`userid`, `username`, `md5username`, `password`, `email`, `full_name`, `gender`, `photo`, `birthday`, `sig`, `regdate`, `website`, `location`, `yim`, `telephone`, `fax`, `mobile`, `question`, `answer`, `passlostkey`, `view_mail`, `remember`, `in_groups`, `active`, `checknum`, `last_login`, `last_ip`, `last_agent`, `last_openid`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '4a467cdf5df6317340f339d54321b0b3d926cd73', 'tvthanh88hp@gmail.com', 'admin', '', '', 0, NULL, 1351249634, '', '', '', '', '', '', 'abc', 'abc', '', 0, 1, '', 1, '', 1351249634, '', '', ''),
(2, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', '4a467cdf5df6317340f339d54321b0b3d926cd73', 'trinhthanh9688@gmail.com', '', '', '', 0, '', 1351407241, '', '', '', '', '', '', 'abc', 'abc', '', 0, 1, '', 1, '', 0, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_users_config`
--

CREATE TABLE IF NOT EXISTS `nv3_users_config` (
  `config` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`config`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_users_config`
--

INSERT INTO `nv3_users_config` (`config`, `content`, `edit_time`) VALUES
('registertype', '1', 1351249594),
('deny_email', 'yoursite.com|mysite.com|localhost|xxx', 1351249594),
('deny_name', 'anonimo|anonymous|god|linux|nobody|operator|root', 1351249594),
('siteterms_vi', '<p> Để trở thành thành viên, bạn phải cam kết đồng ý với các điều khoản dưới đây. Chúng tôi có thể thay đổi lại những điều khoản này vào bất cứ lúc nào và chúng tôi sẽ cố gắng thông báo đến bạn kịp thời.<br  /> <br  /> Bạn cam kết không gửi bất cứ bài viết có nội dung lừa đảo, thô tục, thiếu văn hoá; vu khống, khiêu khích, đe doạ người khác; liên quan đến các vấn đề tình dục hay bất cứ nội dung nào vi phạm luật pháp của quốc gia mà bạn đang sống, luật pháp của quốc gia nơi đặt máy chủ của website này hay luật pháp quốc tế. Nếu vẫn cố tình vi phạm, ngay lập tức bạn sẽ bị cấm tham gia vào website. Địa chỉ IP của tất cả các bài viết đều được ghi nhận lại để bảo vệ các điều khoản cam kết này trong trường hợp bạn không tuân thủ.<br  /> <br  /> Bạn đồng ý rằng website có quyền gỡ bỏ, sửa, di chuyển hoặc khoá bất kỳ bài viết nào trong website vào bất cứ lúc nào tuỳ theo nhu cầu công việc.<br  /> <br  /> Đăng ký làm thành viên của chúng tôi, bạn cũng phải đồng ý rằng, bất kỳ thông tin cá nhân nào mà bạn cung cấp đều được lưu trữ trong cơ sở dữ liệu của hệ thống. Mặc dù những thông tin này sẽ không được cung cấp cho bất kỳ người thứ ba nào khác mà không được sự đồng ý của bạn, chúng tôi không chịu trách nhiệm về việc những thông tin cá nhân này của bạn bị lộ ra bên ngoài từ những kẻ phá hoại có ý đồ xấu tấn công vào cơ sở dữ liệu của hệ thống.</p>', 1274757129);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_users_openid`
--

CREATE TABLE IF NOT EXISTS `nv3_users_openid` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `opid` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`opid`),
  KEY `userid` (`userid`),
  KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_users_question`
--

CREATE TABLE IF NOT EXISTS `nv3_users_question` (
  `qid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `lang` char(2) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`),
  UNIQUE KEY `title` (`title`,`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `nv3_users_question`
--

INSERT INTO `nv3_users_question` (`qid`, `title`, `lang`, `weight`, `add_time`, `edit_time`) VALUES
(1, 'Bạn thích môn thể thao nào nhất', 'vi', 1, 1274840238, 1274840238),
(2, 'Món ăn mà bạn yêu thích', 'vi', 2, 1274840250, 1274840250),
(3, 'Thần tượng điện ảnh của bạn', 'vi', 3, 1274840257, 1274840257),
(4, 'Bạn thích nhạc sỹ nào nhất', 'vi', 4, 1274840264, 1274840264),
(5, 'Quê ngoại của bạn ở đâu', 'vi', 5, 1274840270, 1274840270),
(6, 'Tên cuốn sách &quot;gối đầu giường&quot;', 'vi', 6, 1274840278, 1274840278),
(7, 'Ngày lễ mà bạn luôn mong đợi', 'vi', 7, 1274840285, 1274840285);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_users_reg`
--

CREATE TABLE IF NOT EXISTS `nv3_users_reg` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `full_name` varchar(255) NOT NULL DEFAULT '',
  `regdate` int(11) unsigned NOT NULL DEFAULT '0',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `checknum` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `login` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_about`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_about` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `bodytext` mediumtext NOT NULL,
  `keywords` mediumtext NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `nv3_vi_about`
--

INSERT INTO `nv3_vi_about` (`id`, `title`, `alias`, `bodytext`, `keywords`, `weight`, `admin_id`, `add_time`, `edit_time`, `status`) VALUES
(1, 'Vinagon.com', 'Vinagon-com', '<h2 class="title_about" style="color: rgb(9, 67, 174);font-size:14px; margin-top:5px"> Giới thiệu Công ty TNHH Công Nghệ Số VINAGON</h2><p align="center"> <b><font color="rgb(51, 102, 204);" size="4">Giới thiệu Công ty TNHH Công Nghệ Số VINAGON</font></b></p><div> <a><font color="rgb(51, 102, 204);">VinaGon</font></a><font color="rgb(51, 102, 204);"> là công ty chuyên nghiệp trong cung cấp các giải pháp về phát triển Website ứng dụng trên nền Web, bao gồm: thiết kế, lập trình và các dịch vụ tư vấn khác về ứng dụng Web. </font><a><font color="rgb(51, 102, 204);">VinaGon</font></a><font color="rgb(51, 102, 204);"> còn là nhà cung cấp các giải pháp phát triển ứng dụng phần mềm và thương mại điện tử. VinaGon luôn có tầm nhìn và bắt kịp với sự phát triển về công nghệ cũng như giải pháp cho nhu cầu thực tế.</font></div><div> <a><font color="rgb(51, 102, 204);">VinaGon</font></a><font color="rgb(51, 102, 204);"> xác định mình phải góp phần vào sự phát triển ngành CNTT vốn còn non trẻ của đất nước, với tiêu chí hướng đến mọi người sử dụng chúng tôi đã đầu tư công sức và nhân lực tập trung phát triển những ứng dụng trên nền Website để có được những sản phẩm tốt nhất mang tính ứng dụng cao nhất, đáp ứng được mọi sự kỳ vọng của người sử dụng.<br  /> <br  /> Bên cạnh những dịch vụ Website với chi phí thấp chúng tôi còn cung cấp những hệ thống quản lý chuyên nghiệp mang tính công nghệ và ứng dụng cao, giúp các doanh nghiệp tích kiệm được kinh phí và nhân lực.</font> <p> &nbsp;</p></div><table align="center" border="0"> <tbody> <tr> <td style="text-align: center;"> <a><font color="rgb(51, 102, 204);"><img border="0" src="http://dinhpc.com/uploads/dich-vu-san-pham/2011_07/rg.jpg" style="width: 177px; height: 136px;" /></font></a></td> <td align="center"> <a><font color="rgb(51, 102, 204);"><img border="0" src="http://dinhpc.com/uploads/dich-vu-san-pham/2011_07/nahnhang.jpg" style="width: 175px; height: 133px;" /></font></a></td> <td align="center"> <a><font color="rgb(51, 102, 204);"><img border="0" src="http://dinhpc.com/uploads/dich-vu-san-pham/2011_07/manage.jpg" style="width: 173px; height: 136px;" /></font></a></td> </tr> <tr> <td align="center"> <b><a><font color="rgb(51, 102, 204);">Hệ thống quản lý xuất bản tạp chí</font></a></b></td> <td align="center"> <b><a><font color="rgb(51, 102, 204);">Hệ thống quản lý nhà hàng</font></a></b></td> <td align="center"> <b><a><font color="rgb(51, 102, 204);">Hệ thống quản lý câu lạc bộ Billiard</font></a></b></td> </tr> </tbody></table><ul> <li style="TEXT-ALIGN:justify"> <span style="FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px"><font color="rgb(51, 102, 204);">TNHH VINAGON đã có kinh nghiệm triển khai rất nhiều dự án </font><strong><a href="http://web.vinagon.com/" target="_blank"><font color="rgb(51, 102, 204);">thiết kế website</font></a></strong><font color="rgb(51, 102, 204);">, <strong>Giải pháp seo </strong>thành công. Và </font><a href="http://vinagon.com/about/about/" target="_blank"><font color="rgb(51, 102, 204);">công ty TNHH VINAGON</font></a><font color="rgb(51, 102, 204);"> cũng sẽ đảm bảo mang đến thành công cho công ty bạn.</font></span></li></ul><ul> <li style="TEXT-ALIGN:justify"> <span style="FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px"><font color="rgb(51, 102, 204);">Với một quy trình làm việc hiệu quả, khả năng nắm bắt những yêu cầu tinh tế nhất của khách hàng và việc xây dựng mối quan hệ cộng tác một cách chặt chẽ, uyển chuyển đã tạo nên ưu thế trong việc cung cấp dịch vụ của </font><a href="http://vinagon.com/about/about/" target="_blank"><font color="rgb(51, 102, 204);">công ty TNHH VINAGON</font></a><font color="rgb(51, 102, 204);">.</font></span></li></ul><p style="TEXT-ALIGN:justify;MARGIN-LEFT:80px"> <font color="rgb(51, 102, 204);"><span style="FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px"><strong>1. Chúng tôi đặt tiêu chí phục vụ khách hàng lên hàng đầu</strong>:</span></font></p><p style="TEXT-ALIGN:justify;MARGIN-LEFT:80px"> <font color="rgb(51, 102, 204);"><span style="FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px">Toàn bộ đội ngũ nhân viên của chúng tôi thấu hiểu một điều rằng thành công của chúng tôi nằm trong những giá trị mà chúng tôi đem lại cho khách hàng. Chính vì lẽ đó chúng tôi luôn cam kết mang lại cho khách hàng những giá trị nhiều hơn sự mong đợi.</span></font></p><p style="TEXT-ALIGN:justify;MARGIN-LEFT:80px"> <font color="rgb(51, 102, 204);"><span style="FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px"><strong>2..</strong> <strong>Sản phẩm của bạn sẽ được hoàn thành bởi những chuyên gia</strong></span></font></p><p style="TEXT-ALIGN:justify;MARGIN-LEFT:80px"> <span style="FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px"><font color="rgb(51, 102, 204);">Đội ngũ lập trình của </font><a href="http://vinagon.com/about/about/" target="_blank"><font color="rgb(51, 102, 204);">công ty TNHH VINAGON</font></a><font color="rgb(51, 102, 204);"> đã có kinh nghiệm tham gia nhiều dự án và qua mỗi dự án chúng tôi học hỏi, trau dồi và tìm kiếm tri thức mới để vững vàng hơn, trưởng thành hơn, trở thành những chuyên gia. </font></span></p><p style="TEXT-ALIGN:justify;MARGIN-LEFT:80px"> <font color="rgb(51, 102, 204);"><span style="FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px"><strong>3. Chúng tôi làm việc với niềm say mê và cảm hứng sáng tạo</strong></span></font></p><p style="TEXT-ALIGN:justify;MARGIN-LEFT:80px"> <span style="FONT-FAMILY:&#039;times new roman&#039;,times,serif"><span style="FONT-SIZE:14px"><font color="rgb(51, 102, 204);">Chúng tôi nhận ra rằng những doanh nghiệp thành công là nhờ những con người ưu tú. Mỗi thành viên của </font><a href="http://vinagon.com/about/about/" target="_blank"><font color="rgb(51, 102, 204);">công ty TNHH VINAGON</font></a><font color="rgb(51, 102, 204);"> đều là những chuyên gia trong lĩnh vực của mình. Thân thiện, giầu cảm hứng sáng tạo, có động lực làm việc mạnh mẽ đó chính là điểm khác biệt của họ.</font></span></span></p><p style="TEXT-ALIGN:justify;MARGIN-LEFT:80px"> <span style="FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px"><strong><font color="rgb(51, 102, 204);">4. </font><a href="http://vinagon.com/about/about/" target="_blank"><font color="rgb(51, 102, 204);">Công ty TNHH VINAGON</font></a></strong><font color="rgb(51, 102, 204);"> <strong>là lựa chọn tốt nhất của nhiều các doanh nghiệp vừa và nhỏ</strong></font></span></p><p style="TEXT-ALIGN:justify;MARGIN-LEFT:80px"> <span style="FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px"><a href="http://vinagon.com/about/about/" target="_blank"><font color="rgb(51, 102, 204);">Công ty TNHH VINAGON</font></a><font color="rgb(51, 102, 204);"> giúp các doanh nghiệp vừa và nhỏ tiết kiệm thời gian và chi phí của mình bằng cách đưa ra các gói dịch vụ phù hợp, tư vấn tận tình, cặn kẽ những gì doanh nghiệp cần và sử dụng một quy trình nghiệp vụ đã được tối ưu hóa.</font></span></p><p style="TEXT-ALIGN:justify;MARGIN-LEFT:80px"> <span style="FONT-FAMILY:&#039;times new roman&#039;,times,serif"><span style="FONT-SIZE:14px"><strong><font color="rgb(51, 102, 204);">5. </font><a href="http://vinagon.com/about/about/" target="_blank"><font color="rgb(51, 102, 204);">Công ty TNHH VINAGON</font></a><font color="rgb(51, 102, 204);"> luôn coi trọng mới quan hệ lâu dài </font></strong></span></span></p><p style="TEXT-ALIGN:justify;MARGIN-LEFT:80px"> <span style="FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px"><a href="http://vinagon.com/about/about/" target="_blank"><font color="rgb(51, 102, 204);">Công ty TNHH VINAGON</font></a><font color="rgb(51, 102, 204);"> bắt đầu bằng việc khởi tạo mối quan hệ hợp tác tin tưởng, và hoàn thành công việc bằng việc duy trì quan hệ dài lâu. Chính sách hỗ trợ, hậu mãi tạo cho khách hàng niềm tin hoàn toàn khi trao công việc cho </font><a href="http://vinagon.com/about/about/" target="_blank"><font color="rgb(51, 102, 204);">Công ty TNHH VINAGON</font></a><font color="rgb(51, 102, 204);">. </font></span></p><p> <strong><span style="FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px"><font color="rgb(51, 102, 204);">Các gói </font><a href="http://web.vinagon.com/" target="_blank"><font color="rgb(51, 102, 204);">thiết kế website</font></a><font color="rgb(51, 102, 204);"> của </font><a href="http://vinagon.com/about/about/" target="_blank"><font color="rgb(51, 102, 204);">Công ty TNHH VINAGON</font></a><font color="rgb(51, 102, 204);"> phục vụ quý khách hàng :</font></span></strong></p><div align="center"> <table style="BORDER-BOTTOM:rgb(51, 102, 204); 2px solid;BORDER-LEFT:rgb(51, 102, 204); 2px solid;BORDER-TOP:rgb(51, 102, 204); 2px solid;BORDER-RIGHT:rgb(51, 102, 204); 2px solid" width="50%"> <tbody> <tr> <td align="center"> <font color="rgb(51, 102, 204);"><img border="0" src="http://web.vinagon.com/uploads/shops/thumb/wweb-tt-034-b.jpg" /></font></td> <td align="center"> <font color="rgb(51, 102, 204);"><img border="0" src="http://web.vinagon.com/uploads/shops/thumb/aweb-gt-018-a.jpg" /></font></td> <td align="center"> <font color="rgb(51, 102, 204);"><img border="0" src="http://web.vinagon.com/uploads/shops/thumb/computers-magento-template.jpg" /></font></td> </tr> <tr> <td align="center"> <b><a href="http://web.vinagon.com/shops/Web-tin-tuc/" target="_blank"><font color="rgb(51, 102, 204);">Website Tin Tức</font></a></b></td> <td align="center"> <b><a href="http://web.vinagon.com/shops/Web-Company/" target="_blank"><font color="rgb(51, 102, 204);">Website Doanh Nghiệp</font></a></b></td> <td align="center"> <b><a href="http://web.vinagon.com/shops/Web-ban-hang/" target="_blank"><font color="rgb(51, 102, 204);">Website Thương Mại</font></a></b></td> </tr> </tbody> </table></div><p> <font color="rgb(51, 102, 204);">Ngoài những sản phẩm trên, </font><a><font color="rgb(51, 102, 204);">Công ty TNHH VINAGON</font></a><font color="rgb(51, 102, 204);"> hiện đang cung cấp một kênh quảng cáo hoàn toàn miễn phí giúp công ty và doanh nghiệp khẳng định thương hiệu trên thị trường.<br  /> Quý khách hàng có thể truy cập địa chỉ sau để đăng tải sản phẩm của mình tới người tiêu dùng:</font></p><p align="center"> <b><font color="rgb(51, 102, 204);" size="4"><a href="http://ads.dinhpc.com/" target="_blank">http://ads.dinhpc.com</a></font></b></p><p align="center"> <font color="rgb(51, 102, 204);"><img src="http://vinagon.com/uploads/about/adsdinhpc1.jpg" style="border-width: 0pt; border-style: solid; width: 621px; height: 299px;" /></font></p><p align="center"> <b><a><font color="rgb(51, 102, 204);">ADS Dinh PC</font></a></b></p><p align="center"> <font color="rgb(51, 102, 204);"><img src="http://vinagon.com/uploads/about/adsdinhpc2.jpg" style="border-width: 0pt; border-style: solid; width: 621px; height: 299px;" /></font></p><p align="center"> <b><a><font color="rgb(51, 102, 204);">Quản lý tin đã đăng</font></a></b></p><p align="center"> <font color="rgb(51, 102, 204);"><img src="http://vinagon.com/uploads/about/adsdinhpc3.jpg" style="border-width: 0pt; border-style: solid; width: 621px; height: 299px;" /></font></p><p align="center"> <b><a><font color="rgb(51, 102, 204);">Đăng tin rao vặt mới</font></a></b></p><p style="TEXT-ALIGN:justify"> <span style="FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px"><font color="rgb(51, 102, 204);">Hãy lựa chọn </font><a href="http://vinagon.com/about/about/" target="_blank"><font color="rgb(51, 102, 204);">Công ty TNHH VINAGON</font></a><font color="rgb(51, 102, 204);"> để quý khách hàng có được lựa chọn tốt nhất cho cơ hội kinh doanh online của mình nhé!</font></span></p><p style="TEXT-ALIGN:justify"> <span style="FONT-FAMILY:&#039;times new roman&#039;,times,serif;FONT-SIZE:14px"><font color="rgb(51, 102, 204);">Cảm ơn quý khách hàng đã chú ý tới </font><strong><a href="http://web.vinagon.com/" target="_blank"><font color="rgb(51, 102, 204);">dịch vụ thiết kế website</font></a><font color="rgb(51, 102, 204);"> </font></strong><font color="rgb(51, 102, 204);">của chúng tôi. </font><a href="http://vinagon.com/about/about/" target="_blank"><font color="rgb(51, 102, 204);">Công ty TNHH VINAGON</font></a><font color="rgb(51, 102, 204);"> luôn luôn mong muốn được phục vụ theo yêu cầu và cung cấp giá trị hiệu quả nhất tới quý khách hàng.</font></span></p><table border="0" width="100%"> <tbody> <tr> <td> &nbsp;</td> <td> <font face="Times New Roman"><font color="rgb(51, 102, 204);">Văn phòng Hà Nội: <b>Số 34/28, 180 Nam Dư, Lĩnh Nam, Hoàng Mai, Hà Nội</b><br  /> Email: </font><a href="http://hoichogiaodich.com/link.aspx?url=mailto:info@vinagon.com" target="_blank"><b><font color="rgb(51, 102, 204);">info@vinagon.com</font></b></a><font color="rgb(51, 102, 204);"> | Website: </font><a href="http://hoichogiaodich.com/link.aspx?url=http://www.vinagon.com/" target="_blank"><b><font color="rgb(51, 102, 204);">www.vinagon.com</font></b></a><font color="rgb(51, 102, 204);"> - </font><b><a href="http://hoichogiaodich.com/link.aspx?url=http://web.vinagon.com/" target="_blank"><font color="rgb(51, 102, 204);">web.vinagon.com</font></a></b><font color="rgb(51, 102, 204);">| Điện thoại: <b>(+844) 6. 32.979.36 </b>| Hotline: <b>0903 218 933 - 0942 8888 04</b></font></font></td> </tr> </tbody></table><br  />', 'thế hệ,hoàn toàn,phát triển,tài chính,nhân lực,thời gian,kết quả,sử dụng,cho phép,uyển chuyển,công nghệ,tận dụng,thành tựu,đảm bảo,nền tảng,có nghĩa,phụ thuộc,quá trình,có thể,tự lập,đồng nghĩa', 1, 1, 1275320174, 1351508229, 1);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_archives_cat`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_archives_cat` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '',
  `thumbnail` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `order` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `keywords` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `del_cache_time` int(11) NOT NULL DEFAULT '0',
  `who_view` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL DEFAULT '',
  `numrow` int(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `nv3_vi_archives_cat`
--

INSERT INTO `nv3_vi_archives_cat` (`catid`, `parentid`, `title`, `alias`, `description`, `image`, `thumbnail`, `weight`, `order`, `lev`, `viewcat`, `numsubcat`, `subcatid`, `inhome`, `numlinks`, `keywords`, `admins`, `add_time`, `edit_time`, `del_cache_time`, `who_view`, `groups_view`, `numrow`) VALUES
(1, 0, 'Pháp luật kinh doanh', 'Phap-luat-kinh-doanh', '', '', '', 1, 1, 0, 'viewcat_list', 0, '', 1, 3, '', '', 1351509859, 1351509859, 1377509859, 0, '', 3),
(2, 0, 'Pháp luật Sở hữu trí tuệ', 'Phap-luat-So-huu-tri-tue', '', '', '', 2, 2, 0, 'viewcat_list', 0, '', 1, 3, '', '', 1351513847, 1351513847, 1377513847, 0, '', 1),
(3, 0, 'Pháp luật Hình sự', 'Phap-luat-Hinh-su', '', '', '', 3, 3, 0, 'viewcat_list', 0, '', 1, 3, '', '', 1351513863, 1351513863, 1377513863, 0, '', 0),
(4, 0, 'Pháp luật dân sự', 'Phap-luat-dan-su', '', '', '', 4, 4, 0, 'viewcat_list', 0, '', 1, 3, '', '', 1351513897, 1351513897, 1377513897, 0, '', 0),
(5, 0, 'Pháp luật Lao động', 'Phap-luat-Lao-dong', '', '', '', 5, 5, 0, 'viewcat_list', 0, '', 1, 3, '', '', 1351513915, 1351513915, 1377513915, 0, '', 0),
(6, 0, 'Văn bản pháp luật khác', 'Van-ban-phap-luat-khac', '', '', '', 6, 6, 0, 'viewcat_list', 0, '', 1, 3, '', '', 1351513968, 1351513968, 1377513968, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_archives_field`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_archives_field` (
  `fieldid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `order` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `numsubfield` int(11) NOT NULL DEFAULT '0',
  `subfieldid` varchar(255) NOT NULL DEFAULT '',
  `keywords` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fieldid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_archives_organ`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_archives_organ` (
  `organid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `order` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `numsuborgan` int(11) NOT NULL DEFAULT '0',
  `suborganid` varchar(255) NOT NULL DEFAULT '',
  `keywords` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`organid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_archives_room`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_archives_room` (
  `roomid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `order` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `numsubroom` int(11) NOT NULL DEFAULT '0',
  `subroomid` varchar(255) NOT NULL DEFAULT '',
  `keywords` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`roomid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_archives_rows`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_archives_rows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL DEFAULT '0',
  `title` text NOT NULL,
  `alias` varchar(255) NOT NULL,
  `hometext` text NOT NULL,
  `bodytext` mediumtext NOT NULL,
  `keywords` text NOT NULL,
  `filepath` text NOT NULL,
  `otherpath` text NOT NULL,
  `roomid` int(11) NOT NULL DEFAULT '0',
  `fieldid` int(11) NOT NULL DEFAULT '0',
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `down` int(8) NOT NULL DEFAULT '0',
  `view` int(8) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `status` int(2) NOT NULL DEFAULT '0',
  `type` int(2) NOT NULL DEFAULT '0',
  `sign` text NOT NULL,
  `signtime` int(11) NOT NULL DEFAULT '0',
  `organid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `nv3_vi_archives_rows`
--

INSERT INTO `nv3_vi_archives_rows` (`id`, `catid`, `title`, `alias`, `hometext`, `bodytext`, `keywords`, `filepath`, `otherpath`, `roomid`, `fieldid`, `addtime`, `edittime`, `down`, `view`, `userid`, `status`, `type`, `sign`, `signtime`, `organid`) VALUES
(4, 1, 'LUẬT ĐẦU TƯ', 'LUAT-DAU-TU', 'Căn cứ vào Hiến pháp nước Cộng hòa xã hội chủ nghĩa Việt Nam năm 1992 đã được sửa đổi, bổ sung theo Nghị quyết số 51&#x002F;2001&#x002F;QH10 ngày 25 tháng 12 năm 2001 của Quốc hội khóa X, kỳ họp thứ 10;', 'Điều 1. Phạm vi điều chỉnh<br  />Luật này quy định về hoạt động đầu tư nhằm mục đích kinh doanh; quyền và nghĩa vụ của nhà đầu tư; bảo đảm quyền, lợi ích hợp pháp của nhà đầu tư; khuyến khích và ưu đãi đầu tư; quản lý nhà nước về đầu tư tại Việt Nam và đầu tư từ Việt Nam ra nước ngoài.<br  />&nbsp;<br  />Điều 2. Đối tượng áp dụng<br  />1. Nhà đầu tư trong nước và nhà đầu tư nước ngoài thực hiện hoạt động đầu tư trên lãnh thổ Việt Nam và đầu tư từ Việt Nam ra nước ngoài.<br  />2. Tổ chức, cá nhân liên quan đến hoạt động đầu tư.<br  />&nbsp;<br  />Điều 3. Giải thích từ ngữ<br  />Trong Luật này, các từ ngữ dưới đây được hiểu như sau:<br  />1. Đầu tư là việc nhà đầu tư bỏ vốn bằng các loại tài sản hữu hình hoặc vô hình để hình thành tài sản tiến hành các hoạt động đầu tư theo quy định của Luật này và các quy định khác của pháp luật có liên quan.<br  />2. Đầu tư trực tiếp là hình thức đầu tư do nhà đầu tư bỏ vốn đầu tư và tham gia quản lý hoạt động đầu tư.<br  />3. Đầu tư gián tiếp là hình thức đầu tư thông qua việc mua cổ phần, cổ phiếu, trái phiếu, các giấy tờ có giá khác, quỹ đầu tư chứng khoán và thông qua các định chế tài chính trung gian khác mà nhà đầu tư không trực tiếp tham gia quản lý hoạt động đầu tư.<br  />4. Nhà đầu tư là tổ chức, cá nhân thực hiện hoạt động đầu tư theo quy định của pháp luật Việt Nam, bao gồm:<br  />a) Doanh nghiệp thuộc các thành phần kinh tế thành lập theo Luật doanh nghiệp;<br  />b) Hợp tác xã, liên hiệp hợp tác xã thành lập theo Luật hợp tác xã;<br  />c) Doanh nghiệp có vốn đầu tư nước ngoài được thành lập trước khi Luật này có hiệu lực;<br  />d) Hộ kinh doanh, cá nhân;<br  />đ) Tổ chức, cá nhân nước ngoài; người Việt Nam định cư ở nước ngoài; người nước ngoài thường trú ở Việt Nam;<br  />e) Các tổ chức khác theo quy định của pháp luật Việt Nam.<br  />5. Nhà đầu tư nước ngoài là tổ chức, cá nhân nước ngoài bỏ vốn để thực hiện hoạt động đầu tư tại Việt Nam.<br  />6. Doanh nghiệp có vốn đầu tư nước ngoài bao gồm doanh nghiệp do nhà đầu tư nước ngoài thành lập để thực hiện hoạt động đầu tư tại Việt Nam; doanh nghiệp Việt Nam do nhà đầu tư nước ngoài mua cổ phần, sáp nhập, mua lại.&nbsp;<br  />7. Hoạt động đầu tư là hoạt động của nhà đầu tư trong quá trình đầu tư bao gồm các khâu chuẩn bị đầu tư, thực hiện và quản lý dự án đầu tư.<br  />8. Dự án đầu tư là tập hợp các đề xuất bỏ vốn trung và dài hạn để tiến hành các hoạt động đầu tư trên địa bàn cụ thể, trong khoảng thời gian xác định.<br  />9. Vốn đầu tư là tiền và các tài sản hợp pháp khác để thực hiện các hoạt động đầu tư theo hình thức đầu tư trực tiếp hoặc đầu tư gián tiếp.<br  />10. Vốn nhà nước là vốn đầu tư phát triển từ ngân sách nhà nước, vốn tín dụng do Nhà nước bảo lãnh, vốn tín dụng đầu tư phát triển của Nhà nước và vốn đầu tư khác của Nhà nước.<br  />11. Chủ đầu tư là tổ chức, cá nhân sở hữu vốn hoặc người thay mặt chủ sở hữu hoặc người vay vốn và trực tiếp quản lý, sử dụng vốn để thực hiện hoạt động đầu tư.<br  />12. Đầu tư nước ngoài là việc nhà đầu tư nước ngoài đưa vào Việt Nam vốn bằng tiền và các tài sản hợp pháp khác để tiến hành hoạt động đầu tư.<br  />13. Đầu tư trong nước là việc nhà đầu tư trong nước bỏ vốn bằng tiền và các tài sản hợp pháp khác để tiến hành hoạt động đầu tư tại Việt Nam.<br  />14. Đầu tư ra nước ngoài là việc nhà đầu tư đưa vốn bằng tiền và các tài sản hợp pháp khác từ Việt Nam ra nước ngoài để tiến hành hoạt động đầu tư.<br  />15. Lĩnh vực đầu tư có điều kiện là lĩnh vực chỉ được thực hiện đầu tư với các điều kiện cụ thể do pháp luật quy định.<br  />16. Hợp đồng hợp tác kinh doanh (sau đây gọi tắt là hợp đồng BCC) là hình thức đầu tư được ký giữa các nhà đầu tư nhằm hợp tác kinh doanh phân chia lợi nhuận, phân chia sản phẩm mà không thành lập pháp nhân.<br  />17. Hợp đồng xây dựng - kinh doanh - chuyển giao (sau đây gọi tắt là hợp đồng BOT) là hình thức đầu tư được ký giữa cơ quan nhà nước có thẩm quyền và nhà đầu tư để xây dựng, kinh doanh công trình kết cấu hạ tầng trong một thời hạn nhất định; hết thời hạn, nhà đầu tư chuyển giao không bồi hoàn công trình đó cho Nhà nước Việt Nam.<br  />18. Hợp đồng xây dựng - chuyển giao - kinh doanh (sau đây gọi tắt là hợp đồng BTO) là hình thức đầu tư được ký giữa cơ quan nhà nước có thẩm quyền và nhà đầu tư để xây dựng công trình kết cấu hạ tầng; sau khi xây dựng xong, nhà đầu tư chuyển giao công trình đó cho Nhà nước Việt Nam; Chính phủ dành cho nhà đầu tư quyền kinh doanh công trình đó trong một thời hạn nhất định để thu hồi vốn đầu tư và lợi nhuận.<br  />19. Hợp đồng xây dựng - chuyển giao (sau đây gọi tắt là hợp đồng BT) là hình thức đầu tư được ký giữa cơ quan nhà nước có thẩm quyền và nhà đầu tư để xây dựng công trình kết cấu hạ tầng; sau khi xây dựng xong, nhà đầu tư chuyển giao công trình đó cho Nhà nước Việt Nam; Chính phủ tạo điều kiện cho nhà đầu tư thực hiện dự án khác để thu hồi vốn đầu tư và lợi nhuận hoặc thanh toán cho nhà đầu tư theo thoả thuận trong hợp đồng BT.<br  />20. Khu công nghiệp là khu chuyên sản xuất hàng công nghiệp và thực hiện các dịch vụ cho sản xuất công nghiệp, có ranh giới địa lý xác định, được thành lập theo quy định của Chính phủ.<br  />21. Khu chế xuất là khu công nghiệp chuyên sản xuất hàng xuất khẩu, thực hiện dịch vụ cho sản xuất hàng xuất khẩu và hoạt động xuất khẩu, có ranh giới địa lý xác định, được thành lập theo quy định của Chính phủ.<br  />22. Khu công nghệ cao là khu chuyên nghiên cứu phát triển, ứng dụng công nghệ cao, ươm tạo doanh nghiệp công nghệ cao, đào tạo nhân lực công nghệ cao, sản xuất và kinh doanh sản phẩm công nghệ cao, có ranh giới địa lý xác định, được thành lập theo quy định của Chính phủ.<br  />23. Khu kinh tế là khu vực có không gian kinh tế riêng biệt với môi trường đầu tư và kinh doanh đặc biệt thuận lợi cho các nhà đầu tư, có ranh giới địa lý xác định, được thành lập theo quy định của Chính phủ.<br  />&nbsp;<br  />Điều 4. Chính sách về đầu tư<br  />1. Nhà đầu tư được đầu tư trong các lĩnh vực và ngành, nghề mà pháp luật không cấm; được tự chủ và quyết định hoạt động đầu tư theo quy định của pháp luật Việt Nam.<br  />2. Nhà nước đối xử bình đẳng trước pháp luật đối với các nhà đầu tư thuộc mọi thành phần kinh tế, giữa đầu tư trong nước và đầu tư nước ngoài; khuyến khích và tạo điều kiện thuận lợi cho hoạt động đầu tư.<br  />3. Nhà nước công nhận và bảo hộ quyền sở hữu tài sản, vốn đầu tư, thu nhập và các quyền, lợi ích hợp pháp khác của nhà đầu tư; thừa nhận sự tồn tại và phát triển lâu dài của các hoạt động đầu tư.<br  />4. Nhà nước cam kết thực hiện các điều ước quốc tế liên quan đến đầu tư mà Cộng hòa xã hội chủ nghĩa Việt Nam là thành viên.<br  />5. Nhà nước khuyến khích và có chính sách ưu đãi đối với đầu tư vào các lĩnh vực, địa bàn ưu đãi đầu tư.<br  />&nbsp;<br  />Điều 5. Áp dụng pháp luật đầu tư, điều ước quốc tế, pháp luật nước ngoài và tập quán đầu tư quốc tế<br  />1. Hoạt động đầu tư của nhà đầu tư trên lãnh thổ Việt Nam phải tuân theo quy định của Luật này và các quy định khác của pháp luật có liên quan.<br  />2. Hoạt động đầu tư đặc thù được quy định trong luật khác thì áp dụng quy định của luật đó.<br  />3. Trường hợp điều ước quốc tế mà Cộng hòa xã hội chủ nghĩa Việt Nam là thành viên có quy định&nbsp; khác với quy định của Luật này thì áp dụng theo quy định của điều ước quốc tế đó.<br  />4. Đối với hoạt động đầu tư nước ngoài, trong trường hợp pháp luật Việt Nam chưa có quy định, các bên có thể thỏa thuận trong hợp đồng việc áp dụng pháp luật nước ngoài và tập quán đầu tư quốc tế nếu việc áp dụng pháp luật nước ngoài và tập quán đầu tư quốc tế đó không trái với nguyên tắc cơ bản của pháp luật Việt Nam.<br  /><br  />Còn tiếp...', '', '2012_10/luat-dau-tu.doc', '', 0, 0, 1351515875, 1351515875, 0, 0, 1, 1, 0, 'Nguyễn Văn An', 1133269440, 0),
(5, 2, 'Sở hữu trí tuệ', 'So-huu-tri-tue', 'Căn cứ vào Hiến pháp nước Cộng hoà xã hội chủ nghĩa Việt Nam năm 1992 đã được sửa đổi, bổ sung theo Nghị quyết số 51&#x002F;2001&#x002F;QH10 ngày 25 tháng 12 năm 2001 của Quốc hội khoá X, kỳ họp thứ 10;', '<strong>NHỮNG QUY ĐỊNH CHUNG</strong><br  /><strong>Điều 1.<em> Phạm vi điều chỉnh</em></strong><br  />Luật này quy định về quyền tác giả, quyền liên quan đến quyền tác giả, quyền sở hữu công nghiệp, quyền đối với giống cây trồng và việc bảo hộ các quyền đó.<br  /><strong>Điều 2. <em>Đối tượng áp dụng</em></strong><br  />Luật này áp dụng đối với tổ chức, cá nhân Việt Nam; tổ chức, cá nhân nước ngoài đáp ứng các điều kiện quy định tại Luật này và điều ước quốc tế mà Cộng hoà xã hội chủ nghĩa Việt Nam là thành viên.<br  /><strong>Điều 3. <em>Đối tượng quyền sở hữu trí tuệ</em></strong><br  />1. Đối tượng quyền tác giả bao gồm tác phẩm văn học, nghệ thuật, khoa học; đối tượng quyền liên quan đến quyền tác giả bao gồm cuộc biểu diễn, bản ghi âm, ghi hình, chương trình phát sóng, tín hiệu vệ tinh mang chương trình được mã hoá.<br  />2. Đối tượng quyền sở hữu công nghiệp bao gồm sáng chế, kiểu dáng công nghiệp, thiết kế bố trí mạch tích hợp bán dẫn, bí mật kinh doanh, nhãn hiệu, tên thương mại và chỉ dẫn địa lý.<br  />3. Đối tượng quyền đối với giống cây trồng là giống cây trồng và vật liệu nhân giống.<br  /><strong>Điều 4. <em>Giải thích từ ngữ</em></strong><br  />Trong Luật này, các từ ngữ dưới đây được hiểu như sau:<br  />1. <em>Quyền sở hữu trí tuệ</em> là quyền của tổ chức, cá nhân đối với tài sản trí tuệ, bao gồm quyền tác giả và quyền liên quan đến quyền tác giả, quyền sở hữu công nghiệp và quyền đối với giống cây trồng.<br  />2. <em>Quyền tác giả</em> là quyền của tổ chức, cá nhân đối với tác phẩm do mình sáng tạo ra hoặc sở hữu.<br  />3. <em>Quyền liên quan đến quyền tác giả</em> (sau đây gọi là quyền liên quan) là quyền của tổ chức, cá nhân đối với cuộc biểu diễn, bản ghi âm, ghi hình, chương trình phát sóng, tín hiệu vệ tinh mang chương trình được mã hóa.<br  />4. <em>Quyền sở hữu công nghiệp</em> là quyền của tổ chức, cá nhân đối với sáng chế, kiểu dáng công nghiệp, thiết kế bố trí mạch tích hợp bán dẫn, nhãn hiệu, tên thương mại, chỉ dẫn địa lý, bí mật kinh doanh do mình sáng tạo ra hoặc sở hữu và quyền chống cạnh tranh không lành mạnh.<br  />5. <em>Quyền đối với giống cây trồng</em> là quyền của tổ chức, cá nhân đối với giống cây trồng mới do mình chọn tạo hoặc phát hiện và phát triển hoặc được hưởng quyền sở hữu.<br  />6. <em>Chủ thể quyền sở hữu trí tuệ</em> là chủ sở hữu quyền sở hữu trí tuệ hoặc tổ chức, cá nhân được chủ sở hữu chuyển giao quyền sở hữu trí tuệ.<br  />7. <em>Tác phẩm</em> là sản phẩm sáng tạo trong lĩnh vực văn học, nghệ thuật và khoa học thể hiện bằng bất kỳ phư­ơng tiện hay hình thức nào.<br  />8. <em>Tác phẩm phái sinh</em> là tác phẩm dịch từ ngôn ngữ này sang ngôn ngữ khác, tác phẩm phóng tác, cải biên, chuyển thể, biên soạn, chú giải, tuyển chọn.<br  />9. <em>Tác phẩm, bản ghi âm, ghi hình đã công bố</em> là tác phẩm, bản ghi âm, ghi hình đã được phát hành với sự đồng ý của chủ sở hữu quyền tác giả, chủ sở hữu quyền liên quan để phổ biến đến công chúng với một số lượng bản sao hợp lý.&nbsp;<br  />10. <em>Sao chép</em> là việc tạo ra một hoặc nhiều bản sao của tác phẩm hoặc bản ghi âm, ghi hình bằng bất kỳ phương tiện hay hình thức nào, bao gồm cả việc lưu trữ thường xuyên hoặc tạm thời tác phẩm dưới hình thức điện tử.<br  />11. <em>Phát sóng</em> là việc truyền âm thanh hoặc hình ảnh hoặc cả âm thanh và hình ảnh của tác phẩm, cuộc biểu diễn, bản ghi âm, ghi hình, chương trình phát sóng đến công chúng bằng phương tiện vô tuyến hoặc hữu tuyến, bao gồm cả việc truyền qua vệ tinh để công chúng có thể tiếp nhận được tại địa điểm và thời gian do chính họ lựa chọn.&nbsp;<br  />12. <em>Sáng chế</em> là giải pháp kỹ thuật dưới dạng sản phẩm hoặc quy trình nhằm giải quyết một vấn đề xác định bằng việc ứng dụng các quy luật tự nhiên.<br  />13. <em>Kiểu dáng công nghiệp</em> là hình dáng bên ngoài của sản phẩm được thể hiện bằng hình khối, đường nét, màu sắc hoặc sự kết hợp những yếu tố này.<br  />14. <em>Mạch tích hợp bán dẫn</em> là sản phẩm dưới dạng thành phẩm hoặc bán thành phẩm, trong đó các phần tử với ít nhất một phần tử tích cực và một số hoặc tất cả các mối liên kết được gắn liền bên trong hoặc bên trên tấm vật liệu bán dẫn nhằm thực hiện chức năng điện tử. Mạch tích hợp đồng nghĩa với IC, chip và mạch vi điện tử.<br  />15. <em>Thiết kế bố trí mạch tích hợp bán dẫn</em> (sau đây gọi là thiết kế bố trí) là cấu trúc không gian của các phần tử mạch và mối liên kết các phần tử đó trong mạch tích hợp bán dẫn.<br  />16. <em>Nhãn hiệu</em> là dấu hiệu dùng để phân biệt hàng hoá, dịch vụ của các tổ chức, cá nhân khác nhau.<br  />17. <em>Nhãn hiệu tập thể</em> là nhãn hiệu dùng để phân biệt hàng hoá, dịch vụ của các thành viên của tổ chức là chủ sở hữu nhãn hiệu đó với hàng hoá, dịch vụ của tổ chức, cá nhân không phải là thành viên của tổ chức đó.<br  />18. <em>Nhãn hiệu chứng nhận</em> là nhãn hiệu mà chủ sở hữu nhãn hiệu cho phép tổ chức, cá nhân khác sử dụng trên hàng hóa, dịch vụ của tổ chức, cá nhân đó để chứng nhận các đặc tính về xuất xứ, nguyên liệu, vật liệu, cách thức sản xuất hàng hoá, cách thức cung cấp dịch vụ, chất lượng, độ chính xác, độ an toàn hoặc các đặc tính khác của hàng hoá, dịch vụ mang nhãn hiệu.<br  />19. <em>Nhãn hiệu liên kết</em> là các nhãn hiệu do cùng một chủ thể đăng ký, trùng hoặc tương tự nhau dùng cho sản phẩm, dịch vụ cùng loại hoặc tương tự nhau hoặc có liên quan với nhau.<br  />20. <em>Nhãn hiệu nổi tiếng</em> là nhãn hiệu được người tiêu dùng biết đến rộng rãi trên toàn lãnh thổ Việt Nam.<br  />21. <em>Tên thương mại</em> là tên gọi của tổ chức, cá nhân dùng trong hoạt động kinh doanh để phân biệt chủ thể kinh doanh mang tên gọi đó với chủ thể kinh doanh khác trong cùng lĩnh vực và khu vực kinh doanh.<br  />Khu vực kinh doanh quy định tại khoản này là khu vực địa lý nơi chủ thể kinh doanh có bạn hàng, khách hàng hoặc có danh tiếng.<br  />22. <em>Chỉ dẫn địa lý</em> là dấu hiệu dùng để chỉ sản phẩm có nguồn gốc từ khu vực, địa phương, vùng lãnh thổ hay quốc gia cụ thể.<br  />23. <em>Bí mật kinh doanh</em> là thông tin thu được từ hoạt động đầu tư tài chính, trí tuệ, chưa được bộc lộ và có khả năng sử dụng trong kinh doanh.<br  />24. <em>Giống cây trồng</em> là quần thể cây trồng thuộc cùng một cấp phân loại thực vật thấp nhất, đồng nhất về hình thái, ổn định qua các chu kỳ nhân giống, có thể nhận biết được bằng sự biểu hiện các tính trạng do kiểu gen hoặc sự phối hợp của các kiểu gen quy định và phân biệt được với bất kỳ quần thể cây trồng nào khác bằng sự biểu hiện của ít nhất một tính trạng có khả năng di truyền được.<br  />25. <em>Văn bằng bảo hộ</em> là văn bản do cơ quan nhà nước có thẩm quyền cấp cho tổ chức, cá nhân nhằm xác lập quyền sở hữu công nghiệp đối với sáng chế, kiểu dáng công nghiệp, thiết kế bố trí, nhãn hiệu, chỉ dẫn địa lý; quyền đối với giống cây trồng.<br  /><br  />Còn tiếp....', '', '2012_10/luat-so-huu-tri-tue-2005.doc', '', 0, 0, 1351516282, 1351516282, 0, 0, 1, 1, 0, 'Nguyễn Văn An', 1009285860, 0),
(3, 1, 'KINH DOANH BẤT ĐỘNG SẢN', 'KINH-DOANH-BAT-DONG-SAN', 'Căn cứ vào Hiến pháp nước Cộng hoà xã hội chủ nghĩa Việt Nam năm 1992 đã được sửa đổi, bổ sung theo Nghị quyết số 51&#x002F;2001&#x002F;QH10 ngày 25 tháng 12 năm 2001 của Quốc hội khoá X, kỳ họp thứ 10;', 'Điều 1. Phạm vi điều chỉnh<br  />Luật này quy định về hoạt động kinh doanh bất động sản; quyền, nghĩa vụ của tổ chức, cá nhân hoạt động kinh doanh bất động sản và giao dịch bất động sản có liên quan đến kinh doanh bất động sản.<br  />&nbsp;<br  />Điều 2. Đối tượng áp dụng<br  />1. Tổ chức, cá nhân hoạt động kinh doanh bất động sản tại Việt Nam.<br  />2. Tổ chức, cá nhân có liên quan đến hoạt động kinh doanh bất động sản tại Việt Nam.<br  />&nbsp;<br  />Điều 3. Áp dụng pháp luật<br  />1. Hoạt động kinh doanh bất động sản và quản lý hoạt động kinh doanh bất động sản phải tuân theo quy định của Luật này và các quy định khác của pháp luật có liên quan.<br  />2. Trường hợp đặc thù về hoạt động kinh doanh bất động sản quy định tại luật khác thì áp dụng quy định của luật đó.<br  />3. Trường hợp điều ước quốc tế mà Cộng hoà xã hội chủ nghĩa Việt Nam là thành viên có quy định khác với quy định của Luật này thì áp dụng quy định của điều ước quốc tế đó.<br  />&nbsp;<br  />Điều 4. Giải thích từ ngữ<br  />Trong Luật này, các từ ngữ dưới đây được hiểu như sau:<br  />1. Hoạt động kinh doanh bất động sản bao gồm kinh doanh bất động sản và kinh doanh dịch vụ bất động sản.<br  />2. Kinh doanh bất động sản là việc bỏ vốn đầu tư tạo lập, mua, nhận chuyển nhượng, thuê, thuê mua bất động sản để bán, chuyển nhượng, cho thuê, cho thuê lại, cho thuê mua nhằm mục đích sinh lợi.<br  />3. Kinh doanh dịch vụ bất động sản là các hoạt động hỗ trợ kinh doanh bất động sản và thị trường bất động sản, bao gồm các dịch vụ môi giới bất động sản, định giá bất động sản, sàn giao dịch bất động sản, tư vấn bất động sản, đấu giá bất động sản, quảng cáo bất động sản, quản lý bất động sản.<br  />4. Giao dịch bất động sản có liên quan đến kinh doanh bất động sản là việc mua bán, chuyển nhượng, thuê, thuê mua bất động sản giữa tổ chức, cá nhân không kinh doanh bất động sản với tổ chức, cá nhân kinh doanh bất động sản.<br  />5. Sàn giao dịch bất động sản là nơi diễn ra các giao dịch bất động sản và cung cấp các dịch vụ cho kinh doanh bất động sản.<br  />6. Đấu giá bất động sản là việc bán, chuyển nhượng bất động sản công khai để chọn người mua, nhận chuyển nhượng bất động sản trả giá cao nhất theo thủ tục đấu giá tài sản.<br  />7. Mua bán, chuyển nhượng bất động sản trả chậm, trả dần là việc mua bán, chuyển nhượng bất động sản mà bên mua, bên nhận chuyển nhượng được trả chậm hoặc trả dần tiền mua, tiền chuyển nhượng bất động sản trong thời hạn thỏa thuận trong hợp đồng.<br  />8. Mua bán nhà, công trình xây dựng hình thành trong tương lai là việc mua bán nhà, công trình xây dựng mà tại thời điểm ký hợp đồng, nhà, công trình xây dựng đó chưa hình thành hoặc đang hình thành theo hồ sơ dự án, thiết kế bản vẽ thi công và tiến độ cụ thể.<br  />9. Định giá bất động sản là hoạt động tư vấn, xác định giá của một bất động sản cụ thể tại một thời điểm xác định.<br  />10. Chứng thư định giá bất động sản là văn bản thể hiện kết quả định giá bất động sản do tổ chức, cá nhân kinh doanh dịch vụ định giá bất động sản lập khi có yêu cầu của khách hàng.<br  />11. Dịch vụ quản lý bất động sản là hoạt động của tổ chức, cá nhân kinh doanh dịch vụ bất động sản được chủ sở hữu hoặc chủ sử dụng bất động sản uỷ quyền thực hiện việc bảo quản, giữ gìn, trông coi, vận hành và khai thác bất động sản theo hợp đồng quản lý bất động sản.<br  />12. Thuê mua nhà, công trình xây dựng là hình thức kinh doanh bất động sản, theo đó bên thuê mua trở thành chủ sở hữu nhà, công trình xây dựng đang thuê mua sau khi trả hết tiền thuê mua theo hợp đồng thuê mua.<br  /><br  />Còn tiếp ....<br  />&nbsp;', '', '2012_10/kinh-doanh-bat-dong-san.doc', '', 0, 0, 1351515527, 1351515527, 0, 1, 1, 1, 0, 'Nguyễn Phú Trọng', 1151585880, 0),
(2, 1, 'Luật cạnh tranh 2004', 'Luat-canh-tranh-2004', 'Căn cứ vào Hiến pháp nước Cộng hoà xã hội chủ nghĩa Việt Nam năm 1992 đã được sửa đổi, bổ sung theo Nghị quyết số 51&#x002F;2001&#x002F;QH10 ngày 25 tháng 12 năm 2001 của Quốc hội khoá X, kỳ họp thứ 10.', 'NHỮNG QUY ĐỊNH CHUNG<br  /><br  />Điều 1. Phạm vi điều chỉnh<br  />Luật này quy định về hành vi hạn chế cạnh tranh, hành vi cạnh tranh không lành mạnh, trình tự, thủ tục giải quyết vụ việc cạnh tranh, biện pháp xử lý vi phạm pháp luật về cạnh tranh.<br  /><br  />Điều 2. Đối tượng áp dụng<br  />Luật này áp dụng đối với:<br  />1. Tổ chức, cá nhân kinh doanh (sau đây gọi chung là doanh nghiệp) bao gồm cả doanh nghiệp sản xuất, cung ứng sản phẩm, dịch vụ công ích, doanh nghiệp hoạt động trong các ngành, lĩnh vực thuộc độc quyền nhà nước và doanh nghiệp nước ngoài hoạt động ở Việt Nam;<br  />2. Hiệp hội ngành nghề hoạt động ở Việt Nam.<br  /><br  />Điều 3. Giải thích từ ngữ<br  />Trong Luật này, các từ ngữ dưới đây được hiểu như sau:<br  />1. Thị trường liên quan bao gồm thị trường sản phẩm liên quan và thị trường địa lý liên quan.<br  />Thị trường sản phẩm liên quan là thị trường của những hàng hoá, dịch vụ có thể thay thế cho nhau về đặc tính, mục đích sử dụng và giá cả.<br  />Thị trường địa lý liên quan là một khu vực địa lý cụ thể trong đó có những hàng hoá, dịch vụ có thể thay thế cho nhau với các điều kiện cạnh tranh tương tự và có sự khác biệt đáng kể với các khu vực lân cận.<br  />2. Hiệp hội ngành nghề bao gồm hiệp hội ngành hàng và hiệp hội nghề nghiệp.<br  />3. Hành vi hạn chế cạnh tranh là hành vi của doanh nghiệp làm giảm, sai lệch, cản trở cạnh tranh trên thị trường, bao gồm hành vi thoả thuận hạn chế cạnh tranh, lạm dụng vị trí thống lĩnh thị trường, lạm dụng vị trí độc quyền và tập trung kinh tế.<br  />4. Hành vi cạnh tranh không lành mạnh là hành vi cạnh tranh của doanh nghiệp trong quá trình kinh doanh trái với các chuẩn mực thông thường về đạo đức kinh doanh, gây thiệt hại hoặc có thể gây thiệt hại đến lợi ích của Nhà nước, quyền và lợi ích hợp pháp của doanh nghiệp khác hoặc người tiêu dùng.<br  />5. Thị phần của doanh nghiệp đối với một loại hàng hoá, dịch vụ nhất định là tỷ lệ phần trăm giữa doanh thu bán ra của doanh nghiệp này với tổng doanh thu của tất cả các doanh nghiệp kinh doanh loại hàng hoá, dịch vụ đó trên thị trường liên quan hoặc tỷ lệ phần trăm giữa doanh số mua vào của doanh nghiệp này với tổng doanh số mua vào của tất cả các doanh nghiệp kinh doanh loại hàng hoá, dịch vụ đó trên thị trường liên quan theo tháng, quý, năm.<br  />6. Thị phần kết hợp là tổng thị phần trên thị trường liên quan của các doanh nghiệp tham gia vào thoả thuận hạn chế cạnh tranh hoặc tập trung kinh tế.<br  />7. Giá thành toàn bộ của sản phẩm hàng hoá, dịch vụ bao gồm:<br  />a) Giá thành sản xuất sản phẩm, dịch vụ; giá mua hàng hoá;<br  />b) Chi phí lưu thông đưa hàng hoá, dịch vụ đến người tiêu dùng.<br  />8. Vụ việc cạnh tranh là vụ việc có dấu hiệu vi phạm quy định của Luật này bị cơ quan nhà nước có thẩm quyền điều tra, xử lý theo quy định của pháp luật.<br  />9. Tố tụng cạnh tranh là hoạt động của cơ quan, tổ chức, cá nhân theo trình tự, thủ tục giải quyết, xử lý vụ việc cạnh tranh theo quy định của Luật này.<br  />10. Bí mật kinh doanh là thông tin có đủ các điều kiện sau đây:<br  />a) Không phải là hiểu biết thông thường;<br  />b) Có khả năng áp dụng trong kinh doanh và khi được sử dụng sẽ tạo cho người nắm giữ thông tin đó có lợi thế hơn so với người không nắm giữ hoặc không sử dụng thông tin đó;<br  />c) Được chủ sở hữu bảo mật bằng các biện pháp cần thiết để thông tin đó không bị tiết lộ và không dễ dàng tiếp cận được.<br  />11. Bán hàng đa cấp là phương thức tiếp thị để bán lẻ hàng hóa đáp ứng các điều kiện sau đây:<br  />a) Việc tiếp thị để bán lẻ hàng hóa được thực hiện thông qua mạng lưới người tham gia bán hàng đa cấp gồm nhiều cấp, nhiều nhánh khác nhau;<br  />b) Hàng hóa được người tham gia bán hàng đa cấp tiếp thị trực tiếp cho người tiêu dùng tại nơi ở, nơi làm việc của người tiêu dùng hoặc địa điểm khác không phải là địa điểm bán lẻ thường xuyên của doanh nghiệp hoặc của người tham gia;<br  />c) Người tham gia bán hàng đa cấp được hưởng tiền hoa hồng, tiền thưởng hoặc lợi ích kinh tế khác từ kết quả tiếp thị bán hàng của mình và của người tham gia bán hàng đa cấp cấp dưới trong mạng lưới do mình tổ chức và mạng lưới đó được doanh nghiệp bán hàng đa cấp chấp thuận.<br  /><br  />Điều 4. Quyền cạnh tranh trong kinh doanh<br  />1. Doanh nghiệp được tự do cạnh tranh trong khuôn khổ pháp luật. Nhà nước bảo hộ quyền cạnh tranh hợp pháp trong kinh doanh.<br  />2. Việc cạnh tranh phải được thực hiện theo nguyên tắc trung thực, không xâm phạm đến lợi ích của Nhà nước, lợi ích công cộng, quyền và lợi ích hợp pháp của doanh nghiệp, của người tiêu dùng và phải tuân theo các quy định của Luật này.<br  /><br  />Điều 5. Áp dụng Luật này, các luật khác có liên quan và điều ước quốc tế<br  />1. Trường hợp có sự khác nhau giữa quy định của Luật này với quy định của luật khác về hành vi hạn chế cạnh tranh, cạnh tranh không lành mạnh thì áp dụng quy định của Luật này.<br  />2. Trường hợp điều ước quốc tế mà Cộng hoà xã hội chủ nghĩa Việt Nam ký kết hoặc gia nhập có quy định khác với quy định của Luật này thì áp dụng quy định của điều ước quốc tế đó.<br  /><br  />Điều 6. Các hành vi bị cấm đối với cơ quan quản lý nhà nước<br  />Cơ quan quản lý nhà nước không được thực hiện những hành vi sau đây để cản trở cạnh tranh trên thị trường:<br  />1. Buộc doanh nghiệp, cơ quan, tổ chức, cá nhân phải mua, bán hàng hoá, cung ứng dịch vụ với doanh nghiệp được cơ quan này chỉ định, trừ hàng hoá, dịch vụ thuộc lĩnh vực độc quyền nhà nước hoặc trong trường hợp khẩn cấp theo quy định của pháp luật;<br  />2. Phân biệt đối xử giữa các doanh nghiệp;<br  />3. Ép buộc các hiệp hội ngành nghề hoặc các doanh nghiệp liên kết với nhau nhằm loại trừ, hạn chế, cản trở các doanh nghiệp khác cạnh tranh trên thị trường;<br  />4. Các hành vi khác cản trở hoạt động kinh doanh hợp pháp của doanh nghiệp.<br  /><br  />Điều 7. Trách nhiệm quản lý nhà nước về cạnh tranh<br  />1. Chính phủ thống nhất quản lý nhà nước về cạnh tranh.<br  />2. Bộ Thương mại chịu trách nhiệm trước Chính phủ thực hiện quản lý nhà nước về cạnh tranh.<br  />3. Các bộ, cơ quan ngang bộ, Uỷ ban nhân dân tỉnh, thành phố trực thuộc trung ương trong phạm vi nhiệm vụ, quyền hạn của mình có trách nhiệm phối hợp với Bộ Thương mại thực hiện quản lý nhà nước về cạnh tranh.<br  />', '', '2012_10/luat-canh-tranh-2004.doc', '', 0, 0, 1351515090, 1351515227, 1, 2, 1, 1, 0, 'Nguyễn Văn An', 1102078380, 0);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_blocks_groups`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_blocks_groups` (
  `bid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(55) NOT NULL,
  `module` varchar(55) NOT NULL,
  `file_name` varchar(55) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `template` varchar(55) DEFAULT NULL,
  `position` varchar(55) DEFAULT NULL,
  `exp_time` int(11) DEFAULT '0',
  `active` tinyint(4) DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  `all_func` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text,
  PRIMARY KEY (`bid`),
  KEY `theme` (`theme`),
  KEY `module` (`module`),
  KEY `position` (`position`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `nv3_vi_blocks_groups`
--

INSERT INTO `nv3_vi_blocks_groups` (`bid`, `theme`, `module`, `file_name`, `title`, `link`, `template`, `position`, `exp_time`, `active`, `groups_view`, `all_func`, `weight`, `config`) VALUES
(1, 'default', 'news', 'global.block_category.php', 'Menu', '', '', '[LEFT]', 0, 1, '0', 0, 1, 'a:1:{s:12:"title_length";i:25;}'),
(2, 'default', 'statistics', 'global.counter.php', 'Thống kê truy cập', '', '', '[LEFT]', 0, 1, '0', 1, 2, ''),
(3, 'default', 'banners', 'global.banners.php', 'Quảng cáo trái', '', '', '[LEFT]', 0, 1, '0', 1, 3, 'a:1:{s:12:"idplanbanner";i:2;}'),
(4, 'default', 'about', 'global.about.php', 'Giới thiệu', '', 'orange', '[RIGHT]', 0, 1, '0', 1, 1, ''),
(5, 'default', 'users', 'global.login.php', 'Đăng nhập thành viên', '', '', '[RIGHT]', 0, 1, '0', 1, 2, ''),
(6, 'default', 'voting', 'global.voting_random.php', 'Thăm dò ý kiến', '', '', '[RIGHT]', 0, 1, '0', 1, 3, ''),
(7, 'default', 'news', 'module.block_headline.php', 'Tin nổi bật', '', 'no_title', '[TOP]', 0, 1, '0', 0, 1, ''),
(9, 'modern', 'news', 'module.block_newscenter.php', 'Tin mới', '', 'no_title', '[HEADER]', 0, 1, '0', 0, 1, ''),
(10, 'modern', 'about', 'global.about.php', 'Giới thiệu', '', 'no_title_html', '[RIGHT]', 0, 1, '0', 1, 1, ''),
(11, 'modern', 'users', 'global.login.php', 'Đăng nhập', '', '', '[RIGHT]', 0, 1, '0', 1, 2, ''),
(12, 'modern', 'voting', 'global.voting_random.php', 'Thăm dò ý kiến', '', '', '[RIGHT]', 0, 1, '0', 1, 3, ''),
(13, 'modern', 'statistics', 'global.counter.php', 'Bộ đếm', '', '', '[RIGHT]', 0, 1, '0', 1, 4, ''),
(14, 'modern', 'news', 'module.block_newsright.php', 'News Right', '', 'no_title', '[RIGHT]', 0, 1, '0', 0, 5, ''),
(15, 'modern', 'banners', 'global.banners.php', 'Quảng cáo top banner', '', 'no_title', '[TOPADV]', 0, 1, '0', 1, 1, 'a:1:{s:12:"idplanbanner";i:1;}'),
(16, 'modern', 'menu', 'global.menu_theme_modern.php', 'global menu theme modern', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, ''),
(17, 'default', 'menu', 'global.menu_theme_default.php', 'global menu theme default', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, ''),
(18, 'modern', 'global', 'global.html.php', 'footer site', '', 'no_title', '[FOOTER_SITE]', 0, 1, '0', 1, 1, 'a:1:{s:11:"htmlcontent";s:274:"© Copyright NukeViet 3. All right reserved.<br  />Xây dựng trên nền tảng <a href="http://nukeviet.vn/" title="Mã nguồn mở NukeViet">Mã nguồn mở NukeViet</a>. <a href="http://vinades.vn/" title="Thiết kế web">Thiết kế website</a> bởi VINADES.,JSC";}'),
(19, 'default', 'global', 'global.html.php', 'footer site', '', 'no_title', '[FOOTER_SITE]', 0, 1, '0', 1, 1, 'a:1:{s:11:"htmlcontent";s:231:"<p class="footer"> © Copyright NukeViet 3. All right reserved.</p><p> Powered by <a href="http://nukeviet.vn/" title="NukeViet CMS">NukeViet CMS</a>. Design by <a href="http://vinades.vn/" title="VINADES.,JSC">VINADES.,JSC</a></p>";}'),
(20, 'mobile_nukeviet', 'menu', 'global.menu_theme_default.php', 'global menu theme default', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, ''),
(21, 'phapluat2', 'users', 'global.login.php', 'Thành viên', '', '', '[RIGHT]', 0, 1, '0', 1, 1, ''),
(24, 'phapluat2', 'news', 'global.block_category.php', 'Lĩnh vực hoạt động', '', '', '[LEFT]', 0, 1, '0', 0, 1, 'a:1:{s:12:"title_length";i:30;}'),
(23, 'phapluat2', 'menu', 'global.menu_theme_default.php', 'global menu theme default', '', 'no_title', '[MENU_SITE]', 0, 1, '0', 1, 1, ''),
(25, 'phapluat2', 'news', 'global.block_topnews.php', 'Xem nhiều nhất', '', '', '[RIGHT]', 0, 1, '0', 1, 2, 'a:2:{s:10:"number_day";i:365;s:6:"numrow";i:10;}'),
(26, 'phapluat2', 'voting', 'global.voting.php', 'Thăm dò ý kiến', '', '', '[RIGHT]', 0, 1, '0', 1, 3, 'a:1:{s:3:"vid";i:3;}'),
(27, 'phapluat2', 'statistics', 'global.counter.php', 'Thống kê', '', '', '[LEFT]', 0, 1, '0', 1, 2, '');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_blocks_weight`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_blocks_weight` (
  `bid` int(11) NOT NULL DEFAULT '0',
  `func_id` int(11) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `bid` (`bid`,`func_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_blocks_weight`
--

INSERT INTO `nv3_vi_blocks_weight` (`bid`, `func_id`, `weight`) VALUES
(1, 5, 1),
(1, 6, 1),
(1, 7, 1),
(1, 13, 1),
(1, 15, 1),
(1, 16, 1),
(2, 2, 1),
(2, 36, 1),
(2, 39, 1),
(2, 42, 1),
(2, 43, 1),
(2, 27, 1),
(2, 5, 2),
(2, 6, 2),
(2, 7, 2),
(2, 13, 2),
(2, 15, 2),
(2, 16, 2),
(2, 47, 1),
(2, 46, 1),
(2, 28, 1),
(2, 29, 1),
(2, 30, 1),
(2, 31, 1),
(2, 32, 1),
(2, 33, 1),
(2, 34, 1),
(2, 17, 1),
(2, 25, 1),
(2, 24, 1),
(2, 23, 1),
(2, 22, 1),
(2, 21, 1),
(2, 20, 1),
(2, 19, 1),
(2, 18, 1),
(2, 26, 1),
(3, 2, 2),
(3, 36, 2),
(3, 39, 2),
(3, 42, 2),
(3, 43, 2),
(3, 27, 2),
(3, 5, 3),
(3, 6, 3),
(3, 7, 3),
(3, 13, 3),
(3, 15, 3),
(3, 16, 3),
(3, 47, 2),
(3, 46, 2),
(3, 28, 2),
(3, 29, 2),
(3, 30, 2),
(3, 31, 2),
(3, 32, 2),
(3, 33, 2),
(3, 34, 2),
(3, 17, 2),
(3, 25, 2),
(3, 24, 2),
(3, 23, 2),
(3, 22, 2),
(3, 21, 2),
(3, 20, 2),
(3, 19, 2),
(3, 18, 2),
(3, 26, 2),
(4, 2, 1),
(4, 36, 1),
(4, 39, 1),
(4, 42, 1),
(4, 43, 1),
(4, 27, 1),
(4, 5, 1),
(4, 6, 1),
(4, 7, 1),
(4, 13, 1),
(4, 15, 1),
(4, 16, 1),
(4, 47, 1),
(4, 46, 1),
(4, 28, 1),
(4, 29, 1),
(4, 30, 1),
(4, 31, 1),
(4, 32, 1),
(4, 33, 1),
(4, 34, 1),
(4, 17, 1),
(4, 25, 1),
(4, 24, 1),
(4, 23, 1),
(4, 22, 1),
(4, 21, 1),
(4, 20, 1),
(4, 19, 1),
(4, 18, 1),
(4, 26, 1),
(5, 2, 2),
(5, 36, 2),
(5, 39, 2),
(5, 42, 2),
(5, 43, 2),
(5, 27, 2),
(5, 5, 2),
(5, 6, 2),
(5, 7, 2),
(5, 13, 2),
(5, 15, 2),
(5, 16, 2),
(5, 47, 2),
(5, 46, 2),
(5, 28, 2),
(5, 29, 2),
(5, 30, 2),
(5, 31, 2),
(5, 32, 2),
(5, 33, 2),
(5, 34, 2),
(5, 17, 2),
(5, 25, 2),
(5, 24, 2),
(5, 23, 2),
(5, 22, 2),
(5, 21, 2),
(5, 20, 2),
(5, 19, 2),
(5, 18, 2),
(5, 26, 2),
(6, 2, 3),
(6, 36, 3),
(6, 39, 3),
(6, 42, 3),
(6, 43, 3),
(6, 27, 3),
(6, 5, 3),
(6, 6, 3),
(6, 7, 3),
(6, 13, 3),
(6, 15, 3),
(6, 16, 3),
(6, 47, 3),
(6, 46, 3),
(6, 28, 3),
(6, 29, 3),
(6, 30, 3),
(6, 31, 3),
(6, 32, 3),
(6, 33, 3),
(6, 34, 3),
(6, 17, 3),
(6, 25, 3),
(6, 24, 3),
(6, 23, 3),
(6, 22, 3),
(6, 21, 3),
(6, 20, 3),
(6, 19, 3),
(6, 18, 3),
(6, 26, 3),
(7, 7, 1),
(9, 7, 1),
(10, 2, 1),
(10, 36, 1),
(10, 39, 1),
(10, 42, 1),
(10, 43, 1),
(10, 27, 1),
(10, 5, 1),
(10, 6, 1),
(10, 7, 1),
(10, 13, 1),
(10, 15, 1),
(10, 16, 1),
(10, 47, 1),
(10, 46, 1),
(10, 28, 1),
(10, 29, 1),
(10, 30, 1),
(10, 31, 1),
(10, 32, 1),
(10, 33, 1),
(10, 34, 1),
(10, 17, 1),
(10, 25, 1),
(10, 24, 1),
(10, 23, 1),
(10, 22, 1),
(10, 21, 1),
(10, 20, 1),
(10, 19, 1),
(10, 18, 1),
(10, 26, 1),
(11, 2, 2),
(11, 36, 2),
(11, 39, 2),
(11, 42, 2),
(11, 43, 2),
(11, 27, 2),
(11, 5, 2),
(11, 6, 2),
(11, 7, 2),
(11, 13, 2),
(11, 15, 2),
(11, 16, 2),
(11, 47, 2),
(11, 46, 2),
(11, 28, 2),
(11, 29, 2),
(11, 30, 2),
(11, 31, 2),
(11, 32, 2),
(11, 33, 2),
(11, 34, 2),
(11, 17, 2),
(11, 25, 2),
(11, 24, 2),
(11, 23, 2),
(11, 22, 2),
(11, 21, 2),
(11, 20, 2),
(11, 19, 2),
(11, 18, 2),
(11, 26, 2),
(12, 2, 3),
(12, 36, 3),
(12, 39, 3),
(12, 42, 3),
(12, 43, 3),
(12, 27, 3),
(12, 5, 3),
(12, 6, 3),
(12, 7, 3),
(12, 13, 3),
(12, 15, 3),
(12, 16, 3),
(12, 47, 3),
(12, 46, 3),
(12, 28, 3),
(12, 29, 3),
(12, 30, 3),
(12, 31, 3),
(12, 32, 3),
(12, 33, 3),
(12, 34, 3),
(12, 17, 3),
(12, 25, 3),
(12, 24, 3),
(12, 23, 3),
(12, 22, 3),
(12, 21, 3),
(12, 20, 3),
(12, 19, 3),
(12, 18, 3),
(12, 26, 3),
(13, 2, 4),
(13, 36, 4),
(13, 39, 4),
(13, 42, 4),
(13, 43, 4),
(13, 27, 4),
(13, 5, 4),
(13, 6, 4),
(13, 7, 4),
(13, 13, 4),
(13, 15, 4),
(13, 16, 4),
(13, 47, 4),
(13, 46, 4),
(13, 28, 4),
(13, 29, 4),
(13, 30, 4),
(13, 31, 4),
(13, 32, 4),
(13, 33, 4),
(13, 34, 4),
(13, 17, 4),
(13, 25, 4),
(13, 24, 4),
(13, 23, 4),
(13, 22, 4),
(13, 21, 4),
(13, 20, 4),
(13, 19, 4),
(13, 18, 4),
(13, 26, 4),
(14, 5, 5),
(14, 6, 5),
(14, 7, 5),
(14, 13, 5),
(14, 15, 5),
(14, 16, 5),
(15, 2, 1),
(15, 36, 1),
(15, 39, 1),
(15, 42, 1),
(15, 43, 1),
(15, 27, 1),
(15, 5, 1),
(15, 6, 1),
(15, 7, 1),
(15, 13, 1),
(15, 15, 1),
(15, 16, 1),
(15, 47, 1),
(15, 46, 1),
(15, 28, 1),
(15, 29, 1),
(15, 30, 1),
(15, 31, 1),
(15, 32, 1),
(15, 33, 1),
(15, 34, 1),
(15, 17, 1),
(15, 25, 1),
(15, 24, 1),
(15, 23, 1),
(15, 22, 1),
(15, 21, 1),
(15, 20, 1),
(15, 19, 1),
(15, 18, 1),
(15, 26, 1),
(16, 2, 1),
(16, 36, 1),
(16, 39, 1),
(16, 42, 1),
(16, 43, 1),
(16, 27, 1),
(16, 5, 1),
(16, 6, 1),
(16, 7, 1),
(16, 13, 1),
(16, 15, 1),
(16, 16, 1),
(16, 47, 1),
(16, 46, 1),
(16, 33, 1),
(16, 32, 1),
(16, 30, 1),
(16, 29, 1),
(16, 31, 1),
(16, 28, 1),
(16, 34, 1),
(16, 24, 1),
(16, 20, 1),
(16, 21, 1),
(16, 26, 1),
(16, 23, 1),
(16, 18, 1),
(16, 25, 1),
(16, 17, 1),
(16, 22, 1),
(16, 19, 1),
(17, 2, 1),
(17, 36, 1),
(17, 39, 1),
(17, 42, 1),
(17, 43, 1),
(17, 27, 1),
(17, 5, 1),
(17, 6, 1),
(17, 7, 1),
(17, 13, 1),
(17, 15, 1),
(17, 16, 1),
(17, 47, 1),
(17, 46, 1),
(17, 33, 1),
(17, 32, 1),
(17, 30, 1),
(17, 29, 1),
(17, 31, 1),
(17, 28, 1),
(17, 34, 1),
(17, 24, 1),
(17, 20, 1),
(17, 21, 1),
(17, 26, 1),
(17, 23, 1),
(17, 18, 1),
(17, 25, 1),
(17, 17, 1),
(17, 22, 1),
(17, 19, 1),
(18, 2, 1),
(18, 36, 1),
(18, 39, 1),
(18, 42, 1),
(18, 43, 1),
(18, 27, 1),
(18, 5, 1),
(18, 6, 1),
(18, 7, 1),
(18, 13, 1),
(18, 15, 1),
(18, 16, 1),
(18, 47, 1),
(18, 46, 1),
(18, 33, 1),
(18, 32, 1),
(18, 30, 1),
(18, 29, 1),
(18, 31, 1),
(18, 28, 1),
(18, 34, 1),
(18, 24, 1),
(18, 20, 1),
(18, 21, 1),
(18, 26, 1),
(18, 23, 1),
(18, 18, 1),
(18, 25, 1),
(18, 17, 1),
(18, 22, 1),
(18, 19, 1),
(19, 2, 1),
(19, 36, 1),
(19, 39, 1),
(19, 42, 1),
(19, 43, 1),
(19, 27, 1),
(19, 5, 1),
(19, 6, 1),
(19, 7, 1),
(19, 13, 1),
(19, 15, 1),
(19, 16, 1),
(19, 47, 1),
(19, 46, 1),
(19, 33, 1),
(19, 32, 1),
(19, 30, 1),
(19, 29, 1),
(19, 31, 1),
(19, 28, 1),
(19, 34, 1),
(19, 24, 1),
(19, 20, 1),
(19, 21, 1),
(19, 26, 1),
(19, 23, 1),
(19, 18, 1),
(19, 25, 1),
(19, 17, 1),
(19, 22, 1),
(19, 19, 1),
(19, 48, 1),
(2, 48, 1),
(3, 48, 2),
(17, 48, 1),
(4, 48, 1),
(5, 48, 2),
(6, 48, 3),
(18, 48, 1),
(16, 48, 1),
(10, 48, 1),
(11, 48, 2),
(12, 48, 3),
(13, 48, 4),
(15, 48, 1),
(20, 2, 1),
(20, 36, 1),
(20, 39, 1),
(20, 42, 1),
(20, 43, 1),
(20, 27, 1),
(20, 5, 1),
(20, 6, 1),
(20, 7, 1),
(20, 13, 1),
(20, 15, 1),
(20, 16, 1),
(20, 47, 1),
(20, 46, 1),
(20, 33, 1),
(20, 32, 1),
(20, 30, 1),
(20, 29, 1),
(20, 31, 1),
(20, 28, 1),
(20, 34, 1),
(20, 48, 1),
(20, 24, 1),
(20, 20, 1),
(20, 21, 1),
(20, 26, 1),
(20, 23, 1),
(20, 18, 1),
(20, 25, 1),
(20, 17, 1),
(20, 22, 1),
(20, 19, 1),
(16, 35, 1),
(10, 35, 1),
(11, 35, 2),
(12, 35, 3),
(13, 35, 4),
(15, 35, 1),
(18, 35, 1),
(17, 35, 1),
(19, 35, 1),
(2, 35, 1),
(3, 35, 2),
(4, 35, 1),
(5, 35, 2),
(6, 35, 3),
(20, 35, 1),
(16, 50, 1),
(10, 50, 1),
(11, 50, 2),
(12, 50, 3),
(13, 50, 4),
(15, 50, 1),
(18, 50, 1),
(17, 50, 1),
(19, 50, 1),
(2, 50, 1),
(3, 50, 2),
(4, 50, 1),
(5, 50, 2),
(6, 50, 3),
(20, 50, 1),
(21, 2, 1),
(21, 36, 1),
(21, 39, 1),
(21, 42, 1),
(21, 43, 1),
(21, 27, 1),
(21, 5, 1),
(21, 6, 1),
(21, 7, 1),
(21, 13, 1),
(21, 15, 1),
(21, 16, 1),
(21, 50, 1),
(21, 47, 1),
(21, 46, 1),
(21, 33, 1),
(21, 32, 1),
(21, 30, 1),
(21, 29, 1),
(21, 31, 1),
(21, 28, 1),
(21, 34, 1),
(21, 48, 1),
(21, 24, 1),
(21, 20, 1),
(21, 21, 1),
(21, 26, 1),
(21, 23, 1),
(21, 18, 1),
(21, 25, 1),
(21, 17, 1),
(21, 22, 1),
(21, 19, 1),
(21, 35, 1),
(23, 2, 1),
(23, 36, 1),
(23, 39, 1),
(23, 42, 1),
(23, 43, 1),
(23, 27, 1),
(23, 5, 1),
(23, 6, 1),
(23, 7, 1),
(23, 13, 1),
(23, 15, 1),
(23, 16, 1),
(23, 50, 1),
(23, 47, 1),
(23, 46, 1),
(23, 33, 1),
(23, 32, 1),
(23, 30, 1),
(23, 29, 1),
(23, 31, 1),
(23, 28, 1),
(23, 34, 1),
(23, 48, 1),
(23, 24, 1),
(23, 20, 1),
(23, 21, 1),
(23, 26, 1),
(23, 23, 1),
(23, 18, 1),
(23, 25, 1),
(23, 17, 1),
(23, 22, 1),
(23, 19, 1),
(23, 35, 1),
(24, 2, 1),
(24, 36, 1),
(24, 39, 1),
(24, 42, 1),
(24, 43, 1),
(24, 27, 1),
(24, 5, 1),
(24, 6, 1),
(24, 7, 1),
(24, 13, 1),
(24, 15, 1),
(24, 16, 1),
(24, 50, 1),
(24, 47, 1),
(24, 46, 1),
(24, 33, 1),
(24, 32, 1),
(24, 30, 1),
(24, 29, 1),
(24, 31, 1),
(24, 28, 1),
(24, 34, 1),
(24, 48, 1),
(24, 24, 1),
(24, 20, 1),
(24, 21, 1),
(24, 26, 1),
(24, 23, 1),
(24, 18, 1),
(24, 25, 1),
(24, 17, 1),
(24, 22, 1),
(24, 19, 1),
(24, 35, 1),
(25, 2, 2),
(25, 36, 2),
(25, 39, 2),
(25, 42, 2),
(25, 43, 2),
(25, 27, 2),
(25, 5, 2),
(25, 6, 2),
(25, 7, 2),
(25, 13, 2),
(25, 15, 2),
(25, 16, 2),
(25, 50, 2),
(25, 47, 2),
(25, 46, 2),
(25, 33, 2),
(25, 32, 2),
(25, 30, 2),
(25, 29, 2),
(25, 31, 2),
(25, 28, 2),
(25, 34, 2),
(25, 48, 2),
(25, 24, 2),
(25, 20, 2),
(25, 21, 2),
(25, 26, 2),
(25, 23, 2),
(25, 18, 2),
(25, 25, 2),
(25, 17, 2),
(25, 22, 2),
(25, 19, 2),
(25, 35, 2),
(26, 2, 3),
(26, 36, 3),
(26, 39, 3),
(26, 42, 3),
(26, 43, 3),
(26, 27, 3),
(26, 5, 3),
(26, 6, 3),
(26, 7, 3),
(26, 13, 3),
(26, 15, 3),
(26, 16, 3),
(26, 50, 3),
(26, 47, 3),
(26, 46, 3),
(26, 33, 3),
(26, 32, 3),
(26, 30, 3),
(26, 29, 3),
(26, 31, 3),
(26, 28, 3),
(26, 34, 3),
(26, 48, 3),
(26, 24, 3),
(26, 20, 3),
(26, 21, 3),
(26, 26, 3),
(26, 23, 3),
(26, 18, 3),
(26, 25, 3),
(26, 17, 3),
(26, 22, 3),
(26, 19, 3),
(26, 35, 3),
(27, 2, 2),
(27, 36, 2),
(27, 39, 2),
(27, 42, 2),
(27, 43, 2),
(27, 27, 2),
(27, 5, 2),
(27, 6, 2),
(27, 7, 2),
(27, 13, 2),
(27, 15, 2),
(27, 16, 2),
(27, 50, 2),
(27, 47, 2),
(27, 46, 2),
(27, 33, 2),
(27, 32, 2),
(27, 30, 2),
(27, 29, 2),
(27, 31, 2),
(27, 28, 2),
(27, 34, 2),
(27, 48, 2),
(27, 24, 2),
(27, 20, 2),
(27, 21, 2),
(27, 26, 2),
(27, 23, 2),
(27, 18, 2),
(27, 25, 2),
(27, 17, 2),
(27, 22, 2),
(27, 19, 2),
(27, 35, 2),
(19, 62, 1),
(19, 74, 1),
(19, 58, 1),
(19, 70, 1),
(19, 53, 1),
(19, 63, 1),
(19, 64, 1),
(19, 55, 1),
(19, 60, 1),
(19, 59, 1),
(2, 62, 1),
(2, 74, 1),
(2, 58, 1),
(2, 70, 1),
(2, 53, 1),
(2, 63, 1),
(2, 64, 1),
(2, 55, 1),
(2, 60, 1),
(2, 59, 1),
(3, 62, 2),
(3, 74, 2),
(3, 58, 2),
(3, 70, 2),
(3, 53, 2),
(3, 63, 2),
(3, 64, 2),
(3, 55, 2),
(3, 60, 2),
(3, 59, 2),
(17, 62, 1),
(17, 74, 1),
(17, 58, 1),
(17, 70, 1),
(17, 53, 1),
(17, 63, 1),
(17, 64, 1),
(17, 55, 1),
(17, 60, 1),
(17, 59, 1),
(4, 62, 1),
(4, 74, 1),
(4, 58, 1),
(4, 70, 1),
(4, 53, 1),
(4, 63, 1),
(4, 64, 1),
(4, 55, 1),
(4, 60, 1),
(4, 59, 1),
(5, 62, 2),
(5, 74, 2),
(5, 58, 2),
(5, 70, 2),
(5, 53, 2),
(5, 63, 2),
(5, 64, 2),
(5, 55, 2),
(5, 60, 2),
(5, 59, 2),
(6, 62, 3),
(6, 74, 3),
(6, 58, 3),
(6, 70, 3),
(6, 53, 3),
(6, 63, 3),
(6, 64, 3),
(6, 55, 3),
(6, 60, 3),
(6, 59, 3),
(20, 62, 1),
(20, 74, 1),
(20, 58, 1),
(20, 70, 1),
(20, 53, 1),
(20, 63, 1),
(20, 64, 1),
(20, 55, 1),
(20, 60, 1),
(20, 59, 1),
(18, 62, 1),
(18, 74, 1),
(18, 58, 1),
(18, 70, 1),
(18, 53, 1),
(18, 63, 1),
(18, 64, 1),
(18, 55, 1),
(18, 60, 1),
(18, 59, 1),
(16, 62, 1),
(16, 74, 1),
(16, 58, 1),
(16, 70, 1),
(16, 53, 1),
(16, 63, 1),
(16, 64, 1),
(16, 55, 1),
(16, 60, 1),
(16, 59, 1),
(10, 62, 1),
(10, 74, 1),
(10, 58, 1),
(10, 70, 1),
(10, 53, 1),
(10, 63, 1),
(10, 64, 1),
(10, 55, 1),
(10, 60, 1),
(10, 59, 1),
(11, 62, 2),
(11, 74, 2),
(11, 58, 2),
(11, 70, 2),
(11, 53, 2),
(11, 63, 2),
(11, 64, 2),
(11, 55, 2),
(11, 60, 2),
(11, 59, 2),
(12, 62, 3),
(12, 74, 3),
(12, 58, 3),
(12, 70, 3),
(12, 53, 3),
(12, 63, 3),
(12, 64, 3),
(12, 55, 3),
(12, 60, 3),
(12, 59, 3),
(13, 62, 4),
(13, 74, 4),
(13, 58, 4),
(13, 70, 4),
(13, 53, 4),
(13, 63, 4),
(13, 64, 4),
(13, 55, 4),
(13, 60, 4),
(13, 59, 4),
(15, 62, 1),
(15, 74, 1),
(15, 58, 1),
(15, 70, 1),
(15, 53, 1),
(15, 63, 1),
(15, 64, 1),
(15, 55, 1),
(15, 60, 1),
(15, 59, 1),
(16, 114, 1),
(13, 114, 4),
(24, 118, 2),
(15, 114, 1),
(24, 122, 2),
(27, 114, 1),
(12, 114, 3),
(24, 121, 2),
(24, 123, 2),
(24, 120, 2),
(27, 62, 1),
(27, 74, 1),
(27, 58, 1),
(27, 70, 1),
(27, 53, 1),
(27, 63, 1),
(27, 64, 1),
(27, 55, 1),
(27, 60, 1),
(27, 59, 1),
(23, 62, 1),
(23, 74, 1),
(23, 58, 1),
(23, 70, 1),
(23, 53, 1),
(23, 63, 1),
(23, 64, 1),
(23, 55, 1),
(23, 60, 1),
(23, 59, 1),
(21, 62, 1),
(21, 74, 1),
(21, 58, 1),
(21, 70, 1),
(21, 53, 1),
(21, 63, 1),
(21, 64, 1),
(21, 55, 1),
(21, 60, 1),
(21, 59, 1),
(26, 62, 3),
(26, 74, 3),
(26, 58, 3),
(26, 70, 3),
(26, 53, 3),
(26, 63, 3),
(26, 64, 3),
(26, 55, 3),
(26, 60, 3),
(26, 59, 3),
(19, 86, 1),
(19, 98, 1),
(19, 82, 1),
(19, 94, 1),
(19, 77, 1),
(19, 87, 1),
(19, 88, 1),
(19, 79, 1),
(19, 84, 1),
(19, 83, 1),
(2, 86, 1),
(2, 98, 1),
(2, 82, 1),
(2, 94, 1),
(2, 77, 1),
(2, 87, 1),
(2, 88, 1),
(2, 79, 1),
(2, 84, 1),
(2, 83, 1),
(3, 86, 2),
(3, 98, 2),
(3, 82, 2),
(3, 94, 2),
(3, 77, 2),
(3, 87, 2),
(3, 88, 2),
(3, 79, 2),
(3, 84, 2),
(3, 83, 2),
(17, 86, 1),
(17, 98, 1),
(17, 82, 1),
(17, 94, 1),
(17, 77, 1),
(17, 87, 1),
(17, 88, 1),
(17, 79, 1),
(17, 84, 1),
(17, 83, 1),
(4, 86, 1),
(4, 98, 1),
(4, 82, 1),
(4, 94, 1),
(4, 77, 1),
(4, 87, 1),
(4, 88, 1),
(4, 79, 1),
(4, 84, 1),
(4, 83, 1),
(5, 86, 2),
(5, 98, 2),
(5, 82, 2),
(5, 94, 2),
(5, 77, 2),
(5, 87, 2),
(5, 88, 2),
(5, 79, 2),
(5, 84, 2),
(5, 83, 2),
(6, 86, 3),
(6, 98, 3),
(6, 82, 3),
(6, 94, 3),
(6, 77, 3),
(6, 87, 3),
(6, 88, 3),
(6, 79, 3),
(6, 84, 3),
(6, 83, 3),
(20, 86, 1),
(20, 98, 1),
(20, 82, 1),
(20, 94, 1),
(20, 77, 1),
(20, 87, 1),
(20, 88, 1),
(20, 79, 1),
(20, 84, 1),
(20, 83, 1),
(18, 86, 1),
(18, 98, 1),
(18, 82, 1),
(18, 94, 1),
(18, 77, 1),
(18, 87, 1),
(18, 88, 1),
(18, 79, 1),
(18, 84, 1),
(18, 83, 1),
(16, 86, 1),
(16, 98, 1),
(16, 82, 1),
(16, 94, 1),
(16, 77, 1),
(16, 87, 1),
(16, 88, 1),
(16, 79, 1),
(16, 84, 1),
(16, 83, 1),
(10, 86, 1),
(10, 98, 1),
(10, 82, 1),
(10, 94, 1),
(10, 77, 1),
(10, 87, 1),
(10, 88, 1),
(10, 79, 1),
(10, 84, 1),
(10, 83, 1),
(11, 86, 2),
(11, 98, 2),
(11, 82, 2),
(11, 94, 2),
(11, 77, 2),
(11, 87, 2),
(11, 88, 2),
(11, 79, 2),
(11, 84, 2),
(11, 83, 2),
(12, 86, 3),
(12, 98, 3),
(12, 82, 3),
(12, 94, 3),
(12, 77, 3),
(12, 87, 3),
(12, 88, 3),
(12, 79, 3),
(12, 84, 3),
(12, 83, 3),
(13, 86, 4),
(13, 98, 4),
(13, 82, 4),
(13, 94, 4),
(13, 77, 4),
(13, 87, 4),
(13, 88, 4),
(13, 79, 4),
(13, 84, 4),
(13, 83, 4),
(15, 86, 1),
(15, 98, 1),
(15, 82, 1),
(15, 94, 1),
(15, 77, 1),
(15, 87, 1),
(15, 88, 1),
(15, 79, 1),
(15, 84, 1),
(15, 83, 1),
(19, 115, 1),
(2, 123, 1),
(17, 114, 1),
(2, 120, 1),
(11, 114, 2),
(2, 117, 1),
(2, 119, 1),
(10, 114, 1),
(19, 114, 1),
(3, 114, 2),
(27, 86, 1),
(27, 98, 1),
(27, 82, 1),
(27, 94, 1),
(27, 77, 1),
(27, 87, 1),
(27, 88, 1),
(27, 79, 1),
(27, 84, 1),
(27, 83, 1),
(23, 86, 1),
(23, 98, 1),
(23, 82, 1),
(23, 94, 1),
(23, 77, 1),
(23, 87, 1),
(23, 88, 1),
(23, 79, 1),
(23, 84, 1),
(23, 83, 1),
(21, 86, 1),
(21, 98, 1),
(21, 82, 1),
(21, 94, 1),
(21, 77, 1),
(21, 87, 1),
(21, 88, 1),
(21, 79, 1),
(21, 84, 1),
(21, 83, 1),
(24, 115, 2),
(26, 86, 3),
(26, 98, 3),
(26, 82, 3),
(26, 94, 3),
(26, 77, 3),
(26, 87, 3),
(26, 88, 3),
(26, 79, 3),
(26, 84, 3),
(26, 83, 3),
(19, 104, 1),
(19, 113, 1),
(19, 112, 1),
(19, 103, 1),
(19, 102, 1),
(19, 110, 1),
(19, 101, 1),
(2, 104, 1),
(2, 113, 1),
(2, 112, 1),
(2, 103, 1),
(2, 102, 1),
(2, 110, 1),
(2, 101, 1),
(3, 104, 2),
(3, 113, 2),
(3, 112, 2),
(3, 103, 2),
(3, 102, 2),
(3, 110, 2),
(3, 101, 2),
(17, 104, 1),
(17, 113, 1),
(17, 112, 1),
(17, 103, 1),
(17, 102, 1),
(17, 110, 1),
(17, 101, 1),
(4, 104, 1),
(4, 113, 1),
(4, 112, 1),
(4, 103, 1),
(4, 102, 1),
(4, 110, 1),
(4, 101, 1),
(5, 104, 2),
(5, 113, 2),
(5, 112, 2),
(5, 103, 2),
(5, 102, 2),
(5, 110, 2),
(5, 101, 2),
(6, 104, 3),
(6, 113, 3),
(6, 112, 3),
(6, 103, 3),
(6, 102, 3),
(6, 110, 3),
(6, 101, 3),
(20, 104, 1),
(20, 113, 1),
(20, 112, 1),
(20, 103, 1),
(20, 102, 1),
(20, 110, 1),
(20, 101, 1),
(18, 104, 1),
(18, 113, 1),
(18, 112, 1),
(18, 103, 1),
(18, 102, 1),
(18, 110, 1),
(18, 101, 1),
(16, 104, 1),
(16, 113, 1),
(16, 112, 1),
(16, 103, 1),
(16, 102, 1),
(16, 110, 1),
(16, 101, 1),
(10, 104, 1),
(10, 113, 1),
(10, 112, 1),
(10, 103, 1),
(10, 102, 1),
(10, 110, 1),
(10, 101, 1),
(11, 104, 2),
(11, 113, 2),
(11, 112, 2),
(11, 103, 2),
(11, 102, 2),
(11, 110, 2),
(11, 101, 2),
(12, 104, 3),
(12, 113, 3),
(12, 112, 3),
(12, 103, 3),
(12, 102, 3),
(12, 110, 3),
(12, 101, 3),
(13, 104, 4),
(13, 113, 4),
(13, 112, 4),
(13, 103, 4),
(13, 102, 4),
(13, 110, 4),
(13, 101, 4),
(15, 104, 1),
(15, 113, 1),
(15, 112, 1),
(15, 103, 1),
(15, 102, 1),
(15, 110, 1),
(15, 101, 1),
(5, 114, 2),
(2, 122, 1),
(20, 114, 1),
(4, 114, 1),
(23, 114, 1),
(6, 114, 3),
(2, 121, 1),
(27, 104, 1),
(27, 113, 1),
(27, 112, 1),
(27, 103, 1),
(27, 102, 1),
(27, 110, 1),
(27, 101, 1),
(23, 104, 1),
(23, 113, 1),
(23, 112, 1),
(23, 103, 1),
(23, 102, 1),
(23, 110, 1),
(23, 101, 1),
(21, 104, 1),
(21, 113, 1),
(21, 112, 1),
(21, 103, 1),
(21, 102, 1),
(21, 110, 1),
(21, 101, 1),
(25, 104, 2),
(25, 113, 2),
(25, 112, 2),
(25, 103, 2),
(25, 102, 2),
(25, 110, 2),
(25, 101, 2),
(26, 104, 3),
(26, 113, 3),
(26, 112, 3),
(26, 103, 3),
(26, 102, 3),
(26, 110, 3),
(26, 101, 3),
(24, 119, 2),
(24, 117, 1),
(2, 114, 1),
(26, 114, 3),
(19, 123, 1),
(19, 120, 1),
(21, 114, 1),
(19, 117, 1),
(19, 122, 1),
(25, 114, 2),
(19, 118, 1),
(19, 119, 1),
(19, 121, 1),
(18, 114, 1),
(2, 118, 1),
(2, 115, 1),
(3, 117, 2),
(3, 119, 2),
(3, 120, 2),
(3, 123, 2),
(3, 121, 2),
(3, 122, 2),
(3, 118, 2),
(3, 115, 2),
(17, 117, 1),
(17, 119, 1),
(17, 120, 1),
(17, 123, 1),
(17, 121, 1),
(17, 122, 1),
(17, 118, 1),
(17, 115, 1),
(4, 117, 1),
(4, 119, 1),
(4, 120, 1),
(4, 123, 1),
(4, 121, 1),
(4, 122, 1),
(4, 118, 1),
(4, 115, 1),
(5, 117, 2),
(5, 119, 2),
(5, 120, 2),
(5, 123, 2),
(5, 121, 2),
(5, 122, 2),
(5, 118, 2),
(5, 115, 2),
(6, 117, 3),
(6, 119, 3),
(6, 120, 3),
(6, 123, 3),
(6, 121, 3),
(6, 122, 3),
(6, 118, 3),
(6, 115, 3),
(20, 117, 1),
(20, 119, 1),
(20, 120, 1),
(20, 123, 1),
(20, 121, 1),
(20, 122, 1),
(20, 118, 1),
(20, 115, 1),
(18, 117, 1),
(18, 119, 1),
(18, 120, 1),
(18, 123, 1),
(18, 121, 1),
(18, 122, 1),
(18, 118, 1),
(18, 115, 1),
(16, 117, 1),
(16, 119, 1),
(16, 120, 1),
(16, 123, 1),
(16, 121, 1),
(16, 122, 1),
(16, 118, 1),
(16, 115, 1),
(10, 117, 1),
(10, 119, 1),
(10, 120, 1),
(10, 123, 1),
(10, 121, 1),
(10, 122, 1),
(10, 118, 1),
(10, 115, 1),
(11, 117, 2),
(11, 119, 2),
(11, 120, 2),
(11, 123, 2),
(11, 121, 2),
(11, 122, 2),
(11, 118, 2),
(11, 115, 2),
(12, 117, 3),
(12, 119, 3),
(12, 120, 3),
(12, 123, 3),
(12, 121, 3),
(12, 122, 3),
(12, 118, 3),
(12, 115, 3),
(13, 117, 4),
(13, 119, 4),
(13, 120, 4),
(13, 123, 4),
(13, 121, 4),
(13, 122, 4),
(13, 118, 4),
(13, 115, 4),
(15, 117, 1),
(15, 119, 1),
(15, 120, 1),
(15, 123, 1),
(15, 121, 1),
(15, 122, 1),
(15, 118, 1),
(15, 115, 1),
(27, 117, 2),
(27, 119, 1),
(27, 120, 1),
(27, 123, 1),
(27, 121, 1),
(27, 122, 1),
(27, 118, 1),
(27, 115, 1),
(23, 117, 1),
(23, 119, 1),
(23, 120, 1),
(23, 123, 1),
(23, 121, 1),
(23, 122, 1),
(23, 118, 1),
(23, 115, 1),
(21, 117, 1),
(21, 119, 1),
(21, 120, 1),
(21, 123, 1),
(21, 121, 1),
(21, 122, 1),
(21, 118, 1),
(21, 115, 1),
(25, 117, 2),
(25, 119, 2),
(25, 120, 2),
(25, 123, 2),
(25, 121, 2),
(25, 122, 2),
(25, 118, 2),
(25, 115, 2),
(26, 117, 3),
(26, 119, 3),
(26, 120, 3),
(26, 123, 3),
(26, 121, 3),
(26, 122, 3),
(26, 118, 3),
(26, 115, 3);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_contact_rows`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_contact_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `note` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `nv3_vi_contact_rows`
--

INSERT INTO `nv3_vi_contact_rows` (`id`, `full_name`, `phone`, `fax`, `email`, `note`, `admins`, `act`) VALUES
(1, 'Webmaster', '', '', '', '', '1/1/1/0;', 1);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_contact_send`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_contact_send` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `send_time` int(11) unsigned NOT NULL DEFAULT '0',
  `sender_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sender_name` varchar(100) NOT NULL,
  `sender_email` varchar(100) NOT NULL,
  `sender_phone` varchar(255) NOT NULL,
  `sender_ip` varchar(15) NOT NULL,
  `is_read` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_reply` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `reply_content` mediumtext NOT NULL,
  `reply_time` int(11) unsigned NOT NULL DEFAULT '0',
  `reply_aid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sender_name` (`sender_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_counter`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_counter` (
  `c_type` varchar(100) NOT NULL,
  `c_val` varchar(100) NOT NULL,
  `c_count` int(11) unsigned NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `c_type` (`c_type`,`c_val`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_counter`
--

INSERT INTO `nv3_vi_counter` (`c_type`, `c_val`, `c_count`, `last_update`) VALUES
('c_time', 'start', 0, 0),
('c_time', 'last', 1352876041, 0),
('total', 'hits', 17, 1352876041),
('year', '2009', 0, 0),
('year', '2010', 0, 0),
('year', '2011', 0, 0),
('year', '2012', 17, 1352876041),
('year', '2013', 0, 0),
('year', '2014', 0, 0),
('year', '2015', 0, 0),
('year', '2016', 0, 0),
('year', '2017', 0, 0),
('year', '2018', 0, 0),
('year', '2019', 0, 0),
('year', '2020', 0, 0),
('month', 'Jan', 0, 0),
('month', 'Feb', 0, 0),
('month', 'Mar', 0, 0),
('month', 'Apr', 0, 0),
('month', 'May', 0, 0),
('month', 'Jun', 0, 0),
('month', 'Jul', 0, 0),
('month', 'Aug', 0, 0),
('month', 'Sep', 0, 0),
('month', 'Oct', 10, 1351566649),
('month', 'Nov', 7, 1352876041),
('month', 'Dec', 0, 0),
('day', '01', 0, 0),
('day', '02', 3, 1351842305),
('day', '03', 0, 0),
('day', '04', 0, 0),
('day', '05', 0, 0),
('day', '06', 0, 0),
('day', '07', 0, 0),
('day', '08', 0, 0),
('day', '09', 1, 1352453838),
('day', '10', 0, 0),
('day', '11', 1, 1352618030),
('day', '12', 1, 1352719468),
('day', '13', 0, 0),
('day', '14', 1, 1352876041),
('day', '15', 0, 0),
('day', '16', 0, 0),
('day', '17', 0, 0),
('day', '18', 0, 0),
('day', '19', 0, 0),
('day', '20', 0, 0),
('day', '21', 0, 0),
('day', '22', 0, 0),
('day', '23', 0, 0),
('day', '24', 0, 0),
('day', '25', 0, 0),
('day', '26', 0, 1351257664),
('day', '27', 0, 1351328441),
('day', '28', 0, 1351435247),
('day', '29', 0, 1351517384),
('day', '30', 0, 1351566649),
('day', '31', 0, 0),
('dayofweek', 'Sunday', 3, 1352618030),
('dayofweek', 'Monday', 3, 1352719468),
('dayofweek', 'Tuesday', 2, 1351566649),
('dayofweek', 'Wednesday', 1, 1352876041),
('dayofweek', 'Thursday', 0, 0),
('dayofweek', 'Friday', 6, 1352453838),
('dayofweek', 'Saturday', 2, 1351328441),
('hour', '00', 0, 0),
('hour', '01', 0, 0),
('hour', '02', 0, 0),
('hour', '03', 0, 0),
('hour', '04', 0, 0),
('hour', '05', 0, 0),
('hour', '06', 0, 0),
('hour', '07', 0, 0),
('hour', '08', 0, 0),
('hour', '09', 0, 1351562561),
('hour', '10', 0, 1351566649),
('hour', '11', 0, 1351483819),
('hour', '12', 0, 0),
('hour', '13', 1, 1352876041),
('hour', '14', 0, 1352618030),
('hour', '15', 0, 0),
('hour', '16', 0, 1352453838),
('hour', '17', 0, 0),
('hour', '18', 0, 1352719468),
('hour', '19', 0, 0),
('hour', '20', 0, 1351517384),
('hour', '21', 0, 1351435247),
('hour', '22', 0, 0),
('hour', '23', 0, 0),
('bot', 'Alexa', 0, 0),
('bot', 'AltaVista Scooter', 0, 0),
('bot', 'Altavista Mercator', 0, 0),
('bot', 'Altavista Search', 0, 0),
('bot', 'Aport.ru Bot', 0, 0),
('bot', 'Ask Jeeves', 0, 0),
('bot', 'Baidu', 0, 0),
('bot', 'Exabot', 0, 0),
('bot', 'FAST Enterprise', 0, 0),
('bot', 'FAST WebCrawler', 0, 0),
('bot', 'Francis', 0, 0),
('bot', 'Gigablast', 0, 0),
('bot', 'Google AdsBot', 0, 0),
('bot', 'Google Adsense', 0, 0),
('bot', 'Google Bot', 0, 0),
('bot', 'Google Desktop', 0, 0),
('bot', 'Google Feedfetcher', 0, 0),
('bot', 'Heise IT-Markt', 0, 0),
('bot', 'Heritrix', 0, 0),
('bot', 'IBM Research', 0, 0),
('bot', 'ICCrawler - ICjobs', 0, 0),
('bot', 'Ichiro', 0, 0),
('bot', 'InfoSeek Spider', 0, 0),
('bot', 'Lycos.com Bot', 0, 0),
('bot', 'MSN Bot', 0, 0),
('bot', 'MSN Bot Media', 0, 0),
('bot', 'MSN Bot News', 0, 0),
('bot', 'MSN NewsBlogs', 0, 0),
('bot', 'Majestic-12', 0, 0),
('bot', 'Metager', 0, 0),
('bot', 'NG-Search', 0, 0),
('bot', 'Nutch Bot', 0, 0),
('bot', 'NutchCVS', 0, 0),
('bot', 'OmniExplorer', 0, 0),
('bot', 'Online Link Validator', 0, 0),
('bot', 'Open-source Web Search', 0, 0),
('bot', 'Psbot', 0, 0),
('bot', 'Rambler', 0, 0),
('bot', 'SEO Crawler', 0, 0),
('bot', 'SEOSearch', 0, 0),
('bot', 'Seekport', 0, 0),
('bot', 'Sensis', 0, 0),
('bot', 'Seoma', 0, 0),
('bot', 'Snappy', 0, 0),
('bot', 'Steeler', 0, 0),
('bot', 'Synoo', 0, 0),
('bot', 'Telekom', 0, 0),
('bot', 'TurnitinBot', 0, 0),
('bot', 'Vietnamese Search', 0, 0),
('bot', 'Voyager', 0, 0),
('bot', 'W3 Sitesearch', 0, 0),
('bot', 'W3C Linkcheck', 0, 0),
('bot', 'W3C Validator', 0, 0),
('bot', 'WiseNut', 0, 0),
('bot', 'YaCy', 0, 0),
('bot', 'Yahoo Bot', 0, 0),
('bot', 'Yahoo MMCrawler', 0, 0),
('bot', 'Yahoo Slurp', 0, 0),
('bot', 'YahooSeeker', 0, 0),
('bot', 'Yandex', 0, 0),
('bot', 'Yandex Blog', 0, 0),
('bot', 'Yandex Direct Bot', 0, 0),
('bot', 'Yandex Something', 0, 0),
('browser', 'netcaptor', 0, 0),
('browser', 'opera', 0, 0),
('browser', 'aol', 0, 0),
('browser', 'aol2', 0, 0),
('browser', 'mosaic', 0, 0),
('browser', 'k-meleon', 0, 0),
('browser', 'konqueror', 0, 0),
('browser', 'avantbrowser', 0, 0),
('browser', 'avantgo', 0, 0),
('browser', 'proxomitron', 0, 0),
('browser', 'chrome', 1, 1351517384),
('browser', 'safari', 0, 0),
('browser', 'lynx', 0, 0),
('browser', 'links', 0, 0),
('browser', 'galeon', 0, 0),
('browser', 'abrowse', 0, 0),
('browser', 'amaya', 0, 0),
('browser', 'ant', 0, 0),
('browser', 'aweb', 0, 0),
('browser', 'beonex', 0, 0),
('browser', 'blazer', 0, 0),
('browser', 'camino', 0, 0),
('browser', 'chimera', 0, 0),
('browser', 'columbus', 0, 0),
('browser', 'crazybrowser', 0, 0),
('browser', 'curl', 0, 0),
('browser', 'deepnet', 0, 0),
('browser', 'dillo', 0, 0),
('browser', 'doris', 0, 0),
('browser', 'elinks', 0, 0),
('browser', 'epiphany', 0, 0),
('browser', 'ibrowse', 0, 0),
('browser', 'icab', 0, 0),
('browser', 'ice', 0, 0),
('browser', 'isilox', 0, 0),
('browser', 'lotus', 0, 0),
('browser', 'lunascape', 0, 0),
('browser', 'maxthon', 0, 0),
('browser', 'mbrowser', 0, 0),
('browser', 'multibrowser', 0, 0),
('browser', 'nautilus', 0, 0),
('browser', 'netfront', 0, 0),
('browser', 'netpositive', 0, 0),
('browser', 'omniweb', 0, 0),
('browser', 'oregano', 0, 0),
('browser', 'phaseout', 0, 0),
('browser', 'plink', 0, 0),
('browser', 'phoenix', 0, 0),
('browser', 'shiira', 0, 0),
('browser', 'sleipnir', 0, 0),
('browser', 'slimbrowser', 0, 0),
('browser', 'staroffice', 0, 0),
('browser', 'sunrise', 0, 0),
('browser', 'voyager', 0, 0),
('browser', 'w3m', 0, 0),
('browser', 'webtv', 0, 0),
('browser', 'xiino', 0, 0),
('browser', 'explorer', 0, 0),
('browser', 'firefox', 16, 1352876041),
('browser', 'netscape', 0, 0),
('browser', 'netscape2', 0, 0),
('browser', 'mozilla', 0, 0),
('browser', 'mozilla2', 0, 0),
('browser', 'firebird', 0, 0),
('browser', 'Mobile', 0, 0),
('browser', 'Unknown', 0, 0),
('os', 'windows7', 17, 1352876041),
('os', 'windowsvista', 0, 0),
('os', 'windows2003', 0, 0),
('os', 'windowsxp', 0, 0),
('os', 'windowsxp2', 0, 0),
('os', 'windows2k', 0, 0),
('os', 'windows95', 0, 0),
('os', 'windowsce', 0, 0),
('os', 'windowsme', 0, 0),
('os', 'windowsme2', 0, 0),
('os', 'windowsnt', 0, 0),
('os', 'windowsnt2', 0, 0),
('os', 'windows98', 0, 0),
('os', 'windows', 0, 0),
('os', 'linux', 0, 0),
('os', 'linux2', 0, 0),
('os', 'linux3', 0, 0),
('os', 'macosx', 0, 0),
('os', 'macppc', 0, 0),
('os', 'mac', 0, 0),
('os', 'amiga', 0, 0),
('os', 'beos', 0, 0),
('os', 'freebsd', 0, 0),
('os', 'freebsd2', 0, 0),
('os', 'irix', 0, 0),
('os', 'netbsd', 0, 0),
('os', 'netbsd2', 0, 0),
('os', 'os2', 0, 0),
('os', 'os22', 0, 0),
('os', 'openbsd', 0, 0),
('os', 'openbsd2', 0, 0),
('os', 'palm', 0, 0),
('os', 'palm2', 0, 0),
('os', 'Unspecified', 0, 0),
('country', 'AD', 0, 0),
('country', 'AE', 0, 0),
('country', 'AF', 0, 0),
('country', 'AG', 0, 0),
('country', 'AI', 0, 0),
('country', 'AL', 0, 0),
('country', 'AM', 0, 0),
('country', 'AN', 0, 0),
('country', 'AO', 0, 0),
('country', 'AQ', 0, 0),
('country', 'AR', 0, 0),
('country', 'AS', 0, 0),
('country', 'AT', 0, 0),
('country', 'AU', 0, 0),
('country', 'AW', 0, 0),
('country', 'AZ', 0, 0),
('country', 'BA', 0, 0),
('country', 'BB', 0, 0),
('country', 'BD', 0, 0),
('country', 'BE', 0, 0),
('country', 'BF', 0, 0),
('country', 'BG', 0, 0),
('country', 'BH', 0, 0),
('country', 'BI', 0, 0),
('country', 'BJ', 0, 0),
('country', 'BM', 0, 0),
('country', 'BN', 0, 0),
('country', 'BO', 0, 0),
('country', 'BR', 0, 0),
('country', 'BS', 0, 0),
('country', 'BT', 0, 0),
('country', 'BW', 0, 0),
('country', 'BY', 0, 0),
('country', 'BZ', 0, 0),
('country', 'CA', 0, 0),
('country', 'CD', 0, 0),
('country', 'CF', 0, 0),
('country', 'CG', 0, 0),
('country', 'CH', 0, 0),
('country', 'CI', 0, 0),
('country', 'CK', 0, 0),
('country', 'CL', 0, 0),
('country', 'CM', 0, 0),
('country', 'CN', 0, 0),
('country', 'CO', 0, 0),
('country', 'CR', 0, 0),
('country', 'CS', 0, 0),
('country', 'CU', 0, 0),
('country', 'CV', 0, 0),
('country', 'CY', 0, 0),
('country', 'CZ', 0, 0),
('country', 'DE', 0, 0),
('country', 'DJ', 0, 0),
('country', 'DK', 0, 0),
('country', 'DM', 0, 0),
('country', 'DO', 0, 0),
('country', 'DZ', 0, 0),
('country', 'EC', 0, 0),
('country', 'EE', 0, 0),
('country', 'EG', 0, 0),
('country', 'ER', 0, 0),
('country', 'ES', 0, 0),
('country', 'ET', 0, 0),
('country', 'EU', 0, 0),
('country', 'FI', 0, 0),
('country', 'FJ', 0, 0),
('country', 'FK', 0, 0),
('country', 'FM', 0, 0),
('country', 'FO', 0, 0),
('country', 'FR', 0, 0),
('country', 'GA', 0, 0),
('country', 'GB', 0, 0),
('country', 'GD', 0, 0),
('country', 'GE', 0, 0),
('country', 'GF', 0, 0),
('country', 'GH', 0, 0),
('country', 'GI', 0, 0),
('country', 'GL', 0, 0),
('country', 'GM', 0, 0),
('country', 'GN', 0, 0),
('country', 'GP', 0, 0),
('country', 'GQ', 0, 0),
('country', 'GR', 0, 0),
('country', 'GS', 0, 0),
('country', 'GT', 0, 0),
('country', 'GU', 0, 0),
('country', 'GW', 0, 0),
('country', 'GY', 0, 0),
('country', 'HK', 0, 0),
('country', 'HN', 0, 0),
('country', 'HR', 0, 0),
('country', 'HT', 0, 0),
('country', 'HU', 0, 0),
('country', 'ID', 0, 0),
('country', 'IE', 0, 0),
('country', 'IL', 0, 0),
('country', 'IN', 0, 0),
('country', 'IO', 0, 0),
('country', 'IQ', 0, 0),
('country', 'IR', 0, 0),
('country', 'IS', 0, 0),
('country', 'IT', 0, 0),
('country', 'JM', 0, 0),
('country', 'JO', 0, 0),
('country', 'JP', 0, 0),
('country', 'KE', 0, 0),
('country', 'KG', 0, 0),
('country', 'KH', 0, 0),
('country', 'KI', 0, 0),
('country', 'KM', 0, 0),
('country', 'KN', 0, 0),
('country', 'KR', 0, 0),
('country', 'KW', 0, 0),
('country', 'KY', 0, 0),
('country', 'KZ', 0, 0),
('country', 'LA', 0, 0),
('country', 'LB', 0, 0),
('country', 'LC', 0, 0),
('country', 'LI', 0, 0),
('country', 'LK', 0, 0),
('country', 'LR', 0, 0),
('country', 'LS', 0, 0),
('country', 'LT', 0, 0),
('country', 'LU', 0, 0),
('country', 'LV', 0, 0),
('country', 'LY', 0, 0),
('country', 'MA', 0, 0),
('country', 'MC', 0, 0),
('country', 'MD', 0, 0),
('country', 'MG', 0, 0),
('country', 'MH', 0, 0),
('country', 'MK', 0, 0),
('country', 'ML', 0, 0),
('country', 'MM', 0, 0),
('country', 'MN', 0, 0),
('country', 'MO', 0, 0),
('country', 'MP', 0, 0),
('country', 'MQ', 0, 0),
('country', 'MR', 0, 0),
('country', 'MT', 0, 0),
('country', 'MU', 0, 0),
('country', 'MV', 0, 0),
('country', 'MW', 0, 0),
('country', 'MX', 0, 0),
('country', 'MY', 0, 0),
('country', 'MZ', 0, 0),
('country', 'NA', 0, 0),
('country', 'NC', 0, 0),
('country', 'NE', 0, 0),
('country', 'NF', 0, 0),
('country', 'NG', 0, 0),
('country', 'NI', 0, 0),
('country', 'NL', 0, 0),
('country', 'NO', 0, 0),
('country', 'NP', 0, 0),
('country', 'NR', 0, 0),
('country', 'NU', 0, 0),
('country', 'NZ', 0, 0),
('country', 'OM', 0, 0),
('country', 'PA', 0, 0),
('country', 'PE', 0, 0),
('country', 'PF', 0, 0),
('country', 'PG', 0, 0),
('country', 'PH', 0, 0),
('country', 'PK', 0, 0),
('country', 'PL', 0, 0),
('country', 'PR', 0, 0),
('country', 'PS', 0, 0),
('country', 'PT', 0, 0),
('country', 'PW', 0, 0),
('country', 'PY', 0, 0),
('country', 'QA', 0, 0),
('country', 'RE', 0, 0),
('country', 'RO', 0, 0),
('country', 'RU', 0, 0),
('country', 'RW', 0, 0),
('country', 'SA', 0, 0),
('country', 'SB', 0, 0),
('country', 'SC', 0, 0),
('country', 'SD', 0, 0),
('country', 'SE', 0, 0),
('country', 'SG', 0, 0),
('country', 'SI', 0, 0),
('country', 'SK', 0, 0),
('country', 'SL', 0, 0),
('country', 'SM', 0, 0),
('country', 'SN', 0, 0),
('country', 'SO', 0, 0),
('country', 'SR', 0, 0),
('country', 'ST', 0, 0),
('country', 'SV', 0, 0),
('country', 'SY', 0, 0),
('country', 'SZ', 0, 0),
('country', 'TD', 0, 0),
('country', 'TF', 0, 0),
('country', 'TG', 0, 0),
('country', 'TH', 0, 0),
('country', 'TJ', 0, 0),
('country', 'TK', 0, 0),
('country', 'TL', 0, 0),
('country', 'TM', 0, 0),
('country', 'TN', 0, 0),
('country', 'TO', 0, 0),
('country', 'TR', 0, 0),
('country', 'TT', 0, 0),
('country', 'TV', 0, 0),
('country', 'TW', 0, 0),
('country', 'TZ', 0, 0),
('country', 'UA', 0, 0),
('country', 'UG', 0, 0),
('country', 'US', 0, 0),
('country', 'UY', 0, 0),
('country', 'UZ', 0, 0),
('country', 'VA', 0, 0),
('country', 'VC', 0, 0),
('country', 'VE', 0, 0),
('country', 'VG', 0, 0),
('country', 'VI', 0, 0),
('country', 'VN', 0, 0),
('country', 'VU', 0, 0),
('country', 'WS', 0, 0),
('country', 'YE', 0, 0),
('country', 'YT', 0, 0),
('country', 'YU', 0, 0),
('country', 'ZA', 0, 0),
('country', 'ZM', 0, 0),
('country', 'ZW', 0, 0),
('country', 'ZZ', 17, 1352876041),
('country', 'unkown', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_menu_menu`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_menu_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `menu_item` mediumtext NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_menu_rows`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_menu_rows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentid` int(11) unsigned NOT NULL,
  `mid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `link` text NOT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  `weight` int(11) NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `lev` int(11) NOT NULL DEFAULT '0',
  `subitem` mediumtext NOT NULL,
  `who_view` tinyint(2) NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL,
  `module_name` varchar(255) NOT NULL DEFAULT '',
  `op` varchar(255) NOT NULL DEFAULT '',
  `target` tinyint(4) NOT NULL DEFAULT '0',
  `css` varchar(255) NOT NULL DEFAULT '',
  `active_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_modfuncs`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_modfuncs` (
  `func_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `func_name` varchar(55) NOT NULL,
  `func_custom_name` varchar(255) NOT NULL,
  `in_module` varchar(55) NOT NULL,
  `show_func` tinyint(4) NOT NULL DEFAULT '0',
  `in_submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subweight` smallint(2) unsigned NOT NULL DEFAULT '1',
  `setting` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`func_id`),
  UNIQUE KEY `func_name` (`func_name`,`in_module`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=124 ;

--
-- Dumping data for table `nv3_vi_modfuncs`
--

INSERT INTO `nv3_vi_modfuncs` (`func_id`, `func_name`, `func_custom_name`, `in_module`, `show_func`, `in_submenu`, `subweight`, `setting`) VALUES
(1, 'Sitemap', 'Sitemap', 'about', 0, 0, 0, ''),
(2, 'main', 'Main', 'about', 1, 0, 1, ''),
(3, 'Sitemap', 'Sitemap', 'news', 0, 0, 0, ''),
(4, 'comment', 'Comment', 'news', 0, 0, 0, ''),
(5, 'content', 'Content', 'news', 1, 0, 1, ''),
(6, 'detail', 'Detail', 'news', 1, 0, 2, ''),
(7, 'main', 'Main', 'news', 1, 0, 3, ''),
(8, 'postcomment', 'Postcomment', 'news', 0, 0, 0, ''),
(9, 'print', 'Print', 'news', 0, 0, 0, ''),
(10, 'rating', 'Rating', 'news', 0, 0, 0, ''),
(11, 'rss', 'Rss', 'news', 0, 0, 0, ''),
(12, 'savefile', 'Savefile', 'news', 0, 0, 0, ''),
(13, 'search', 'Search', 'news', 1, 0, 4, ''),
(14, 'sendmail', 'Sendmail', 'news', 0, 0, 0, ''),
(15, 'topic', 'Topic', 'news', 1, 0, 5, ''),
(16, 'viewcat', 'Viewcat', 'news', 1, 0, 6, ''),
(17, 'active', 'Active', 'users', 1, 0, 8, ''),
(18, 'changepass', 'Đổi mật khẩu', 'users', 1, 1, 6, ''),
(19, 'editinfo', 'Editinfo', 'users', 1, 0, 10, ''),
(20, 'login', 'Đăng nhập', 'users', 1, 1, 2, ''),
(21, 'logout', 'Logout', 'users', 1, 1, 3, ''),
(22, 'lostactivelink', 'Lostactivelink', 'users', 1, 0, 9, ''),
(23, 'lostpass', 'Quên mật khẩu', 'users', 1, 1, 5, ''),
(24, 'main', 'Main', 'users', 1, 1, 1, ''),
(25, 'openid', 'Openid', 'users', 1, 1, 7, ''),
(26, 'register', 'Đăng ký', 'users', 1, 1, 4, ''),
(27, 'main', 'Main', 'contact', 1, 0, 1, ''),
(28, 'allbots', 'Máy chủ tìm kiếm', 'statistics', 1, 1, 6, ''),
(29, 'allbrowsers', 'Theo trình duyệt', 'statistics', 1, 1, 4, ''),
(30, 'allcountries', 'Theo quốc gia', 'statistics', 1, 1, 3, ''),
(31, 'allos', 'Theo hệ điều hành', 'statistics', 1, 1, 5, ''),
(32, 'allreferers', 'Theo đường dẫn đến site', 'statistics', 1, 1, 2, ''),
(33, 'main', 'Main', 'statistics', 1, 0, 1, ''),
(34, 'referer', 'Đường dẫn đến site theo tháng', 'statistics', 1, 0, 7, ''),
(35, 'main', 'Main', 'voting', 1, 0, 0, ''),
(36, 'addads', 'Addads', 'banners', 1, 0, 1, ''),
(37, 'cledit', 'Cledit', 'banners', 0, 0, 0, ''),
(38, 'click', 'Click', 'banners', 0, 0, 0, ''),
(39, 'clientinfo', 'Clientinfo', 'banners', 1, 0, 2, ''),
(40, 'clinfo', 'Clinfo', 'banners', 0, 0, 0, ''),
(41, 'logininfo', 'Logininfo', 'banners', 0, 0, 0, ''),
(42, 'main', 'Main', 'banners', 1, 0, 3, ''),
(43, 'stats', 'Stats', 'banners', 1, 0, 4, ''),
(44, 'viewmap', 'Viewmap', 'banners', 0, 0, 0, ''),
(45, 'adv', 'Adv', 'search', 0, 0, 0, ''),
(46, 'main', 'Main', 'search', 1, 0, 1, ''),
(47, 'main', 'Main', 'rss', 1, 0, 1, ''),
(48, 'regroups', 'Nhóm thành viên', 'users', 1, 0, 1, ''),
(50, 'groups', 'Groups', 'news', 1, 0, 7, ''),
(123, 'viewroom', 'Viewroom', 'archives', 1, 0, 4, ''),
(122, 'vieworgan', 'Vieworgan', 'archives', 1, 0, 6, ''),
(121, 'viewfield', 'Viewfield', 'archives', 1, 0, 5, ''),
(120, 'viewcat', 'Viewcat', 'archives', 1, 0, 3, ''),
(119, 'view', 'View', 'archives', 1, 0, 2, ''),
(118, 'search', 'Search', 'archives', 1, 0, 7, ''),
(117, 'main', 'Main', 'archives', 1, 0, 1, ''),
(116, 'down', 'Down', 'archives', 0, 0, 0, ''),
(115, 'content', 'Content', 'archives', 1, 0, 8, '');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_modthemes`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_modthemes` (
  `func_id` int(11) DEFAULT NULL,
  `layout` varchar(100) DEFAULT NULL,
  `theme` varchar(100) DEFAULT NULL,
  UNIQUE KEY `func_id` (`func_id`,`layout`,`theme`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_modthemes`
--

INSERT INTO `nv3_vi_modthemes` (`func_id`, `layout`, `theme`) VALUES
(0, 'body', 'mobile_nukeviet'),
(0, 'body-right', 'modern'),
(0, 'left-body-right', 'default'),
(0, 'left-body-right', 'phapluat2'),
(2, 'body', 'mobile_nukeviet'),
(2, 'body', 'modern'),
(2, 'left-body-right', 'default'),
(2, 'left-body-right', 'phapluat2'),
(5, 'body', 'mobile_nukeviet'),
(5, 'body-right', 'modern'),
(5, 'left-body-right', 'default'),
(5, 'left-body-right', 'phapluat2'),
(6, 'body', 'mobile_nukeviet'),
(6, 'body-right', 'modern'),
(6, 'left-body-right', 'default'),
(6, 'left-body-right', 'phapluat2'),
(7, 'body', 'mobile_nukeviet'),
(7, 'body-right', 'modern'),
(7, 'left-body-right', 'default'),
(7, 'left-body-right', 'phapluat2'),
(13, 'body', 'mobile_nukeviet'),
(13, 'body-right', 'modern'),
(13, 'left-body-right', 'default'),
(13, 'left-body-right', 'phapluat2'),
(15, 'body', 'mobile_nukeviet'),
(15, 'body-right', 'modern'),
(15, 'left-body-right', 'default'),
(15, 'left-body-right', 'phapluat2'),
(16, 'body', 'mobile_nukeviet'),
(16, 'body-right', 'modern'),
(16, 'left-body-right', 'default'),
(16, 'left-body-right', 'phapluat2'),
(17, 'body', 'mobile_nukeviet'),
(17, 'body-right', 'modern'),
(17, 'left-body-right', 'default'),
(17, 'left-body-right', 'phapluat2'),
(18, 'body', 'mobile_nukeviet'),
(18, 'body-right', 'modern'),
(18, 'left-body-right', 'default'),
(18, 'left-body-right', 'phapluat2'),
(19, 'body', 'mobile_nukeviet'),
(19, 'body-right', 'modern'),
(19, 'left-body-right', 'default'),
(19, 'left-body-right', 'phapluat2'),
(20, 'body', 'mobile_nukeviet'),
(20, 'body-right', 'modern'),
(20, 'left-body-right', 'default'),
(20, 'left-body-right', 'phapluat2'),
(21, 'body', 'mobile_nukeviet'),
(21, 'body-right', 'modern'),
(21, 'left-body-right', 'default'),
(21, 'left-body-right', 'phapluat2'),
(22, 'body', 'mobile_nukeviet'),
(22, 'body-right', 'modern'),
(22, 'left-body-right', 'default'),
(22, 'left-body-right', 'phapluat2'),
(23, 'body', 'mobile_nukeviet'),
(23, 'body-right', 'modern'),
(23, 'left-body-right', 'default'),
(23, 'left-body-right', 'phapluat2'),
(24, 'body', 'mobile_nukeviet'),
(24, 'body-right', 'modern'),
(24, 'left-body-right', 'default'),
(24, 'left-body-right', 'phapluat2'),
(25, 'body', 'mobile_nukeviet'),
(25, 'body-right', 'modern'),
(25, 'left-body-right', 'default'),
(25, 'left-body-right', 'phapluat2'),
(26, 'body', 'mobile_nukeviet'),
(26, 'body-right', 'modern'),
(26, 'left-body-right', 'default'),
(26, 'left-body-right', 'phapluat2'),
(27, 'body', 'mobile_nukeviet'),
(27, 'body-right', 'modern'),
(27, 'left-body-right', 'default'),
(27, 'left-body-right', 'phapluat2'),
(28, 'body', 'mobile_nukeviet'),
(28, 'body', 'modern'),
(28, 'left-body', 'default'),
(28, 'left-body', 'phapluat2'),
(29, 'body', 'mobile_nukeviet'),
(29, 'body', 'modern'),
(29, 'left-body', 'default'),
(29, 'left-body', 'phapluat2'),
(30, 'body', 'mobile_nukeviet'),
(30, 'body', 'modern'),
(30, 'left-body', 'default'),
(30, 'left-body', 'phapluat2'),
(31, 'body', 'mobile_nukeviet'),
(31, 'body', 'modern'),
(31, 'left-body', 'default'),
(31, 'left-body', 'phapluat2'),
(32, 'body', 'mobile_nukeviet'),
(32, 'body', 'modern'),
(32, 'left-body', 'default'),
(32, 'left-body', 'phapluat2'),
(33, 'body', 'mobile_nukeviet'),
(33, 'body', 'modern'),
(33, 'left-body', 'default'),
(33, 'left-body', 'phapluat2'),
(34, 'body', 'mobile_nukeviet'),
(34, 'body', 'modern'),
(34, 'left-body', 'default'),
(34, 'left-body', 'phapluat2'),
(35, 'body', 'mobile_nukeviet'),
(35, 'body-right', 'modern'),
(35, 'left-body-right', 'default'),
(35, 'left-body-right', 'phapluat2'),
(36, 'body', 'mobile_nukeviet'),
(36, 'body-right', 'modern'),
(36, 'left-body-right', 'default'),
(36, 'left-body-right', 'phapluat2'),
(39, 'body', 'mobile_nukeviet'),
(39, 'body-right', 'modern'),
(39, 'left-body-right', 'default'),
(39, 'left-body-right', 'phapluat2'),
(42, 'body', 'mobile_nukeviet'),
(42, 'body-right', 'modern'),
(42, 'left-body-right', 'default'),
(42, 'left-body-right', 'phapluat2'),
(43, 'body', 'mobile_nukeviet'),
(43, 'body-right', 'modern'),
(43, 'left-body-right', 'default'),
(43, 'left-body-right', 'phapluat2'),
(46, 'body', 'mobile_nukeviet'),
(46, 'body-right', 'modern'),
(46, 'left-body-right', 'default'),
(46, 'left-body-right', 'phapluat2'),
(47, 'body', 'mobile_nukeviet'),
(47, 'body', 'modern'),
(47, 'left-body-right', 'default'),
(47, 'left-body-right', 'phapluat2'),
(48, 'body', 'mobile_nukeviet'),
(48, 'body-right', 'modern'),
(48, 'left-body-right', 'default'),
(48, 'left-body-right', 'phapluat2'),
(50, 'body', 'mobile_nukeviet'),
(50, 'body-right', 'modern'),
(50, 'left-body-right', 'default'),
(50, 'left-body-right', 'phapluat2'),
(115, 'body', 'mobile_nukeviet'),
(115, 'body-right', 'modern'),
(115, 'left-body-right', 'default'),
(115, 'left-body-right', 'phapluat2'),
(117, 'body', 'mobile_nukeviet'),
(117, 'body-right', 'modern'),
(117, 'left-body-right', 'default'),
(117, 'left-body-right', 'phapluat2'),
(118, 'body', 'mobile_nukeviet'),
(118, 'body-right', 'modern'),
(118, 'left-body-right', 'default'),
(118, 'left-body-right', 'phapluat2'),
(119, 'body', 'mobile_nukeviet'),
(119, 'body-right', 'modern'),
(119, 'left-body-right', 'default'),
(119, 'left-body-right', 'phapluat2'),
(120, 'body', 'mobile_nukeviet'),
(120, 'body-right', 'modern'),
(120, 'left-body-right', 'default'),
(120, 'left-body-right', 'phapluat2'),
(121, 'body', 'mobile_nukeviet'),
(121, 'body-right', 'modern'),
(121, 'left-body-right', 'default'),
(121, 'left-body-right', 'phapluat2'),
(122, 'body', 'mobile_nukeviet'),
(122, 'body-right', 'modern'),
(122, 'left-body-right', 'default'),
(122, 'left-body-right', 'phapluat2'),
(123, 'body', 'mobile_nukeviet'),
(123, 'body-right', 'modern'),
(123, 'left-body-right', 'default'),
(123, 'left-body-right', 'phapluat2');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_modules`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_modules` (
  `title` varchar(55) NOT NULL,
  `module_file` varchar(55) NOT NULL DEFAULT '',
  `module_data` varchar(55) NOT NULL DEFAULT '',
  `custom_title` varchar(255) NOT NULL,
  `admin_title` varchar(255) NOT NULL,
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  `main_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admin_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `theme` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `keywords` mediumtext NOT NULL,
  `groups_view` varchar(255) NOT NULL,
  `in_menu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admins` varchar(255) NOT NULL,
  `rss` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_modules`
--

INSERT INTO `nv3_vi_modules` (`title`, `module_file`, `module_data`, `custom_title`, `admin_title`, `set_time`, `main_file`, `admin_file`, `theme`, `mobile`, `keywords`, `groups_view`, `in_menu`, `weight`, `submenu`, `act`, `admins`, `rss`) VALUES
('about', 'about', 'about', 'Giới thiệu', '', 1276333182, 1, 1, '', 'mobile_nukeviet', '', '0', 1, 2, 1, 1, '', 0),
('news', 'news', 'news', 'Trang chủ', '', 1270400000, 1, 1, '', 'mobile_nukeviet', '', '0', 1, 1, 1, 1, '', 1),
('users', 'users', 'users', 'Thành viên', 'Tài khoản', 1274080277, 1, 1, '', 'mobile_nukeviet', '', '0', 1, 4, 1, 1, '', 0),
('contact', 'contact', 'contact', 'Liên hệ', '', 1275351337, 1, 1, '', 'mobile_nukeviet', '', '0', 1, 5, 1, 1, '', 0),
('statistics', 'statistics', 'statistics', 'Thống kê', '', 1276520928, 1, 0, '', 'mobile_nukeviet', 'truy cập, online, statistics', '0', 1, 6, 1, 1, '', 0),
('voting', 'voting', 'voting', 'Thăm dò ý kiến', '', 1275315261, 1, 1, '', 'mobile_nukeviet', '', '0', 0, 7, 1, 1, '', 1),
('banners', 'banners', 'banners', 'Quảng cáo', '', 1270400000, 1, 1, '', 'mobile_nukeviet', '', '0', 0, 8, 1, 1, '', 0),
('search', 'search', 'search', 'Tìm kiếm', '', 1273474173, 1, 0, '', 'mobile_nukeviet', '', '0', 0, 9, 1, 1, '', 0),
('menu', 'menu', 'menu', 'Menu Site', '', 1295287334, 0, 1, '', 'mobile_nukeviet', '', '0', 0, 10, 1, 1, '', 0),
('rss', 'rss', 'rss', 'Sơ đồ site', '', 1279366705, 1, 1, '', 'mobile_nukeviet', '', '0', 1, 11, 10, 1, '', 0),
('archives', 'archives', 'archives', 'Văn bản pháp luật', '', 1351506920, 1, 1, '', '', '', '0', 1, 3, 1, 1, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_23`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_23` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `nv3_vi_news_23`
--

INSERT INTO `nv3_vi_news_23` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`, `keywords`) VALUES
(11, 31, '23,31', 0, 1, '', 0, 1351408478, 1351436954, 1, 1351408478, 0, 2, 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Nhung-van-de-can-luu-y-khi-thuc-hien-thu-tuc-dang-ky-kinh-doanh', 'BRANDCO - Để giúp các bạn khởi sự kinh doanh nhanh chóng và thuận lợi. Brandco xin cung cấp cho quý khách hàng một số vấn đề cần lưu ý khi thực hiện thủ tục đăng ký doanh nghiệp theo Luật Doanh nghiệp năm 2005.', '2012_10/dkkd.jpeg', '', 'thumb/dkkd.jpeg.jpg|block/dkkd.jpeg.jpg', 1, 2, 1, 1, 0, 5, 1, 'khởi sự,kinh doanh,nhanh chóng,thuận lợi,quý khách,vấn đề,lưu ý,thực hiện,thủ tục,đăng ký,doanh nghiệp'),
(14, 32, '23,32', 0, 1, '', 0, 1351421497, 1351421554, 1, 1351421497, 0, 2, 'Công ty luật Brandco&#x3A; Xin giấy phép đầu tư&#33;', 'Cong-ty-luat-Brandco-Xin-giay-phep-dau-tu', 'BRANDCO - Công ty Luật Brandco  tự hào là công ty hàng đầu trong lĩnh vực tư vấn đầu tư và cung cấp các dịch vụ hỗ trợ các nhà đầu tư tại việt nam như: tư vấn thành lập doanh nghiệp liên doanh, công ty 100% vốn nước ngoài, tư vấn lập dự án đầu tư (dự án tiền khả thi và dự án khả thi), tư vấn thủ tục xin ưu đãi đầu tư....', '2012_10/dau-tu.jpg', '', 'thumb/dau-tu.jpg|block/dau-tu.jpg', 1, 2, 1, 0, 0, 0, 0, 'công ty,tự hào,hàng đầu,lĩnh vực,tư vấn,hỗ trợ,thành lập,doanh nghiệp,liên doanh,dự án,khả thi,thủ tục'),
(12, 31, '23,31', 0, 1, '', 0, 1351421031, 1351437155, 1, 1351421031, 0, 2, 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Cong-ty-luat-Brandco-Dich-vu-thanh-lap-doanh-nghiep', 'BRANDCO -  Là nhà tư vấn chuyên nghiệp trong lĩnh vực tư vấn đầu tư và tư vấn sở hữu trí tuệ, với nhiều năm kinh nghiệm phục vụ khách hàng, Công ty luật Brandco xin được giới thiệu tới rộng rãi các nhà đầu tư dịch vụ tư vấn thành lập doanh nghiệp do Công ty luật Brandco cung cấp.', '2012_10/thanhlapdoanhnghiep.jpeg', '', 'thumb/thanhlapdoanhnghiep.jpeg.jpg|block/thanhlapdoanhnghiep.jpeg.jpg', 1, 2, 1, 0, 0, 0, 0, 'tư vấn,lĩnh vực,sở hữu,trí tuệ,kinh nghiệm,phục vụ,khách hàng,công ty,giới thiệu,rộng rãi,thành lập,doanh nghiệp'),
(13, 31, '23,31', 0, 1, '', 0, 1351421252, 1351421641, 1, 1351421252, 0, 2, 'Công ty luật Brandco&#x3A; Đặc điểm của các loại hình các loại hình doanh nghiệp&#33;', 'Cong-ty-luat-Brandco-Dac-diem-cua-cac-loai-hinh-cac-loai-hinh-doanh-nghiep', 'BRANDCO - Để giúp các bạn khởi sự kinh doanh nhanh chóng và thuận lợi. Brandco xin cung cấp cho quý khách hàng một số kiến thức về sự khác nhau giữa các loại hình doanh nghiệp, để quý khách có được sự lựa chọn tốt nhất', '2012_10/doanh-nghiep.jpeg', '', 'thumb/doanh-nghiep.jpeg.jpg|block/doanh-nghiep.jpeg.jpg', 1, 2, 1, 1, 0, 0, 0, 'khởi sự,kinh doanh,nhanh chóng,thuận lợi,quý khách,kiến thức,loại hình,doanh nghiệp'),
(15, 32, '23,32', 0, 1, '', 0, 1351421742, 1351421742, 1, 1351421742, 0, 2, 'Thành lập văn phòng đại diên của doanh nghiệp nước ngoài&#33;&#33;&#33;', 'Thanh-lap-van-phong-dai-dien-cua-doanh-nghiep-nuoc-ngoai', 'BRANDCO -  Sau sự kiện Việt Nam tham gia vào WTO ngày càng có nhiều thương nhân nước ngoài đến Việt Nam để tìm hiểu môi trường đầu tư, xúc tiến các hoạt động kinh doanh. Là nhà tư vấn chuyên nghiệp trong lĩnh vực doanh nghiệp – thương mại – kinh tế, công ty luật  Brandco xin cung cấp tới quý khách hàng  về điều kiện cấp phép thành lập văn phòng đại diện của thương nhân nước ngoài tại Việt Nam.', '2012_10/vanphongdaidien.jpg', '', 'thumb/vanphongdaidien.jpg|block/vanphongdaidien.jpg', 1, 2, 1, 1, 0, 0, 0, 'sự kiện,tham gia,ngày càng,tìm hiểu,môi trường,xúc tiến,hoạt động,kinh doanh,tư vấn,lĩnh vực,doanh nghiệp,thương mại,kinh tế,công ty,quý khách,thành lập,văn phòng,đại diện'),
(16, 23, '23,32', 0, 1, '', 0, 1351421861, 1351438317, 1, 1351438200, 0, 2, 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 'Tu-van-xin-chung-nhan-dau-tu-thanh-lap-cong-ty-lien-doanh-cong-ty-100-von-dau-tu-nuoc-ngoai-ve-phan-phoi', 'BRANDCO LAWFIRM - Công ty Luật Brandco  tự hào là công ty hàng đầu trong lĩnh vực tư vấn đầu tư và cung cấp các dịch vụ hỗ trợ các nhà đầu tư tại việt nam như: tư vấn thành lập doanh nghiệp liên doanh, công ty 100% vốn nước ngoài, tư vấn lập dự án đầu tư (dự án tiền khả thi và dự án khả thi), tư vấn thủ tục xin ưu đãi đầu tư....', '2012_10/dau-tu.jpeg', '', 'thumb/dau-tu.jpeg.jpg|block/dau-tu.jpeg.jpg', 1, 2, 1, 2, 0, 0, 0, 'công ty,tự hào,hàng đầu,lĩnh vực,tư vấn,hỗ trợ,thành lập,doanh nghiệp,liên doanh,dự án,khả thi,thủ tục'),
(17, 33, '23,33', 0, 1, '', 0, 1351436724, 1351436724, 1, 1351436724, 0, 2, 'Tư vấn thành lập, tổ chức, quản lý doanh nghiệp theo mô hình tập đoàn kinh tế', 'Tu-van-thanh-lap-to-chuc-quan-ly-doanh-nghiep-theo-mo-hinh-tap-doan-kinh-te', 'BRANDCO LAWFIRM - Pháp luật hiện hành đã quy định rất cụ thể về việc thành lập ra các tập đoàn kinh tế nhà nước, cụ thể nhất là quy định tại Số: 101/2009/NĐ-CP ngày 05/11/2009 của chính phủ. Tuy nhiên, việc thành lập các tập đoàn kinh tế theo mô hình &quot; Công ty mẹ - Công ty con&quot; đối với khối Doanh nghiệp dân doanh lại chưa được ghi nhận.', '2012_10/to-chuc-doanh-nghiep.jpg', '', 'thumb/to-chuc-doanh-nghiep.jpg|block/to-chuc-doanh-nghiep.jpg', 1, 2, 1, 1, 0, 0, 0, 'pháp luật,hiện hành,quy định,cụ thể,thành lập,tập đoàn,kinh tế,nhà nước,nhất là,tuy nhiên,mô hình,công ty,doanh nghiệp'),
(18, 23, '23,33', 0, 1, '', 0, 1351436786, 1351436889, 1, 1351436786, 0, 2, 'Tái cơ cấu&#x3A; Sáng tạo để tiếp tục đổi mới', 'Tai-co-cau-Sang-tao-de-tiep-tuc-doi-moi', 'BRANDCO LAWFIRM  - Hơn hai mươi năm trước, chúng ta đã thực hiện cấu trúc lại nền kinh tế để tạo nên kỳ tích đổi mới. Bây giờ, đổi mới vẫn được tiếp tục nhưng cần được đặt trên một lộ trình mới. Tái cấu trúc nền kinh tế chính là tiếp tục thúc đẩy tiến trình đổi mới, để đạt được thành quả cao và hưởng lợi nhiều hơn từ đổi mới.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'thực hiện,kinh tế,kỳ tích,bây giờ,tiếp tục,lộ trình,thúc đẩy,tiến trình,thành quả');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_24`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_24` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `nv3_vi_news_24`
--

INSERT INTO `nv3_vi_news_24` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`, `keywords`) VALUES
(19, 34, '24,34', 0, 1, '', 0, 1351437291, 1351437291, 1, 1351437291, 0, 2, 'Công ty luật Brandco&#x3A; Dịch vụ đăng ký bảo hộ quyền tác giả.', 'Cong-ty-luat-Brandco-Dich-vu-dang-ky-bao-ho-quyen-tac-gia', 'BRANDCO - Bảo hộ quyền tác giả là một trong những phương thức hiệu quả để thúc đẩy và phổ biến trí thức quốc gia. Sự phát triển của một đất nước phụ thuộc chủ yếu vào hoạt động sáng tạo của người dân và việc khuyến khích sáng tạo cá nhân và phổ biến cập nhật các sáng tạo đó sẽ là tiền đề đối với quá trính phát triển.', '2012_10/hanggia.jpg', '', 'thumb/hanggia.jpg|block/hanggia.jpg', 1, 2, 1, 1, 0, 0, 0, 'bảo hộ,tác giả,phương thức,hiệu quả,thúc đẩy,phổ biến,trí thức,quốc gia,phát triển,phụ thuộc,chủ yếu,hoạt động,sáng tạo,khuyến khích,cá nhân,tiền đề'),
(20, 34, '24,34', 0, 1, '', 0, 1351437427, 1351437427, 1, 1351437427, 0, 2, 'Công ty luật Brandco&#x3A; Đăng ký bảo hộ độc quyền sáng chế&#33;', 'Cong-ty-luat-Brandco-Dang-ky-bao-ho-doc-quyen-sang-che', 'BRANDCO – Sáng chế, một đối tượng quan trọng cơ bản của quyền sở hữu trí tuệ, một tài sản vô hình vô cùng quan trọng đối với mỗi doanh nghiệp. Tuy nhiên, ở Việt nam hiện nay vấn đề bảo hộ độc quyền các ý tưởng sáng tạo đối với sáng chế đang bị coi nhẹ. Công ty Luật Brandco, với tư cách là một chuyên gia hàng đầu về bảo hộ độc quyền sáng chế, xin được chia sẻ với các bạn một số kinh nghiệm liên quan để bảo vệ quyền hợp pháp của mình với loại tài sản đặc biệt này', '2012_10/sang-che.jpg', '', 'thumb/sang-che.jpg|block/sang-che.jpg', 1, 2, 1, 1, 0, 0, 0, 'sáng chế,quan trọng,cơ bản,sở hữu,trí tuệ,tài sản,vô hình,doanh nghiệp,tuy nhiên,hiện nay,vấn đề,bảo hộ,ý tưởng,sáng tạo,công ty,tư cách,chuyên gia,hàng đầu,kinh nghiệm,liên quan,bảo vệ'),
(21, 34, '24,34', 0, 1, '', 0, 1351437554, 1351437554, 1, 1351437554, 0, 2, 'Công ty luật Brandco&#x3A; Dịch vụ Bảo hộ Kiểu dáng công nghiệp', 'Cong-ty-luat-Brandco-Dich-vu-Bao-ho-Kieu-dang-cong-nghiep', 'BRANDCO - Kiểu dáng công nghiệp, một đối tượng quan trọng cơ bản của quyền sở hữu trí tuệ, một tài sản vô hình vô cùng quan trọng đối với mỗi doanh nghiệp sản xuất. Công ty Luật Brandco, với tư cách là một chuyên gia hàng đầu về bảo hộ độc quyền kiểu dáng công nghiệp, xin được chia sẻ với các bạn một số kinh nghiệm liên quan để bảo vệ quyền hợp pháp của mình với loại tài sản đặc biệt này.', '2012_10/xemay.jpg', '', 'thumb/xemay.jpg|block/xemay.jpg', 1, 2, 1, 1, 0, 0, 0, 'công nghiệp,quan trọng,cơ bản,sở hữu,trí tuệ,tài sản,vô hình,doanh nghiệp,sản xuất,công ty,tư cách,chuyên gia,hàng đầu,bảo hộ,kinh nghiệm,liên quan,bảo vệ,hợp pháp,đặc biệt'),
(22, 35, '24,35', 0, 1, '', 0, 1351437917, 1351437917, 1, 1351437917, 0, 2, 'Khiếu nại &amp; xử lý vi phạm quyền sở hữu trí tuệ', 'Khieu-nai-xu-ly-vi-pham-quyen-so-huu-tri-tue', 'BRANDCO - Hãng luật Brandco là một hãng tư vấn luật thành công nhất ở Việt Nam trong việc phối hợp có hiệu quả với các cơ quan có thẩm quyền Việt Nam tiến hành các biện pháp thực thi quyền chống lại vi phạm quyền nhãn hiệu hàng hoá, kiểu dáng công nghiệp, bản quyền tác giả và sáng chế để đảm bảo rằng quyền sở hữu trí tuệ của Quý doanh nghiệp được bảo hộ, thực thi phù hợp với mục tiêu và chiến lược của họ trên thị trường.', '2012_10/xulyviphamshtt.jpg', '', 'thumb/xulyviphamshtt.jpg|block/xulyviphamshtt.jpg', 1, 2, 1, 1, 0, 0, 0, 'tư vấn,thành công,phối hợp,hiệu quả,cơ quan,thẩm quyền,tiến hành,biện pháp,vi phạm,nhãn hiệu,công nghiệp,bản quyền,tác giả,sáng chế,đảm bảo,sở hữu,trí tuệ,doanh nghiệp,bảo hộ,phù hợp,mục tiêu');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_25`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_25` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `nv3_vi_news_25`
--

INSERT INTO `nv3_vi_news_25` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`, `keywords`) VALUES
(23, 37, '25,37', 0, 1, '', 0, 1351438502, 1351438502, 1, 1351438502, 0, 2, 'Tư vấn soạn thảo quy chế, nội quy lao động của doanh nghiệp', 'Tu-van-soan-thao-quy-che-noi-quy-lao-dong-cua-doanh-nghiep', 'BRANDCO LAW FIRM - Ngày nay, kinh tế của Việt Nam ngày càng phát triển, các doanh nghiệp nước ngoài vào Việt Nam và các doanh nghiệp trong nước được thành lập ngày càng nhiều do đó mối qua hệ giữa người lao động và người sử dụng lao động ngày càng phức tạp, nảy sinh những trang chấp trong quan hệ lao động giữa người sử dụng lao động và người lao động.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'ngày nay,kinh tế,ngày càng,phát triển,doanh nghiệp,thành lập,lao động,sử dụng,phức tạp,nảy sinh,quan hệ'),
(24, 37, '25,37', 0, 1, '', 0, 1351484608, 1351484608, 1, 1351484608, 0, 2, 'Công ty Luật Brandco&#x3A; Dịch vụ tư vấn hợp đồng', 'Cong-ty-Luat-Brandco-Dich-vu-tu-van-hop-dong', 'BRANDCO - Là Hãng luật hàng đầu trong lĩnh vực tư vấn đầu tư và tư vấn Sở hữu trí tuệ, hãng luật Brandco xin giới thiệu với Quý doanh nghiệp các dịch vụ pháp lý liên quan tới các hợp đồng, bao gồm việc chuẩn bị cơ sở pháp lý, đàm phán, soạn thảo và hiệu chỉnh các loại hợp đồng kinh tế, thương mại, đầu tư….', '2012_10/tu-van-hop-dong.jpeg', '', 'thumb/tu-van-hop-dong.jpeg.jpg|block/tu-van-hop-dong.jpeg.jpg', 1, 2, 1, 0, 0, 0, 0, 'hàng đầu,lĩnh vực,tư vấn,sở hữu,trí tuệ,giới thiệu,doanh nghiệp,pháp lý,liên quan,hợp đồng,bao gồm,chuẩn bị,cơ sở,đàm phán,soạn thảo,kinh tế,thương mại'),
(25, 37, '25,37', 0, 1, '', 0, 1351484700, 1351484700, 1, 1351484700, 0, 2, 'Tư vấn về thừa kế tài sản theo quy định của bộ luật dân sự', 'Tu-van-ve-thua-ke-tai-san-theo-quy-dinh-cua-bo-luat-dan-su', 'BRANDCO LAW FIRM - Pháp luật Việt nam khẳng định quyền được thừa kế của mọi cá nhân, tổ chức theo quy định tại Điều 631, Bộ luật Dân sự, cụ thể: “Cá nhân có quyền lập di chúc để định đoạt tài sản của mình; để lại tài sản của mình cho người thừa kế theo pháp luật; hưởng di sản theo di chúc hoặc theo pháp luật&quot; - Luật sư Nguyễn Văn Thi', '2012_10/dich-vu-thua-ke.jpg', '', 'thumb/dich-vu-thua-ke.jpg|block/dich-vu-thua-ke.jpg', 1, 2, 1, 0, 0, 0, 0, 'pháp luật,khẳng định,thừa kế,cá nhân,tổ chức,quy định,dân sự,cụ thể,di chúc,tài sản,di sản,luật sư'),
(26, 38, '25,38', 0, 1, '', 0, 1351484820, 1351484820, 1, 1351484820, 0, 2, 'Tư vấn xin giấy phép sản xuất thuốc lá', 'Tu-van-xin-giay-phep-san-xuat-thuoc-la', 'BRANDCO - Trình tự thủ tục và thẩm quyền cấp giấy phép trong lĩnh vực sản xuất thuốc lá.', '2012_10/thuocla.jpg', '', 'thumb/thuocla.jpg|block/thuocla.jpg', 1, 2, 1, 0, 0, 0, 0, 'trình tự,thủ tục,thẩm quyền,giấy phép,lĩnh vực,sản xuất'),
(27, 38, '25,38', 0, 1, '', 0, 1351484905, 1351485526, 1, 1351484905, 0, 2, 'Tư vấn xin giấy phép hoạt động điện lực', 'Tu-van-xin-giay-phep-hoat-dong-dien-luc', 'BRANDCO - Nội dung công việc các luật sư của chúng tôi cam kết tiến hành:', '2012_10/dien1.jpg', '', 'thumb/dien1.jpg|block/dien1.jpg', 1, 2, 1, 0, 0, 0, 0, 'nội dung,luật sư,cam kết'),
(28, 38, '25,38', 0, 1, '', 0, 1351485646, 1351485646, 1, 1351485646, 0, 2, 'Quy định về việc thu, nộp, quản lý và sử dụng phí bán đấu giá cổ phần', 'Quy-dinh-ve-viec-thu-nop-quan-ly-va-su-dung-phi-ban-dau-gia-co-phan', 'BRANDCO - Ngày 27/4/2009, Bộ Tài chính đã ban hành Thông tư số 82/2009/TT-BTC Quy định về mức thu, chế độ thu, nộp, quản lý và sử dụng phí bán đấu giá cổ phần', '', '', '', 1, 2, 1, 1, 0, 0, 0, 'tài chính,ban hành,thông tư,quy định,chế độ,quản lý,sử dụng,đấu giá'),
(29, 39, '25,39', 0, 1, '', 0, 1351485834, 1351485834, 1, 1351485834, 0, 2, 'Thủ tục thanh toán chi phí khám bệnh, chữa bệnh đối với người tham gia bảo hiểm y tế bị tai nạn giao thông', 'Thu-tuc-thanh-toan-chi-phi-kham-benh-chua-benh-doi-voi-nguoi-tham-gia-bao-hiem-y-te-bi-tai-nan-giao-thong', 'BRANDCO LAWFIRM - Liên Bộ Tài chính, Bộ Y tế vừa ban hành Thông tư liên tịch số 39/2011/TTLT-BYT-BTC hướng dẫn thủ tục thanh toán chi phí khám bệnh, chữa bệnh đối với người tham gia bảo hiểm y tế bị tai nạn giao thông.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'liên bộ,tài chính,y tế,ban hành,thông tư,liên tịch,hướng dẫn,thủ tục,thanh toán,chi phí,khám bệnh,tham gia,bảo hiểm,tai nạn'),
(30, 39, '25,39', 0, 1, '', 0, 1351485905, 1351485905, 1, 1351485905, 0, 2, 'Rút ngắn thời gian cấp Giấy miễn thị thực xuống 5 ngày', 'Rut-ngan-thoi-gian-cap-Giay-mien-thi-thuc-xuong-5-ngay', 'BRANDCO LAWFIRM - Thủ tướng Chính phủ vừa ban hành Quyết định sửa đổi, bổ sung một số điều Quy chế về miễn thị thực cho người Việt Nam định cư ở nước ngoài (Quyết định số 10/2012/QĐ-TTg).', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'thủ tướng,ban hành,quyết định,sửa đổi,bổ sung,quy chế,thị thực,định cư'),
(31, 39, '25,39', 0, 1, '', 0, 1351485981, 1351485981, 1, 1351485981, 0, 2, 'Hướng dẫn quyết toán thuế thu nhập cá nhân năm 2011', 'Huong-dan-quyet-toan-thue-thu-nhap-ca-nhan-nam-2011', 'BRANDCO LAWFIRM - Tổng cục Thuế vừa có Công văn hướng dẫn một số điểm về quyết toán thuế Thu nhập cá nhân năm 2011.', '2012_10/1394335.jpg', '', 'thumb/1394335.jpg|block/1394335.jpg', 1, 2, 1, 1, 0, 0, 0, 'tổng cục,công văn,hướng dẫn,quyết toán,thu nhập,cá nhân');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_26`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_26` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `nv3_vi_news_26`
--

INSERT INTO `nv3_vi_news_26` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`, `keywords`) VALUES
(32, 26, '26', 0, 1, '', 0, 1351486200, 1351486200, 1, 1351486200, 0, 2, 'Phân biệt về dịch vụ Kê khai thuế qua mạng và Chữ ký số', 'Phan-biet-ve-dich-vu-Ke-khai-thue-qua-mang-va-Chu-ky-so', 'BRANDCO LAWFIRM - Công ty Luật Brandco là công ty tư vấn hàng đầu trong lĩnh vực tư vấn đầu tư, tư vấn tài chính kế toán, hoàn thiện tờ khai, dọn dẹp sổ sách kế toán và báo cáo tài chính kế toán năm ….cho hàng ngàn lượt doanh nghiệp tại Việt nam', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'công ty,tư vấn,hàng đầu,lĩnh vực,tài chính,kế toán,hoàn thiện,sổ sách,báo cáo,doanh nghiệp'),
(33, 26, '26', 0, 1, '', 0, 1351486248, 1351486248, 1, 1351486248, 0, 2, 'Khấu trừ, hoàn thuế GTGT đối với trường hợp Gđốc hoặc Tổng gđốc của Cty không được đồng thời làm Gđốc hoặc Tổng gđốc của DN khác', 'Khau-tru-hoan-thue-GTGT-doi-voi-truong-hop-Gdoc-hoac-Tong-gdoc-cua-Cty-khong-duoc-dong-thoi-lam-Gdoc-hoac-Tong-gdoc-cua-DN-khac', 'BRANDCO LAWFIRM - Công ty Luật Brandco là công ty tư vấn hàng đầu trong lĩnh vực tư vấn đầu tư, tư vấn tài chính kế toán, hoàn thiện tờ khai, dọn dẹp sổ sách kế toán và báo cáo tài chính kế toán năm ….cho hàng ngàn lượt doanh nghiệp tại Việt nam.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'công ty,tư vấn,hàng đầu,lĩnh vực,tài chính,kế toán,hoàn thiện,sổ sách,báo cáo,doanh nghiệp'),
(34, 26, '26', 0, 1, '', 0, 1351486288, 1351486288, 1, 1351486288, 0, 2, 'Từ 1&#x002F;1&#x002F;2012&#x3A; Cơ quan Thuế không bán hóa đơn cho doanh nghiệp', 'Tu-1-1-2012-Co-quan-Thue-khong-ban-hoa-don-cho-doanh-nghiep', 'BRANDCO LAWFIRM - Công ty Luật Brandco là công ty tư vấn hàng đầu trong lĩnh vực tư vấn đầu tư, tư vấn tài chính kế toán, hoàn thiện tờ khai, dọn dẹp sổ sách kế toán và báo cáo tài chính kế toán năm ….cho hàng ngàn lượt doanh nghiệp tại Việt nam.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'công ty,tư vấn,hàng đầu,lĩnh vực,tài chính,kế toán,hoàn thiện,sổ sách,báo cáo,doanh nghiệp');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_27`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_27` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `nv3_vi_news_27`
--

INSERT INTO `nv3_vi_news_27` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`, `keywords`) VALUES
(35, 40, '27,40', 0, 1, '', 0, 1351498289, 1351498289, 1, 1351498289, 0, 2, 'Lương tối thiểu dự kiến tăng 35&#x25;', 'Luong-toi-thieu-du-kien-tang-35', 'BRANDCO LAWFIRM - Lương tối thiểu dự kiến tăng 35% Từ 1/1/2013, lương tối thiểu vùng tại mọi loại hình doanh nghiệp có thể tăng 700.000 đồng lên mức cao nhất 2,7 triệu đồng một tháng, theo đề xuất của Bộ Lao động Thương binh và Xã hội.', '2012_10/luongtoithieu.jpg', '', 'thumb/luongtoithieu.jpg|block/luongtoithieu.jpg', 1, 2, 1, 0, 0, 0, 0, 'tối thiểu,loại hình,doanh nghiệp,có thể,lao động,thương binh'),
(36, 40, '27,40', 0, 1, '', 0, 1351498364, 1351498364, 1, 1351498364, 0, 2, 'Miễn, giảm thuế sử dụng đất phi nông nghiệp', 'Mien-giam-thue-su-dung-dat-phi-nong-nghiep', 'BRANDCO LAWFIRM - Bộ Tài chính vừa ban hành văn bản số 11850/BTC-TCT tháo gỡ những vướng mắc cho cơ quan Thuế địa phương trong việc thực hiện chính sách miễn, giảm tiền thuế sử dụng đất phi nông nghiệp.', '2012_10/03_dool_tt_091203_p4_1.jpg', '', 'thumb/03_dool_tt_091203_p4_1.jpg|block/03_dool_tt_091203_p4_1.jpg', 1, 2, 1, 0, 0, 0, 0, 'tài chính,ban hành,cơ quan,thực hiện,sử dụng'),
(37, 40, '27,40', 0, 1, '', 0, 1351498432, 1351498432, 1, 1351498432, 0, 2, 'Thuế TNDN từ chuyển nhượng bất động sản được xác định theo giá hợp đồng', 'Thue-TNDN-tu-chuyen-nhuong-bat-dong-san-duoc-xac-dinh-theo-gia-hop-dong', 'BRANDCO LAWFIRM - Theo quy định của Bộ Tài chính, bắt đầu từ ngày 10-9-2012 sẽ thực hiện đánh thuế thu nhập DN đối với một số DN có thu nhập từ chuyển nhượng bất động sản.', '2012_10/bat_dong_.jpg', '', 'thumb/bat_dong_.jpg|block/bat_dong_.jpg', 1, 2, 1, 0, 0, 0, 0, 'quy định,tài chính,bắt đầu,thực hiện,đánh thuế,thu nhập,bất động'),
(38, 41, '27,41', 0, 1, '', 0, 1351499047, 1351499047, 1, 1351499047, 0, 2, 'Không biến hợp tác xã thành mô hình tự cung tự cấp', 'Khong-bien-hop-tac-xa-thanh-mo-hinh-tu-cung-tu-cap', 'BRANDCO LAWFIRM -  Hợp tác xã được tổ chức hoạt động không chỉ vì lợi ích kinh tế mà còn có cả lợi ích xã hội. Do đó, cần tăng cường quan hệ kinh tế trong hợp tác xã, không biến hợp tác xã trở thành mô hình tự cung tự cấp. Điều này đòi hỏi cần minh bạch hóa các nguồn vốn, xác lập lại cổ phần xã viên, tư cách xã viên và chú trọng hơn đến công nghiệp chế biến và dịch vụ tiêu thụ sản phẩm, khuyến khích phát triển mới những hợp tác xã thương mại, dịch vụ đa ngành.', '2012_10/htx.jpg', '', 'thumb/htx.jpg|block/htx.jpg', 1, 2, 1, 0, 0, 0, 0, 'hợp tác xã,tổ chức,hoạt động,lợi ích,kinh tế,xã hội,tăng cường,quan hệ,trở thành,mô hình,tự cung,tự cấp,minh bạch,cổ phần,tư cách,công nghiệp,chế biến,tiêu thụ,sản phẩm,khuyến khích,phát triển'),
(39, 41, '27,41', 0, 1, '', 0, 1351499127, 1351499127, 1, 1351499127, 0, 2, 'Cơ chế giải quyết tranh chấp không rõ sẽ rất phức tạp', 'Co-che-giai-quyet-tranh-chap-khong-ro-se-rat-phuc-tap', 'BRANDCO LAWFIRM -  Cho ý kiến về việc ban hành Nghị định về kinh doanh trò chơi điện tử có thưởng dành cho người nước ngoài, các Ủy viên UBTVQH đều tán thành về sự cần thiết phải ban hành Nghị định nhằm kịp thời khắc phục những hạn chế trong lĩnh vực này, từng bước nâng cao hiệu quả quản lý, khai thác hợp lý nguồn thu cho ngân sách Nhà nước. Tuy nhiên, việc ban hành Nghị định cần chú trọng đến mục tiêu tạo công cụ pháp lý để tăng cường sự quản lý của Nhà nước với lĩnh vực kinh doanh có điều kiện này, tạo điều kiện để hoạt động kinh doanh trò chơi điện tử có thưởng trở thành kênh góp phần thúc đẩy phát triển dịch vụ du lịch đồng thời bảo đảm quyền và lợi ích hợp pháp của người tham gia…', '2012_10/imagesca8lezqn.jpg', '', 'thumb/imagesca8lezqn.jpg|block/imagesca8lezqn.jpg', 1, 2, 1, 0, 0, 0, 0, 'ý kiến,ban hành,nghị định,kinh doanh,trò chơi,ủy viên,tán thành,cần thiết,kịp thời,khắc phục,hạn chế,lĩnh vực,nâng cao,hiệu quả,quản lý,khai thác,hợp lý,ngân sách,nhà nước,tuy nhiên,mục tiêu'),
(40, 41, '27,41', 0, 1, '', 0, 1351499221, 1351499221, 1, 1351499221, 0, 2, 'Lấp “lỗ hổng” lớn trong xử lý tội phạm thuế, tài chính', 'Lap-lo-hong-lon-trong-xu-ly-toi-pham-thue-tai-chinh', 'BRANDCO LAWFIRM -  Bộ luật Hình sự (BLHS) hiện hành còn quá thiếu các quy định để xử lý những hành vi vi phạm pháp luật liên quan đến lĩnh vực thuế, tài chính – kế toán, đòi hỏi phải được “lấp đầy” trong quá trình sửa đổi, bổ sung BLHS tới đây.', '2012_10/images663125_ngan_hang_480.jpg', '', 'thumb/images663125_ngan_hang_480.jpg|block/images663125_ngan_hang_480.jpg', 1, 2, 1, 1, 0, 0, 0, 'luật hình,hiện hành,quy định,xử lý,hành vi,vi phạm,pháp luật,liên quan,lĩnh vực,tài chính,kế toán,quá trình,sửa đổi,bổ sung');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_28`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_28` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `nv3_vi_news_28`
--

INSERT INTO `nv3_vi_news_28` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`, `keywords`) VALUES
(41, 28, '28', 0, 1, '', 0, 1351499374, 1351499374, 1, 1351499374, 0, 2, 'Doanh nghiệp nước ngoài tiếp tục than phiền về Nghị định 46', 'Doanh-nghiep-nuoc-ngoai-tiep-tuc-than-phien-ve-Nghi-dinh-46', 'BRANDCO LAWFIRM  - Các thành viên thuộc Hiệp hội Doanh nghiệp châu Âu ở Việt Nam (Eurocham) lại tiếp tục nêu ra những điểm mà họ cho là bất hợp lý của Nghị định 46/2011/NĐ-CP (sửa đổi, bổ sung Nghị định 34/2008/NĐ-CP về tuyển dụng lao động nước ngoài) tại cuộc tọa đàm ngày 24-8 ở TPHCM do Eurocham và Phòng Thương mại và Công nghiệp Việt Nam (VCCI) cùng tổ chức.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'thành viên,hiệp hội,doanh nghiệp,tiếp tục,hợp lý,nghị định,sửa đổi,bổ sung,tuyển dụng,lao động,tọa đàm,thương mại,công nghiệp'),
(42, 28, '28', 0, 1, '', 0, 1351499425, 1351499425, 1, 1351499425, 0, 2, 'Nghị định 70&#x002F;2011&#x002F;NĐ-CP quy định mức lương tối thiểu vùng đối với người lao động', 'Nghi-dinh-70-2011-ND-CP-quy-dinh-muc-luong-toi-thieu-vung-doi-voi-nguoi-lao-dong', 'BRANDCO LAWFIRM  - Ngày 22/08/2011, Chính phủ đã ban hành Nghị định 70/2011/NĐ-CP quy định mức lương tối thiểu vùng đối với người lao động làm việc ở công ty, doanh nghiệp, hợp tác xã, tổ hợp tác, trang trại, hộ gia đình, cá nhân và các cơ quan, tổ chức có thuê mướn lao động, có hiệu lực từ ngày 05/10/2011 và thay thế 02 Nghị định số 107/2010/NĐ-CP; 108/2010/NĐ-CP ngày 29/10/2010.', '', '', '', 1, 2, 1, 1, 0, 0, 0, 'ban hành,nghị định,quy định,tối thiểu,lao động,làm việc,công ty,doanh nghiệp,hợp tác xã,tổ hợp tác,trang trại,gia đình,cá nhân,cơ quan,tổ chức,thuê mướn,hiệu lực,thay thế'),
(43, 28, '28', 0, 1, '', 0, 1351499616, 1351499616, 1, 1351499616, 0, 2, 'Cơ quan Thuế không bán hóa đơn cho doanh nghiệp', 'Co-quan-Thue-khong-ban-hoa-don-cho-doanh-nghiep', 'BRANDCO LAWFIRM  - Từ 1/1/2012: Tổng cục Thuế cho biết, triển khai Nghị định số 51/2010/NĐ-CP về hoá đơn (có hiệu lực thi hành từ 1/1/2011), tính đến hết ngày 30/4/2011, trên địa bàn cả nước đã có 145.693 doanh nghiệp đã tự in, đặt in hoá đơn. Tuy nhiên vẫn còn 188.421 doanh nghiệp siêu nhỏ, doanh nghiệp ở địa bàn kinh tế xã hội khó khăn và đặc biệt khó khăn đang thực hiện mua hóa đơn của cơ quan thuế.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'tổng cục,cho biết,triển khai,nghị định,hiệu lực,thi hành,doanh nghiệp,tuy nhiên,kinh tế,xã hội,khó khăn,đặc biệt,thực hiện,hóa đơn,cơ quan');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_29`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_29` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `nv3_vi_news_29`
--

INSERT INTO `nv3_vi_news_29` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`, `keywords`) VALUES
(44, 29, '29', 0, 1, '', 0, 1351499674, 1351499674, 1, 1351499674, 0, 2, 'Dự thảo Luật Hợp tác xã &#40;sửa đổi&#41; - Băn khoăn về mức góp vốn và giới hạn quyền cung ứng sản phẩm, dịch vụ', 'Du-thao-Luat-Hop-tac-xa-sua-doi-Ban-khoan-ve-muc-gop-von-va-gioi-han-quyen-cung-ung-san-pham-dich-vu', 'BRANDCO LAWFIRM - Tiếp tục có những tranh luận sôi nổi về dự thảo Luật Hợp tác xã (sửa đổi) với những vấn đề có tính chất sống còn của hợp tác xã (HTX) như mức góp vốn tối đa của một thành viên bao nhiêu là phù hợp, vừa bảo đảm lợi ích của người góp vốn vừa bảo đảm quyền của các thành viên khác; nên hay không nên hạn chế việc cung cấp dịch vụ, sản phẩm của HTX ra thị trường… Một lần nữa, dự thảo đã được mổ xẻ dưới góc pháp lý trước khi trình QH xem xét, thông qua.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'tiếp tục,tranh luận,sôi nổi,hợp tác xã,sửa đổi,vấn đề,tính chất,sống còn,góp vốn,tối đa,thành viên,bao nhiêu,phù hợp,bảo đảm,lợi ích,hạn chế,sản phẩm,thị trường,mổ xẻ,pháp lý,trước khi'),
(45, 29, '29', 0, 1, '', 0, 1351499772, 1351499772, 1, 1351499772, 0, 2, 'Trao đổi về phạm vi hòa giải ở cơ sở', 'Trao-doi-ve-pham-vi-hoa-giai-o-co-so', 'BRANDCO LAWFIRM - Hiện có hai ý kiến không giống nhau xung quanh quy định về phạm vi hòa giải ở cơ sở được quy định tại dự thảo Luật Hòa giải cơ sở. Ý kiến thứ nhất, giữ nguyên như quy định tại Pháp lệnh về tổ chức và hoạt động hòa giải ở cơ sở đó là, việc hòa giải được tiến hành đối với các mâu thuẫn, vi phạm pháp luật và tranh chấp nhỏ trong cộng đồng dân cư. ý kiến thứ hai cho rằng, cần mở rộng phạm vi hòa giải, không chỉ giới hạn ở những vi phạm pháp luật và tranh chấp nhỏ. Việc lựa chọn ý kiến thứ nhất của Ban soạn thảo có hợp lý không?', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'ý kiến,quy định,phạm vi,hòa giải,cơ sở,pháp lệnh,tổ chức,hoạt động,tiến hành,mâu thuẫn,vi phạm,pháp luật,tranh chấp,dân cư,thứ hai,giới hạn,soạn thảo,hợp lý'),
(46, 29, '29', 0, 1, '', 0, 1351499846, 1351499846, 1, 1351499846, 0, 2, 'Dựng lại tường lửa ngăn sở hữu chéo ngân hàng', 'Dung-lai-tuong-lua-ngan-so-huu-cheo-ngan-hang', 'BRANDCO LAWFIRM - Luật Các tổ chức tín dụng được thông qua, một trong những sai lầm chết người là xóa bức tường lửa của ngân hàng đầu tư và ngân hàng thương mại. Ông Võ Trí Thành Phó Viện trưởng Viện Nghiên cứu quản lý kinh tế Trung ương đã nhận định như vậy.', '2012_10/hang-20f1d.jpg', '', 'thumb/hang-20f1d.jpg|block/hang-20f1d.jpg', 1, 2, 1, 1, 0, 0, 0, 'tổ chức,tín dụng,thông qua,sai lầm,ngân hàng,thương mại,nghiên cứu,quản lý,kinh tế,trung ương,nhận định');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_30`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_30` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=50 ;

--
-- Dumping data for table `nv3_vi_news_30`
--

INSERT INTO `nv3_vi_news_30` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`, `keywords`) VALUES
(47, 30, '30', 0, 1, '', 0, 1351501275, 1351501275, 1, 1351501275, 0, 2, 'Luật sư và người chăn lừa', 'Luat-su-va-nguoi-chan-lua', 'BRANDCO - Một anh chàng ngồi một mình trong góc quán rượu, uống tì tì suốt ba giờ liền.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'tì tì'),
(48, 30, '30', 0, 1, '', 0, 1351501314, 1351501314, 1, 1351501314, 0, 2, 'Lý luận của luật sư', 'Ly-luan-cua-luat-su', 'BRANDCO - Một luật sư đang biện hộ cho một người bị buộc tội ăn trộm. Luật sư nói với tòa... Kính thưa ngài tôi xin trình bày rằng thân chủ của tôi không hề đột nhập vào căn nhà đó.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'luật sư,biện hộ,buộc tội,ăn trộm,trình bày,không hề'),
(49, 30, '30', 0, 1, '', 0, 1351501355, 1351501355, 1, 1351501355, 0, 2, 'Từ thị trường USD tự do nghĩ về chính sách tỷ giá', 'Tu-thi-truong-USD-tu-do-nghi-ve-chinh-sach-ty-gia', 'BRANDCO LAWFIRM - Sau một thời gian tạm dừng hoạt động để nghe ngóng, thị trường USD tự do tại Hà Nội lại hoạt động trở lại. Nguyên nhân cơ bản là vì nhu cầu mua USD vì những mục đích chính đáng của người dân và doanh nghiệp vượt quá khả năng cung ứng của thị trường chính thức tại mức tỷ giá được công bố chính thức hiện tại.', '', '', '', 1, 2, 1, 1, 0, 0, 0, 'thời gian,hoạt động,nghe ngóng,thị trường,tự do,hà nội,trở lại,nguyên nhân,cơ bản,nhu cầu,mục đích,doanh nghiệp,khả năng,tỷ giá,công bố');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_31`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_31` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `nv3_vi_news_31`
--

INSERT INTO `nv3_vi_news_31` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`, `keywords`) VALUES
(11, 31, '23,31', 0, 1, '', 0, 1351408478, 1351436954, 1, 1351408478, 0, 2, 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Nhung-van-de-can-luu-y-khi-thuc-hien-thu-tuc-dang-ky-kinh-doanh', 'BRANDCO - Để giúp các bạn khởi sự kinh doanh nhanh chóng và thuận lợi. Brandco xin cung cấp cho quý khách hàng một số vấn đề cần lưu ý khi thực hiện thủ tục đăng ký doanh nghiệp theo Luật Doanh nghiệp năm 2005.', '2012_10/dkkd.jpeg', '', 'thumb/dkkd.jpeg.jpg|block/dkkd.jpeg.jpg', 1, 2, 1, 1, 0, 5, 1, 'khởi sự,kinh doanh,nhanh chóng,thuận lợi,quý khách,vấn đề,lưu ý,thực hiện,thủ tục,đăng ký,doanh nghiệp'),
(12, 31, '23,31', 0, 1, '', 0, 1351421031, 1351437155, 1, 1351421031, 0, 2, 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Cong-ty-luat-Brandco-Dich-vu-thanh-lap-doanh-nghiep', 'BRANDCO -  Là nhà tư vấn chuyên nghiệp trong lĩnh vực tư vấn đầu tư và tư vấn sở hữu trí tuệ, với nhiều năm kinh nghiệm phục vụ khách hàng, Công ty luật Brandco xin được giới thiệu tới rộng rãi các nhà đầu tư dịch vụ tư vấn thành lập doanh nghiệp do Công ty luật Brandco cung cấp.', '2012_10/thanhlapdoanhnghiep.jpeg', '', 'thumb/thanhlapdoanhnghiep.jpeg.jpg|block/thanhlapdoanhnghiep.jpeg.jpg', 1, 2, 1, 0, 0, 0, 0, 'tư vấn,lĩnh vực,sở hữu,trí tuệ,kinh nghiệm,phục vụ,khách hàng,công ty,giới thiệu,rộng rãi,thành lập,doanh nghiệp'),
(13, 31, '23,31', 0, 1, '', 0, 1351421252, 1351421641, 1, 1351421252, 0, 2, 'Công ty luật Brandco&#x3A; Đặc điểm của các loại hình các loại hình doanh nghiệp&#33;', 'Cong-ty-luat-Brandco-Dac-diem-cua-cac-loai-hinh-cac-loai-hinh-doanh-nghiep', 'BRANDCO - Để giúp các bạn khởi sự kinh doanh nhanh chóng và thuận lợi. Brandco xin cung cấp cho quý khách hàng một số kiến thức về sự khác nhau giữa các loại hình doanh nghiệp, để quý khách có được sự lựa chọn tốt nhất', '2012_10/doanh-nghiep.jpeg', '', 'thumb/doanh-nghiep.jpeg.jpg|block/doanh-nghiep.jpeg.jpg', 1, 2, 1, 1, 0, 0, 0, 'khởi sự,kinh doanh,nhanh chóng,thuận lợi,quý khách,kiến thức,loại hình,doanh nghiệp');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_32`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_32` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `nv3_vi_news_32`
--

INSERT INTO `nv3_vi_news_32` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`, `keywords`) VALUES
(14, 32, '23,32', 0, 1, '', 0, 1351421497, 1351421554, 1, 1351421497, 0, 2, 'Công ty luật Brandco&#x3A; Xin giấy phép đầu tư&#33;', 'Cong-ty-luat-Brandco-Xin-giay-phep-dau-tu', 'BRANDCO - Công ty Luật Brandco  tự hào là công ty hàng đầu trong lĩnh vực tư vấn đầu tư và cung cấp các dịch vụ hỗ trợ các nhà đầu tư tại việt nam như: tư vấn thành lập doanh nghiệp liên doanh, công ty 100% vốn nước ngoài, tư vấn lập dự án đầu tư (dự án tiền khả thi và dự án khả thi), tư vấn thủ tục xin ưu đãi đầu tư....', '2012_10/dau-tu.jpg', '', 'thumb/dau-tu.jpg|block/dau-tu.jpg', 1, 2, 1, 0, 0, 0, 0, 'công ty,tự hào,hàng đầu,lĩnh vực,tư vấn,hỗ trợ,thành lập,doanh nghiệp,liên doanh,dự án,khả thi,thủ tục'),
(15, 32, '23,32', 0, 1, '', 0, 1351421742, 1351421742, 1, 1351421742, 0, 2, 'Thành lập văn phòng đại diên của doanh nghiệp nước ngoài&#33;&#33;&#33;', 'Thanh-lap-van-phong-dai-dien-cua-doanh-nghiep-nuoc-ngoai', 'BRANDCO -  Sau sự kiện Việt Nam tham gia vào WTO ngày càng có nhiều thương nhân nước ngoài đến Việt Nam để tìm hiểu môi trường đầu tư, xúc tiến các hoạt động kinh doanh. Là nhà tư vấn chuyên nghiệp trong lĩnh vực doanh nghiệp – thương mại – kinh tế, công ty luật  Brandco xin cung cấp tới quý khách hàng  về điều kiện cấp phép thành lập văn phòng đại diện của thương nhân nước ngoài tại Việt Nam.', '2012_10/vanphongdaidien.jpg', '', 'thumb/vanphongdaidien.jpg|block/vanphongdaidien.jpg', 1, 2, 1, 1, 0, 0, 0, 'sự kiện,tham gia,ngày càng,tìm hiểu,môi trường,xúc tiến,hoạt động,kinh doanh,tư vấn,lĩnh vực,doanh nghiệp,thương mại,kinh tế,công ty,quý khách,thành lập,văn phòng,đại diện'),
(16, 23, '23,32', 0, 1, '', 0, 1351421861, 1351438317, 1, 1351438200, 0, 2, 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 'Tu-van-xin-chung-nhan-dau-tu-thanh-lap-cong-ty-lien-doanh-cong-ty-100-von-dau-tu-nuoc-ngoai-ve-phan-phoi', 'BRANDCO LAWFIRM - Công ty Luật Brandco  tự hào là công ty hàng đầu trong lĩnh vực tư vấn đầu tư và cung cấp các dịch vụ hỗ trợ các nhà đầu tư tại việt nam như: tư vấn thành lập doanh nghiệp liên doanh, công ty 100% vốn nước ngoài, tư vấn lập dự án đầu tư (dự án tiền khả thi và dự án khả thi), tư vấn thủ tục xin ưu đãi đầu tư....', '2012_10/dau-tu.jpeg', '', 'thumb/dau-tu.jpeg.jpg|block/dau-tu.jpeg.jpg', 1, 2, 1, 2, 0, 0, 0, 'công ty,tự hào,hàng đầu,lĩnh vực,tư vấn,hỗ trợ,thành lập,doanh nghiệp,liên doanh,dự án,khả thi,thủ tục');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_33`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_33` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `nv3_vi_news_33`
--

INSERT INTO `nv3_vi_news_33` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`, `keywords`) VALUES
(17, 33, '23,33', 0, 1, '', 0, 1351436724, 1351436724, 1, 1351436724, 0, 2, 'Tư vấn thành lập, tổ chức, quản lý doanh nghiệp theo mô hình tập đoàn kinh tế', 'Tu-van-thanh-lap-to-chuc-quan-ly-doanh-nghiep-theo-mo-hinh-tap-doan-kinh-te', 'BRANDCO LAWFIRM - Pháp luật hiện hành đã quy định rất cụ thể về việc thành lập ra các tập đoàn kinh tế nhà nước, cụ thể nhất là quy định tại Số: 101/2009/NĐ-CP ngày 05/11/2009 của chính phủ. Tuy nhiên, việc thành lập các tập đoàn kinh tế theo mô hình &quot; Công ty mẹ - Công ty con&quot; đối với khối Doanh nghiệp dân doanh lại chưa được ghi nhận.', '2012_10/to-chuc-doanh-nghiep.jpg', '', 'thumb/to-chuc-doanh-nghiep.jpg|block/to-chuc-doanh-nghiep.jpg', 1, 2, 1, 1, 0, 0, 0, 'pháp luật,hiện hành,quy định,cụ thể,thành lập,tập đoàn,kinh tế,nhà nước,nhất là,tuy nhiên,mô hình,công ty,doanh nghiệp'),
(18, 23, '23,33', 0, 1, '', 0, 1351436786, 1351436889, 1, 1351436786, 0, 2, 'Tái cơ cấu&#x3A; Sáng tạo để tiếp tục đổi mới', 'Tai-co-cau-Sang-tao-de-tiep-tuc-doi-moi', 'BRANDCO LAWFIRM  - Hơn hai mươi năm trước, chúng ta đã thực hiện cấu trúc lại nền kinh tế để tạo nên kỳ tích đổi mới. Bây giờ, đổi mới vẫn được tiếp tục nhưng cần được đặt trên một lộ trình mới. Tái cấu trúc nền kinh tế chính là tiếp tục thúc đẩy tiến trình đổi mới, để đạt được thành quả cao và hưởng lợi nhiều hơn từ đổi mới.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'thực hiện,kinh tế,kỳ tích,bây giờ,tiếp tục,lộ trình,thúc đẩy,tiến trình,thành quả');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_34`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_34` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `nv3_vi_news_34`
--

INSERT INTO `nv3_vi_news_34` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`, `keywords`) VALUES
(19, 34, '24,34', 0, 1, '', 0, 1351437291, 1351437291, 1, 1351437291, 0, 2, 'Công ty luật Brandco&#x3A; Dịch vụ đăng ký bảo hộ quyền tác giả.', 'Cong-ty-luat-Brandco-Dich-vu-dang-ky-bao-ho-quyen-tac-gia', 'BRANDCO - Bảo hộ quyền tác giả là một trong những phương thức hiệu quả để thúc đẩy và phổ biến trí thức quốc gia. Sự phát triển của một đất nước phụ thuộc chủ yếu vào hoạt động sáng tạo của người dân và việc khuyến khích sáng tạo cá nhân và phổ biến cập nhật các sáng tạo đó sẽ là tiền đề đối với quá trính phát triển.', '2012_10/hanggia.jpg', '', 'thumb/hanggia.jpg|block/hanggia.jpg', 1, 2, 1, 1, 0, 0, 0, 'bảo hộ,tác giả,phương thức,hiệu quả,thúc đẩy,phổ biến,trí thức,quốc gia,phát triển,phụ thuộc,chủ yếu,hoạt động,sáng tạo,khuyến khích,cá nhân,tiền đề'),
(20, 34, '24,34', 0, 1, '', 0, 1351437427, 1351437427, 1, 1351437427, 0, 2, 'Công ty luật Brandco&#x3A; Đăng ký bảo hộ độc quyền sáng chế&#33;', 'Cong-ty-luat-Brandco-Dang-ky-bao-ho-doc-quyen-sang-che', 'BRANDCO – Sáng chế, một đối tượng quan trọng cơ bản của quyền sở hữu trí tuệ, một tài sản vô hình vô cùng quan trọng đối với mỗi doanh nghiệp. Tuy nhiên, ở Việt nam hiện nay vấn đề bảo hộ độc quyền các ý tưởng sáng tạo đối với sáng chế đang bị coi nhẹ. Công ty Luật Brandco, với tư cách là một chuyên gia hàng đầu về bảo hộ độc quyền sáng chế, xin được chia sẻ với các bạn một số kinh nghiệm liên quan để bảo vệ quyền hợp pháp của mình với loại tài sản đặc biệt này', '2012_10/sang-che.jpg', '', 'thumb/sang-che.jpg|block/sang-che.jpg', 1, 2, 1, 1, 0, 0, 0, 'sáng chế,quan trọng,cơ bản,sở hữu,trí tuệ,tài sản,vô hình,doanh nghiệp,tuy nhiên,hiện nay,vấn đề,bảo hộ,ý tưởng,sáng tạo,công ty,tư cách,chuyên gia,hàng đầu,kinh nghiệm,liên quan,bảo vệ'),
(21, 34, '24,34', 0, 1, '', 0, 1351437554, 1351437554, 1, 1351437554, 0, 2, 'Công ty luật Brandco&#x3A; Dịch vụ Bảo hộ Kiểu dáng công nghiệp', 'Cong-ty-luat-Brandco-Dich-vu-Bao-ho-Kieu-dang-cong-nghiep', 'BRANDCO - Kiểu dáng công nghiệp, một đối tượng quan trọng cơ bản của quyền sở hữu trí tuệ, một tài sản vô hình vô cùng quan trọng đối với mỗi doanh nghiệp sản xuất. Công ty Luật Brandco, với tư cách là một chuyên gia hàng đầu về bảo hộ độc quyền kiểu dáng công nghiệp, xin được chia sẻ với các bạn một số kinh nghiệm liên quan để bảo vệ quyền hợp pháp của mình với loại tài sản đặc biệt này.', '2012_10/xemay.jpg', '', 'thumb/xemay.jpg|block/xemay.jpg', 1, 2, 1, 1, 0, 0, 0, 'công nghiệp,quan trọng,cơ bản,sở hữu,trí tuệ,tài sản,vô hình,doanh nghiệp,sản xuất,công ty,tư cách,chuyên gia,hàng đầu,bảo hộ,kinh nghiệm,liên quan,bảo vệ,hợp pháp,đặc biệt');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_35`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_35` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `nv3_vi_news_35`
--

INSERT INTO `nv3_vi_news_35` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`, `keywords`) VALUES
(22, 35, '24,35', 0, 1, '', 0, 1351437917, 1351437917, 1, 1351437917, 0, 2, 'Khiếu nại &amp; xử lý vi phạm quyền sở hữu trí tuệ', 'Khieu-nai-xu-ly-vi-pham-quyen-so-huu-tri-tue', 'BRANDCO - Hãng luật Brandco là một hãng tư vấn luật thành công nhất ở Việt Nam trong việc phối hợp có hiệu quả với các cơ quan có thẩm quyền Việt Nam tiến hành các biện pháp thực thi quyền chống lại vi phạm quyền nhãn hiệu hàng hoá, kiểu dáng công nghiệp, bản quyền tác giả và sáng chế để đảm bảo rằng quyền sở hữu trí tuệ của Quý doanh nghiệp được bảo hộ, thực thi phù hợp với mục tiêu và chiến lược của họ trên thị trường.', '2012_10/xulyviphamshtt.jpg', '', 'thumb/xulyviphamshtt.jpg|block/xulyviphamshtt.jpg', 1, 2, 1, 1, 0, 0, 0, 'tư vấn,thành công,phối hợp,hiệu quả,cơ quan,thẩm quyền,tiến hành,biện pháp,vi phạm,nhãn hiệu,công nghiệp,bản quyền,tác giả,sáng chế,đảm bảo,sở hữu,trí tuệ,doanh nghiệp,bảo hộ,phù hợp,mục tiêu');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_36`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_36` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_37`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_37` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `nv3_vi_news_37`
--

INSERT INTO `nv3_vi_news_37` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`, `keywords`) VALUES
(23, 37, '25,37', 0, 1, '', 0, 1351438502, 1351438502, 1, 1351438502, 0, 2, 'Tư vấn soạn thảo quy chế, nội quy lao động của doanh nghiệp', 'Tu-van-soan-thao-quy-che-noi-quy-lao-dong-cua-doanh-nghiep', 'BRANDCO LAW FIRM - Ngày nay, kinh tế của Việt Nam ngày càng phát triển, các doanh nghiệp nước ngoài vào Việt Nam và các doanh nghiệp trong nước được thành lập ngày càng nhiều do đó mối qua hệ giữa người lao động và người sử dụng lao động ngày càng phức tạp, nảy sinh những trang chấp trong quan hệ lao động giữa người sử dụng lao động và người lao động.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'ngày nay,kinh tế,ngày càng,phát triển,doanh nghiệp,thành lập,lao động,sử dụng,phức tạp,nảy sinh,quan hệ'),
(24, 37, '25,37', 0, 1, '', 0, 1351484608, 1351484608, 1, 1351484608, 0, 2, 'Công ty Luật Brandco&#x3A; Dịch vụ tư vấn hợp đồng', 'Cong-ty-Luat-Brandco-Dich-vu-tu-van-hop-dong', 'BRANDCO - Là Hãng luật hàng đầu trong lĩnh vực tư vấn đầu tư và tư vấn Sở hữu trí tuệ, hãng luật Brandco xin giới thiệu với Quý doanh nghiệp các dịch vụ pháp lý liên quan tới các hợp đồng, bao gồm việc chuẩn bị cơ sở pháp lý, đàm phán, soạn thảo và hiệu chỉnh các loại hợp đồng kinh tế, thương mại, đầu tư….', '2012_10/tu-van-hop-dong.jpeg', '', 'thumb/tu-van-hop-dong.jpeg.jpg|block/tu-van-hop-dong.jpeg.jpg', 1, 2, 1, 0, 0, 0, 0, 'hàng đầu,lĩnh vực,tư vấn,sở hữu,trí tuệ,giới thiệu,doanh nghiệp,pháp lý,liên quan,hợp đồng,bao gồm,chuẩn bị,cơ sở,đàm phán,soạn thảo,kinh tế,thương mại'),
(25, 37, '25,37', 0, 1, '', 0, 1351484700, 1351484700, 1, 1351484700, 0, 2, 'Tư vấn về thừa kế tài sản theo quy định của bộ luật dân sự', 'Tu-van-ve-thua-ke-tai-san-theo-quy-dinh-cua-bo-luat-dan-su', 'BRANDCO LAW FIRM - Pháp luật Việt nam khẳng định quyền được thừa kế của mọi cá nhân, tổ chức theo quy định tại Điều 631, Bộ luật Dân sự, cụ thể: “Cá nhân có quyền lập di chúc để định đoạt tài sản của mình; để lại tài sản của mình cho người thừa kế theo pháp luật; hưởng di sản theo di chúc hoặc theo pháp luật&quot; - Luật sư Nguyễn Văn Thi', '2012_10/dich-vu-thua-ke.jpg', '', 'thumb/dich-vu-thua-ke.jpg|block/dich-vu-thua-ke.jpg', 1, 2, 1, 0, 0, 0, 0, 'pháp luật,khẳng định,thừa kế,cá nhân,tổ chức,quy định,dân sự,cụ thể,di chúc,tài sản,di sản,luật sư');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_38`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_38` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `nv3_vi_news_38`
--

INSERT INTO `nv3_vi_news_38` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`, `keywords`) VALUES
(26, 38, '25,38', 0, 1, '', 0, 1351484820, 1351484820, 1, 1351484820, 0, 2, 'Tư vấn xin giấy phép sản xuất thuốc lá', 'Tu-van-xin-giay-phep-san-xuat-thuoc-la', 'BRANDCO - Trình tự thủ tục và thẩm quyền cấp giấy phép trong lĩnh vực sản xuất thuốc lá.', '2012_10/thuocla.jpg', '', 'thumb/thuocla.jpg|block/thuocla.jpg', 1, 2, 1, 0, 0, 0, 0, 'trình tự,thủ tục,thẩm quyền,giấy phép,lĩnh vực,sản xuất'),
(27, 38, '25,38', 0, 1, '', 0, 1351484905, 1351485526, 1, 1351484905, 0, 2, 'Tư vấn xin giấy phép hoạt động điện lực', 'Tu-van-xin-giay-phep-hoat-dong-dien-luc', 'BRANDCO - Nội dung công việc các luật sư của chúng tôi cam kết tiến hành:', '2012_10/dien1.jpg', '', 'thumb/dien1.jpg|block/dien1.jpg', 1, 2, 1, 0, 0, 0, 0, 'nội dung,luật sư,cam kết'),
(28, 38, '25,38', 0, 1, '', 0, 1351485646, 1351485646, 1, 1351485646, 0, 2, 'Quy định về việc thu, nộp, quản lý và sử dụng phí bán đấu giá cổ phần', 'Quy-dinh-ve-viec-thu-nop-quan-ly-va-su-dung-phi-ban-dau-gia-co-phan', 'BRANDCO - Ngày 27/4/2009, Bộ Tài chính đã ban hành Thông tư số 82/2009/TT-BTC Quy định về mức thu, chế độ thu, nộp, quản lý và sử dụng phí bán đấu giá cổ phần', '', '', '', 1, 2, 1, 1, 0, 0, 0, 'tài chính,ban hành,thông tư,quy định,chế độ,quản lý,sử dụng,đấu giá');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_39`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_39` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `nv3_vi_news_39`
--

INSERT INTO `nv3_vi_news_39` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`, `keywords`) VALUES
(29, 39, '25,39', 0, 1, '', 0, 1351485834, 1351485834, 1, 1351485834, 0, 2, 'Thủ tục thanh toán chi phí khám bệnh, chữa bệnh đối với người tham gia bảo hiểm y tế bị tai nạn giao thông', 'Thu-tuc-thanh-toan-chi-phi-kham-benh-chua-benh-doi-voi-nguoi-tham-gia-bao-hiem-y-te-bi-tai-nan-giao-thong', 'BRANDCO LAWFIRM - Liên Bộ Tài chính, Bộ Y tế vừa ban hành Thông tư liên tịch số 39/2011/TTLT-BYT-BTC hướng dẫn thủ tục thanh toán chi phí khám bệnh, chữa bệnh đối với người tham gia bảo hiểm y tế bị tai nạn giao thông.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'liên bộ,tài chính,y tế,ban hành,thông tư,liên tịch,hướng dẫn,thủ tục,thanh toán,chi phí,khám bệnh,tham gia,bảo hiểm,tai nạn'),
(30, 39, '25,39', 0, 1, '', 0, 1351485905, 1351485905, 1, 1351485905, 0, 2, 'Rút ngắn thời gian cấp Giấy miễn thị thực xuống 5 ngày', 'Rut-ngan-thoi-gian-cap-Giay-mien-thi-thuc-xuong-5-ngay', 'BRANDCO LAWFIRM - Thủ tướng Chính phủ vừa ban hành Quyết định sửa đổi, bổ sung một số điều Quy chế về miễn thị thực cho người Việt Nam định cư ở nước ngoài (Quyết định số 10/2012/QĐ-TTg).', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'thủ tướng,ban hành,quyết định,sửa đổi,bổ sung,quy chế,thị thực,định cư'),
(31, 39, '25,39', 0, 1, '', 0, 1351485981, 1351485981, 1, 1351485981, 0, 2, 'Hướng dẫn quyết toán thuế thu nhập cá nhân năm 2011', 'Huong-dan-quyet-toan-thue-thu-nhap-ca-nhan-nam-2011', 'BRANDCO LAWFIRM - Tổng cục Thuế vừa có Công văn hướng dẫn một số điểm về quyết toán thuế Thu nhập cá nhân năm 2011.', '2012_10/1394335.jpg', '', 'thumb/1394335.jpg|block/1394335.jpg', 1, 2, 1, 1, 0, 0, 0, 'tổng cục,công văn,hướng dẫn,quyết toán,thu nhập,cá nhân');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_40`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_40` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `nv3_vi_news_40`
--

INSERT INTO `nv3_vi_news_40` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`, `keywords`) VALUES
(35, 40, '27,40', 0, 1, '', 0, 1351498289, 1351498289, 1, 1351498289, 0, 2, 'Lương tối thiểu dự kiến tăng 35&#x25;', 'Luong-toi-thieu-du-kien-tang-35', 'BRANDCO LAWFIRM - Lương tối thiểu dự kiến tăng 35% Từ 1/1/2013, lương tối thiểu vùng tại mọi loại hình doanh nghiệp có thể tăng 700.000 đồng lên mức cao nhất 2,7 triệu đồng một tháng, theo đề xuất của Bộ Lao động Thương binh và Xã hội.', '2012_10/luongtoithieu.jpg', '', 'thumb/luongtoithieu.jpg|block/luongtoithieu.jpg', 1, 2, 1, 0, 0, 0, 0, 'tối thiểu,loại hình,doanh nghiệp,có thể,lao động,thương binh'),
(36, 40, '27,40', 0, 1, '', 0, 1351498364, 1351498364, 1, 1351498364, 0, 2, 'Miễn, giảm thuế sử dụng đất phi nông nghiệp', 'Mien-giam-thue-su-dung-dat-phi-nong-nghiep', 'BRANDCO LAWFIRM - Bộ Tài chính vừa ban hành văn bản số 11850/BTC-TCT tháo gỡ những vướng mắc cho cơ quan Thuế địa phương trong việc thực hiện chính sách miễn, giảm tiền thuế sử dụng đất phi nông nghiệp.', '2012_10/03_dool_tt_091203_p4_1.jpg', '', 'thumb/03_dool_tt_091203_p4_1.jpg|block/03_dool_tt_091203_p4_1.jpg', 1, 2, 1, 0, 0, 0, 0, 'tài chính,ban hành,cơ quan,thực hiện,sử dụng'),
(37, 40, '27,40', 0, 1, '', 0, 1351498432, 1351498432, 1, 1351498432, 0, 2, 'Thuế TNDN từ chuyển nhượng bất động sản được xác định theo giá hợp đồng', 'Thue-TNDN-tu-chuyen-nhuong-bat-dong-san-duoc-xac-dinh-theo-gia-hop-dong', 'BRANDCO LAWFIRM - Theo quy định của Bộ Tài chính, bắt đầu từ ngày 10-9-2012 sẽ thực hiện đánh thuế thu nhập DN đối với một số DN có thu nhập từ chuyển nhượng bất động sản.', '2012_10/bat_dong_.jpg', '', 'thumb/bat_dong_.jpg|block/bat_dong_.jpg', 1, 2, 1, 0, 0, 0, 0, 'quy định,tài chính,bắt đầu,thực hiện,đánh thuế,thu nhập,bất động');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_41`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_41` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `nv3_vi_news_41`
--

INSERT INTO `nv3_vi_news_41` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`, `keywords`) VALUES
(38, 41, '27,41', 0, 1, '', 0, 1351499047, 1351499047, 1, 1351499047, 0, 2, 'Không biến hợp tác xã thành mô hình tự cung tự cấp', 'Khong-bien-hop-tac-xa-thanh-mo-hinh-tu-cung-tu-cap', 'BRANDCO LAWFIRM -  Hợp tác xã được tổ chức hoạt động không chỉ vì lợi ích kinh tế mà còn có cả lợi ích xã hội. Do đó, cần tăng cường quan hệ kinh tế trong hợp tác xã, không biến hợp tác xã trở thành mô hình tự cung tự cấp. Điều này đòi hỏi cần minh bạch hóa các nguồn vốn, xác lập lại cổ phần xã viên, tư cách xã viên và chú trọng hơn đến công nghiệp chế biến và dịch vụ tiêu thụ sản phẩm, khuyến khích phát triển mới những hợp tác xã thương mại, dịch vụ đa ngành.', '2012_10/htx.jpg', '', 'thumb/htx.jpg|block/htx.jpg', 1, 2, 1, 0, 0, 0, 0, 'hợp tác xã,tổ chức,hoạt động,lợi ích,kinh tế,xã hội,tăng cường,quan hệ,trở thành,mô hình,tự cung,tự cấp,minh bạch,cổ phần,tư cách,công nghiệp,chế biến,tiêu thụ,sản phẩm,khuyến khích,phát triển'),
(39, 41, '27,41', 0, 1, '', 0, 1351499127, 1351499127, 1, 1351499127, 0, 2, 'Cơ chế giải quyết tranh chấp không rõ sẽ rất phức tạp', 'Co-che-giai-quyet-tranh-chap-khong-ro-se-rat-phuc-tap', 'BRANDCO LAWFIRM -  Cho ý kiến về việc ban hành Nghị định về kinh doanh trò chơi điện tử có thưởng dành cho người nước ngoài, các Ủy viên UBTVQH đều tán thành về sự cần thiết phải ban hành Nghị định nhằm kịp thời khắc phục những hạn chế trong lĩnh vực này, từng bước nâng cao hiệu quả quản lý, khai thác hợp lý nguồn thu cho ngân sách Nhà nước. Tuy nhiên, việc ban hành Nghị định cần chú trọng đến mục tiêu tạo công cụ pháp lý để tăng cường sự quản lý của Nhà nước với lĩnh vực kinh doanh có điều kiện này, tạo điều kiện để hoạt động kinh doanh trò chơi điện tử có thưởng trở thành kênh góp phần thúc đẩy phát triển dịch vụ du lịch đồng thời bảo đảm quyền và lợi ích hợp pháp của người tham gia…', '2012_10/imagesca8lezqn.jpg', '', 'thumb/imagesca8lezqn.jpg|block/imagesca8lezqn.jpg', 1, 2, 1, 0, 0, 0, 0, 'ý kiến,ban hành,nghị định,kinh doanh,trò chơi,ủy viên,tán thành,cần thiết,kịp thời,khắc phục,hạn chế,lĩnh vực,nâng cao,hiệu quả,quản lý,khai thác,hợp lý,ngân sách,nhà nước,tuy nhiên,mục tiêu'),
(40, 41, '27,41', 0, 1, '', 0, 1351499221, 1351499221, 1, 1351499221, 0, 2, 'Lấp “lỗ hổng” lớn trong xử lý tội phạm thuế, tài chính', 'Lap-lo-hong-lon-trong-xu-ly-toi-pham-thue-tai-chinh', 'BRANDCO LAWFIRM -  Bộ luật Hình sự (BLHS) hiện hành còn quá thiếu các quy định để xử lý những hành vi vi phạm pháp luật liên quan đến lĩnh vực thuế, tài chính – kế toán, đòi hỏi phải được “lấp đầy” trong quá trình sửa đổi, bổ sung BLHS tới đây.', '2012_10/images663125_ngan_hang_480.jpg', '', 'thumb/images663125_ngan_hang_480.jpg|block/images663125_ngan_hang_480.jpg', 1, 2, 1, 1, 0, 0, 0, 'luật hình,hiện hành,quy định,xử lý,hành vi,vi phạm,pháp luật,liên quan,lĩnh vực,tài chính,kế toán,quá trình,sửa đổi,bổ sung');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_admins`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_admins` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `comment` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_block`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_block` (
  `bid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_block`
--

INSERT INTO `nv3_vi_news_block` (`bid`, `id`, `weight`) VALUES
(2, 13, 37),
(2, 15, 35),
(2, 17, 33),
(2, 11, 39),
(2, 12, 38),
(2, 14, 36),
(2, 16, 34),
(2, 18, 32),
(2, 19, 31),
(2, 20, 30),
(2, 21, 29),
(2, 22, 28),
(1, 16, 1),
(2, 23, 27),
(2, 24, 26),
(2, 25, 25),
(2, 26, 24),
(2, 27, 23),
(2, 28, 22),
(2, 29, 21),
(2, 30, 20),
(2, 31, 19),
(2, 32, 18),
(2, 33, 17),
(2, 34, 16),
(2, 35, 15),
(2, 36, 14),
(2, 37, 13),
(2, 38, 12),
(2, 39, 11),
(2, 40, 10),
(2, 41, 9),
(2, 42, 8),
(2, 43, 7),
(2, 44, 6),
(2, 45, 5),
(2, 46, 4),
(2, 47, 3),
(2, 48, 2),
(2, 49, 1);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_block_cat`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_block_cat` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `number` mediumint(4) NOT NULL DEFAULT '10',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `nv3_vi_news_block_cat`
--

INSERT INTO `nv3_vi_news_block_cat` (`bid`, `adddefault`, `number`, `title`, `alias`, `image`, `thumbnail`, `description`, `weight`, `keywords`, `add_time`, `edit_time`) VALUES
(1, 0, 4, 'Tin tiêu điểm', 'Tin-tieu-diem', '', '', 'Tin tiêu điểm', 1, '', 1279945710, 1279956943),
(2, 1, 4, 'Tin mới nhất', 'Tin-moi-nhat', '', '', 'Tin tiêu điểm', 2, '', 1279945725, 1279956445);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_bodyhtml_1`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_bodyhtml_1` (
  `id` int(11) unsigned NOT NULL,
  `bodyhtml` longtext NOT NULL,
  `sourcetext` varchar(255) NOT NULL DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_bodyhtml_1`
--

INSERT INTO `nv3_vi_news_bodyhtml_1` (`id`, `bodyhtml`, `sourcetext`, `imgposition`, `copyright`, `allowed_send`, `allowed_print`, `allowed_save`) VALUES
(18, '<p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> Chặng đường đổi mới hơn 20 năm qua của Việt<span class="Apple-converted-space">&nbsp;</span>Nam<span class="Apple-converted-space">&nbsp;</span>thực tế là quá trình cơ cấu lại nền kinh tế và đã mạng lại thành quả tốt đẹp. Sau 20 năm, Việt Nam lại đứng trước yêu cầu tái cấu trúc để tiếp tục lộ trình đổi mới của đất nước, nâng những thành quả đã đạt được lên tầm cao hơn trong môi trường toàn cầu hóa và những biến đổi của thế giới thời hậu khủng hoảng.</p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> <span style="font-family: arial; font-size: 12px; color: rgb(0, 0, 0); text-decoration: none; font-weight: bold; ">Thời điểm nhìn lại mình</span></p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> Trong một thời gian dài, Việt<span class="Apple-converted-space">&nbsp;</span>Nam<span class="Apple-converted-space">&nbsp;</span>được ca ngợi là một mẫu hình thành công, một ngôi sao đang lên và là điểm đến lý tưởng của các nhà đầu tư. Vào những năm trước 2008, điều đó đã phần nào thể hiện trên thực tế. Nhưng từ đó trở về sau, thu hút đầu tư bắt đầu khó khăn và năm 2011 đã đánh dấu một sự sụt giảm đáng kể. Đã có nhiều lý giải cho hiện tượng này, hầu hết đều cho rằng nó xuất phát từ khó khăn của chính các nhà đầu tư và những nền kinh tế của các quốc gia đó đang bất ổn.</p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> Lý giải đó có phần đúng. Tuy nhiên, theo nhiều chuyên gia về đầu tư nước ngoài thì cắt giảm hay chuyển hướng của các nhà đầu tư nước ngoài cũng chính là biểu hiện của qua trình tái cơ cấu mà các tập đoàn nước ngoài thực hiện trên phạm vi toàn cầu. Qua khó khăn, tất cả các tập đoàn lớn đều buộc phải tính toán lại các chiến lược và quyết định đầu tư của mình. Và nguyên lý đơn giản nhất là họ sẽ chọn những địa điểm đầu tư cạnh tranh nhất và hiệu quả nhất để triển khai các dự án. Các đầu tư trên toàn cầu buộc phải nhìn nhận lại mình, tái cơ cấu để đứng vững và phát triển trước khủng hoảng. Họ sẵn sàng từ bỏ những dự án đã dày công theo đuổi nhưng nay không còn phù hợp trong chiến lược phát triển mới.</p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> Và Việt<span class="Apple-converted-space">&nbsp;</span>Nam<span class="Apple-converted-space">&nbsp;</span>đang nằm trong tác động của xu hướng đó. Thực tế của quốc tế và diễn biến thu hút đầu tư buộc chúng ta phải nhìn lại mình để có những sự thay đổi.</p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> Câu chuyện khủng hoảng từ 2008 tác động vào Việt<span class="Apple-converted-space">&nbsp;</span>Nam<span class="Apple-converted-space">&nbsp;</span>cho chúng ta một nhận thức mới. Khủng hoảng thời toàn cầu hóa vượt ra ngoài khuôn khổ quốc gia và tất nhiên, tái cấu trúc cũng phải đặt trong không gian của toàn cầu hóa. Nhưng đến năm 2011, thì Việt<span class="Apple-converted-space">&nbsp;</span>Nam<span class="Apple-converted-space">&nbsp;</span>lại có thêm một thách thức nữa đó những khó khăn và bất ổn nội tại ngày càng bộc lộ. Để tránh những nguy cơ, Chính phủ đã buộc phải chuyển hướng trong chính sách từ tăng trưởng sang ổn định. Và như một lộ trình tất yếu, vấn đề tái cơ cấu đã một lần nữa được đặt ra và nhận được sự đồng thuận cao. Nó không chỉ là những đề xuất như những năm 2008 mà đã trở thành nghị quyết của Đảng và cụ thể hóa bằng chính sách của Chính phủ và hành động của mỗi thực thể kinh tế.</p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> &nbsp;</p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> Một điều đã được thừa nhận là khủng hoảng là hậu quả của mất bằng trong cấu trúc kinh tế nhưng đây cũng là thời điểm bắt buộc tính đến chuyện tái cấu trúc. Vì thế, bên cạnh những hậu quả nặng nề thì khủng hoảng cũng được nhắc đến là một cơ hội. Lịch sử thế giới đã có nhiều cuộc khủng hoảng kinh tế lớn và cũng ghi nhận, sau khủng hoảng các nước sẽ tái cơ cấu để phát triển lên mức cao hơn.</p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> Việt<span class="Apple-converted-space">&nbsp;</span>Nam<span class="Apple-converted-space">&nbsp;</span>đã tăng trưởng cao liên tục trong 20 năm qua, tạo ra một Việt<span class="Apple-converted-space">&nbsp;</span>Nammới được cả thế giới thừa nhận. Nhưng trong hơn 20 năm qua, mô hình của Việt<span class="Apple-converted-space">&nbsp;</span>Nam<span class="Apple-converted-space">&nbsp;</span>vẫn chủ yếu tăng trưởng theo chiều rộng bằng cách tăng vốn đầu tư, thâm dụng lớn tài nguyên và lao động giản đơn. Trong một giai đoạn đầu của quá trình phát triển, với một thị trường nội địa lớn, xuất khẩu rộng mở, tài nguyên sẵn có và chấp nhận bán sức lao động giá rẻ... &nbsp;với sự cộng hưởng của tài chính và kỹ thuật mà &quot;mở cửa&quot; thu hút đầu tư mang lại, Việt Nam dễ dàng đạt được sự tăng trưởng vượt bậc.</p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> Tuy nhiên, trong khi chúng ta đang say mê với những con số tăng trưởng và thậm chí, không ít người vẫn muốn tiếp tục mô hình càng đào tài nguyên, thêm nhiều vốn thì càng phát triển mạnh. Và điều đó khiến chúng ta đã vấp phải những thách thức mới từ quá trình phát triển của chính mình.</p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> Đáng lẽ đi cùng với quá trình đầu tư và thu hút vốn cần phải gia tăng công nghệ, nâng cao năng suất để tạo ra giá trị gia tăng lớn thì chúng ta lại bơm tiền ra nhiều để gánh lấy hậu họa lạm phát và những bất ổn của nền kinh tế. Sự lệnh hướng đó khiến hiệu quả của nền kinh tế ngày càng thấp nhưng bất ổn ngày càng lớn.</p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> Không thể phủ nhận mô hình tăng trưởng hiện nay đã đưa nền kinh tế thoát khỏi kinh tế tập trung, nông nghiệp lạc hậu. Nhưng sau 20 năm, thực lực và vị thế đất nước đã đổi khác. Chúng ta mạnh hơn những cũng đối mặt với canh tranh quốc tế gay gắt hơn. Vì thế, không thể chấp nhận mãi áp dụng một mô hình cũ mà phải tỉnh táo nhận ra rằng mô hình tăng trưởng này đã không còn phù hợp. Điều đó buộc chúng ta phải tính đến tái cơ cấu, đưa đất nước sang một giai đoạn phát triển mới</p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> Hơn hai mươi năm trước, chúng ta đã thực hiện cấu trúc lại nền kinh tế để tạo nên kỳ tích đổi mới. Bây giờ, đổi mới vẫn được tiếp tục nhưng cần được đặt trên một lộ trình mới. Tái cấu trúc nền kinh tế chính là tiếp tục thúc đẩy tiến trình đổi mới, để đạt được thành quả cao và hưởng lợi nhiều hơn từ đổi mới.</p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> <span style="font-family: arial; font-size: 12px; color: rgb(0, 0, 0); text-decoration: none; font-weight: bold; ">Nhóm lợi ích và thách thức tái cơ cấu</span></p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> Một mô hình tăng trường có lợi ích trước mắt nhưng có thể gây hại về lâu dài. Mô hình tăng trưởng của Việt<span class="Apple-converted-space">&nbsp;</span>Nam, không chỉ đến khủng hoảng mới bộc lộ nguy cơ, mà những bấp cập trong quản trị, phân bổ nguồn lực... đã được cảnh báo từ lâu.</p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> Vì thế, điều quan trọng nhất của tái cấu trúc là làm sao phân bố và quản lý các nguồn lực một cách hợp lý. Theo đó, cần xúc tiến đột phá chiến lược và tái cơ cấu nền kinh tế, đổi mới mô hình tăng trưởng theo hướng nâng cao hiệu quả và khả năng cạnh tranh<span style="font-family: arial; font-size: 12px; color: rgb(0, 0, 0); text-decoration: none; font-style: italic; ">.</span><span class="Apple-converted-space">&nbsp;</span>Hoàn thiện cơ chế huy động các nguồn lực ưu tiên cho các lĩnh vực, dự án có hiệu tác động lan tỏa cao, tạo tiền đề tái cơ cấu nền kinh tế thay vì sự phân phối chủ quan và kém hiệu quả của thời gian qua.</p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> Nếu như từ trước đến nay, chúng ta phân bổ nguồn lực hường tập trung vào những khu vực DN nhà nước, hay những chương trình đầu tư duy ý chí mà quên đi những tính toán hiệu quả. Vì thế, điều cần thiết là một cơ chế mới để phân phối và điều tiết nguồn lực một cách công bàng và hiệu quả. Theo đó, một thị trường đồng bộ sẽ là hệ thống phân phối nguồn lực công bằng và minh bạch. Một hệ thống thị trường đồng bộ với các yếu tố canh tranh lành mạnh thì mọi quyết định đầu tư của DN&nbsp; hay nhà nước đều mang lại hiệu quả vì phải dựa trên những điều kiện đã được phân tích, so sánh lợi thế và hiệu quả không chỉ trong nước mà cả với thế giới.</p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> Với yêu cầu đó, nhiệm vụ của Nhà nước phải nâng cao khả năng quản trị là tạo ra môi trường canh tranh, lành mạnh, có định hướng tốt... để từ đó có sự công bằng và cạnh tranh trong tiếp cận nguồn lực. Đảm bảo những khu vực hiệu quả nhất sẽ được tiếp cận nguồn lực một cách tốt nhất.</p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> Tuy nhiên, sự thay đổi này sẽ kéo theo những ảnh hưởng quyền lợi của nhiều nhóm lợi ích vốn đã được hưởng lợi nhiều từ nguồn lực sẵn có, được phân bổ một cách dễ dãi và kiểm soát kém dẫn đến hiệu quả thấp nhưng vẫn tồn tại trong sự biện minh rằng đó là sự cần thiết tất yếu. Và tất nhiên, những người hưởng lợi sẽ không dễ dàng từ bỏ.</p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> Trong khi ủng hộ quyết tâm tái cơ cấu của chính phủ nhưng nhiều chuyên gia cũng không dấu được lo ngại về những cản trở từ vấn đề lợi ích nhóm. Một trong những ngành đã thực thi những bước đi tái cơ cấu đầu tiên là ngân hàng. Tuy nhiên, Thống đốc Ngân hàng Nhà nước đã cho rằng, việc tái cấu trúc, lợi&nbsp; ích nhóm sẽ&nbsp;nổi lên rất nhiều, nhưng phải lấy lợi ích quốc gia làm trọng.</p><p style="margin: 0cm 0cm 0pt; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> Điều đó đòi hỏi những hành động kiên quyết và mạnh mẽ thể hiện quyết tâm, bản lĩnh, sáng tạo trong một lộ trình tái cơ cấu còn kéo dài. Tuy nhiên, chúng ta có niềm tin vì thực tế phát triển của Việt<span class="Apple-converted-space">&nbsp;</span>Nam<span class="Apple-converted-space">&nbsp;</span>đã không ít lần chứng minh điều đó.</p><p style="margin-right: 0cm; margin-left: 0cm; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-align: right; "> <span style="font-family: arial; font-size: 12px; color: rgb(0, 0, 0); text-decoration: none; font-style: italic; ">&nbsp;<span class="Apple-converted-space">&nbsp;</span>http://vef.vn/2012-01-19-tai-co-cau-sang-tao-de-tiep-tuc-doi-moi</span></p><p style="margin-right: 0cm; margin-left: 0cm; font-size: 12px; font-family: arial; color: rgb(0, 0, 0); text-decoration: none; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); "> Mọi thông tin&nbsp;thắc mắc cần trao&nbsp;đổi liên quan&nbsp;đến các vấn&nbsp;đề&nbsp;trên, xin Quý khách hàng vui lòng liên lạc với<span class="Apple-converted-space">&nbsp;</span><a href="http://brandco.vn/service-view-1394/service-view-872/service-view-871/service-view-858/" style="color: purple; text-decoration: underline; "><span style="font-family: arial; font-size: 12px; color: black; text-decoration: none; ">Tư vấn Luật Brandco</span></a>&nbsp;để&nbsp;được hướng dẫn chi tiết.</p>', '', 1, 0, 1, 1, 1),
(16, 'Theo Khoản 1, Ðiều 50 Luật Ðầu tư thì nhà đầu tư nước ngoài lần đầu tiên đầu tư vào Việt Nam phải có dự án đầu tư và làm thủ tục đăng ký đầu tư hoặc thẩm tra dự án đầu tư tại cơ quan Nhà nước quản lý đầu tư để được cấp Giấy chứng nhận đầu tư. Giấy chứng nhận đầu tư đồng thời là Giấy chứng nhận đăng ký kinh doanh.<br  />&nbsp;<br  />1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Các văn bản pháp luật tham khảo:<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Biểu Cam kết dịch vụ WTO của Việt&nbsp;Nam.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Quyết định 10/2007/QÐ-BTM của Bộ Thương Mại ngày 21/05/2007 về Quyết định công bố lộ trình thực hiện hoạt động mua bán hàng hóa và các hoạt động liên quan trực tiếp đến mua bán hàng hóa.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Thông tư 09/2007/TT-BTM của Bộ Thương Mại ngày 17/07/2007 về Hướng dẫn thi hành Nghị định số 23/2007/NÐ-CP ngày 12 tháng 02 năm 2007 quy định chi tiết Luật Thương mại về hoạt động mua bán hàng hóa và các hoạt động liên quan trực tiếp đến mua bán hàng hóa của doanh nghiệp có vốn đầu tư nước ngoài tại Việt Nam.<br  />2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hồ sơ xin cấp giấy phép thành lập Công ty:<br  />a.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Văn bản đề nghị cấp Giấy chứng nhận đầu tư - theo mẫu I-3 của Quyết định 1088/2006/QÐ-BKH.<br  />b.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Báo cáo năng lực tài chính của nhà đầu tư (do nhà đầu tư lập và chịu trách nhiệm).<br  />c.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Giải trình khả năng đáp ứng điều kiện mà dự án đầu tư phải đáp ứng theo quy định của pháp luật.<br  />d.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hồ sơ pháp lý liên quan đến địa chỉ trụ sở chính và địa điểm thực hiện dự án (Nhà đầu tư chỉ mang đến để chuyên viên tiếp nhận hồ sơ xem và đối chiếu).<br  />e.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Dự thảo Ðiều lệ Công ty tương ứng với từng loại hình doanh nghiệp (Công ty TNHH 2 thành viên trở lên, Công ty Cổ phần) (được người đại diện theo pháp luật, các thành viên hoặc người đại diện theo uỷ quyền ký từng trang). Danh sách thành viên sáng lập/ cổ đông sáng lập.<br  />f.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Văn bản xác nhận tư cách pháp lý của các thành viên sáng lập:<br  />&nbsp;<br  /><ul> <li> Ðối với thành viên sáng lập là pháp nhân: Bản sao hợp lệ có hợp pháp hóa lãnh sự (không quá 3 tháng trước ngày nộp hồ sơ) của một trong các loại giấy tờ: Quyết định thành lập, Giấy chứng nhận Ðăng ký kinh doanh hoặc Giấy tờ tương đương khác, Ðiều lệ (đối với pháp nhân trong nước).</li></ul>&nbsp;<br  /><ul> <li> Ðối với thành viên sáng lập là cá nhân: Bản sao hợp lệ có hợp pháp hóa lãnh sự (bản sao có công chứng không quá 3 tháng trước ngày nộp hồ sơ) của một trong các giấy tờ: Giấy chứng minh nhân dân, Hộ chiếu hoặc giấy tờ chứng thực cá nhân hợp pháp còn hiệu lực.</li></ul>&nbsp;<br  />&nbsp;<br  />g.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Văn bản uỷ quyền của Chủ sở hữu cho người được uỷ quyền đối với trường hợp chủ sở hữu công ty là tổ chức và Bản sao hợp lệ (bản sao có công chứng) một trong các giấy tờ chứng thực cá nhân của người đại diện theo uỷ quyền.<br  />&nbsp;<br  />h.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hợp đồng liên doanh đối với hình thức đầu tư thành lập tổ chức kinh tế liên doanh giữa nhà đầu tư trong nước và nhà đầu tư nước ngoài. (Tham khảo Ðiều 54, 55 Nghị định 108/2006/NÐ-CP ngày 22/09/2006).<br  />&nbsp;<br  />i.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Trường hợp dự án đầu tư liên doanh có sử dụng vốn Nhà nước thì phải có văn bản chấp thuận việc sử dụng vốn Nhà nước để đầu tư của cơ quan có thẩm quyền.<br  />&nbsp;<br  />j.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Bản sao hợp lệ chứng chỉ hành nghề của Giám đốc (Tổng Giám đốc) và các cá nhân khác quy định tại K.13 Ðiều 4 Luật Doanh nghiệp.<br  />&nbsp;<br  />3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hồ sơ nộp tại :<br  />a.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Sở Kế hoạch và Ðầu tư phòng doanh nghiệp nước ngoài Phòng Doanh nghiệp nước ngoài<br  />b.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Số lượng hồ sơ nộp: 8 bộ (trong đó có 1 bộ gốc)<br  />&nbsp;<br  />Mọi vấn đề còn thắc mắc liên quan đến thủ tục nói trên, xin Quý khách hàng vui lòng liên lạc với công ty chúng tôi để được cung cấp&nbsp;<a href="http://brandco.vn/?do=service&amp;mod=category&amp;show=search&amp;kw=ch%E1%BB%A9ng%20nh%E1%BA%ADn%20%C4%91%E1%BA%A7u%20t%C6%B0">dịch vụ tư vấn thành lập công ty có vốn đầu tư nước ngoài tại Việt nam</a>.', '', 1, 0, 1, 1, 1),
(17, 'Mặc dù chưa có quy chế pháp lý để thành lập các tập đoàn kinh tế tư nhân song thực tế, xu thế thành lập hệ thống&nbsp;<a href="http://brandco.vn/service-view-918/?do=service&amp;mod=category&amp;show=search&amp;kw=t%E1%BA%ADp%20%C4%91o%C3%A0n">doạnh nghiệp</a>&nbsp;theo mô hình tập đoàn kinh tế đang diễn ra một cách sôi động ở nước ta và mang lại hiệu quả rất lớn. Những cái tên như&nbsp;<a href="http://brandco.vn/service-view-918/?do=service&amp;mod=category&amp;show=search&amp;kw=t%E1%BA%ADp%20%C4%91o%C3%A0n">Tập đoàn kinh tế</a>&nbsp;HIPT, Tập đoàn Thái Tuấn, Tập đoàn Việt Á, Tập đoàn Mai Linh, Tập đoàn Hòa Phát… bắt đầu được biết đến một cách thuyết phục và ấn tượng. Với tư cách là nhà tư vấn cho hơn 3000 lượt doanh nghiệp tại Việt nam, Công ty luật Brandco xin chia sẻ với Quý khách hàng một số vấn đề cơ bản liên quan đến việc thành lập và quản lý điều hành một tổ hợp công ty theo mô hình&nbsp;<a href="http://brandco.vn/service-view-918/?do=service&amp;mod=category&amp;show=search&amp;kw=t%E1%BA%ADp%20%C4%91o%C3%A0n">Tập đoàn kinh tế</a>:<br  />&nbsp;<br  />I.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Những khái niệm cơ bản về tập đoàn kinh tế:<br  />1.&nbsp;<a href="http://brandco.vn/service-view-918/?do=service&amp;mod=category&amp;show=search&amp;kw=t%E1%BA%ADp%20%C4%91o%C3%A0n">Tập đoàn kinh tế</a>&nbsp;bao gồm nhóm các&nbsp;<a href="http://brandco.vn/service-category-172/thanh-lap-doanh-nghiep/">Công ty</a>&nbsp;có tư cách pháp nhân độc lập, được hình thành trên cơ sở tập hợp, liên kết thông qua đầu tư, góp vốn, sáp nhập, mua lại, tổ chức lại hoặc các hình thức liên kết khác; gắn bó lâu dài với nhau về lợi ích kinh tế, công nghệ, thị trường và các dịch vụ kinh doanh khác tạo thành tổ hợp kinh doanh có từ hai cấp công ty trở lên dưới hình thức&nbsp;<a href="http://brandco.vn/service-view-918/service-category-172/thanh-lap-doanh-nghiep/">Công ty</a>&nbsp;mẹ -&nbsp;<a href="http://brandco.vn/service-view-918/service-category-172/thanh-lap-doanh-nghiep/">Công ty</a>&nbsp;con.<br  />2. Tập đoàn kinh tế không có tư cách pháp nhân, không phải đăng ký kinh doanh theo quy định của Luật Doanh nghiệp. Việc tổ chức hoạt động của tập đoàn do các Công ty thành lập tập đoàn tự thỏa thuận quyết định.<br  /><br  />3. Công ty mẹ được tổ chức dưới hình thức Công ty cổ phần hoặc Công ty trách nhiệm hữu hạn, đáp ứng điều kiện nêu tại khoản 15 Điều 4 của Luật Doanh nghiệp.&nbsp;<a href="http://brandco.vn/service-view-918/service-category-172/thanh-lap-doanh-nghiep/">Công ty</a>&nbsp;con được tổ chức dưới hình thức Công ty cổ phần hoặc Công ty trách nhiệm hữu hạn theo quy định của Luật Doanh nghiệp hoặc của pháp Luật liên quan.<br  />&nbsp;<br  /><a href="http://brandco.vn/service-view-918/service-category-172/thanh-lap-doanh-nghiep/">Công ty</a>&nbsp;mẹ, Công ty con và các&nbsp;<a href="http://brandco.vn/service-view-918/service-category-172/thanh-lap-doanh-nghiep/">Công ty</a>&nbsp;khác hợp thành tập đoàn kinh tế có các quyền, nghĩa vụ, cơ cấu tổ chức quản lý và hoạt động phù hợp với hình thức tổ chức Tập đoàn kinh tế theo quy định của Luật doanh nghiệp, Pháp luật liên quan và Điều lệ Tập đoàn kinh tế.<br  /><br  />4. Cụm từ &quot;tập đoàn&quot; có thể sử dụng như một thành tố phụ trợ cấu thành tên riêng của&nbsp;<a href="http://brandco.vn/service-view-918/service-category-172/thanh-lap-doanh-nghiep/">Công ty</a>&nbsp;mẹ, phù hợp với các quy định từ Điều 31 đến Điều 34 của Luật Doanh nghiệp về đặt tên Doanh nghiệp.<br  /><br  /><br  />II.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dịch vụ tư vấn của Công ty luật Brandco:<br  />&nbsp;<br  />Với tư cách của một nhà tư vấn tận tâm của Quý khách hàng, Công ty luật Brandco sẽ có các hỗ trợ quan trọng dành cho Quý khách hàng, cụ thể:<br  /><ul> <li> <a href="http://brandco.vn/service-view-918/service-view-6/service-list/">Tư vấn</a>&nbsp;các vấn đề pháp lý liên quan đến quá trình thành lập, hoạt động, quản lý&nbsp;<a href="http://brandco.vn/service-view-918/?do=service&amp;mod=category&amp;show=search&amp;kw=t%E1%BA%ADp%20%C4%91o%C3%A0n">Tập đoàn kinh tế</a>;</li> <li> <a href="http://brandco.vn/service-view-918/service-view-6/service-list/">Tư vấn</a>&nbsp;xây dựng quy chế tổ chức, quản lý và hoạt động của&nbsp;<a href="http://brandco.vn/service-view-918/?do=service&amp;mod=category&amp;show=search&amp;kw=t%E1%BA%ADp%20%C4%91o%C3%A0n">Tập đoàn kinh tế</a>;</li> <li> <a href="http://brandco.vn/service-view-918/service-view-6/service-list/">Tư vấn</a>&nbsp;cơ cấu nhân sự trong&nbsp;<a href="http://brandco.vn/service-view-918/?do=service&amp;mod=category&amp;show=search&amp;kw=t%E1%BA%ADp%20%C4%91o%C3%A0n">Tập đoàn kinh tế</a>;</li> <li> <a href="http://brandco.vn/service-view-918/service-view-6/service-list/">Tư vấn</a>&nbsp;về việc thiết lập văn bản ràng buộc giữa các công ty thành viên trong T<a href="http://brandco.vn/service-view-918/?do=service&amp;mod=category&amp;show=search&amp;kw=t%E1%BA%ADp%20%C4%91o%C3%A0n">Tập đoàn kinh tế</a>;</li> <li> <a href="http://brandco.vn/service-view-918/service-view-6/service-list/">Tư vấn</a>&nbsp;cách phân chia lợi nhuận của các công ty thành viên;</li> <li> <a href="http://brandco.vn/service-view-918/service-view-6/service-list/">Tư vấn</a>&nbsp;về vốn đầu tư, vốn pháp định, vốn điều lệ… của tập đoàn và các công ty thành viên.</li> <li> <a href="http://brandco.vn/service-view-918/service-view-6/service-list/">Tư vấn</a>&nbsp;cách đặt tên&nbsp;<a href="http://brandco.vn/?do=service&amp;mod=category&amp;show=search&amp;kw=t%E1%BA%ADp%20%C4%91o%C3%A0n">Tập đoàn kinh tế</a>, tên viết tắt phù hợp với nhu cầu và yêu cầu của hoạt động kinh doanh;</li> <li> <a href="http://brandco.vn/service-view-918/service-view-6/service-list/">Tư vấn</a>&nbsp;chi tiết cho&nbsp;<a href="http://brandco.vn/service-view-918/?do=service&amp;mod=category&amp;show=search&amp;kw=t%E1%BA%ADp%20%C4%91o%C3%A0n">Tập đoàn kinh tế</a>&nbsp;các vấn đề về thuế, các nghĩa vụ về tài chính sau khi thành lập và trong quá trình hoạt động sản xuất kinh doanh ;</li> <li> <a href="http://brandco.vn/service-view-918/service-view-6/service-list/">Tư vấn</a>&nbsp;về cơ cấu nhân sự, quyền hạn, nghĩa vụ của các công ty thành viên trong tập đoàn kinh tế được xây dựng;</li></ul>&nbsp;<br  /><ul> <li> Note: Đặc&nbsp;&nbsp;biệt các luật sư của công ty luật Brandco đã trực tiếp tham gia đàm pháp và tư vấn xây dựng thành công quy chế tổ chức, quản lý và hoạt động của nhiều tổ hợp doanh nghiệp theo mô hình&nbsp;<a href="http://brandco.vn/service-view-918/?do=service&amp;mod=category&amp;show=search&amp;kw=t%E1%BA%ADp%20%C4%91o%C3%A0n">Tập đoàn kinh tế</a>&nbsp;taị Việt nam;</li></ul><br  />Mọi thông tin&nbsp;thắc mắc cần trao&nbsp;đổi liên quan&nbsp;đến các vấn&nbsp;đề&nbsp;trên, xin Quý khách hàng vui lòng liên lạc với Công ty Luật Brandco&nbsp;để&nbsp;được hướng dẫn chi tiết.', '', 1, 0, 1, 1, 1),
(14, '<div align="justify"> Là một nhà tư vấn chuyên nghiệp trong lĩnh vực tư vấn đầu tư, Công ty Luật Brandco hiện đang cung cấp nhiều các dịch vụ tư vấn đầu tư hỗ trợ Quý khách hàng, cụ thể:<br  /> &nbsp;</div><strong>- Tư vấn đầu tư trong và ngoài nước</strong>: Tư vấn và giúp khách hàng lựa chọn các hình thức đầu tư tối ưu: đầu tư trực tiếp, đầu tư gián tiếp, thành lập các đơn vị sản xuất kinh doanh như :&nbsp;<br  /><br  /><br  /><ul> <li> Thành lập Công ty Liên doanh;</li> <li> Thành lập Doanh nghiệp 100% vốn nước ngoài;</li> <li> Thành lập công ty cổ phần có vốn đầu tư nước ngoài;</li> <li> Hợp đồng hợp tác liên doanh;</li> <li> Lập dự án Đầu tư nước ngoài tại Việt&nbsp;Nam;</li> <li> Cung cấp thông tin về môi trường đầu tư tại Việt&nbsp;Nam;</li> <li> Điều tra vị trí đầu tư, đối tác, cung cấp dịch vụ Tư vấn chuyên nghiệp&nbsp; cho các Doanh nghiệp nước ngoài;</li> <li> Luật sư Đại diện tại Việt&nbsp;Nam&nbsp;cho doanh nghiệp đầu tư nước ngoài tại Việt&nbsp;Nam;</li> <li> Dự án đầu tư trong nước và đầu tư ra nước ngoài;</li> <li> Mở Văn phòng đại diện, chi nhánh công ty tại Việt nam và ở nước ngoài;</li> <li> Cơ cấu lại doanh nghiệp có vốn đầu tư nước ngoài tại Việt&nbsp;Nam;</li> <li> Giải thể, phá sản doanh nghiệp có vốn đầu tư nước ngoài tại ViệtNam;</li> <li> Hợp nhất, sáp nhập doanh nghiệp có vốn đầu tư nước ngoài tại ViệtNam;-&nbsp;&nbsp;<strong>Đại diện cho nhà đầu tư</strong>&nbsp;liên hệ với các cơ quan chức năng để triển khai Dự án;<br  /> -&nbsp;<strong>Giới thiệu về những ưu đãi đầu tư</strong>&nbsp;trong các lĩnh vực, địa bàn đầu tư cũng như điều kiện để nhận được những ưu đãi đó.<br  /> -&nbsp;<strong>Cung cấp các thông tin về các dự án</strong>&nbsp;gọi vốn đầu tư nước ngoài, bao gồm các thông tin chi tiết về các lĩnh vực, địa bàn đặc biệt khuyến khích đầu tư, các dự án có thể triển khai ngay. Những thông tin về những dự án quan trọng được cập nhật từ những cơ quan chức năng của Nhà nước Việt&nbsp;Nam.<br  /> -&nbsp;<strong>Lập Hồ sơ xin đăng ký đầu tư</strong>&nbsp;và các ưu đãi đầu tư;&nbsp;<br  /> <br  /> -&nbsp;Lập Hồ sơ&nbsp;<strong>xin cấp Giấy phép đầu tư</strong>&nbsp;và các ưu đãi đầu tư;<br  /> - Lập các Dự án chi tiết;<br  /> -&nbsp;<strong>Dịch các tài liệu pháp lý</strong>&nbsp;liên quan đến Dự án đầu tư;<br  /> -&nbsp;Tham gia đàm phán, xây dựng các&nbsp;<strong>Hợp đồng liên doanh, Hợp tác kinh doanh</strong><br  /> -&nbsp;<strong>Nhận sự uỷ quyền của các nhà đầu tư</strong>&nbsp;để liên hệ với các cơ quan chức năng Việt&nbsp;Nam&nbsp;hoàn thành các thủ tục đăng ký hoặc xin cấp phép đầu tư.<br  /> &nbsp;<br  /> Mọi thông tin&nbsp;thắc mắc cần trao&nbsp;đổi liên quan&nbsp;đến các vấn&nbsp;đề&nbsp;trên, xin Quý khách hàng vui lòng liên lạc với&nbsp;<strong>Tư vấn Luật Brandco</strong>&nbsp;để&nbsp;được hướng dẫn chi tiết<strong>. </strong><br  /> &nbsp;</li></ul>', '', 1, 0, 1, 1, 1),
(15, '<strong>1. Điều kiện cấp Giấy phép thành lập Văn phòng đại diện</strong><br  />1. Thương nhân nước ngoài được cấp Giấy phép thành lập Văn phòng đại diện tại Việt Nam khi có đủ các điều kiện sau:<br  />a) Là thương nhân được pháp luật nước, vùng lãnh thổ (sau đây gọi chung là nước) nơi thương nhân đó thành lập hoặc đăng ký kinh doanh công nhận hợp pháp;<br  />b) Đã hoạt động không dưới 01 năm, kể từ khi được thành lập hoặc đăng ký kinh doanh hợp pháp ở nước của thương nhân.<br  /><strong>2.&nbsp;Hồ sơ&nbsp;&nbsp;thành lập VPDD:</strong><br  />Hồ sơ xin cấp giấy phép thành lập VPDD của Quý khách hàng sẽ gồm các giấy tờ sau đây:<br  />1) Đơn đề nghị cấp Giấy phép thành lập văn phòng đại diện bằng tiếng Việt Nam (theo mẫu của Bộ Thương mại) do đại diện có thẩm quyền của thương nhân nước ngoài ký;<br  />2) Bản sao Giấy đăng ký kinh doanh hoặc giấy tờ có giá trị tương đương của thương nhân nước ngoài được cơ quan có thẩm quyền nơi thương nhân nước ngoài thành lập xác nhận. Trong trường hợp Giấy đăng ký kinh doanh hoặc giấy tờ có giá trị tương đương có quy định thời hạn hoạt động của thương nhân nước ngoài thì thời hạn đó phải còn ít nhất là một năm;<br  />3) Báo cáo tài chính có kiểm toán hoặc tài liệu khác có giá trị tương đương chứng minh được sự tồn tại và hoạt động thực sự của thương nhân nước ngoài trong năm tài chính gần nhất;<br  />4) Bản sao Điều lệ hoạt động của thương nhân đối với thương nhân nước ngoài là các tổ chức kinh tế.<br  />5) Bản sao hộ chiếu hoặc giấy chứng minh nhân dân (nếu là người ViệtNam); bản sao hộ chiếu (nếu là người nước ngoài) của người đứng đầu văn phòng đại diện;<br  />6) Bản sao hợp đồng thuê địa điểm đặt trụ sở văn phòng đại diện.<br  />Các giấy tờ quy định tại điểm 2 và 3 được lập bằng tiếng nước nơi thương nhân đăng ký và phải dịch ra tiếng Việt, được cơ quan đại diện ngoại giao, cơ quan lãnh sự của Việt Nam ở nước sở tại chứng nhận và thực hiện việc hợp pháp hóa lãnh sự theo quy định của pháp luật Việt Nam.&nbsp;<br  />&nbsp;<br  />Mọi thông tin&nbsp;thắc mắc cần trao&nbsp;đổi liên quan&nbsp;đến các vấn&nbsp;đề&nbsp;trên, xin Quý khách hàng vui lòng liên lạc với&nbsp;<strong>Tư vấn Luật Brandco</strong>&nbsp;để&nbsp;được hướng dẫn chi tiết<strong>. </strong><br  />', '', 1, 0, 1, 1, 1);
INSERT INTO `nv3_vi_news_bodyhtml_1` (`id`, `bodyhtml`, `sourcetext`, `imgposition`, `copyright`, `allowed_send`, `allowed_print`, `allowed_save`) VALUES
(11, '<strong>I- Lựa chọn ngành, nghề kinh doanh</strong><br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Doanh&nbsp; nghiệp có quyền kinh doanh tất cả các ngành mà pháp luật không cấm trừ kinh doanh các ngành, nghề gây phương hại đến quốc phòng, an ninh, trật tự, an toàn xã hội, truyền thống lịch sử, văn hóa, đạo đức,&nbsp; thuần phong mỹ tục Việt Nam và sức khỏe của nhân dân.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>&nbsp;Điều 7 của Luật Doanh nghiệp (Luật Doanh nghiệp năm 2005):</strong><br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1. Doanh nghiệp thuộc mọi thành phần kinh tế có quyền kinh doanh các ngành, nghề mà pháp luật không cấm.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. Đối với ngành, nghề mà pháp luật về đầu tư và pháp luật có liên quan quy định phải có điều kiện thì doanh nghiệp chỉ được kinh doanh ngành,&nbsp;nghề đó khi có đủ điều kiện theo quy định.<br  />Điều kiện kinh doanh là yêu cầu mà doanh nghiệp phải có hoặc phải thực hiện khi kinh doanh ngành, nghề cụ thể, được thể hiện bằng giấy phép kinh doanh, giấy chứng nhận đủ điều kiện kinh doanh, chứng chỉ hành nghề, chứng nhận bảo hiểm trách nhiệm nghề nghiệp, yêu cầu về vốn pháp định hoặc yêu cầu khác.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3. Cấm hoạt động kinh doanh gây phương hại đến quốc phòng, an ninh, trật tự, an toàn xã hội, truyền thống lịch sử, văn hoá, đạo đức, thuần phong mỹ tục Việt Nam và sức khoẻ của nhân dân, làm huỷ hoại tài nguyên, phá huỷ môi trường.<br  />Chính phủ quy định cụ thể danh mục ngành, nghề kinh doanh bị cấm.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4. Chính phủ định kỳ rà soát, đánh giá lại toàn bộ hoặc một phần các điều kiện kinh doanh; bãi bỏ hoặc kiến nghị bãi bỏ các điều kiện không còn phù hợp; sửa đổi hoặc kiến nghị sửa đổi các điều kiện bất hợp lý; ban hành hoặc kiến nghị ban hành điều kiện kinh doanh mới theo yêu cầu quản lý nhà nước.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5. Bộ, cơ quan ngang bộ, Hội đồng nhân dân và Uỷ ban nhân dân các cấp không được quy định về ngành, nghề kinh doanh có điều kiện và điều kiện kinh doanh.<br  /><br  /><br  />&nbsp;<strong>II- Quyền thành lập, góp vốn, mua cổ phần và quản lý doanh nghiệp:</strong><br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Điều 13 của Luật Doanh nghiệp (Luật Doanh nghiệp&nbsp; năm 2005):</strong><br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1. Tổ chức, cá nhân Việt Nam, tổ chức, cá nhân nước ngoài có quyền thành lập và quản lý doanh nghiệp tại Việt Nam theo quy định của Luật này, trừ trường hợp quy định tại khoản 2 Điều này.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. Tổ chức, cá nhân sau đây không được quyền thành lập và quản lý doanh nghiệp tại Việt Nam:<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; a) Cơ quan nhà nước, đơn vị lực lượng vũ trang nhân dân Việt Nam sử dụng tài sản nhà nước để thành lập doanh nghiệp kinh doanh thu lợi riêng cho cơ quan, đơn vị mình;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; b) Cán bộ, công chức theo quy định của pháp luật về cán bộ, công chức;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; c) Sĩ quan, hạ sĩ quan, quân nhân chuyên nghiệp, công nhân quốc phòng trong các cơ quan, đơn vị thuộc Quân đội nhân dân Việt Nam; sĩ quan,&nbsp;hạ sĩ quan chuyên nghiệp trong các cơ quan, đơn vị thuộc Công an nhân dân Việt Nam;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; d) Cán bộ lãnh đạo, quản lý nghiệp vụ trong các doanh nghiệp 100% vốn sở hữu nhà nước, trừ những người được cử làm đại diện theo uỷ quyền để quản lý phần vốn góp của Nhà nước tại doanh nghiệp khác;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; đ) Người chưa thành niên; người bị hạn chế năng lực hành vi dân sự hoặc bị mất năng lực hành vi dân sự;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; e) Người đang chấp hành hình phạt tù hoặc đang bị Toà án cấm hành nghề kinh doanh;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; g) Các trường hợp khác theo quy định của pháp luật về phá sản.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3. Tổ chức, cá nhân có quyền mua cổ phần của công ty cổ phần, góp vốn vào công ty trách nhiệm hữu hạn, công ty hợp danh theo quy định của Luật này, trừ trường hợp quy định tại khoản 4 Điều này.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4. Tổ chức, cá nhân sau đây không được mua cổ phần của công ty cổ phần, góp vốn vào công ty trách nhiệm hữu hạn, công ty hợp danh theo quy định của Luật này:<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; a) Cơ quan nhà nước, đơn vị lực lượng vũ trang nhân dân Việt Nam sử dụng tài sản nhà nước góp vốn vào doanh nghiệp để thu lợi riêng cho cơ quan, đơn vị mình;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; b) Các đối tượng không được góp vốn vào doanh nghiệp theo quy định của pháp luật về cán bộ, công chức.<br  /><br  /><br  /><strong>III- Cách đặt tên của doanh nghiệp:</strong><br  /><strong>(Tên của doanh&nbsp; nghiệp phải bảo đảm theo quy định tại Điều 31, 32, 33, 34 - Luật Doanh nghiệp năm 2005)</strong><br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Điều 31. </strong>Tên doanh nghiệp<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1. Tên doanh nghiệp phải viết được bằng tiếng Việt, có thể kèm theo chữ số và ký hiệu, phải phát âm được và có ít nhất hai thành tố sau đây:<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; a) Loại hình doanh nghiệp;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; b) Tên riêng.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. Tên doanh nghiệp phải được viết hoặc gắn tại trụ sở chính, chi nhánh, văn phòng đại diện của doanh nghiệp. Tên doanh nghiệp phải được in hoặc viết trên các giấy tờ giao dịch, hồ sơ tài liệu và ấn phẩm do doanh nghiệp phát hành.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3. Căn cứ vào quy định tại Điều này và các điều 32, 33 và 34 của Luật này, cơ quan đăng ký kinh doanh có quyền từ chối chấp thuận tên dự kiến đăng ký của doanh nghiệp. Quyết định của cơ quan đăng ký kinh doanh là quyết định cuối cùng.<br  />&nbsp;<strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Điều 32.</strong> Những điều cấm trong đặt tên doanh nghiệp<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1. Đặt tên trùng hoặc tên gây nhầm lẫn với tên của doanh nghiệp đã đăng ký.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. Sử dụng tên cơ quan nhà nước, đơn vị lực lượng vũ trang nhân dân, tên của tổ chức chính trị, tổ chức chính trị - xã hội, tổ chức chính trị xã hội - nghề nghiệp, tổ chức xã hội, tổ chức xã hội - nghề nghiệp để làm toàn bộ hoặc một phần tên riêng của doanh nghiệp, trừ trường hợp có sự chấp thuận của cơ quan, đơn vị hoặc tổ chức đó.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3. Sử dụng từ ngữ, ký hiệu vi phạm truyền thống lịch sử, văn hoá, đạo đức và thuần phong mỹ tục của dân tộc.<br  />&nbsp;<strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Điều 33.</strong> Tên doanh nghiệp viết bằng tiếng nước ngoài và tên viết tắt của doanh nghiệp<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1. Tên doanh nghiệp viết bằng tiếng nước ngoài là tên được dịch từ tên bằng tiếng Việt sang tiếng nước ngoài tương ứng. Khi dịch sang tiếng nước ngoài, tên riêng của doanh nghiệp có thể giữ nguyên hoặc dịch theo nghĩa tương ứng sang tiếng nước ngoài.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. Tên bằng tiếng nước ngoài của doanh nghiệp được in hoặc viết với khổ chữ nhỏ hơn tên bằng tiếng Việt của doanh nghiệp tại cơ sở của doanh nghiệp hoặc trên các giấy tờ giao dịch, hồ sơ tài liệu và ấn phẩm do doanh nghiệp phát hành.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3. Tên viết tắt của doanh nghiệp được viết tắt từ tên bằng tiếng Việt hoặc tên viết bằng tiếng nước ngoài.<br  />&nbsp;<strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Điều 34.</strong> Tên trùng và tên gây nhầm lẫn<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1. Tên trùng là tên của doanh nghiệp yêu cầu đăng ký được viết và đọc bằng tiếng Việt hoàn toàn giống với tên của doanh nghiệp đã đăng ký.<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. Các trường hợp sau đây được coi là tên gây nhầm lẫn với tên của doanh nghiệp đã đăng ký:<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; a) Tên bằng tiếng Việt của doanh nghiệp yêu cầu đăng ký được đọc giống như tên doanh nghiệp đã đăng ký;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; b) Tên bằng tiếng Việt của doanh nghiệp yêu cầu đăng ký chỉ khác tên doanh nghiệp đã đăng ký bởi ký hiệu “&amp;”;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; c) Tên viết tắt của doanh nghiệp yêu cầu đăng ký trùng với tên viết tắt của doanh nghiệp đã đăng ký;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; d) Tên bằng tiếng nước ngoài của doanh nghiệp yêu cầu đăng ký trùng với tên bằng tiếng nước ngoài của doanh nghiệp đã đăng ký;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; đ) Tên riêng của doanh nghiệp yêu cầu đăng ký khác với tên riêng của doanh nghiệp đã đăng ký bởi số tự nhiên, số thứ tự hoặc các chữ cái tiếng Việt ngay sau tên riêng của doanh nghiệp đó, trừ trường hợp doanh nghiệp yêu cầu đăng ký là công ty con của doanh nghiệp đã đăng ký;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; e) Tên riêng của doanh nghiệp yêu cầu đăng ký khác với tên riêng của doanh nghiệp đã đăng ký bởi từ “tân” ngay trước hoặc “mới” ngay sau tên riêng của doanh nghiệp đã đăng ký;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; g) Tên riêng của doanh nghiệp yêu cầu đăng ký chỉ khác tên riêng của doanh nghiệp đã đăng ký bằng các từ “miền bắc”, “miền nam”, “miền trung”, “miền tây”, “miền đông” hoặc các từ có ý nghĩa tương tự, trừ trường hợp doanh nghiệp yêu cầu đăng ký là công ty con của doanh nghiệp đã đăng ký.<br  />&nbsp;<br  />&nbsp;<br  />Mọi thông tin&nbsp;thắc mắc cần trao&nbsp;đổi liên quan&nbsp;đến các vấn&nbsp;đề&nbsp;trên, xin Quý khách hàng vui lòng liên lạc với <strong>Tư vấn Luật Brandco</strong>&nbsp;để&nbsp;được hướng dẫn chi tiết<strong>.</strong>', '', 1, 0, 1, 1, 1),
(12, '<strong>A.</strong>&nbsp;<strong><u>Thủ tục thành lập doanh nghiệp:</u></strong><br  />&nbsp;<br  />Để khởi sự kinh doanh theo quy định của pháp luật, các nhà đầu tư cần tiến hành thủ tục đăng ký kinh doanh để thành lập doanh nghiệp theo quy trình sau:&nbsp;<br  /><br  /><strong>1.</strong>&nbsp;<strong>Đăng ký kinh doanh:</strong><br  />Doanh nghiệp phải tiến hành nộp hồ sơ đăng ký kinh doanh của Công ty tại<strong>Sở kế hoạch và đầu tỉnh thành phố nơi doanh nghiệp đặt trụ sở chính;</strong><br  />&nbsp;<br  /><strong>2.</strong>&nbsp;<strong>Đăng ký con dấu pháp&nbsp; nhân:</strong><br  />Sau khi có Giấy đăng ký kinh doanh Quý khách hàng phải tiến hành&nbsp; đăng ký sử dụng hợp pháp con dấu pháp nhân của doanh nghiệp tại cơ quan Công an tỉnh thành phố nơi doanh nghiệp đặt trụ sở chính;<br  />&nbsp;<br  /><strong>3.</strong>&nbsp;<strong>Đăng ký mã số thuế:</strong><br  />Quý khách hàng phải đăng ký sử dụng hợp pháp Mã số thuế, Mã số Hải quan của doanh nghiệp&nbsp; tại Cục Thuế tỉnh thành phố nơi doanh nghiệp đặt trụ sở chính;<br  />&nbsp;<br  /><strong><u>B.&nbsp;Các dịch vụ hỗ trợ của Công ty luật Brandco:</u></strong><br  />Với tư cách của một nhà tư vấn tận tâm của Quý khách hàng,&nbsp;<strong>Công ty luật Brandco</strong>&nbsp;sẽ có các hỗ trợ quan trọng dành cho Quý khách hàng, cụ thể:<br  />&nbsp;<br  /><strong>I. Tư vấn, giải đáp các vướng mắc của nhà đầu tư:</strong><br  /><ul> <li> Tư vấn các vấn đề pháp lý liên quan đến quá trình thành lập, hoạt động, quản lý Doanh nghiệp;</li> <li> Tư vấn cơ cấu nhân sự trong công ty;</li> <li> Tư vấn về các hợp đồng trước khi đăng ký kinh doanh;</li> <li> Tư vấn về việc thiết lập văn bản ràng buộc giữa các thành viên/cổ đông trong công ty;</li> <li> Tư vấn hồ sơ, tài liệu chuẩn bị thành lập Doanh nghiệp;</li> <li> Tư vấn về chọn loại hình doanh nghiệp phù hợp với ngành nghề kinh doanh và quy mô của công ty;</li> <li> Tư vấn cách phân chia lợi nhuận của các thành viên;</li> <li> Tư vấn chi tiết về thủ tục mua hoá đơn lần đầu cho doanh nghiệp;</li> <li> Tư vấn về vốn đầu tư ban đầu, vốn pháp định, vốn điều lệ…</li> <li> Tư vấn cách đặt tên Doanh nghiệp, tên viết tắt phù hợp với nhu cầu và yêu cầu của hoạt động kinh doanh và tiến hành tra cứu tên doanh nghiệp;</li> <li> Tư vấn về đăng ký ngành nghề Đăng ký kinh doanh (lựa chọn, sắp xếp ngành nghề và dự tính ngành nghề kinh doanh sắp tới);</li> <li> Tư vấn những điều kiện trước khi thành lập, những điều kiện sau khi thành lập đối với nghành nghề đăng ký kinh doanh;</li> <li> Tư vấn chi tiết cho doanh nghiệp các vấn đề về thuế, các nghĩa vụ về tài chính sau khi đăng ký kinh doanh và quá trình hoạt động sản xuất kinh doanh ;</li> <li> Tư vấn về cơ cấu nhân sự, quyền hạn, nghĩa vụ của các thành viên/cổ đông trong công ty;</li></ul><br  /><strong><u>II. Tư vấn, soạn thảo tài liệu hò sơ doanh nghiệp:</u></strong><br  /><ul> <li> Đơn đăng ký kinh doanh;</li> <li> Danh sách&nbsp; thành viên/cổ đông;</li> <li> Điều lệ công ty;</li> <li> Quyết định bổ nhiệm Kế toán trưởng;</li> <li> Sổ đăng ký thành viên/cổ dông sáng lập.&nbsp;</li> <li> Hợp đồng lao động_nếu có;</li> <li> Biên bản họp công ty về việc góp vốn của sáng lập viên;</li> <li> Giấy chứng nhận góp vốn cho các thành viên/cổ đông;</li> <li> Quyết định bổ nhiệm Giám đốc;</li></ul><strong><u>III. Thực hiện dịch vụ tư vấn:</u></strong><br  /><ul> <li> Đại diện cho khách hàng trên phòng đăng ký kinh doanh của sở&nbsp;kế hoạch và đầu tư để nộp hồ&nbsp;sơ Thành lập Doanh nghiệp;</li> <li> Đại diện cho khách hàng để theo dõi hồ sơ của doanh nghiệp và nhận kết quả trả lời của Phòng đăng ký kinh doanh;</li> <li> Nhận kết quả là Giấy chứng nhận ĐKKD tại Phòng đăng ký kinh doanh;</li> <li> Đại diện tại cơ quan Công an để xin giấy phép sử dụng con dấu;</li> <li> Tiến hành thủ tục để làm con dấu cho Doanh nghiệp (dấu công ty, dấu chức danh, dấu đăng ký&nbsp;mã số thuế);</li> <li> Tiến hành thủ tục đăng ký mã số thuế và mã số hải quan cho doanh nghiệp;</li></ul>&nbsp;<br  /><strong>IV.</strong>&nbsp;<strong>Thời gian thực hiện dịch vụ:</strong><br  />Thời gian để hoàn thiện thủ tục thành lập doanh nghiệp là 05 - 20 ngày làm việc. Tuy nhiên,&nbsp;<strong>thời gian nói trên có thể thay đổi theo yêu cầu</strong>&nbsp;của Quý khách hàng.<br  />&nbsp;<br  /><em><strong><u>Lưu ý</u></strong></em><em><strong>:&nbsp;</strong></em><em>Trong quá trình thành lập Doanh nghiệp người đại diện theo pháp luật của doanh nghiệp phải 02 lần đến cơ quan đăng ký kinh doanh (1) để ký nhận giấy chứng nhận đăng ký kinh doanh (2) ký lấy dấu pháp nhân của doanh nghiệp)_khách hàng nhớ mang theo một trong hai giấy tờ: CMTND bản gốc hoặc Hộ Chiếu.</em><br  />&nbsp;<br  /><strong>C.Trách nhiệm của Công ty luật Brandco sau thành lập:</strong><br  /><ul> <li> Tư vấn chính sách thuế hiện hành liên quan đến hoạt động của doanh nghiệp;</li> <li> Tư vấn các vấn đề liên quan đến tổ chức và hoạt động của doanh nghiệp;</li> <li> Hướng dẫn thủ tục mua hóa đơn thuế Giá trị gia tăng;</li> <li> Tư vấn kê khai thuế;</li> <li> Tư vấn và hoàn thiện Bộ hồ sơ Nội bộ doanh nghiệp, bao gồm: Điều lệ Doanh nghiệp, Danh sách thành viên, Giấy chứng nhận Vốn góp, các Quyết định bổ nhiệm các chức danh quản lý của doanh nghiệp...</li></ul>&nbsp;<br  /><strong>Note: Đặc biệt, để đồng hành cùng sự phát triển của Cộng đồng doanh nhân Việt. Công ty Luật Brandco cam kết tư vấn miễn phí về chính sách pháp luật hiện hành liên quan đến hoạt động của Công ty 01 năm sau thành lập</strong>;<br  />&nbsp;<br  />Hãy để chúng tôi chuẩn hóa ý tưởng&nbsp;thành lập doanh nghiệp&nbsp;của bạn bằng cách cung cấp thông tin thành lập doanh nghiệp theo mẫu sau:&nbsp;<a href="http://www.camnangphapluat.com/Uploaded/admins/YEU%20CAU%20THONG%20TIN%20TL%20CA%20NHAN%20MOI.doc">YEU CAU THONG TIN TL CA NHAN MOI.doc</a><br  />&nbsp;<br  />=========================<br  />Mọi thông tin&nbsp;thắc mắc cần trao&nbsp;đổi liên quan&nbsp;đến các vấn&nbsp;đề&nbsp;trên, xin Quý khách hàng vui lòng liên lạc với&nbsp;<strong>Công ty Luật Brandco</strong>&nbsp;để&nbsp;được hướng dẫn chi tiết<strong>.</strong>', '', 1, 0, 1, 1, 1),
(13, 'Việc lựa chọn hình thức doanh nghiệp trước khi bắt đầu công việc kinh doanh là rất quan trọng, nó có ảnh hưởng không nhỏ tới sự tồn tại và phát triển của doanh nghiệp. Về cơ bản, những sự khác biệt tạo ra bởi loại hình doanh nghiệp là: (i) uy tín doanh nghiệp do thói quen tiêu dùng; (ii) khả năng huy động vốn; (iii) rủi ro đầu tư; (iv) tính phức tạp của thủ tục và các chi phí thành lập doanh nghiệp; (v) tổ chức quản lý doanh nghiệp.<br  />&nbsp;<br  /><strong>1. Công ty cổ phần:</strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Vốn điều lệ được chia thành nhiều phần bằng nhau gọi là cổ phần (Công ty cổ phần phải có cổ phần phổ thông và có thể có cổ phần ưu đãi. Cổ phần ưu đãi gồm các loại như cổ phần ưu đãi biểu quyết, cổ phần ưu đãi cổ tức, cổ phần ưu đãi hoàn lại và cổ phần ưu đãi khác do Điều lệ công ty quy định);<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cổ đông có thể là tổ chức, cá nhân; số lượng cổ đông tối thiểu là ba và không hạn chế số lượng tối đa;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cổ đông chỉ chịu trách nhiệm về các khoản nợ và nghĩa vụ tài sản khác của doanh nghiệp trong phạm vi số vốn đã góp vào doanh nghiệp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cổ đông có quyền tự do chuyển nhượng cổ phần của mình cho người khác, trừ trường hợp (Cổ đông sở hữu cổ phần ưu đãi biểu quyết không được chuyển nhượng cổ phần đó cho người khác; Trong thời hạn ba năm, kể từ ngày công ty được cấp Giấy chứng nhận đăng ký kinh doanh, cổ đông sáng lập có quyền tự do chuyển nhượng cổ phần phổ thông của mình cho cổ đông sáng lập khác nhưng chỉ được chuyển nhượng cổ phần phổ thông của mình cho người không phải là cổ đông sáng lập nếu được sự chấp thuận của Đại hội đồng cổ đông sau 3 năm mọi hạn chế đối với cổ đông sáng lập bị bãi bỏ).<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty cổ phần có quyền phát hành chứng khoán các loại để huy động vốn.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty cổ phần có tư cách pháp nhân kể từ ngày được cấp Giấy chứng nhận đăng ký kinh doanh.<br  /><strong><u>Ưu điểm:</u></strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chế độ trách nhiệm của công ty cổ phần là trách nhiệm hữu hạn, các cổ đông chỉ chịu trách nhiệm về nợ và các nghĩa vụ tài sản khác của công ty trong phạm vi vốn góp nên mức độ rủi do của các cổ đông không cao;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Khả năng hoạt động của công ty cổ phần rất rộng, trong hầu hết các lịch vực, ngành nghề;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cơ cấu vốn của công ty cổ phần hết sức linh hoạt tạo điều kiện nhiều người cùng góp vốn vào công ty;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Khả năng huy động vốn của công ty cổ phầnrất cao thông qua việc phát hành cổ phiếu ra công chúng, đây là đặc điểm riêng có của công ty cổ phần;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Việc chuyển nhượng vốn trong công ty cổ phần là tương đối dễ dàng, do vậy phạm vi đối tượng được tham gia công ty cổ phần là rất rộng, ngay cả các cán bộ công chức cũng có quyền mua cổ phiếu của công ty cổ phần.<br  /><strong><u>Nhược điểm:</u></strong><br  />Bên cạnh những lợi thế nêu trên, loại hình công ty cổ phần cũng có những hạn chế nhất định như.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Việc quản lý và điều hành công ty cổ phần rất phức tạp do số lượng các cổ đông có thể rất lớn, có nhiều người không hề quen biết nhau và thậm chí có thể có sự phân hóa thành các nhóm cổ động đối kháng nhau về lợi ích;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Việc thành lập và quản lý công ty cổ phần cũng phức tạp hơn các loại hình công ty khác do bị ràng buộc chặt chẽ bởi các quy định của pháp luật, đặc biệt về chế độ tài chính, kế toán.<br  />&nbsp;<br  /><strong>2. Công ty trách nhiệm hữu hạn 2 thành viên trở lên:</strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thành viên có thể là tổ chức, cá nhân; số lượng thành viên không vượt quá năm mươi;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thành viên chịu trách nhiệm về các khoản nợ và nghĩa vụ tài sản khác của doanh nghiệp trong phạm vi số vốn cam kết góp vào doanh nghiệp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phần vốn góp của thành viên được chuyển nhượng cho người khác (Phần vốn góp của thành viên được phép chuyển nhượng toàn bộ hoặc một phần cho các thành viên còn lại trong công ty hoặc cho người không phải là thành viên công ty nếu các thành viên còn lại của công ty không mua hoặc không mua hết. Thành viên công ty cũng có quyền yêu cầu công ty mua lại phần vốn góp của mình nếu không đồng ý với quyết định của Hội đồng thành viên về những vấn đề các vấn đề như sửa đổi, bổ sung Điều lệ công ty liên quan đến quyền và nghĩa vụ của thành viên, quyền và nhiệm vụ của Hội đồng thành viên; tổ chức lại công ty; và các trường hợp khác quy định tại Điều lệ công ty).<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty trách nhiệm hữu hạn không được quyền phát hành cổ phần.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty trách nhiệm hữu hạn có tư cách pháp nhân kể từ ngày được cấp Giấy chứng nhận đăng ký kinh doanh.<br  />&nbsp;<br  /><strong>3.Công ty trách nhiệm hữu hạn một thành viên:</strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty trách nhiệm hữu hạn một thành viên là doanh nghiệp do một tổ chức hoặc một cá nhân làm chủ sở hữu (gọi là chủ sở hữu công ty); chủ sở hữu công ty chịu trách nhiệm về các khoản nợ và nghĩa vụ tài sản khác của công ty trong phạm vi số vốn điều lệ của công ty.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty trách nhiệm hữu hạn một thành viên không được quyền phát hành cổ phần.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty trách nhiệm hữu hạn một thành viên có tư cách pháp nhân kể từ ngày được cấp Giấy chứng nhận đăng ký kinh doanh.<br  /><strong><u>Ưu điểm</u></strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Do có tư cách pháp nhân nên các thành viên công ty chỉ trách nhiệm về các hoạt động của công ty trong phạm vi số vốn góp vào công ty nên ít gây rủi ro cho người góp vốn;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Số lượng thành viên công ty trách nhiệm không nhiều và các thành viên thường là người quen biết, tin cậy nhau, nên việc quản lý, điều hành công ty không quá phức tạp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chế độ chuyển nhượng vốn được điều chỉnh chặt chẽ nên nhà đầu tư dễ dàng kiểm soát được việc thay đổi các thành viên, hạn chế sự thâm nhập của người lạ vào công ty.<br  /><strong><u>Nhược điểm:</u></strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Do chế độ trách nhiệm hữu hạn nên uy tín của công ty trước đối tác, bạn hàng cũng phần nào bị ảnh hưởng;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty trách nhiệm hữu hạn chịu sự điều chỉnh chặt chẽ của pháp luật hơn là doanh nghiệp tư nhân hay công ty hợp danh;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Việc huy động vốn của công ty trách nhiệm hữu hạn bị hạn chế do không có quyền phát hành cổ phiếu.<br  />&nbsp;<br  /><strong>4. Công ty hợp danh:</strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phải có ít nhất hai thành viên là chủ sở hữu chung của công ty, cùng nhau kinh doanh dưới một tên chung (gọi là thành viên hợp danh); ngoài các thành viên hợp danh có thể có thành viên góp vốn (thành viên góp vốn không được tham gia quản lý công ty và hoạt động kinh doanh nhân danh công ty);<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thành viên hợp danh phải là cá nhân, chịu trách nhiệm bằng toàn bộ tài sản của mình về các nghĩa vụ của công ty;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thành viên góp vốn chỉ chịu trách nhiệm về các khoản nợ của công ty trong phạm vi số vốn đã góp vào công ty.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty hợp danh không được phát hành bất kỳ loại chứng khoán nào.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Công ty hợp danh có tư cách pháp nhân kể từ ngày được cấp Giấy chứng nhận đăng ký kinh doanh.<br  /><strong><u>Ưu điểm:</u></strong><br  />Ưu điểm của công ty hợp danh là kết hợp được uy tín cá nhân của nhiều người. Do chế độ liên đới chịu trách nhiệm vô hạn của các thành viên hợp danh mà công ty hợp danh dễ dàng tạo được sự tin cậy của các bạn hàng, đối tác kinh doanh. Việc điều hành quản lý công ty không quá phức tạp do số lượng các thành viên ít và là những người có uy tín, tuyệt đối tin tưởng nhau.<br  /><strong><u>Nhược điểm:</u></strong><br  />Hạn chế của công ty hợp danh là do chế độ liên đới chịu trách nhiệm vô hạn nên mức độ rủi ro của các thành viên hợp danh là rất cao.<br  />Loại hình công ty hợp danh được quy định trong Luật doanh nghiệp năm 1999 và 2005 nhưng trên thực tế loại hình doanh nghiệp này chưa phổ biến.<br  /><br  />&nbsp;<br  /><strong>5. Doanh nghiệp tư nhân:</strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Doanh nghiệp tư nhân là doanh nghiệp do một cá nhân làm chủ và tự chịu trách nhiệm bằng toàn bộ tài sản của mình về mọi hoạt động của doanh nghiệp.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Doanh nghiệp tư nhân không được phát hành bất kỳ loại chứng khoán nào.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mỗi cá nhân chỉ được quyền thành lập một doanh nghiệp tư nhân.<br  /><strong><u>Ưu điểm:</u></strong><br  />Do là chủ sở hữu duy nhất của doanh nghiệp nên doanh nghiệp tư nhân hoàn toàn chủ động trong việc quyết định các vấn đề liên quan đến hoạt động kinh doanh của Doanh nghiệp. Chế độ trách nhiệm vô hạn của chủ doanh nghiệp tư nhân tạo sự tin tưởng cho đối tác, khách hàng và giúp cho doanh nghiệp ít chịu sự ràng buộc chặt chẽ bởi pháp luật như các loại hình doanh nghiệp khác.<br  /><strong><u>Nhược điểm:</u></strong><br  />Do không có tư cách pháp nhân nên mức độ rủi ro của chủ doanh tư nhân cao, chủ doanh nghiệp tư nhân phải chịu trách nhiệm bằng toàn bộ tài sản của doanh nghiệp và của chủ doanh nghiệp chứ không giới hạn số vốn mà chủ doanh nghiệp đã đầu tư vào doanh nghiệp.<br  /><br  /><br  /><strong>6. Hợp tác xã.</strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hợp tác xã là tổ chức kinh tế tập thể do các cá nhân, hộ gia đình, pháp nhân (gọi chung là xã viên) có nhu cầu, lợi ích chung, tự nguyện góp vốn, góp sức lập ra theo quy định của Luật hợp tác xã để phát huy sức mạnh tập thể của từng xã viên tham gia hợp tác xã, cùng giúp nhau thực hiện có hiệu quả các hoạt động sản xuất, kinh doanh và nâng cao đời sống vật chất, tinh thần, góp phần phát triển kinh tế - xã hội của đất nước.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hợp tác xã là một loại hình doanh nghiệp đặc biệt, có tư cách pháp nhân, tự chủ, tự chịu trách nhiệm về các nghĩa vụ tài chính trong phạm vi vốn điều lệ, vốn tích luỹ và các nguồn vốn khác của hợp tác xã theo quy định của pháp luật. Nhưng ưu điểm, nhược điểm của Hợp tác xã.<br  /><strong><u>Ưu điểm</u></strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Có thể thu hút được đông đảo người lao động tham gia;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Việc quản lý hợp tác xã thực hiện trên nguyên tắc dân chủ và bình đẳng nên mọi xã viên đều bình đẳng trong việc tham gia quyết định các vấn đề liên quan đến hoạt động của hợp tác xã không phân biệt nhiều vốn hay ít vốn;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Các xã viên tham gia hợp tác xã chỉ chịu trách nhiệm trước các hoạt động của hợp tác xã trong phạm vi vốn góp vào hợp tác xã.<br  /><strong><u>Nhược điểm:</u></strong><br  />Hoạt động kinh doanh theo hình thức hợp tác xã cũng có những hạn chế nhất định như.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Không khuyến khích được người nhiều vốn;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nhiều kinh nghiệm quản lý, kinh doanh tham gia hợp tác xã do nguyên tắc chia lợi nhuận kết hợp lợi ích của xã viên với sự phát triển của hợp tác xã;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Việc quản lý hợp tác xã phức tạp do số lượng xã viên đông;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sở hữu manh mún của các xã viên đối tài sản của mình làm hạn chế các quyết định của Hợp tác xã.<br  />&nbsp;<br  />&nbsp;<br  />(Các quy định trên căn cứ theo Luật Doanh nghiệp được Quốc hội thông qua ngày 29/11/2005 có hiệu lực thi hành từ ngày 01/07/2006.)', '', 1, 0, 1, 1, 1),
(19, '<strong>Đối tượng bảo hộ bản quyền tác giả bao gồm:&nbsp;</strong>các tác phẩm văn học, khoa học, sách giáo khoa, giáo trình, chương trình máy tính, sưu tập dữ liệu và các tác phẩm khác được thể hiện dưới dạng chữ viết hoặc ký tự khác; các bài giảng, bài phát biểu và bài nói khác; tác phẩm báo chí; tác phẩm âm nhạc; tác phẩm sân khấu; tác phẩm điện ảnh và các tác phẩm được tạo ra theo phương pháp tương tự; tác phẩm tạo hình, mỹ thuật ứng dụng; tác phẩm nhiếp ảnh; tác phẩm kiến trúc; các bản họa đồ, sơ đồ, bản đồ, bản vẽ liên quan đến địa hình, công trình khoa học; tác phẩm văn học, nghệ thuật dân gian…<br  />Ý tưởng được thể hiện tác phẩm không cần phải đảm bảo tính mới, tuy nhiên, tác phẩm phải là sự sáng tạo nguyên gốc của tác giả. Việc bảo hộ bản quyền tác giả không phụ thuộc vào chất lượng hoặc giá trị của tác phẩm thậm chí cả mục đích mà tác phẩm hướng tới và việc sử dụng tác phẩm như thế nào. Tác giả không có nghĩa vụ chứng minh quyền tác giả, quyền liên quan thuộc về mình khi có tranh chấp trừ trường hợp có chứng cứ ngược lại.<br  />Tư vấn Luật Brandco là một tổ chức tư vấn, dịch vụ quyền tác giả, quyền liên quan có chức năng tư vấn và đại diện cho tác giả, chủ sở hữu tác phẩm và người có quyền liên quan thực hiện các dịch vụ sau:<br  />1. Tra cứu thông tin và tình trạng pháp lý các tác phẩm viết; bài giảng; bài phát biểu; tác phẩm điện ảnh; tác phẩm sẩn khấu; tác phẩm âm nhạc; tác phẩm báo chí; tác phẩm kiến trúc; tác phẩm tạo hình, mỹ thuật ứng dụng; Công trình khoa học, sách giáo khao, giáo trình; Các bức họa đồ, bản vẽ sơ đồ, bản đồ; Tác phẩm dịch, phóng tác, cải biên, chuyển thể, biên soạn, chú giải, tuyến tập, hợp tuyển…<br  />2. Nộp đơn đăng ký bản quyển tác giả cho tác giả, đồng tác giả, cho chủ sở hữu tác phẩm;<br  />3. Đại diện cho khách hàng đàm phán tiến hành việc chuyển nhượng, cho phép sử dụng, chuyển thể, sao chép tác phẩm …<br  />4. Đại diện cho khách hàng kết hợp với cơ quan Nhà nước có thẩm quyền tiến hành các thủ tục hành chính; Tham gia tố tụng Dân sự, Hình sự tại Toà án các cấp có thẩm quyền nhằm bảo vệ các đối tượng đã đăng ký, chống lại các hành vi xâm hại quyền đối với tác phẩm và tác giả;<br  /><br  /><br  />Mọi thông tin&nbsp;thắc mắc cần trao&nbsp;đổi liên quan&nbsp;đến các vấn&nbsp;đề&nbsp;trên, xin Quý khách hàng vui lòng liên lạc với&nbsp;<strong>Tư vấn Luật Brandco</strong>&nbsp;để&nbsp;được hướng dẫn chi tiết<strong>.&nbsp;</strong><br  />', '', 1, 0, 1, 1, 1);
INSERT INTO `nv3_vi_news_bodyhtml_1` (`id`, `bodyhtml`, `sourcetext`, `imgposition`, `copyright`, `allowed_send`, `allowed_print`, `allowed_save`) VALUES
(20, 'Là một doanh nghiệp hàng đầu trong lĩnh vực sản xuất hàng hóa trong xu thế hội nhập hiện nay, Quý khách hàng hãy giành&nbsp;&nbsp;một phần quan trọng trong quỹ thời gian quý báu của mình để thực hiện ngay các hoạt động xác lập quyền đối với các&nbsp;<strong>sáng chế</strong>&nbsp;mình đang sở hữu, tránh mọi hành vi xâm hại đáng tiếc có thể xảy ra với doanh nghiệp của mình.<strong>Công ty Luật Brandco</strong>, với tư cách là một chuyên gia hàng đầu về bảo hộ độc quyền&nbsp;<strong>sáng chế</strong>, xin được chia sẻ với các bạn một số kinh nghiệm liên quan để bảo vệ quyền hợp pháp của mình với loại tài sản đặc biệt này.<br  /><br  /><strong>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>Sáng chế là gì?</strong><br  />Sáng chế&nbsp;là giải pháp kỹ thuật dưới dạng sản phẩm hoặc quy trình nhằm giải quyết một vấn đề xác định bằng việc ứng dụng các quy luật tự nhiên.<br  />&nbsp;<br  /><strong>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>Căn cứ xác lập quyền sở hữu công nghiệp đối với sáng chế.</strong><br  /><br  />Quyền sở hữu công nghiệp đối với&nbsp;&nbsp;sáng chế được xác lập trên cơ sở quyết định cấp văn bằng bảo hộ của Cơ quan Nhà nước có thẩm quyền theo thủ tục đăng ký quy định tại&nbsp;<strong>Luật Sở hữu trí tuệ</strong>&nbsp;hoặc công nhận đăng ký quốc tế theo quy định của điều ước quốc tế mà Cộng hoà xã hội chủ nghĩa Việt Nam là thành viên.<br  />&nbsp;<br  /><strong>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>Quyền nộp đơn đăng ký sáng chế:</strong><br  /><br  /><strong>Các đối tượng sau có quyền nộp đơn đăng ký bảo hộ độc quyền sáng chế tại cơ quan nhà nước có thẩm quyền:</strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tác giả tạo ra sáng chế bằng công sức và chi phí của mình;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tổ chức, cá nhân đầu tư kinh phí, phương tiện vật chất cho tác giả dưới hình thức giao việc, thuê việc, trừ trường hợp các bên có thoả thuận khác.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Đối với sáng chế được tạo ra do sử dụng cơ sở vật chất - kỹ thuật, kinh phí từ ngân sách nhà nước quyền đăng ký sang chế thuộc về Nhà nước. Tổ chức, cơ quan nhà nước được giao quyền chủ đầu tư có trách nhiệm đại diện Nhà nước thực hiện quyền đăng ký. Trong trường hợp sáng chế được tạo ra trên cơ sở Nhà nước góp vốn đầu tư thì tổ chức, cá nhân được nhà nước giao quyền đầu tư có trách nhiệm đại diện Nhà nước thực hiện quyền đăng ký<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Trường hợp nhiều tổ chức, cá nhân cùng nhau tạo ra hoặc đầu tư để tạo ra sáng chế, kiểu dáng công nghiệp, thiết kế bố trí thì các tổ chức, cá nhân đó đều có quyền đăng ký và quyền đăng ký đó chỉ được thực hiện nếu được tất cả các tổ chức, cá nhân đó đồng ý.<br  />&nbsp;<br  /><strong>4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>Doanh nghiệp cần cân nhắc những điều gì trước khi làm đơn đăng ký sáng chế&nbsp;?</strong><br  /><br  />Sáng chế sẽ bị từ chối bảo hộ nếu thuộc một trong những trường hợp sau đây:<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phát minh, lý thuyết khoa học, phương pháp toán học;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sơ đồ, kế hoạch, quy tắc và phương pháp để thực hiện các hoạt động trí óc, huấn luyện vật nuôi, thực hiện trò chơi, kinh doanh; chương trình máy tính;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cách thức thể hiện thông tin;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Giải pháp chỉ mang đặc tính thẩm mỹ;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Giống thực vật, giống động vật;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Quy trình sản xuất thực vật, động vật chủ yếu mang bản chất sinh học mà không phải là quy trình vi sinh;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phương pháp phòng ngừa, chẩn đoán và chữa bệnh cho người và động vật.<br  />&nbsp;<br  /><strong>5.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>Sáng chế đảm bảo những điều kiện gì để được bảo hộ?</strong><br  /><br  />Sáng chế được bảo hộ dưới hình thức cấp Bằng độc quyền sáng chế nếu đáp ứng các điều kiện sau đây:<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Có tính mới;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Có trình độ sáng tạo;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Có khả năng áp dụng công nghiệp.<br  />&nbsp;<br  /><strong>6.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>Hồ sơ đăng ký yêu cầu cấp bằng độc quyền đăng ký sáng chế.</strong><br  /><br  />Hồ sơ đăng ký sáng chế được lập bằng tiếng Việt bao gồm những tài liệu tối thiểu sau đây:<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tờ khai đăng ký sáng chế (được lập theo mẫu);<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bản mô tả sáng chế;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Các tài liệu khác (Giấy uỷ quyền nếu nộp đơn thông qua đại diện; tài liệu chứng minh quyền ưu tiên, tài liệu chứng minh quyền đăng ký…);<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chứng từ phí/lệ phí&nbsp;;<br  />&nbsp;<br  /><strong>7.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>Quá trình xem xét đơn kéo dài trong bao lâu?</strong><br  /><br  />Thời hạn thẩm định về hình thức đơn đăng ký sáng chế là 01 tháng kể từ ngày nộp đơn.<br  />Thẩm định hình thức đơn là việc kiểm tra việc tuân thủ các quy định về hình thức đối với đơn, từ đó đưa ra kết luận đơn có được coi là hợp lệ hay không.<br  />Việc thẩm định nội dung đơn đăng ký sáng chế chỉ có thể được tiến hành khi có yêu cầu của chủ đơn. Thời hạn thẩm định nội dung đơn đăng ký sáng chế là 12 tháng kể từ ngày công bố đơn nếu yêu cầu thẩm định nội dung được nộp trước ngày công bố đơn hoặc kể từ ngày nhận được yêu cầu thẩm định nội dung nếu yêu cầu đó được nộp sau ngày công bố đơn<br  />Mục đích của việc thẩm định nội dung đơn là đánh giá khả năng được bảo hộ của đối tượng nêu trong đơn theo các điều kiện bảo hộ, xác định phạm vi (khối lượng) bảo hộ tương ứng.<br  />&nbsp;<br  />&nbsp;<br  /><strong>8.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>Trước khi cấp văn bằng độc quyền, chủ đơn có quyền nào không?</strong><br  /><br  />Trường hợp người nộp đơn đăng ký sáng chế/giải pháp hữu ích biết rằng sáng chế/giải pháp hữu ích đang được người khác sử dụng nhằm mục đích thương mại và người đó không có quyền sử dụng trước thì người nộp đơn có quyền thông báo bằng văn bản cho người sử dụng về việc mình đã nộp đơn đăng ký, trong đó chỉ rõ ngày nộp đơn và ngày công bố đơn trên Công báo sở hữu công nghiệp để người đó chấm dứt việc sử dụng hoặc tiếp tục sử dụng.<br  /><br  />Trong trường hợp đã được thông báo mà người được thông báo vẫn tiếp tục sử dụng sáng chế/giải pháp hữu ích thì khi Bằng độc quyền sáng chế/giải pháp hữu ích được cấp, chủ sở hữu sáng chế/giải pháp hữu íchcó quyền yêu cầu người đã sử dụng sáng chế/giải pháp hữu ích phải trả một khoản tiền đền bù tương đương với giá chuyển giao quyền sử dụng sáng chế/giải pháp hữu ích đó trong phạm vi và thời hạn sử dụng tương ứng.<br  />&nbsp;<br  /><strong>9.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>Khai thác và bảo vệ sáng chế đã được cấp bằng độc quyền.</strong><br  /><br  />Trường hợp được chấp nhận đăng ký, sáng chế được ghi nhận vào sổ đăng bạ (Sổ đăng ký quốc gia về sáng chế), chủ đơn được cấp Bằng độc quyền sáng chế và trở thành chủ sở hữu sáng chế.<br  />Chủ sở hữu sáng chế có các quyền sau đây:<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sản xuất sản phẩm theo giải pháp kỹ thuật được bảo hộ;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Áp dụng quy trình được bảo hộ;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Khai thác công dụng của sản phẩm được bảo hộ hoặc sản phẩm được sản xuất theo quy trình được bảo hộ;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Lưu thông, quảng cáo, chào hàng, tàng trữ để lưu thông sản phẩm được sản xuất theo quy trình được bảo hộ;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nhập khẩu sản phẩm được sản xuất theo quy trình được bảo hộ<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tự mình sử dụng sáng chế hoặc cho phép người khác sử dụng sáng chế (để đổi lấy các lợi ích vật chất khác) hoặc ngăn cấm người khác sử dụng sáng chế;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chuyển nhượng quyền sở hữu sáng chế cho người khác (để đổi lấy các lợi ích vật chất)<br  />&nbsp;<br  /><strong>10.&nbsp;&nbsp;&nbsp;</strong><strong>Chủ văn bằng độc quyền sáng chế/giải pháp hữu ích có nghĩa vụ gì không?</strong><br  /><br  />Chủ văn bằng độc quyền sáng chế/ giải pháp hữu ích có nghĩa vụ sau đây:<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Trả thù lao cho tác giả: tối thiểu 10% tiền làm lợi, 15% tiền chuyển giao quyền sử dụng sáng chế/giải pháp hữu ích trong suốt khoảng thời gian có hiệu lực của văn bằng bảo hộ;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Không được cấm chủ thể khác sử dụng sáng chế/giải pháp hữu ích trên cơ sở người đó có quyền sử dụng trước;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cho phép sử dụng sáng chế cơ bản nhằm sử dụng sáng chế phụ thuộc;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chuyển giao quyền sử dụng sáng chế theo quyết định của cơ quan Nhà nước về việc chuyển giao không tự nguyện&nbsp;;<br  />&nbsp;<br  /><strong>11.&nbsp;&nbsp;&nbsp;</strong><strong>Chủ văn bằng độc quyền sáng chế/giải pháp hữu ích&nbsp;&nbsp;phải làm gì để bảo vệ quyền của mình?</strong><br  />&nbsp;<br  />Để bảo vệ quyền của mình, chủ văn bằng cần theo dõi để phát hiện có chủ thể nào xâm phạm đến quyền của mình hay không, bao gồm những hành vi sau đây:<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sử dụng sáng chế/giải pháp hữu ích được bảo hộ, trong thời hạn hiệu lực của văn bằng bảo hộ mà không được phép của chủ sở hữu;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sử dụng sáng chế/giải pháp hữu ích mà không trả tiền đền bù theo quy định về quyền tạm thời tại Luật sở hữu trí tuệ.<br  />&nbsp;<br  />Trong trường hợp có phát hiện có hành vi xâm hại, chủ văn bằngcó quyền yêu cầu cơ quan Nhà nước có thẩm quyền can thiệp để bảo vệ quyền của mình.&nbsp;Doanh nghiệp cũng cần phối hợp với các cơ quan bảo vệ pháp luật bằng cách cung cấp thông tin, chứng cứ về hành vi vi phạm.<br  />&nbsp;<br  />Hành vi xâm phạm quyền sở hữu sáng chế/giải pháp hữu ích phải bị chấm dứt trọng mọi trường hợp. Người có hành vi xâm phạm bị xử lý vi phạm hành chính. Chủ văn bằng cũng có thể kiện người xâm phạm ra toà theo thủ tục tố tụng dân sự yêu cầu bồi thường thiệt hại về những thiệt hại mà mình phải gánh chịu.<br  />&nbsp;<br  /><strong>12.&nbsp;&nbsp;&nbsp;</strong><strong>Các dịch vụ về sáng chế của Tư vấn Luật Brandco&nbsp;:</strong><br  />&nbsp;<br  /><strong>Là nhà tư vấn chuyên nghiệp trong lĩnh vực tư vấn xác lập và bảo hộ độc quyền&nbsp;</strong><strong>kiểu dáng công nghiệp</strong><strong>,&nbsp;</strong><strong>tư vấn luật Brandco</strong><strong>&nbsp;cung cấp các dịch vụ tư vấn chuyên nghiệp sau cho khách hàng:</strong><br  />&nbsp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn về khả năng bảo hộ sáng chế/giải pháp hữu ích;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tra cứu và cung cấp các thông tin sáng chế/giải pháp hữu ích và Khoa học kỹ thuật ở Việt&nbsp;Nam&nbsp;và nước ngoài;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hoàn thiện hồ sơ bao gồm dịch và/hoặc viết bản mô tả sáng chế, và tiến hành các thủ tục xin cấp Bằng độc quyền sáng chế và giải pháp hữu ích;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn về hiệu lực của Bằng độc quyền;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn bảo vệ quyền lợi khách hàng trước những hành vi xâm phạm quyền của chủ sở hữu Bằng độc quyền;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thay mặt khách hàng khiếu kiện Quyết định của Cục sở hữu trí tuệ bao gồm phản đối, kiến nghị thay đổi quyết định;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn và đại diện cho khách hàng trong việc đăng ký sáng chế ở các nước thành viên của Hiệp ước Hợp tác Patent (PCT) mà Việt&nbsp;Namlà một quốc gia thành viên.<br  />&nbsp;<br  />Mọi thông tin&nbsp;thắc mắc cần trao&nbsp;đổi liên quan&nbsp;đến các vấn&nbsp;đề&nbsp;trên, xin Quý khách hàng vui lòng liên lạc với&nbsp;<strong>Tư vấn Luật Brandco</strong>&nbsp;để&nbsp;được hướng dẫn chi tiết<strong>. </strong><br  />', '', 1, 0, 1, 1, 1),
(21, 'Là một doanh nghiệp hàng đầu trong lĩnh vực sản xuất hàng hóa trong xu thế hội nhập hiện nay, Quý khách hàng hãy giành&nbsp;&nbsp;một phần quan trọng trong quỹ thời gian quý báu của mình để thực hiện ngay các hoạt động xác lập quyền đối với các kiểu dáng công nghiệp minh đang sở hữu, tránh mọi hành vi xâm hại đáng tiếc có thể xảy ra với doanh nghiệp của mình. Công ty Luật Brandco, với tư cách là một chuyên gia hàng đầu về bảo hộ độc quyền kiểu dáng công nghiệp, xin được chia sẻ với các bạn một số kinh nghiệm liên quan để bảo vệ quyền hợp pháp của mình với loại tài sản đặc biệt này.<br  />&nbsp;<br  /><strong>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>Kiểu dáng công nghiệp là gì?</strong><br  /><br  />Kiểu dáng công nghiệp là hình dáng bên ngoài của sản phẩm được thể hiện bằng hình khối, đường nét, màu sắc hoặc sự kết hợp những yếu tố này.<br  />&nbsp;<br  /><strong>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>Căn cứ xác lập quyền sở hữu công nghiệp đối với kiểu dáng công nghiệp.</strong><br  /><br  />Quyền sở hữu công nghiệp đối với&nbsp;&nbsp;kiểu dáng công nghiệp được xác lập trên cơ sở quyết định cấp văn bằng bảo hộ của Cơ quan Nhà nước có thẩm quyền theo thủ tục đăng ký quy định tại Luật Sở hữu trí tuệ hoặc công nhận đăng ký quốc tế theo quy định của điều ước quốc tế mà Cộng hoà xã hội chủ nghĩa Việt Nam là thành viên.<br  />&nbsp;<br  /><strong>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>Quyền nộp đơn đăng ký kiểu dáng công nghiệp</strong><br  /><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tác giả tạo ra kiểu dáng công nghiệp bằng công sức và chi phí của mình;&nbsp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tổ chức, cá nhân đầu tư kinh phí, phương tiện vật chất cho tác giả dưới hình thức giao việc, thuê việc, trừ trường hợp các bên có thoả thuận khác.&nbsp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Đối với kiểu dáng công nghiệp được tạo ra do sử dụng cơ sở vật chất - kỹ thuật, kinh phí từ ngân sách nhà nước quyền đăng ký kiểu dáng công nghiệp thuộc về Nhà nước. Tổ chức, cơ quan nhà nước được giao quyền chủ đầu tư có trách nhiệm đại diện Nhà nước thực hiện quyền đăng ký.&nbsp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Trường hợp nhiều tổ chức, cá nhân cùng nhau tạo ra hoặc đầu tư để tạo ra kiểu dáng công nghiệp, kiểu dáng công nghiệp, thì các tổ chức, cá nhân đó đều có quyền đăng ký và quyền đăng ký đó chỉ được thực hiện nếu được tất cả các tổ chức, cá nhân đó đồng ý.<br  />&nbsp;<br  /><strong>4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>Kiểu dáng công nghiệp đảm bảo những điều kiện gì để được bảo hộ?</strong><br  /><br  />Kiểu dáng công nghiệp được bảo hộ dưới hình thức cấp Bằng độc quyền kiểu dáng công nghiệp nếu đáp ứng các điều kiện sau đây:&nbsp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Có tính mới;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Có tính&nbsp;sáng tạo;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Có khả năng áp dụng công nghiệp.<br  /><br  />Kiểu dáng công nghiệp được coi là có khả năng áp dụng công nghiệp nếu có thể dùng làm mẫu để chế tạo hàng loạt sản phẩm có hình dáng bên ngoài là kiểu dáng công nghiệp đó bằng phương pháp công nghiệp hoặc thủ công nghiệp.<br  />&nbsp;<br  /><strong>5.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>Hồ sơ đăng ký yêu cầu cấp bằng độc quyền đăng ký kiểu dáng công nghiệp.</strong><br  />Hồ sơ đăng ký kiểu dáng công nghiệp được lập bằng tiếng Việt bao gồm những tài liệu tối thiểu sau đây:<br  /><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tờ khai đăng ký kiểu dáng công nghiệp (được lập theo mẫu);<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bản mô tả kiểu dáng công nghiệp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bộ ảnh chụp/bản vẽ kiểu dáng công nghiệp yêu cầu bảo hộ<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Các tài liệu khác (Giấy uỷ quyền nếu nộp đơn thông qua đại diện; tài liệu chứng minh quyền ưu tiên, tài liệu chứng minh quyền đăng ký…);<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chứng từ phí/lệ phí;<br  />&nbsp;<br  /><strong>6.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>Cách thức nộp và theo đuổi đơn đăng ký kiểu dáng công nghiệp.</strong><br  />&nbsp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hồ sơ yêu cầu đăng ký kiểu dáng công nghiệp được nộp tại Cục sở hữu trí tuệ là Cơ quan quản lý nhà nước về kiểu dáng công nghiệp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chủ đơn có thể tự mình nộp đơn đăng ký kiểu dáng công nghiệp hoặc có thể nộp qua trung gian là các tổ chức dịch vụ đại diện sở hữu công nghiệp. Nếu chủ đơn chưa hiểu rõ cách thức làm và nộp đơn đăng ký kiểu dáng công nghiệp thì nên sử dụng các dịch vụ chuyên nghiệp – thay mặt mình làm và nộp đơn đăng ký kiểu dáng công nghiệp.<br  />&nbsp;<br  /><strong>7.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>Quá trình xem xét đơn kéo dài trong bao lâu?</strong><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thời hạn thẩm định về hình thức đơn đăng ký kiểu dáng công nghiệp là 01 tháng kể từ ngày nộp đơn.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thẩm định hình thức đơn là việc kiểm tra việc tuân thủ các quy định về hình thức đối với đơn, từ đó đưa ra kết luận đơn có được coi là hợp lệ hay không.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Đơn đăng ký kiểu dáng công nghiệp được thẩm định nội dung trong thời hạn 6 tháng kể từ ngày công bố đơn. Mục đích của việc thẩm định nội dung đơn là đánh giá khả năng được bảo hộ của đối tượng nêu trong đơn theo các điều kiện bảo hộ, xác định phạm vi (khối lượng) bảo hộ tương ứng.<br  />&nbsp;<br  /><strong>8.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>Trước khi cấp văn bằng độc quyền, chủ đơn có quyền nào?</strong><br  /><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Trường hợp người nộp đơn đăng ký kiểu dáng công nghiệp biết rằng kiểu dáng công nghiệp&nbsp;đang được người khác sử dụng nhằm mục đích thương mại và người đó không có quyền sử dụng trước thì người nộp đơn có quyền thông báo bằng văn bản cho người sử dụng về việc mình đã nộp đơn đăng ký, trong đó chỉ rõ ngày nộp đơn và ngày công bố đơn trên Công báo sở hữu công nghiệp để người đó chấm dứt việc sử dụng hoặc tiếp tục sử dụng.<br  /><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Trong trường hợp đã được thông báo mà người được thông báo vẫn tiếp tục sử dụng kiểu dáng công nghiệp thì khi Bằng độc quyền kiểu dáng công nghiệp được cấp, chủ sở hữu kiểu dáng công nghiệpcó quyền yêu cầu người đã sử dụng kiểu dáng công nghiệp phải trả một khoản tiền đền bù tương đương với giá chuyển giao quyền sử dụng kiểu dáng công nghiệp đó trong phạm vi và thời hạn sử dụng tương ứng.<br  />&nbsp;<br  /><strong>9.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>Khai thác và bảo vệ kiểu dáng công nghiệp đã được cấp bằng độc quyền.</strong><br  />&nbsp;<br  />Trường hợp được chấp nhận đăng ký, kiểu dáng công nghiệp được ghi nhận vào sổ đăng bạ (Sổ đăng ký quốc gia về kiểu dáng công nghiệp), chủ đơn được cấp Bằng độc quyền kiểu dáng công nghiệp và trở thành chủ sở hữu kiểu dáng công nghiệp.<br  />&nbsp;<br  />Chủ sở hữu kiểu dáng công nghiệp có các quyền sau đây:<br  /><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sản xuất sản phẩm có hình dáng bên ngoài là kiểu dáng công nghiệp được bảo hộ;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Lưu thông, quảng cáo, chào hàng, tàng trữ để lưu thông sản phẩm quy định tại điểm a khoản này;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nhập khẩu sản phẩm có hình dáng bên ngoài là kiểu dáng công nghiệp được bảo hộ<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tự mình sử dụng kiểu dáng công nghiệp hoặc cho phép người khác sử dụng kiểu dáng công nghiệp (để đổi lấy các lợi ích vật chất khác) hoặc ngăn cấm người khác sử dụng kiểu dáng công nghiệp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chuyển nhượng quyền sở hữu kiểu dáng công nghiệp cho người khác (để đổi lấy các lợi ích vật chất)&nbsp;;<br  />&nbsp;<br  /><strong>10.&nbsp;&nbsp;&nbsp;</strong><strong>Chủ văn bằng độc quyền kiểu dáng công nghiệp&nbsp;&nbsp;phải làm gì để bảo vệ quyền của mình?</strong><br  />Để bảo vệ quyền của mình, chủ văn bằng cần theo dõi để phát hiện có chủ thể nào xâm phạm đến quyền của mình hay không, bao gồm những hành vi sau đây:<br  /><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sử dụng kiểu dáng công nghiệp được bảo hộ, trong thời hạn hiệu lực của văn bằng bảo hộ mà không được phép của chủ sở hữu;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sử dụng kiểu dáng công nghiệp mà không trả tiền đền bù theo quy định về quyền tạm thời tại Luật sở hữu trí tuệ.<br  /><br  /><br  />Trong trường hợp có phát hiện có hành vi xâm hại, chủ văn bằng có quyền yêu cầu cơ quan Nhà nước có thẩm quyền can thiệp để bảo vệ quyền của mình. Doanh nghiệp cũng cần phối hợp với các cơ quan bảo vệ pháp luật bằng cách cung cấp thông tin, chứng cứ về hành vi vi phạm.<br  /><br  /><br  />Hành vi xâm phạm quyền sở hữu kiểu dáng công nghiệp phải bị chấm dứt trọng mọi trường hợp. Người có hành vi xâm phạm bị xử lý vi phạm hành chính. Chủ văn bằng cũng có thể kiện người xâm phạm ra toà theo thủ tục tố tụng dân sự yêu cầu bồi thường thiệt hại về những thiệt hại mà mình phải gánh chịu.<br  />&nbsp;<br  /><strong>11.&nbsp;&nbsp;&nbsp;</strong><strong>Các dịch vụ về kiểu dáng công nghiệp do Tư vấn Luật Brandco cung cấp:</strong><br  />&nbsp;<br  /><strong>Là nhà tư vấn chuyên nghiệp trong lĩnh vực tư vấn xác lập và bảo hộ độc quyền&nbsp;</strong><strong>kiểu dáng công nghiệp</strong><strong>,&nbsp;</strong><strong>tư vấn luật Brandco</strong><strong>&nbsp;cung cấp các dịch vụ tư vấn chuyên nghiệp sau cho khách hàng:</strong><br  /><br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tra cứu thông tin về đăng ký và sử dụng&nbsp;<strong>Kiểu dáng công nghiệp</strong>;&nbsp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Đánh giá khả năng đăng ký và sử dụng Kiểu dáng công nghiệp;&nbsp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nộp đơn và tiến hành các thủ tục pháp lý đăng ký&nbsp;<strong>Kiểu dáng công nghiệp</strong>;&nbsp;-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn và tiến hành các thủ tục pháp lý ghi nhận chuyển giao đơn đăng ký KDCN;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn và tiến hành các thủ tục pháp lý khiếu nại, phản đối cấp hay không cấp Kiểu dáng công nghiệp;&nbsp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ghi nhận sửa đổi liên quan đến đơn xin đăng ký KDCN, ví dụ như: tên, địa chỉ của người nộp đơn;&nbsp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn và tiến hành các thủ tục pháp lý ghi nhận sửa đổi liên quan đến Văn bằng bảo hộ KDCN trên cơ sở chuyển nhượng quyền sở hữu, sáp nhập công ty; ghi nhận đổi tên, địa chỉ chủ Văn bằng bảo hộ;&nbsp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Duy trì, ra hạn hiệu lực bằng độc quyền kiểu dáng công nghiệp;&nbsp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn, thực hiện và phối kết hợp với các cơ quan chức năng tiến hành xử lý các vi phạm đến Độc quyền kiểu dáng công nghiệp theo trình tự thủ tục hành chính;&nbsp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn, đại diện và cử luật sư tố tụng dân sự, tố tụng hình sự tại Tòa án nhân dân các cấp.<br  />&nbsp;<br  />Mọi thông tin&nbsp;thắc mắc cần trao&nbsp;đổi liên quan&nbsp;đến các vấn&nbsp;đề&nbsp;trên, xin Quý khách hàng vui lòng liên lạc với&nbsp;<strong>Tư vấn Luật Brandco</strong>&nbsp;để&nbsp;được hướng dẫn chi tiết<strong>. </strong><br  />', '', 1, 0, 1, 1, 1),
(22, 'Hãng luật Brandco là một hãng tư vấn luật thành công nhất ở Việt Nam trong việc phối hợp có hiệu quả với các cơ quan có thẩm quyền Việt Nam tiến hành các biện pháp thực thi quyền chống lại vi phạm quyền nhãn hiệu hàng hoá, kiểu dáng công nghiệp, bản quyền tác giả và sáng chế để đảm bảo rằng quyền sở hữu trí tuệ của Quý doanh nghiệp được bảo hộ, thực thi phù hợp với mục tiêu và chiến lược của họ trên thị trường. Liên quan đến hoạt động thực thi quyền SHTT, hãng luật Brandco cung cấp các dịch vụ tư vấn, đại diện sau:<br  /><ul> <li> Tư vấn và đại diện cho khách hàng trong các vụ tranh chấp và kiếu nại liên quan đến việc xác lập quyền sở hữu trí tuệ, bao gồm: <ul> <li> Khiếu nại các quyết định từ chối cấp văn bằng bảo hộ các đối tượng sở hữu trí tuệ;</li> <li> Phản đối đơn xin cấp Văn bằng bảo hộ các đối tượng sở hữu công nghiệp;</li> <li> Phản đối các quyết định cấp Văn bằng bảo hộ các đối tượng sở hữu công nghiệp của cơ quan Nhà nước có thẩm quyền;</li> </ul> </li> <li> Tư vấn và đại diện cho khách hàng trong việc thực thi quyền sở hữu trí tuệ, bao gồm:</li> <li> Yêu cầu cơ quan Nhà nước có thẩm quyền thẩm định và kết luận về các hành vi vi phạm các đối tượng sở hữu trí tuệ;</li> <li> Yêu cầu người vi phạm chấm dứt hành vi vi phạm;</li> <li> Yêu cầu các cơ quan Nhà nước có thẩm quyền xử lý vi phạm;&nbsp;</li> <li> Tham gia tố tụng với tư cách luật sư bảo vệ quyền và lợi ích của khách hàng liên quan đến sở hữu trí tuệ tại Toà án có thẩm quyền.</li></ul>Trong thời gian qua, Hãng luật Brandco đã trợ giúp thành công các doanh nghiệp trong và ngoài nước trong nhiều vụ tranh chấp pháp lý quan trọng liên quan đến SHCN và thực thi quyền sở hữu trí tuệ.<br  />Mọi thông tin&nbsp;liên quan đến các hoạt động xử lý vi phạm quyền sở hữu trí tuệ, xin Quý khách hàng vui lòng liên lạc với&nbsp;<strong>Hãng luật Brandco</strong>&nbsp;để&nbsp;được hướng dẫn sử dụng dịch vụ<strong>.</strong>', '', 1, 0, 1, 1, 1),
(23, 'Bộ Luật Lao động và các văn bản hướng dẫn thi hành có rất nhiều quy định nhằm bảo vệ quyền và lợi ích của người lao động, tuy nhiên quá trình áp dụng pháp luật tại các doanh nghiệp, tổ chức nếu không xây dựng trên sự bình đẳng, đúng pháp Luật sẽ dễ dẫn đến sự vi phạm quyền lợi, gây nên sự bất đồng, tranh chấp. Là một tổ chức hành nghề luật sư có nhiều kinh nghiệm trong&nbsp;&nbsp;lĩnh vực tư vấn pháp luật lao động, Công ty Luật Brandco thực hiện tư vấn chuyên sâu cho khách hàng các lĩnh vực sau:<br  />1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn nội dung Hợp đồng lao động nhằm đảm bảo tốt nhất quyền lợi của người sử dụng lao động và ràng buộc trách nhiệm của người lao động đối với doanh nghiệp;<br  />2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn hoàn thiện hồ sơ lao động; hồ sơ bảo hiểm xã hội của người lao động làm việc tại doanh nghiệp của Bên yêu cầu tư vấn theo quy định của pháp luật lao động;<br  />3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn xây dựng, hoàn thiện quy định về thang bảng lương, quy chế tăng lương... tại doanh nghiệp của Bên yêu cầu tư vấn theo quy định của pháp luật lao động;<br  />4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn nội dung Bản Thỏa ước lao động tập thể giữa người lao động và doanh nghiệp của bên yêu cầu tư vấn theo quy định của pháp luật lao động;<br  />5.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn, xây dựng và hoàn thiện nội quy lao động trong doanh nghiệp phù hợp với quy định của pháp luật và đáp ứng nhu cầu của chủ sử dụng lao động.<br  />6.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn, chuẩn hóa toàn bộ hồ sơ quản lý lao động của doanh nghiệp theo quy định pháp luật lao động, bao gồm nhưng không giới hạn: các quyết định bổ nhiệm, các quyết định phân công công tác, phạm vi thẩm quyền của các cơ quan, bộ phận trong doanh nghiệp; tư vấn về thẩm quyền trong công tác quản lý doanh nghiệp...<br  />I. CĂN CỨ PHÁP LÝ:<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bộ luật Lao động (đã được sửa đổi, bổ sung năm 2002, 2006, 2007);<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Các văn bản hướng dẫn thi hành Bộ luật lao động.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Luật doanh nghiệp và các văn bản hướng dẫn thi hành Luật doanh nghiệp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Các văn bản quy&nbsp;&nbsp;phạm pháp luật liên quan khác;<br  />&nbsp;<br  />II. Ý KIẾN TƯ VẤN:<br  />1. Liên quan đến dịch vụ tư vấn pháp luật nói trên, công ty chúng tôi sẽ thực hiện các công việc sau:<br  />a)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Giai đoạn thứ nhất:<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn các vấn đề pháp lý liên quan đến lao động tại Việt Nam;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Khảo sát thực trạng doanh nghiệp và các yêu cầu của Quý khách hàng về nội quy lao động, quy chế tổ chức, hoạt động trong doanh nghiệp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phân tích và tư vấn những nội dung chính liên quan đến các yêu cầu tư vấn của doanh nghiệp;<br  />b)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Giai đoạn thứ hai:<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn và soạn thảo hợp đồng lao động và các thỏa thuận liên quan đến lao động.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn và soạn thảo thỏa ước lao động tập thể;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn, soạn thảo quy định về thang bảng lương doanh nghiệp theo quy định của pháp luật;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn cấu trúc và các nội dung chính của một thỏa ước lao động tập thể&nbsp;&nbsp;phù hợp với hoạt động sản xuất kinh doanh và&nbsp;&nbsp;cơ cấu tổ chức của doanh nghiệp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Đại diện đàm phán về nội dung của thỏa ước lao động tập thể;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn cơ cấu và nội dung của nội quy lao động, quy chế tổ chức, hoạt động phù hợp với hoạt động sản xuất, kinh doanh và cơ cấu tổ chức của doanh nghiệp;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Soạn thảo nội quy lao động, quy chế tổ chức, hoạt động cho Quý khách hàng;<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tư vấn, chuẩn hóa toàn bộ hồ sơ quản lý lao động của doanh nghiệp theo quy định pháp luật lao động, bao gồm nhưng không giới hạn: các quyết định bổ nhiệm, các quyết định phân công công tác, phạm vi thẩm quyền của các cơ quan, bộ phận trong doanh nghiệp; tư vấn về thẩm quyền trong công tác quản lý doanh nghiệp.<br  />a)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Giai đoạn thứ ba:<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Họp thống nhất với quý khách hàng về các nội dung theo yêu cầu tư vấn của quý khách hàng;<br  />b)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Giai đoạn thứ tư:<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thay mặt Quý khách hàng nộp hồ sơ đăng ký thỏa ước lao động tập thể với cơ quan lao động địa phương, bao gồm cả việc đại diện khách hàng thương thảo với cơ quan lao động địa phương về nội dung của thỏa ước lao động tập thể.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thay mặt Quý khách hàng nộp hồ sơ đăng ký nội quy lao động với cơ quan lao động địa phương nếu doanh nghiệp thuộc diện phải đăng ký nội quy lao động theo quy định của pháp luật.', '', 1, 0, 1, 1, 1),
(24, 'Là Hãng luật hàng đầu trong lĩnh vực tư vấn đầu tư và tư vấn Sở hữu trí tuệ, hãng luật Brandco xin giới thiệu với Quý doanh nghiệp các dịch vụ pháp lý liên quan tới các hợp đồng, bao gồm việc chuẩn bị cơ sở pháp lý, đàm phán, soạn thảo và hiệu chỉnh các loại hợp đồng kinh tế, thương mại, đầu tư….<br  />&nbsp;<br  /><h2> A.Phạm vi hợp đồng:</h2>- Hợp đồng kinh tế,<br  />- Hợp đồng thương mại,<br  />- Hợp đồng đầu tư,<br  />- Hợp đồng dân sự,<br  />- Hợp đồng lao động,<br  />- Hợp đồng hợp đồng hợp tác kinh doanh,<br  />- Hợp đồng hợp đồng liên doanh,<br  />- Hợp đồng hợp đồng mua bán hàng hóa,<br  />- Hợp đồng hợp đồng bảo đảm bí mật...<br  />- Hợp đồng li-xăng;<br  />- Hợp đồng mua bán;<br  />- Các loại hợp đồng khác...<br  />&nbsp;<br  /><h2> B.Nội dung tư vấn:</h2>&nbsp;- Hãng luật Brandco chuẩn bị các cơ sở pháp lý, các văn bản pháp luật điều chỉnh các vấn đề liên quan;<br  />- Hãng luật Brandco nghiên cứu tài liệu liên quan, tìm hiểu thông tin liên quan về các bên của hợp đồng trong các trường hợp cụ thể theo yêu cầu của doanh nghiệp từ đó đưa ra giải pháp tư vấn tối ưu cho việc soạn thảo và ký kết hợp đồng, đảm bảo lợi ích tối đa cho doanh nghiệp và cân bằng được lợi ích của các bên trong hợp đồng;<br  />- Hãng luật Brandco cử (các) Luật sư tham gia vào ban đàm phán hợp đồng;<br  />- Hãng luật Brandco đưa ra các ý kiến pháp lý để bên thuê Tư vấn đánh giá, quyết định trong việc đàm phán các nội dung hợp đồng;<br  />- Hãng luật Brandco thẩm định các nội dung, rà soát, chỉnh sửa các điều khoản hợp đồng do đối tác đưa ra;<br  />&nbsp;- Hãng luật Brandco soạn thảo các điều khỏan hợp đồng cần thiết, đàm phán với đối tác để bảo vệ các điều khỏan quan trọng, bảo đảm được quyền hợp pháp của bên thuê tư vấn;<br  />- Hãng luật Brandco soạn thảo và hiệu chỉnh các điều khỏan liên quan tới quyền và nghĩa vụ của các bên trong hợp đồng;<br  />- Hãng luật Brandco tư vấn và soạn thảo các nội dung khác trên cơ sở các qui định của pháp luật về hợp đồng như điều khỏan thanh toán, phạt hợp đồng, luật áp dụng, cơ quan tài phán...&nbsp;<br  />&nbsp;<br  /><h2> C.Thời gian thực hiện dịch vụ:</h2>Thời gian hoàn thành công việc tư vấn, soạn thảo hợp đồng từ 05 - 20 ngày làm việc, tùy theo yêu cầu tư vấn của Quý doanh nghiệp. Tuy nhiên, <strong>thời gian nói trên có thể thay đổi theo yêu cầu</strong> của Quý khách hàng.<br  />&nbsp;<br  />&nbsp;<br  /><h2> D.Phí dịch vụ tư vấn;</h2>Mức phí dịch vụ tư&nbsp; vấn&nbsp; được tính toán dựa trên sự phức tạp của yêu cầu công việc và khối lượng công việc thực tế. Phí dịch vụ tư&nbsp; vấn&nbsp; sẽ được thông báo sau khi đã làm rõ các yêu cầu của Quý doanh nghiệp.', '', 1, 0, 1, 1, 1);
INSERT INTO `nv3_vi_news_bodyhtml_1` (`id`, `bodyhtml`, `sourcetext`, `imgposition`, `copyright`, `allowed_send`, `allowed_print`, `allowed_save`) VALUES
(25, '1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Việc phân chia tài sản thừa kế theo quy định của pháp luật:<br  />- Pháp luật Việt nam khẳng định quyền được thừa kế của mọi cá nhân, tổ chức theo quy định tại Điều 631, Bộ luật Dân sự, cụ thể: “Cá nhân có quyền lập di chúc để định đoạt tài sản của mình; để lại tài sản của mình cho người thừa kế theo pháp luật; hưởng di sản theo di chúc hoặc theo pháp luật.”<br  />Theo quy định này: Mọi cá nhân, tổ chức đều được quyền để lại di sản của mình cho người thừa kế&nbsp; hoặc được nhận thừa kế do người khác để lại theo di chúc hoặc theo pháp luật.<br  />&nbsp;<br  />A. Thừa kế theo di chúc:<br  />Được quy định tại Điều 646, Bộ luật Dân sự: “Di chúc là sự thể hiện ý chí của cá nhân nhằm chuyển tài sản của mình cho người khác sau khi chết”. Quy định này được hiểu là việc người có tài sản có quyền để lại tài sản của mình cho người khác sau khi chết.<br  />- Hình thức của di chúc:&nbsp; Được quy định tại Điều 649, Bộ Luật Dân sự: “ Di chúc phải được lập thành văn bản; nếu không thể lập được di chúc bằng văn bản thì có thể di chúc miệng. Người thuộc dân tộc thiểu số có quyền lập di chúc bằng chữ viết hoặc tiếng nói của dân tộc mình.”<br  />- Nội dung của di chúc phải đáp ứng các điều kiện sau: Quy định tại Điều 652, Bộ luật Dân sự&nbsp;:<br  />a) Người lập di chúc minh mẫn, sáng suốt trong khi lập di chúc; không bị lừa dối, đe doạ hoặc cưỡng ép;<br  />b) Nội dung di chúc không trái pháp luật, đạo đức xã hội; hình thức di chúc không trái quy định của pháp luật.<br  />c) Người lập di chúc phải tự tay viết và ký vào bản di chúc.<br  />d) Trong trường hợp người lập di chúc không thể tự mình viết bản di chúc thì có thể nhờ người khác viết, nhưng phải có ít nhất là hai người làm chứng. Người lập di chúc phải ký hoặc điểm chỉ vào bản di chúc trước mặt những người làm chứng; những người làm chứng xác nhận chữ ký, điểm chỉ của người lập di chúc và ký vào bản di chúc.<br  />Nếu di chúc được lập đảm bảo tất&nbsp; cả các điều kiện tại mục a, b,c,d&nbsp; nói trên thì không cần thiết phải công chứng, chứng thực.<br  />Tuy nhiên, để đảm bảo giá trị&nbsp; của di chúc Người lập di chúc có thể yêu cầu công chứng hoặc chứng thực bản di chúc, tức là bạn có thể yêu cầu cơ quan công chứng hoặc ủy ban nhân dân xác nhận.<br  />Di chúc&nbsp; chỉ phát sinh hiệu lực khi người để lại di chúc chết.<br  />&nbsp;<br  />B. Thừa kế theo pháp&nbsp; luật:<br  />Trong trường hợp người để lại di sản thừa kế chết mà không để lại di chúc hoặc để lại di chúc không hợp pháp thì di sản thừa kế sẽ được chia theo quy định của pháp luật cho các người thừa kế theo pháp luật được quy định tại Điều 676, Bộ luật dân sự, cụ thể:<br  />1. Những người thừa kế theo pháp luật được quy định theo thứ tự sau đây:<br  />a) Hàng thừa kế thứ nhất gồm: vợ, chồng, cha đẻ, mẹ đẻ, cha nuôi, mẹ nuôi, con đẻ, con nuôi của người chết;<br  />b) Hàng thừa kế thứ hai gồm: ông nội, bà nội, ông ngoại, bà ngoại, anh ruột, chị ruột, em ruột của người chết; cháu ruột của người chết mà người chết là ông nội, bà nội, ông ngoại, bà ngoại;<br  />c) Hàng thừa kế thứ ba gồm: cụ nội, cụ ngoại của người chết; bác ruột, chú ruột, cậu ruột, cô ruột, dì ruột của người chết; cháu ruột của người chết mà người chết là bác ruột, chú ruột, cậu ruột, cô ruột, dì ruột, chắt ruột của người chết mà người chết là cụ nội, cụ ngoại.<br  />2. Những người thừa kế cùng hàng được hưởng phần di sản bằng nhau.<br  />3. Những người ở hàng thừa kế sau chỉ được hưởng thừa kế, nếu không còn ai ở hàng thừa kế trước do đã chết, không có quyền hưởng di sản, bị truất quyền hưởng di sản hoặc từ chối nhận di sản.<br  />&nbsp;<br  />2. Việc phân chia tài sản thừa kế áp dụng đối với các loại tài sản khác nhau được thực hiện như thế nào<br  />Việc chia tài sản thừa kế theo hai phương thức trên được áp dụng đối với mọi tài sản hợp pháp của&nbsp; người để lại di sản, bao gồm&nbsp;:<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Tài sản là bất động sản&nbsp;: quyền sử dụng đất, quyền sở hữu nhà...<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Tài sản là bất động sản&nbsp;: tiền, các giấy tờ trị giá được bằng tiền, các động sản khác&nbsp;: ô tô, xe máy....<br  />Các loại tài sản nói trên được chia thành hai loại chính&nbsp;:<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Tài sản phải đăng ký quyền sở hữu, quyền sử dụng&nbsp;: Quyền sử&nbsp; dụng đất, quyền sở hữu nhà, ô tô, xe máy, cổ phiếu...<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Tài sản không phải đăng ký&nbsp;: Tiền, vàng, kim khí quý, đá quý...<br  />Căn cứ vào việc phân chia nói trên, người để lại sản thừa kế và người nhận di sản thừa kế lại có phương thức để lại và nhận tài sản thừa kế khác nhau tương ứng&nbsp;:<br  />A.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Đối với&nbsp; tài sản là bất động sản và tài sản phải đăng ký&nbsp;:<br  />Trường hợp&nbsp; này, để tạo điều kiện thuận lợi cho quá trình cho và nhận di sản cũng như xác lập quyền đối với di sản, người để lại di sản và người nhận di sản phải xác định cụ thể&nbsp; loại di sản để lại, ví dụ&nbsp;: tên tài sản, số đăng ký, cơ quan cấp đăng ký, vị trí tài sản.. và các đặc điểm khác theo quy định của pháp luật.<br  />Khuyến nghị&nbsp;:<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Việc để lại di sản&nbsp; nên được lập thành di chúc bằng văn&nbsp; bản có luật sư làm chứng hoặc công chứng viên chứng nhận.<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Khi phát sinh hiệu lực của việc nhận di sản, nên tiến hành đăng ký ngay theo quy định của pháp luật để xác&nbsp; lập quyền của người nhận di sản.<br  />B.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Đối với tài sản là động sản và tài sản không phải đăng ký&nbsp;:<br  />Trường hợp&nbsp; này, để tạo điều kiện thuận lợi cho quá trình cho và nhận di sản cũng như xác lập quyền đối với di sản, người để lại di sản và người nhận di sản phải xác định cụ thể&nbsp; loại di sản để lại, ví dụ&nbsp;: tên tài sản, số lượng, giá trị, vị trí tài sản.. và các đặc điểm khác theo quy định của pháp luật.<br  />Khuyến nghị&nbsp;:<br  />-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Việc để lại di sản&nbsp; nên được lập thành di chúc bằng văn&nbsp; bản có luật sư làm chứng hoặc công chứng viên chứng nhận để hạn chế tranh chấp xảy ra.', '', 1, 0, 1, 1, 1),
(26, '<strong>1. Điều kiện cấp phép:</strong>Là tổ chức, cá nhân có đăng ký kinh doanh, được thành lập và hoạt động theo quy định của pháp luật, gồm<a href="http://www.luatcongminh.com/">:</a><br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Doanh nghiệp thuộc mọi thành phần kinh tế được thành lập và hoạt động theo quy định của pháp luật;<br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hợp tác xã được thành lập và hoạt động theo Luật Hợp tác xã;<br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hộ kinh doanh, cá nhân có đăng ký kinh doanh theo quy định của pháp luật;<br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Các tổ chức khác được thành lập theo quy định của pháp luật.<br  /><strong>2. Thẩm quyền:</strong> Sở công nghiệp- Nay là Sở công thương.<br  /><strong>3. Thời hạn:</strong> 15 ngày làm việc kể từ ngày nộp đầy đủ hồ sơ hợp lệ<a href="http://www.luatcongminh.com/">.</a><br  /><strong>4. Hồ sơ bao gồm:</strong><br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Đơn xin cấp giấy phép sản xuất thuốc lá (Theo mẫu).<br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Biên bản kiểm tra kho hàng đáp ứng điều kiện phòng cháy chữa cháy.<br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Đề án sản xuất – kinh doanh:<br  />o&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Mô tã kho hàng.<br  />o&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Nguồn nguyên liệu.<br  />o&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Danh sách đơn vị cung cấp nguyên liệu.<br  />o&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Danh sách nhân lực lao động tại công ty.<br  />o&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Các điều kiện về kho bãi.<br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Sơ đồ thiết bị phòng cháy chữa cháy.<br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Sơ đồ kho bãi, khu nghỉ ngơi.<br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Bản sao danh sách các đơn vị cung cấp nguyên liệu.<br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hợp đồng nguyên tắc cung cấp nguyên liệu với đại diện vùng nguyên liệu.<br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Bản sao chứng chỉ của các chức danh quản lý<a href="http://www.luatcongminh.com/">.</a><br  /><strong>5. Số lượng:</strong> 02 bộ', '', 1, 0, 1, 1, 1),
(27, '<strong>1. Tư vấn các quy định của pháp luật có liên quan đến việc xin giấy phép</strong><strong>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong><strong>Tư vấn Điều kiện về tư cách pháp lý của tổ chức xin cấp phép;</strong><br  /><strong>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong><strong>Tư vấn Điều kiện về năng lực thực hiện và nhân sự thực hiện;</strong><br  /><strong>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong><strong>Tư vấn Điều kiện về khả năng tài chính;</strong><br  /><strong>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong><strong>Tư vấn quy trình thực hiện xin giấy phép;</strong><br  /><strong>·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong><strong>Tư vấn Các điều kiện khác có liên quan.</strong><br  /><strong>2. Hoàn thiện hồ sơ xin giấy phép:</strong><br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Văn bản đề nghị cấp, sửa đổi, bổ sung giấy phép hoạt động điện lực (theo mẫu).<br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hồ sơ năng lực, hồ sơ pháp lý, sơ đồ bộ máy tổ chức quản lý điều hành, các đơn vị trực thuộc<a href="http://www.luatcongminh.com/">.</a><br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Danh sách các cán bộ quản lý, chuyên gia tư vấn chủ trì các lĩnh vực tư vấn chính.<br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Danh sách các dự án tương tự mà tổ chức tư vấn đã thực hiện hoặc các chuyên gia chính của tổ chức tư vấn đã chủ trì, tham gia thực hiện.<br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Danh mục trang thiết bị, phương tiện, phần mềm ứng dụng phục vụ công tác tư vấn do tổ chức đề nghị cấp phép<a href="http://www.luatcongminh.com/">.</a><br  /><strong>3. Đại diện thực hiện các thủ tục:</strong><br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Tiến hành nộp hồ sơ xin giấy phép tại cơ quan nhà nước có thẩm quyền;<br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Theo dõi tiến trình xử lý và thông báo kết qủa hồ sơ đã nộp<a href="http://www.luatcongminh.com/">;</a><br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Tiến hành thủ tục thanh toán chi phí cấp giấy phép;<br  />·&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Nhận giấy phép tại cơ quan cấp giấy phép;<br  />&nbsp;', '', 1, 0, 1, 1, 1),
(28, 'Phí bán đấu giá cổ phần quy định tại Thông tư này áp dụng đối với việc bán đấu giá cổ phần tại Sở giao dịch Chứng khoán, Trung tâm giao dịch Chứng khoán và&nbsp; các tổ chức được phép tổ chức bán đấu giá cổ phần theo quy định của pháp luật. &nbsp;<br  />Thông tư này quy định mức thu phí bán đấu giá cổ phần áp dụng tại Sở Giao dịch chứng khoán, Trung tâm giao dịch chứng khoán là 0,3% trên tổng giá trị cổ phần thực tế bán được và tối đa không vượt quá 300 triệu đồng/1 cuộc bán đấu giá cổ phần.&nbsp; Mức thu phí bán đấu giá cổ phần áp dụng tại các tổ chức được phép tổ chức bán đấu giá cổ phần theo quy định của pháp luật do các bên tự thỏa thuận nhưng mức thu không vượt quá 0,3% trên tổng giá trị cổ phần thực tế bán được.<br  />&nbsp;<br  />Phí từ hoạt động bán đấu giá cổ phần được thu bằng Việt Nam đồng. Các công ty đăng ký bán đấu giá cổ phần có trách nhiệm nộp toàn bộ phí bán đấu giá theo quy định cho Sở Giao dịch chứng khoán, Trung tâm giao dịch chứng khoán và các tổ chức được phép tổ chức bán đấu giá cổ phần sau khi hoàn tất đợt bán đấu giá.&nbsp;&nbsp;<br  />&nbsp;<br  />Phí bán đấu giá cổ phần thu được là khoản thu không thuộc Ngân sách nhà nước. Đơn vị thu phí có nghĩa vụ nộp thuế theo quy định của pháp luật đối với số phí thu được và có quyền quản lý, sử dụng số tiền thu phí sau khi đã nộp thuế theo quy định của pháp luật.<br  />&nbsp;<br  />Thông tư này có hiệu lực thi hành sau 45 ngày, kể từ ngày ký.<br  />&nbsp;<br  />(&nbsp;Theo mof.gov.vn)<br  />&nbsp;', '', 1, 0, 1, 1, 1),
(29, 'Theo đó, người tham gia bảo hiểm y tế bị tai nạn giao thông, trong khi chưa có đủ căn cứ để xác định nguyên nhân xảy ra tai nạn giao thông là do hành vi vi phạm pháp luật về giao thông của người đó gây ra, khi đi khám bệnh, chữa bệnh được hưởng chế độ bảo hiểm y tế theo quy định. Khi có đủ căn cứ xác định nguyên nhân xảy ra tai nạn giao thông là do hành vi vi phạm pháp luật về giao thông của người bị tai nạn gây ra hoặc trường hợp bị tai nạn giao thông nhưng không thuộc phạm vi thanh toán của quỹ bảo hiểm y tế, người bị tai nạn không được hưởng chế độ bảo hiểm y tế và có trách nhiệm hoàn trả đầy đủ các khoản chi phí khám bệnh, chữa bệnh cho quỹ bảo hiểm y tế.<br  />Đối với người cao tuổi từ 80 tuổi trở lên và trẻ em dưới 14 tuổi thì vẫn được được hưởng chế độ khám bệnh, chữa bệnh bảo hiểm y tế theo quy định mà không phải thực hiện việc xác định hành vi vi phạm pháp luật về giao thông theo quy định.<br  />Cũng theo Thông tư, khi có đủ căn cứ xác định nguyên nhân xảy ra tai nạn giao thông là do hành vi vi phạm pháp luật về giao thông của người bị tai nạn gây ra, cơ quan Bảo hiểm xã hội thực hiện thanh toán như sau: Trường hợp người bị tai nạn còn đang điều trị tại cơ sở khám bệnh, chữa bệnh, cơ quan Bảo hiểm xã hội thông báo trực tiếp cho cho người bị tai nạn hoặc thân nhân của người bị tai nạn (cha, mẹ đẻ; vợ hoặc chồng; con đẻ từ 18 tuổi trở lên) biết về việc người bị tai nạn đã vi phạm pháp luật về giao thông và không được quỹ Bảo hiểm y tế thanh toán chi phí khám bệnh, chữa bệnh; Trường hợp người bị tai nạn đã ra viện, cơ quan Bảo hiểm xã hội thực hiện thu hồi chi phí khám bệnh, chữa bệnh mà quỹ Bảo hiểm y tế đã thanh toán theo quy định; Trường hợp người bị tai nạn tử vong, cơ quan Bảo hiểm xã hội thực hiện thanh quyết toán các khoản chi phí khám bệnh, chữa bệnh với cơ sở khám bệnh, chữa bệnh theo chế độ bảo hiểm y tế (không thu hồi chi phí khám bệnh, chữa bệnh đã thanh toán đối với trường hợp này).<br  />Ngoài ra, Thông tư cũng quy định về việc thu hồi chi phí khám bệnh, chữa bệnh do quỹ bảo hiểm y tế đã thanh toán: Cơ quan Bảo hiểm xã hội có trách nhiệm thông báo cho người bị tai nạn hoặc thân nhân người bị tai nạn biết kết quả xác định vi phạm pháp luật về giao thông của cơ quan công an và yêu cầu người bị tai nạn hoặc thân nhân người bị tai nạn có trách nhiệm hoàn trả cho quỹ bảo hiểm y tế các khoản chi phí khám bệnh, chữa bệnh mà cơ quan Bảo hiểm xã hội đã thanh toán; Sau 30 ngày, kể từ ngày gửi văn bản yêu cầu hoàn trả lần thứ nhất, nếu người bị tai nạn hoặc thân nhân người bị tai nạn không hoàn trả chi phí thì cơ quan Bảo hiểm xã hội tiếp tục có văn bản đôn đốc thực hiện; Trường hợp sau 03 tháng kể từ ngày gửi thông báo và đôn đốc theo quy định nhưng người bị tai nạn hoặc thân nhân người bị tai nạn vẫn không hoàn trả, cơ quan Bảo hiểm xã hội cấp dưới báo cáo Bảo hiểm xã hội cấp trên để tổng hợp báo cáo Bảo hiểm xã hội Việt Nam; Kết thúc năm tài chính, Bảo hiểm xã hội Việt Nam tổng hợp các khoản chi phí khám bệnh, chữa bệnh cho người tham gia bảo hiểm y tế bị tai nạn giao thông nhưng không thu hồi được báo cáo Bộ Y tế để chủ trì, phối hợp với Bộ Tài chính trình Thủ tướng Chính phủ cho phép quyết toán vào quỹ bảo hiểm y tế đối với các khoản không thu được này.<br  /><br  />Thông tư có hiệu lực thi hành kể từ ngày 26/12/2011./.<br  />&nbsp;<br  /><em>&nbsp;(Trích nguồn: www.mof.gov.vn)</em>', '', 1, 0, 1, 1, 1),
(30, 'Theo đó,&nbsp;kể từ ngày 15/4/2012, hồ sơ đề nghị cấp Giấy miễn thị thực phải được lập thành một bộ (trước đây chưa có quy định).&nbsp;Cơ quan có thẩm quyền cấp Giấy miễn thị thực trong thời hạn 5 ngày làm việc từ ngày nhận đủ hồ sơ hợp lệ.<br  />Quy định sửa đổi, bổ sung cũng quy định, người nhập cảnh Việt Nam bằng Giấy miễn thị thực, được tạm trú tại Việt Nam không quá 90 ngày cho mỗi lần nhập cảnh. Nếu có nhu cầu ở lại quá 90 ngày, được cơ quan, tổ chức, cá nhân tại Việt Nam bảo lãnh và có lý do chính đáng thì được xem xét, giải quyết gia hạn tạm trú, mỗi lần không quá 90 ngày.<br  />Người có nhu cầu gia hạn tạm trú phải làm thủ tục trước khi hết hạn 5 ngày.<br  />Trong đó, hồ sơ đề nghị gia hạn tạm trú gồm: Hộ chiếu của người xin gia hạn tạm trú và Tờ khai đề nghị cấp, bổ sung, sửa đổi thị thực, gia hạn tạm trú (mẫu N5), có xác nhận của Công an xã, phường nơi tạm trú; và yêu cầu nộp tại Cục Quản lý xuất nhập cảnh hoặc Phòng Quản lý xuất nhập cảnh công an tỉnh, thành phố nơi tạm trú...<br  /><br  /><br  />Mọi thông tin&nbsp;thắc mắc cần trao&nbsp;đổi liên quan&nbsp;đến các vấn&nbsp;đề&nbsp;trên, xin Quý khách hàng vui lòng liên lạc với <a href="http://brandco.vn/service-view-3323/service-view-3307/service-view-1394/service-view-872/service-view-871/service-view-858/">Tư vấn Luật Brandco</a>&nbsp;để&nbsp;được hướng dẫn chi tiết.&nbsp;<br  /><br  />', '', 1, 0, 1, 1, 1),
(31, 'Theo đó, các tổ chức, cá nhân trả thu nhập phải khấu trừ thuế không phân biệt có phát sinh khấu trừ hay không khấu trừ thuế; Các cá nhân cư trú có thu nhập từ tiền lương, tiền công, thu nhập từ kinh doanh phải quyết toán thuế thu nhập cá nhân: Có số thuế phải nộp lớn hơn số thuế đã khấu trừ hoặc tạm nộp; Có yêu cầu hoàn số thuế nộp thừa hoặc bù trừ vào kỳ sau; Các cá nhân cư trú có thu nhập từ chuyển nhượng chứng khoán đã đăng ký nộp thuế Thu nhập cá nhân theo thuế suất 20% tính trên thu nhập tính thuế với cơ quan thuế phải quyết toán thuế trong các trường hợp: Số thuế phải nộp tính theo thuế suất 20% lớn hơn tổng số thuế đã tạm khấu trừ theo thuế suất 0,1% trong 7 tháng đầu năm và 0,05% trong 5 tháng cuối năm 2011; Có yêu cầu hoàn thuế nộp thừa;&nbsp; Các cá nhân cư trú là người nước ngoài khi kết thúc hợp đồng làm việc tại Việt Nam trước khi xuất cảnh phải thực hiện quyết toán thuế.<br  />Theo nội dung công văn, thu nhập chịu thuế từ tiền lương, tiền công được xác định bằng tổng số tiền lương, tiền công, tiền thù lao và các khoản thu nhập khác theo hướng dẫn tại Khoản 2, Mục II, Phần A Thông tư số 84/2008/TT-BTC ngày 30/9/2008; Điều 1 Thông tư số 62/2009/TT-BTC ngày 27/3/2009; Điều 1 Thông tư số 02/2010/TT-BTC ngày 11/01/2010 của Bộ Tài chính mà người nộp thuế nhận được trong năm 2011.<br  />Trường hợp tổ chức, cá nhân trả tiền ăn giữa ca cho từng người lao động thì mức ăn giữa ca không tính vào thu nhập chịu thuế tối đa không vượt mức tiền chi cho ăn giữa ca quy định tại Khoản 3, Điều 5 Thông tư số 12/2011/TT-BLĐTBXH ngày 26/4/2011 của Bộ Lao động, Thương binh và Xã hội về việc hướng dẫn thực hiện mức lương tối thiểu chung đối với công ty trách nhiệm hữu hạn một thành viên do Nhà nước làm chủ sở hữu.<br  />Thời điểm xác định thu nhập chịu thuế là thời điểm tổ chức, cá nhân trả thu nhập từ tiền lương, tiền công cho cá nhân. Trường hợp tiền lương, tiền công tháng 12/2010, tổ chức, cá nhân trả thu nhập cho đối tượng nộp thuế vào tháng 1/2011 thì tính vào thu nhập chịu thuế của năm 2011 để quyết toán thuế trong năm 2011.<br  />Đối với thu nhập chuyển nhượng chứng khoán, thu nhập chịu thuế từ chuyển nhượng chứng khoán được xác định bằng giá bán chứng khoán trừ giá mua và các chi phí liên quan đến chuyển nhượng.<br  />Về đối tượng giảm trừ gia cảnh và các khoản được giảm trừ để xác định thu nhập tính thuế được hướng dẫn tại Mục I, Phần B Thông tư số 84/2008/TT-BTC ngày 30/9/2009; Điều 2, Điều 3 Thông tư số 62/2009/TT-BTC ngày 27/3/2009.<br  />Cá nhân được giảm trừ cho người phụ thuộc từ tháng có nghĩa vụ nuôi dưỡng. Đối với người nước ngoài cư trú tại Việt Nam được tính giảm trừ gia cảnh cho bản thân từ tháng đến Việt Nam đến tháng rời khỏi Việt Nam.<br  />Đối với cá nhân cư trú có thu nhập từ tiền lương, tiền công, thu nhập từ kinh doanh:<br  /><table align="center" border="0" cellpadding="0" cellspacing="0" style="width:570px;" width="570"> <tbody> <tr> <td style="width:126px;"> Số thuế phải nộp</td> <td style="width:25px;"> =</td> <td style="width:133px;"> Thu nhập tính thuế bình quân tháng</td> <td style="width:26px;"> x</td> <td style="width:150px;"> Thuế suất theo biểu thuế luỹ tiến từng phần tháng</td> <td style="width:30px;"> x</td> <td style="width:80px;"> 12 tháng</td> </tr> </tbody></table><div style="clear:both;"> &nbsp;</div>Đối với cá nhân có thu nhập tính thuế từ tiền lương, tiền công, thu nhập từ kinh doanh đến mức phải chịu thuế Thu nhập cá nhân ở bậc 1 của Biểu thuế luỹ tiến từng phần (nhỏ hơn hoặc bằng 5 triệu đồng/tháng) thì được miễn thuế 5 tháng cuối năm 2011.<br  /><table align="center" border="0" cellpadding="0" cellspacing="0" style="width:436px;" width="436"> <tbody> <tr> <td rowspan="2" style="width:126px;"> Số thuế được miễn</td> <td rowspan="2" style="width:25px;"> =</td> <td style="width:285px;"> Thuế phải nộp năm 2011 x 5 tháng</td> </tr> <tr> <td style="width:285px;"> _______________________<br  /> 12 tháng</td> </tr> </tbody></table><div style="clear:both;"> &nbsp;</div>&nbsp;<br  /><em>&nbsp;(Trích nguồn: www.mof.gov.vn)</em>', '', 1, 0, 1, 1, 1),
(32, 'Theo thông tư số 180/2010/TT-BTC được Bộ Tài chính ban hành ngày 10 tháng 11 năm 2010 về hướng dẫn giao dịch điện tử trong lĩnh vực thuế, Doanh nghiệp và cá nhân sẽ sử dụng chữ ký số công công (CA) của mình khi thực hiện xác thực các giao dịch Kê khai và nộp tờ khai thuế qua mạng và các giao dịch thuế điện tử khác khi giao dịch với cơ quan thuế.<br  />Trong thời gian triển khai áp dụng vừa qua, còn nhiều Doanh nghiệp và các cá nhân vẫn chưa thực sự hiểu rõ và phân biệt chính xác về hai nội dung Đăng ký cấp phát chữ ký số công cộng và Đăng ký thực hiện kê khai thuế qua mạng mà ngành thuế dang triển khai, áp dụng.&nbsp; Còn có một số Doanh nghiệp khi mới chỉ thực hiện Đăng ký cấp phát chữ ký số công cộng và đã nghĩ rằng mình đã thực hiện Đăng ký kê khai thuế qua mạng.&nbsp;<br  />Để có thể giúp doanh nghiệp, cá nhân phân biệt và hiểu rõ hơn về ý nghĩa của các nội dung này, chúng tôi xin đưa ra một số định nghĩa, mô tả ngắn gọn về ý nghĩa, quy trình thực hiện của hai vấn đề này như sau:<br  /><strong><em>1. Chữ ký số và quy trình đăng ký cấp phát chữ ký số công cộng:</em></strong><br  />Chữ ký số là chuỗi thông tin được đính kèm theo dữ liệu (văn bản: word, excel, pdf…; hình ảnh; video...) nhằm mục đích xác định người chủ của dữ liệu đó. Chữ ký số được hiểu và có ý nghĩa như con dấu điện tử của doanh nghiệp hay cá nhân. Vì vậy, chữ ký số không những chỉ dùng trong việc kê khai thuế, mà người sử dụng còn có thể sử dụng chữ ký số trong tất cả các giao dịch điện tử với mọi tổ chức và cá nhân khác nếu các tổ chức này đã chấp nhận các giao dịch điện tử với chữ ký số.<br  />Chữ ký số sẽ do một nhà cung cấp dịch vụ chứng thực chữ ký số công cộng cấp phát và được lưu trữ trong một thiết bị phần cứng chuyên dụng gọi là USB Token hoặc SmartCard.<br  />Hiện tại đã có 06 nhà cung cấp dịch vụ chữ ký số công cộng được phép cấp phát và chứng thực chữ ký số cho Doanh nghiệp và cá nhận là: VDC, Viettel, FPT, Nacencom, BKAV, CK<br  />Khi Doanh nghiệp, cá nhân đã thực hiện đăng ký cấp phát và sử dụng dịch vụ chữ ký số công cộng với các nhà cung cấp dịch vụ chữ ký số nêu trên có nghĩa là Doanh nghiệp, cá nhân vẫn chưa thực hiện thủ tục đăng ký sử dụng dịch vụ Kê khai và nộp tờ khai thuế qua mạng.<br  />Để đăng ký sử dụng hệ thống kê khai và nộp hồ sơ thuế qua mạng của ngành thuế thì Doanh nghiệp, cá nhân phải đăng ký với Cơ quan thuế hoặc đăng ký với các nhà cung cấp dịch vụ thuế điện tử (T-VAN) đã được Tổng cục thuế cấp phép hoạt động<br  /><strong><em>2. Kê khai và nộp tờ khai&nbsp; thuế qua mạng:</em></strong><br  />Từ cuối năm 2009, ngành thuế đã ứng dụng và triển khai hệ thống phần mềm Kê khai và nộp tờ khai thuế qua mạng Internet cho đối tượng sử dụng là các Doanh nghiệp hoạt động tại Việt nam.<br  />Hệ thống này là một ứng dụng phần mềm tin học, cho phép các Doanh nghiệp đăng nhập vào hệ thống phần mềm qua mạng Internet và thực hiện các nghiệp vụ chính như sau<br  />- Kê khai các tờ khai thuế phát sinh của Doanh nghiệp theo nghĩa vụ kê khai thuế<br  />- Sử dụng chữ ký số công cộng đã tổ chức cung cấp chữ ký số công cộng cấp phát để ký xác nhận về nội dung thông tin trên tờ khai thuế đã kê khai<br  />- Gửi tờ khai thuế cho cơ quan thuế qua mạng Internet<br  />- Nhận và tra cứu các thông báo từ cơ quan thuế trả về.<br  />Doanh nghiệp muốn thực hiện Kê khai và nộp tờ khai thuế qua mạng với cơ quan thuế thì Doanh nghiệp phải có chữ ký số công cộng và phải đăng ký kê khai thuế qua mạng với Tổng cục thuế hoặc Đăng ký qua các công ty đã được Tổng cục thuế cấp phép cung cấp dịch vụ thuế điện tử (T-VAN).<br  />Một số nhà cung cấp dịch vụ thuế điện tử (T-VAN) hiện nay cũng đã phối hợp chặt chẽ với các nhà cung cấp dịch vụ chữ ký số công cộng để cung cấp dịch vụ trọn gói và làm toàn bộ các thủ tục đăng ký, cấp phát... cho Doanh nghiệp, cá nhân, tạo thuận tiện tối đa cho các Doanh nghiệp khai thuế qua mạng.&nbsp;<br  />Hiện nay tại Việt Nam đã có 06 nhà cung cấp được phép cung cấp dịch vụ thuế điện tử (T-VAN) là các tổ chức:<br  />- Công ty Seatech<br  />- Công ty Viettel<br  />- Công ty Thái Sơn<br  />- Công ty BKAV<br  />- Công ty FPT<br  />- Công ty TS24,<br  />Với các định nghĩa và nội dung mô tả như trên sẽ giúp Doanh nghiệp, cá nhân có thể phân biệt rõ về các nội dung dịch vụ cụ thể và hiểu rõ các quy trình đăng ký, cấp phát... khi làm việc với nhà cung cấp dịch vụ chữ ký số công cộng và nhà cung cấp dịch vụ kê khai thuế qua mạng.<br  />Mọi thông tin&nbsp;thắc mắc cần trao&nbsp;đổi liên quan&nbsp;đến các vấn&nbsp;đề&nbsp;trên, xin Quý khách hàng vui lòng liên lạc với <a href="http://brandco.vn/service-view-1394/service-view-872/service-view-871/service-view-858/">Tư vấn Luật Brandco</a>&nbsp;để&nbsp;được hướng dẫn chi tiết.&nbsp;<br  />-', '', 1, 0, 1, 1, 1),
(33, '<strong>Trong thời gian qua Bộ Tài chính đã nhận được phản ánh vướng mắc của một số Cục Thuế, doanh nghiệp về việc khấu trừ, hoàn thuế GTGT đối với trường hợp một cá nhân vừa làm giám đốc của Công ty cổ phần vừa làm giám đốc của doanh nghiệp (công ty) khác. Trên cơ sở đó, Bộ Tài chính vừa mới ban hành Công văn số 13238/BTC-TCT về việc khấu trừ, hoàn thuế GTGT đối với trường hợp Giám đốc hoặc Tổng giám đốc của Công ty không được đồng thời làm Giám đốc hoặc Tổng giám đốc của doanh nghiệp khác.</strong><br  />Căn cứ Khoản 2 Điều 116 Chương IV (Công ty cổ phần) Luật Doanh nghiệp số 60/2005/QH11 ngày 29 tháng 11 năm 2005, quy định: “2. Giám đốc hoặc Tổng giám đốc của Công ty không được đồng thời làm Giám đốc hoặc Tổng giám đốc của doanh nghiệp khác”;<br  />Căn cứ Khoản 4 Điều 15 (hướng dẫn bổ sung về giám đốc (Tổng giám đốc) và Thành viên Hội đồng quản trị) Nghị định số 102/2010/NĐ-CP ngày 01/10/2010 của Chính phủ hướng dẫn chi tiết thi hành một số điều Luật Doanh nghiệp: “4. Nếu Điều lệ công ty không quy định khác thì Chủ tịch Hội đồng thành viên, Chủ tịch công ty, Chủ tịch Hội đồng quản trị và Giám đốc (Tổng giám đốc) của một công ty có thể kiêm Chủ tịch Hội đồng thành viên, Chủ tịch công ty, Chủ tịch Hội đồng quản trị hoặc Giám đốc (Tổng giám đốc) của công ty khác, trừ trường hợp Giám đốc (Tổng giám đốc) công ty cổ phần không được đồng thời làm Giám đốc (Tổng giám đốc) công ty khác theo Khoản 2 Điều 116 của Luật Doanh nghiệp”;<br  />Căn cứ Điểm 1.2 (c9) Mục III Phần B; Điểm 8 Phần C Thông tư số 129/2008/TT-BTC ngày 26/12/2008 của Bộ Tài chính hướng dẫn thi hành một số điều của Luật Thuế giá trị gia tăng và hướng dẫn thi hành Nghị định số 123/2008/NĐ-CP ngày 08 tháng 12 năm 2008 của Chính phủ quy định chi tiết và hướng dẫn thi hành một số điều của Luật Thuế giá trị gia tăng­­­­;<br  />Căn cứ Điểm 2 Mục IV Phần C Thông tư số 130/2008/TT-BTC ngày 26/12/2008 của Bộ Tài chính hướng dẫn thi hành một số điều của Luật Thuế thu nhập doanh nghiệp số 14/2008/QH12 và hướng dẫn thi hành Nghị định số 124/2008/NĐ-CP ngày 11 tháng 12 năm 2008 của Chính phủ quy định chi tiết thi hành một số điều của Luật Thuế thu nhập doanh nghiệp;<br  />Căn cứ công văn số 6347/BKHĐT-TCTT ngày 21/9/2011 của Bộ Kế hoạch và Đầu tư về việc khấu trừ, hoàn thuế GTGT đối với trường hợp vi phạm Luật Doanh nghiệp;<br  />Trường hợp trong cùng một thời gian mà một cá nhân vừa làm giám đốc (hoặc Tổng giám đốc) của Công ty cổ phần, vừa làm giám đốc (hoặc Tổng giám đốc) của doanh nghiệp (công ty) khác là vi phạm qui định của Khoản 2 Điều 116 của Luật doanh nghiệp và Khoản 4 Điều 15 Nghị định số 102/2010/NĐ-CP ngày 01/10/2010 của Chính phủ hướng dẫn thi hành một số điều Luật Doanh nghiệp và bị xử phạt hành chính theo Luật Doanh nghiệp.<br  />Trong trường hợp này, theo quyết định của Cơ quan đăng ký kinh doanh, sau khi khắc phục lỗi vi phạm doanh nghiệp vẫn được tiếp tục hoạt động mà chưa đến mức bị thu hồi Giấy chứng nhận đăng ký kinh doanh và làm thủ tục giải thể doanh nghiệp, nếu các tài liệu trong hồ sơ đề nghị hoàn thuế của công ty cổ phần vẫn đáp ứng đủ các điều kiện về kê khai khấu trừ, hoàn thuế GTGT theo quy định thì công ty cổ phần vẫn được kê khai khấu trừ, hoàn thuế đầu vào tương ứng.<br  />Trường hợp vi phạm qui định của Khoản 2 Điều 116 của Luật doanh nghiệp, Khoản 4 Điều 15 Nghị định số 102/2010/NĐ-CP ngày 01/10/2010 của Chính phủ nêu trên, bị thu hồi Giấy chứng nhận đăng ký kinh doanh và làm thủ tục giải thể doanh nghiệp thì các tài liệu trong hồ sơ đề nghị hoàn thuế của Công ty cổ phần không đảm bảo tính hợp pháp để kê khai khấu trừ, hoàn thuế GTGT.<br  />Mọi thông tin&nbsp;thắc mắc cần trao&nbsp;đổi liên quan&nbsp;đến các vấn&nbsp;đề&nbsp;trên, xin Quý khách hàng vui lòng liên lạc với <a href="http://brandco.vn/service-view-1394/service-view-872/service-view-871/service-view-858/">Tư vấn Luật Brandco</a>&nbsp;để&nbsp;được hướng dẫn chi tiết.<br  />', '', 1, 0, 1, 1, 1),
(34, 'Tổng cục Thuế cho biết, triển khai Nghị định số 51/2010/NĐ-CP về hoá đơn (có hiệu lực thi hành từ 1/1/2011), tính đến hết ngày 30/4/2011, trên địa bàn cả nước đã có 145.693 doanh nghiệp đã tự in, đặt in hoá đơn. Tuy nhiên vẫn còn 188.421 doanh nghiệp siêu nhỏ, doanh nghiệp ở địa bàn kinh tế xã hội khó khăn và đặc biệt khó khăn đang thực hiện mua hóa đơn của cơ quan thuế.<br  />Do vậy, từ nay đến cuối năm 2011, một trong những nhiệm vụ trong tâm của ngành Thuế là triển khai các giải pháp thực hiện đồng bộ và thống nhất thúc đẩy các doanh nghiệp nêu trên đặt in hoặc tự in hóa đơn để có hóa đơn sử dụng từ ngày 1/1/2012. &nbsp;<br  />Việc chuyển hết các doanh nghiệp siêu nhỏ, doanh nghiệp ở tại địa bàn kinh tế xã hội khó khăn và đặc biệt khó khăn từ cơ chế mua hóa đơn của cơ quan thuế sang cơ chế tự chủ đặt in, tự in hóa đơn có ý nghĩa quan trọng trong việc nâng cao tính tự chủ của các doanh nghiệp trong công tác tự chịu trách nhiệm về&nbsp; quản lý hóa đơn của doanh nghiệp, giảm chi phí quản lý của cơ quan thuế dùng vào việc bán hóa đơn, ấn chỉ cho các doanh nghiệp. &nbsp;<br  />Phấn đấu hết tháng 10/2011, doanh nghiệp siêu nhỏ có phương án sử dụng hóa đơn tự in<br  />Tổng cục Thuế đề nghị cơ quan Thuế các cấp cần tập trung các giải pháp phấn đấu hết tháng 10/2011, về cơ bản tất cả các doanh nghiệp trên địa bàn ký được hợp đồng đặt in hoá đơn hoặc đã có phương án sử dụng hoá đơn tự in.<br  />Đồng thời, cũng để tránh hiện tượng các doanh nghiệp đặt in hoá đơn dồn vào thời điểm cuối năm, Tổng cục Thuế giao chỉ tiêu cho các Cục thuế thực hiện đảm bảo đến hết ngày 31/10/2011, 100% số lượng doanh nghiệp siêu nhỏ, doanh nghiệp ở địa bàn khó khăn và đặc biệt khó khăn có hoá đơn đặt in hoặc ký được hợp đồng đặt in hoá đơn hoặc có phương án sử dụng hoá đơn tự in.<br  />Trường hợp doanh nghiệp gặp vướng mắc trong việc đặt in, tự in hóa đơn, Tổng cục Thuế đề nghị Cục thuế liên hệ trực tiếp, phối hợp với các nhà in, doanh nghiệp cung cấp phần mềm in hoá đơn để hỗ trợ giải quyết vướng mắc cho doanh nghiệp.<br  /><strong>Cơ quan thuế chỉ bán số lượng hóa đơn đủ dùng đến hết 31/12/2011</strong><br  />Bên cạnh đó, Tổng cục Thuế yêu cầu cần tiếp tục thực hiện công tác tuyên truyền để phổ biến và quán triệt sâu sắc đến từng doanh nghiệp hiện đang mua hóa đơn của cơ quan thuế để doanh nghiệp biết nội dung: Từ ngày 1/1/2012 cơ quan Thuế không bán hóa đơn cho doanh nghiệp. Tuỳ vào đặc điểm của từng địa phương, Cục thuế chủ động sử dụng các hình thức tuyên truyền khác nhau đảm bảo hiệu quả.<br  />Căn cứ số lượng hoá đơn còn tồn kỳ trước, trong quý IV/2011 cơ quan Thuế các cấp giảm dần số lượng hoá đơn bán cho các doanh nghiệp, chỉ bán với số lượng đủ dùng đến hết 31/12/2011. Cục Thuế thông báo đến từng doanh nghiệp về việc hoá đơn do Cục thuế đặt in bán cho doanh nghiệp đến ngày 31/12/2011 doanh nghiệp còn tồn sẽ hết giá trị sử dụng, doanh nghiệp phải nộp lại số còn tồn cho cơ quan Thuế để cơ quan Thuế huỷ theo quy định. &nbsp;<br  />Đồng thời với việc bán hoá đơn với số lượng đủ dùng này, cơ quan Thuế yêu cầu từng doanh nghiệp siêu nhỏ, doanh nghiệp ở tại địa bàn kinh tế xã hội khó khăn và đặc biệt khó khăn hiện đang mua hoá đơn cam kết với cơ quan Thuế về việc doanh nghiệp đã được cơ quan Thuế triển khai các quy định về hoá đơn và chịu trách nhiệm đảm bảo có hoá đơn để sử dụng từ 1/1/2012 theo quy định.<br  />Mọi thông tin&nbsp;thắc mắc cần trao&nbsp;đổi liên quan&nbsp;đến các vấn&nbsp;đề&nbsp;trên, xin Quý khách hàng vui lòng liên lạc với <a href="http://brandco.vn/service-view-1394/service-view-872/service-view-871/service-view-858/">Tư vấn Luật Brandco</a>&nbsp;để&nbsp;được hướng dẫn chi tiết.', '', 1, 0, 1, 1, 1);
INSERT INTO `nv3_vi_news_bodyhtml_1` (`id`, `bodyhtml`, `sourcetext`, `imgposition`, `copyright`, `allowed_send`, `allowed_print`, `allowed_save`) VALUES
(35, 'Trong dự thảo Nghị định về lương tối thiểu vùng công bố chiều 16/8, Bộ Lao động Thương binh và Xã hội đề xuất 2 phương án điều chỉnh. Với phương án thứ nhất, mức tối thiểu quy định cho các doanh nghiệp hoạt động trên địa bàn thuộc vùng I là 2,7 triệu đồng, tăng 700.000 đồng so với hiện hành. Các doanh nghiệp hoạt động ở vùng II, III và IV lần lượt áp dụng mức 2,4 - 2,13 - 1,93 triệu đồng một tháng.<br  />Ở phương án thứ hai, Bộ đề xuất mức cao nhất cho vùng một là 2,5 triệu đồng và thấp nhất là 1,8 triệu đồng cho vùng IV.<br  /><table align="center" border="1" cellpadding="0" cellspacing="1" id="table2" style="width:434px;" width="434"> <tbody> <tr> <td style="width:10%;"> <strong>Vùng </strong></td> <td style="width:30%;"> <strong>Hiện hành</strong><br  /> <em>(Đến hết 31/12/2012)</em></td> <td style="width:30%;"> <strong>Phương án 1</strong><br  /> <em>(Từ 1/1/2013)</em></td> <td style="width:30%;"> <strong>Phương án 2</strong><br  /> <em>(Từ 1/1/2013)</em></td> </tr> <tr> <td style="width:10%;"> I</td> <td style="width:30%;"> 2.000.000</td> <td style="width:30%;"> 2.700.000</td> <td style="width:30%;"> 2.500.000</td> </tr> <tr> <td style="width:10%;"> II</td> <td style="width:30%;"> 1.780.000</td> <td style="width:30%;"> 2.400.000</td> <td style="width:30%;"> 2.250.000</td> </tr> <tr> <td style="width:10%;"> III</td> <td style="width:30%;"> 1.550.000</td> <td style="width:30%;"> 2.130.000</td> <td style="width:30%;"> 1.950.000</td> </tr> <tr> <td style="width:10%;height:25px;"> IV</td> <td style="width:30%;height:25px;"> 1.400.000</td> <td style="width:30%;height:25px;"> 1.930.000</td> <td style="width:30%;height:25px;"> 1.800.000</td> </tr> </tbody></table><div style="clear:both;"> &nbsp;</div>(<em>Đồng/tháng</em>)<br  />Nghị định này nếu được thông qua sẽ áp dụng từ 1/1/2013, cho các công ty, doanh nghiệp, hợp tác xã, trang trại, hộ gia đình, cá nhân và cơ quan, tổ chức có thuê mướn lao động.<br  />Lương tối thiểu vùng là mức sàn cho doanh nghiệp và người lao động căn cứ để thỏa thuận tiền lương. Dự thảo khuyến khích các doanh nghiệp trả lương cho người lao động cao hơn quy định. Đồng thời, dự thảo quy định tiền lương thấp nhất trả cho người lao động đã qua học nghề, kể cả lao động do doanh nghiệp tự dạy nghề, phải cao hơn ít nhất 7% so với mức lương tối thiểu vùng theo quy định.<br  />Trên thực tế, lương tối thiểu vùng chỉ mang tính chất tham chiếu để các doanh nghiệp xây dựng bảng lương và làm căn cứ tính bảo hiểm cho người lao động. Và thu nhập thực lĩnh của lao động tại nhiều doanh nghiệp đều cao hơn so với mức tối thiểu này.<br  />Bản thân mức lương tối thiểu cũng được cho là lạc hậu so với đời sống thực tế. Khảo sát năm 2011 của Tổng liên đoàn Lao động Việt Nam cho thấy, mức sống tối thiểu của người lao động từ vùng IV đến vùng I lần lượt là 2,47 - 2,66 - 2,86 và 3,04 triệu đồng mỗi tháng. Trong khi mức cao nhất áp dụng trước 1/10/2011 là 1,55 triệu đồng và sau mốc này cũng chỉ là 2 triệu đồng một tháng.<br  />Trong một hội thảo tổ chức tháng 5, ông Đặng Quang Điều, Viện trưởng Viện Nghiên cứu công nhân công đoàn (Tổng liên đoàn Lao động Việt Nam) phải thốt lên 20 năm qua lương tối thiểu chưa bao giờ đạt đến mức sống tối thiểu.<br  /><h1> Danh mục địa bàn áp dụng mức lương tối thiểu vùng</h1><h3> 1. Vùng I, gồm các địa bàn:</h3>- Các quận và các huyện Gia Lâm, Đông Anh, Sóc Sơn, Thanh Trì, Từ Liêm, Thường Tín, Hoài Đức, Thạch Thất, Quốc Oai, Thanh Oai, Mê Linh, Chương Mỹ và thị xã Sơn Tây thuộc thành phố Hà Nội;<br  />- Các quận và các huyện Thủy Nguyên, An Dương, An Lão, Vĩnh Bảo thuộc thành phố Hải Phòng;<br  />- Các quận và các huyện Củ Chi, Hóc Môn, Bình Chánh, Nhà Bè thuộc thành phố Hồ Chí Minh;<br  />- Thành phố Biên Hòa và các huyện Nhơn Trạch, Long Thành, Vĩnh Cửu, Trảng Bom thuộc tỉnh Đồng Nai;<br  />- Thị xã Thủ Dầu Một và các huyện Thuận An, Dĩ An, Bến Cát, Tân Uyên thuộc tỉnh Bình Dương;<br  />- Thành phố Vũng Tàu thuộc tỉnh Bà Rịa - Vũng Tàu.<br  /><h3> 2. Vùng II, gồm các địa bàn:</h3>- Các huyện còn lại thuộc thành phố Hà Nội;<br  />- Các huyện còn lại thuộc thành phố Hải Phòng;<br  />- Thành phố Hải Dương thuộc tỉnh Hải Dương;<br  />- Thành phố Hưng Yên và các huyện Mỹ Hào, Văn Lâm, Văn Giang, Yên Mỹ thuộc tỉnh Hưng Yên;<br  />- Thành phố Vĩnh Yên, thị xã Phúc Yên và các huyện Bình Xuyên, Yên Lạc, thuộc tỉnh Vĩnh Phúc;<br  />- Thành phố Bắc Ninh, thị xã Từ Sơn và các huyện Quế Võ, Tiên Du, Yên Phong, Thuận Thành thuộc tỉnh Bắc Ninh;<br  />- Các thành phố Hạ Long, Móng Cái thuộc tỉnh Quảng Ninh;<br  />- Thành phố Thái Nguyên thuộc tỉnh Thái Nguyên;<br  />- Thành phố Việt Trì thuộc tỉnh Phú Thọ;<br  />- Thành phố Lào Cai thuộc tỉnh Lào Cai;<br  />- Thành phố Ninh Bình thuộc tỉnh Ninh Bình;<br  />- Thành phố Huế thuộc tỉnh Thửa Thiên Huế;<br  />- Các quận, huyện thuộc thành phố Đà Nẵng;<br  />- Thành phố Nha Trang và thị xã Cam Ranh thuộc tỉnh Khánh Hòa;<br  />- Các thành phố Đà Lạt, Bảo Lộc thuộc tỉnh Lâm Đồng;<br  />- Thành phố Phan Thiết thuộc tỉnh Bình Thuận;<br  />- Các huyện còn lại thuộc thành phố Hồ Chí Minh;<br  />- Thị xã Long Khánh và các huyện Định Quán, Xuân Lộc thuộc tỉnh Đồng Nai;<br  />- Các huyện Phú Giáo, Dầu Tiếng thuộc tỉnh Bình Dương;<br  />- Huyện Chơn Thành thuộc tỉnh Bình Phước;<br  />- Thị xã Bà Rịa và huyện Tân Thành thuộc tỉnh Bà Rịa - Vũng Tàu;<br  />- Thành phố Tân An và các huyện Đức Hòa, Bến Lực, Cần Đước, Cần Giuộc thuộc tỉnh Long An;<br  />- Thành phố Mỹ Tho thuộc tỉnh Tiền Giang;<br  />- Các quận thuộc thành phố Cần Thơ;<br  />- Thành phố Rạch Giá thuộc tỉnh Kiên Giang;<br  />- Thành phố Long Xuyên thuộc tỉnh An Giang;<br  />- Thành phố Cà Mau thuộc tỉnh Cà Mau.<br  /><h3> 3. Vùng III, gồm các địa bàn:</h3>- Các thành phố trực thuộc tỉnh còn lại (trừ các thành phố trực thuộc tỉnh nêu tại vùng II);<br  />- Thị xã Chí Linh và các huyện Cẩm Giàng, Nam Sách, Kim Thành, Kim Môn, Gia Lộc, Bình Giang, Tứ Kỳ thuộc tỉnh Hải Dương;<br  />- Các huyện Vĩnh Tường, Tam Đảo, Tam Dương, Lập Thạch, Sông Lô thuộc tỉnh Vĩnh Phúc;<br  />- Thị xã Phú Thọ và các huyện Phù Ninh, Lâm Thao, Thanh Ba, Tam Nông thuộc tỉnh Phú Thọ;<br  />- Các huyện Gia Bình, Lương Tài thuộc tỉnh Bắc Ninh;<br  />- Các huyện Việt Yên, Yên Dũng, Hiệp Hòa, Tân Yên, Lạng Giang thuộc tỉnh Bắc Giang;<br  />- Các thị xã Uông Bí, Cẩm Phả và các huyện Hoàng Bồ, Đông Triều thuộc tỉnh Quảng Ninh;<br  />- Các huyện Bảo Thắng, Sa Pa thuộc tỉnh Lào Cai;<br  />- Các huyện còn lại thuộc tỉnh Hưng Yên;<br  />- Các huyện Mỹ Hào, Văn Lâm, Văn Giang, Yên Mỹ thuộc tỉnh Hưng Yên;<br  />- Thị xã Sông Công và các huyện Phổ Yên, Phú Bình, Phú Lương, Đồng Hỷ, Đại Từ thuộc tỉnh Thái Nguyên;<br  />- Huyện Mỹ Lộc thuộc tỉnh Nam Định;<br  />- Các huyện Duy Tiên, Kim Bảng thuộc tỉnh Hà Nam;<br  />- Thị xã Tam Điệp và các huyện Gia Viễn, Yên Khánh, Hoa Lư thuộc tỉnh Ninh Bình;<br  />- Thị xã Bỉm Sơn và huyện Tĩnh Gia thuộc tỉnh Thanh Hóa;<br  />- Huyện Kỳ Anh thuộc tỉnh Hà Tĩnh;<br  />- Thị xã Hương Thủy và các huyện Hương Trà, Phú Lộc, Phong Điền, Quảng Điền, Phú Vang thuộc tỉnh Thừa Thiên-Huế;<br  />- Các huyện Điện Bàn, Đại Lộc, Duy Xuyên, Núi Thành thuộc tỉnh Quảng Nam;<br  />- Các huyện Bình Sơn, Sơn Tịnh thuộc tỉnh Quảng Ngãi;<br  />- Thị xã Sông Cầu thuộc tỉnh Phú Yên;<br  />- Các huyện Cam Lâm, Diên Khánh, Ninh Hòa, Vạn Ninh thuộc tỉnh Khánh Hòa;<br  />- Các huyện Ninh Hải, Thuận Bắc thuộc tỉnh Ninh Thuận;<br  />- Huyện Đăk Hà thuộc tỉnh Kon Tum;<br  />- Các huyện Đức Trọng, Di Linh thuộc tỉnh Lâm Đồng;<br  />- Thị xã La Gi và các huyện Hàm Thuận Bắc, Hàm Thuận Nam thuộc tỉnh Bình Thuận;<br  />- Các huyện Trảng Bàng, Gò Dầu thuộc tỉnh Tây Ninh;<br  />- Các thị xã Đồng Xoài, Phước Long, Bình Long và các huyện Đồng Phú, Hớn Quản thuộc tỉnh Bình Phước;<br  />- Các huyện còn lại thuộc tỉnh Đồng Nai;<br  />- Các huyện còn lại thuộc tỉnh Bình Dương;<br  />- Các huyện Long Điền, Đất Đỏ, Xuyên Mộc, Châu Đức, Côn Đảo thuộc tỉnh Bà Rịa - Vũng Tàu;<br  />- Các huyện Thủ Thừa, Đức Huệ, Châu Thành, Tân Trụ, Thạnh Hóa thuộc tỉnh Long An;<br  />- Thị xã Gò Công và huyện Châu Thành thuộc tỉnh Tiền Giang;<br  />- Huyện Châu Thành thuộc tỉnh Bến Tre;<br  />- Các huyện Bình Minh, Long Hồ thuộc tỉnh Vĩnh Long;<br  />- Các huyện thuộc thành phố Cần Thơ;<br  />- Thị xã Hà Tiên và các huyện Kiên Lương, Phú Quốc, Kiên Hải, Giang Thành, Châu Thành thuộc tỉnh Kiên Giang;<br  />- Các thị xã Châu Đốc, Tân Châu thuộc tỉnh An Giang;<br  />- Thị xã Ngã Bảy và các huyện Châu Thành, Châu Thành A thuộc tỉnh Hậu Giang;<br  />- Các huyện Năm Căn, Cái Nước, U Minh, Trần Văn Thời thuộc tỉnh Cà Mau.<br  /><h3> 4. Vùng IV, gồm các địa bàn còn lại.</h3><em>(Nguồn: Báo điện tử VnExpress) </em>', '', 1, 0, 1, 1, 1),
(36, 'Theo đó,&nbsp; sẽ miễn thuế đối với đất ở trong hạn mức tại địa bàn có điều kiện kinh tế - xã hội đặc biệt khó khăn; Đất của dự án đầu tư thuộc lĩnh vực đặc biệt khuyến khích đầu tư (đặc biệt ưu đãi đầu tư); dự án đầu tư tại địa bàn có điều kiện kinh tế - xã hội đặc biệt khó khăn; dự án đầu tư thuộc lĩnh vực khuyến khích đầu tư (ưu đãi đầu tư) tại địa bàn có điều kiện kinh tế - xã hội khó khăn; đất của doanh nghiệp sử dụng trên 50% số lao động là thương binh, bệnh binh...<br  />Giảm 50% số thuế phải nộp đối với đất ở trong hạn mức tại địa bàn có điều kiện kinh tế - xã hội khó khăn; Đất của dự án đầu tư thuộc lĩnh vực ưu đãi đầu tư; dự án đầu tư tại địa bàn có điều kiện kinh tế - xã hội khó khăn; đất của DN sử dụng từ 20% đến 50% số lao động là thương binh, bệnh binh.<br  />Đất ở trong hạn mức của thương binh hạng 3/4, 4/4; người hưởng chính sách như thương binh hạng 3/4, 4/4; bệnh binh hạng 2/3, 3/3; con của liệt sỹ không được hưởng trợ cấp hàng tháng. Người nộp thuế gặp khó khăn do sự kiện bất khả kháng nếu giá trị thiệt hại về đất và nhà trên đất từ 20% đến 50% giá tính thuế nhưng phải có xác nhận của UBND cấp xã nơi có đất bị thiệt hại..<br  />Do vậy, nếu các xã thuộc danh mục các xã đặc biệt khó khăn quy định tại các Quyết định số&nbsp; 164/2006/QĐ-TTg ngày 11-7-2006, Quyết định số 113/2007/QĐ-TTg ngày 20-7-2007 và Quyết định số 69/2008/QĐ-TTg ngày 19-5-2008 của Thủ tướng Chính phủ nhưng không thuộc danh mục địa bàn có điều kiện kinh tế - xã hội khó khăn, đặc biệt khó khăn theo quy định tại Nghị định số 108/2006/NĐ-CP ngày 22-9-2006 của Chính phủ và các văn bản sửa đổi, bổ sung thì không thuộc diện được xét miễn, giảm thuế sử dụng đất phi nông nghiệp.<br  /><strong>Mai Ka</strong><br  /><em>(Trích nguồn: Báo Hải Quan)</em>', '', 1, 0, 1, 1, 1),
(37, 'Theo TS. Nguyễn Xuân Sơn - Phó Ban Cải cách Tổng cục Thuế, DN thuộc diện chịu thuế thu nhập từ chuyển nhượng bất động sản bao gồm: DN thuộc mọi thành phần kinh tế, mọi ngành nghề có thu nhập từ hoạt động chuyển nhượng bất động sản; DN kinh doanh bất động sản có thu nhập từ hoạt động cho thuê lại đất.<br  />Thu nhập từ hoạt động chuyển nhượng bất động sản bao gồm: thu nhập từ chuyển nhượng quyền sử dụng đất, chuyển nhượng quyền thuê đất (gồm cả chuyển nhượng dự án gắn với chuyển nhượng quyền sử dụng đất, quyền thuê đất theo quy định của pháp luật); Thu nhập từ hoạt động cho thuê lại đất của doanh nghiệp kinh doanh bất động sản theo quy định của pháp luật về đất đai không phân biệt có hay không có kết cấu hạ tầng, công trình kiến trúc gắn liền với đất; Thu nhập từ chuyển nhượng nhà, công trình xây dựng gắn liền với đất, kể cả các tài sản gắn liền với nhà, công trình xây dựng đó nếu không tách riêng giá trị tài sản khi chuyển nhượng không phân biệt có hay không có chuyển nhượng quyền sử dụng đất, chuyển nhượng quyền thuê đất; Thu nhập từ chuyển nhượng các tài sản gắn liền với đất; Thu nhập từ chuyển nhượng quyền sở hữu hoặc quyền sử dụng nhà ở.<br  />Nếu so với các qui định trước đây thì qui định mới của Bộ Tài chính đã bổ sung thêm nhóm: Thu nhập từ chuyển nhượng nhà, công trình xây dựng gắn liền với đất, kể cả các tài sản gắn liền với nhà, công trình xây dựng đó nếu không tách riêng giá trị tài sản khi chuyển nhượng không phân biệt có hay không có chuyển nhượng quyền sử dụng đất, chuyển nhượng quyền thuê đất.<br  />Theo TS. Nguyễn Xuân Sơn, một trong những căn cứ tính thuế là doanh thu từ hoạt động chuyển nhượng bất động sản được xác định theo giá thực tế chuyển nhượng bất động sản theo hợp đồng chuyển nhượng, mua bán bất động sản phù hợp với quy định của pháp luật (bao gồm cả các khoản phụ thu và phí thu thêm nếu có).<br  />Trường hợp giá chuyển quyền sử dụng đất theo hợp đồng chuyển nhượng, mua bán bất động sản thấp hơn giá đất do UBND tỉnh, thành phố trực thuộc Trung ương quy định tại thời điểm ký hợp đồng chuyển nhượng bất động sản thì tính theo giá đất do UBND tỉnh, thành phố trực thuộc Trung ương quy định tại thời điểm ký hợp đồng chuyển nhượng bất động sản.<br  />Đối với, trường hợp DN được Nhà nước giao đất, cho thuê đất để thực hiện dự án đầu tư cơ sở hạ tầng, nhà để chuyển nhượng hoặc cho thuê, có thu tiền ứng trước của khách hàng theo tiến độ dưới mọi hình thức thì thời điểm xác định doanh thu tính thuế thu nhập DN tạm nộp là thời điểm thu tiền của khách hàng, cụ thể: Trường hợp DN có thu tiền của khách hàng mà chưa xác định được chi phí tương ứng với doanh thu thì DN kê khai tạm nộp thuế thu nhập doanh nghiệp theo tỷ lệ 1% trên doanh thu thu được tiền và doanh thu này chưa phải tính vào doanh thu tính thuế thu nhập DN trong năm.<br  />Trường hợp DN có cho thuê lại đất thì doanh thu để tính thu nhập chịu thuế là số tiền bên thuê trả từng kỳ theo hợp đồng thuê. Trường hợp bên thuê trả tiền thuê trước cho nhiều năm thì doanh thu để tính thu nhập chịu thuế được phân bổ cho số năm trả tiền trước hoặc được xác định theo doanh thu trả tiền một lần. Việc chọn hình thức doanh thu trả tiền một lần chỉ được xác định khi DN đã đảm bảo hoàn thành các trách nhiệm tài chính đối với Nhà nước, đảm bảo các nghĩa vụ đối với các bên thuê lại đất cho hết thời hạn cho thuê lại đất.<br  />Trường hợp DN đang trong thời gian hưởng ưu đãi thuế thu nhập DN lựa chọn phương pháp xác định doanh thu để tính thu nhập chịu thuế là toàn bộ số tiền thuê bên thuê trả trước cho nhiều năm thì việc xác định số thuế thu nhập doanh nghiệp từng năm miễn thuế, giảm thuế căn cứ vào tổng số thuế thu nhập DN của số năm trả tiền trước chia&nbsp; số năm bên thuê trả tiền trước.<br  />Trường hợp trước năm 2012, DN có cho thuê lại đất thu tiền trả trước cho nhiều năm và đã xác định doanh thu tính thuế theo hình thức phân bổ cho số năm trả tiền trước, nếu đến năm 2012 DN vẫn còn trong thời hạn cho thuê lại đất thì được lựa chọn xác định doanh thu tính thuế phân bổ hàng năm hoặc theo doanh thu trả tiền một lần cho số năm còn lại của thời hạn cho thuê lại đất.<br  />&nbsp;<br  /><em>(Trích nguồn: Báo Hải Quan)</em>', '', 1, 0, 1, 1, 1),
(38, '<p style="MARGIN: 0cm 0cm 0pt; LINE-HEIGHT: 150%; TEXT-ALIGN: justify"> <font size="3"><font color="rgb(0, 0, 0);"><font face="Times New Roman">Sự trở lại của&nbsp;hợp tác xã&nbsp;thời kỳ mới&nbsp;đã tạo động lực để đổi mới tư duy và đem lại hiệu quả kinh tế cho người nông dân. Cụ thể, trong giai đoạn từ 2002 – 2011 khu vực hợp tác xã đóng góp bình quân 6,38% tổng sản phẩm nội địa, trong khi chỉ chiếm 0,58% vốn đầu tư tài sản cố định và đầu tư tài chính dài hạn; tạo việc làm thường xuyên cho khoảng 300.000 lao động trong tổng số 14.500 hợp tác xã; đồng thời có tác động quan trọng đối với kinh tế hộ, cá thể xã viên; góp phần xây dựng hạ tầng cơ sở nông thôn, nông nghiệp. Với cơ chế chính sách và tổ chức thực hiện tốt, hợp tác xã đã thu hút được nhiều hộ nông dân tham gia. Người nông dân được hưởng nhiều lợi ích như được mua hàng hóa, sản phẩm với giá cả hợp lý; giảm chi phí sản xuất và các tầng nấc trung gian; góp phần tạo mối liên kết hợp tác giữa các hộ nông dân. Đồng thời, tạo điều kiện tốt để hình thành những cánh đồng mẫu lớn, từ đó tạo ra những sản phẩm có năng suất, chất lượng đồng nhất, nâng cao sức cạnh tranh của nông sản Việt Nam... Nhờ vậy, các chính sách của Nhà nước đến được đúng đối tượng yếu thế cần được hỗ trợ, góp phần lành mạnh hóa môi trường kinh doanh và phát triển bền vững của hợp tác xã.</font></font></font></p><p style="MARGIN: 0cm 0cm 0pt; LINE-HEIGHT: 150%; TEXT-ALIGN: justify"> <font size="3"><font color="rgb(0, 0, 0);"><font face="Times New Roman">Có một thực tế trong phát triển hợp tác xã là &nbsp;trình độ công nghệ còn lạc hậu, năng lực đội ngũ cán bộ quản lý còn yếu, chất lượng hiệu quả hoạt động còn thấp; nhiều hợp tác xã vẫn còn lúng túng trong tổ chức hoạt động, không rõ hướng đi. Bên cạnh đó, Tổ chức&nbsp;đóng vai&nbsp;trò dẫn dắt, chỉ&nbsp;đường là &nbsp;Liên hiệp hợp tác xã chưa phát huy được hết khả năng, chưa hấp dẫn nhân dân, tổ chức tham gia tích cực, đông đảo. Số lượng hợp tác xã đang hoạt động giảm dần qua các năm, nếu năm 2007 có 14.500 hợp tác xã, thì đến năm 2009 chỉ còn 12.249; tốc độ tăng trưởng thấp, chỉ bằng ½ tốc độ tăng trưởng chung của nền kinh tế. Mặt khác, trong vòng 15 năm qua đóng góp của hợp tác xã vào GDP liên tục giảm, nếu năm 1995 là 11%, thì đến 2012 giảm xuống còn 5,22%. Như vậy, hiệu quả hoạt động của hợp tác xã có suy giảm. Đây là một thách thức không nhỏ với một nước có nền nông nghiệp là trọng tâm như Việt Nam&nbsp;.</font></font></font></p><p style="MARGIN: 0cm 0cm 0pt; LINE-HEIGHT: 150%; TEXT-ALIGN: justify"> <font size="3"><font color="rgb(0, 0, 0);"><font face="Times New Roman">Nhận thức của người nông dân còn chưa đầy đủ, chưa thống nhất về tính ưu việt của tổ chức hợp tác xã chính là một trong&nbsp; các nguyên nhân chủ quan dẫn đến hoạt động của hợp tác xã thời gian qua chưa&nbsp; hiệu quả. Trong khi&nbsp; tâm lý xã hội còn bị ảnh hưởng của mô hình hợp tác xã kiểu cũ, hoài nghi về vai trò và hiệu quả của tổ chức hợp tác xã; một số cán bộ, xã viên còn nặng tính bao cấp, thụ động, trông chờ vào sự bao cấp của nhà nước.&nbsp;Các chuyên gia cho rằng đây là&nbsp; những nguyên nhân quan trọng nhất, ảnh hưởng trực tiếp tới hoạt động và sự phát triển của hợp tác xã;&nbsp;bản chất của hợp tác xã trong luật&nbsp; chưa được làm&nbsp;&nbsp;rõ&nbsp; dẫn đến&nbsp; cách hiểu khác nhau&nbsp;đã tác động đến nhận thức về quyền và nghĩa vụ của xã viên; còn xã viên thì chưa thực sự là chủ mà còn mang tính hình thức. ..<br  /> <br  /> Nhìn nhận&nbsp;về những tồn tại hoạt động trong hợp tác xã, Vụ trưởng Vụ Hợp tác xã, Bộ Kế hoạch và Đầu tư Nguyễn Minh Tú cho biết, nguyên nhân quan trọng nhất, nguyên nhân của mọi nguyên nhân là nhận thức của người nông dân chưa được đầy đủ và đi kèm theo với hợp tác xã chuyển đổi cũng không rõ; đồng thời công tác nghiên cứu lý luận còn chưa hiệu quả, công tác thông tin tuyên truyền do vậy cũng không theo kịp; ngoài ra, chưa có bộ máy tổ chức quản lý nhà nước chuyên ngành luật, để giám sát, kiểm tra, thay đổi luật và xử lý vi phạm.<br  /> <br  /> Dù chúng ta đang công nghiệp hóa hiện đại hóa mạnh mẽ đất nước. Nhưng rõ ràng nông nghiệp và kinh tế nông thôn vẫn đang đóng vai trò quan trọng của nền kinh tế ; nông dân là lực lượng chiếm đại đa số dân cư, là lực lượng không thế thiếu trong phát triển nông nghiệp, nông thôn. Và&nbsp;hợp tác xã có vai trò hỗ trợ kinh tế thành viên là nông dân, góp phần bảo đảm an ninh lương thực cho toàn xã hội.&nbsp;Chính vì&nbsp;vậy, việc xây dựng và tạo điều kiện thuận lợi cho hợp tác xã phát triển là điều rất cần thiết .</font></font></font></p><p style="MARGIN: 0cm 0cm 0pt; LINE-HEIGHT: 150%; TEXT-ALIGN: justify"> <font color="rgb(0, 0, 0);" face="Times New Roman" size="3">Có nhiều giải pháp được đưa ra nhằm tháo gỡ khó khăn, tạo điều kiện cho hợp tác xã phát triển, trong đó vấn về nâng cao nhận thức của người dân về vai trò và hiệu quả của hợp tác xã đặc biệt được chú trọng. Đồng thời, xác định đúng vai trò của hợp tác xã trong thời kỳ mới.&nbsp;Ngay trong Luật Hợp tác xã (sửa đổi) cần phải làm rõ bản chất của tổ chức hợp tác xã; lãnh đạo các địa phương, các ngành &nbsp;và đặc biệt là người dân nhận thức đầy đủ về bản chất và tính ưu việt của tổ chức hợp tác xã; đưa hợp tác xã về hoạt động đúng bản chất và tạo điều kiện cho các hợp tác xã hoạt động hiệu quả.<br  /> &nbsp;<br  /> Một giải pháp cũng khá quan trọng mà các chuyên gia đưa ra là&nbsp;làm rõ bản chất tổ chức Liên minh hợp tác xã để liên kết nông dân theo quy mô lớn hơn; nâng cao tính minh bạch trong tài chính của hợp tác xã; cơ cấu lại chính sách hỗ trợ phù hợp với bản chất hợp tác xã, mang lại lợi ích trực tiếp cho xã viên; làm rõ chính sách hỗ trợ vốn, tăng cường năng lực qua đào tạo nguồn nhân lực. Ngoài ra, cần phân công cơ quan chuyên trách về hợp tác xã, từ đó quản lý, giám sát, hỗ trợ trong từng giai đoạn cho phù hợp với quá trình thực hiện tái cơ cấu nền kinh tế; huy động sự tham gia tích cực của đoàn thể, hội, hiệp hội; liên kết hợp tác các hợp tác xã, giữa hợp tác xã nông nghiệp với các loại hình hợp tác xã khác và với doanh nghiệp; sớm đưa ra những giải pháp hữu hiệu để đề xuất với cơ quan chức năng ban hành để hỗ trợ hợp tác xã ngày càng phát triển hơn.</font></p><p style="MARGIN: 0cm 0cm 0pt; LINE-HEIGHT: 150%; TEXT-ALIGN: justify"> <font color="rgb(0, 0, 0);" face="Times New Roman" size="3">&nbsp;</font></p><font size="3"><font color="rgb(0, 0, 0);"><font face="Times New Roman">Hoa Lê<br  />(<em>Nguồn: Báo đại biểu nhân dân)</em></font></font></font>', '', 1, 0, 1, 1, 1),
(39, '<strong>Phó chủ tịch QH Uông Chu Lưu: Sự khác biệt giữa casino và trò chơi có thưởng là gì?</strong><br  />&nbsp;<br  />Theo tôi, nếu không làm rõ sự khác biệt giữa casino với trò chơi điện tử sẽ dẫn đến lẫn lộn. Bởi vì thực ra casino chỉ khác với trò chơi điện tử ở những đơn vị kinh doanh này là có bàn chơi, tức là tương tác giữa người với người. Còn đây là tương tác giữa người với máy. Như vậy trong casino có 2 kiểu để chơi: một là chơi với máy, hai là có bàn chơi. Vậy bây giờ xác định hai cái này có gì khác biệt? Trước đây tôi nhớ trong Nghị định số 108 năm 2006 của Chính phủ thì Thủ tướng Chính phủ đã có quyết định chấp nhận chủ trương đầu tư kinh doanh casino, bây giờ sự khác nhau giữa cái đó với cái này như thế nào. Nếu chỗ này không làm rõ thì sẽ dẫn đến giữa việc kinh doanh ở chỗ này và kinh doanh casino không có gì khác nhau, nếu chỉ trông vào phương tiện, hình thức chơi.<br  />&nbsp;<br  />Thứ hai, cơ chế giải quyết tranh chấp trong này không nêu ra sẽ rất phức tạp về sau. Trên thực tế, hiện nay đang có một vụ kiện từ tháng 6 của năm nay ở tại Tòa án quận 1, TP Hồ Chí Minh. Khi người ta chơi thì máy hiện lên số người ta trúng thưởng, đến khi người ta đề nghị với câu lạc bộ và đơn vị kinh doanh đó trả thưởng thì nói là lỗi của máy. Cho nên vấn đề tôi muốn đặt ra ở đây là những cơ chế giải quyết tranh chấp. Nếu không xác định thì sau này rất khó giải quyết những tranh chấp như vậy. Ở đây có đặt ra vấn đề là có xác định tỷ lệ phần trăm trả thưởng bình quân cho người chơi và có xác định giá trị cá cược của người chơi đối với trò chơi điện tử có thưởng này không, ví dụ chỉ chơi cá cược này đến một giá trị nhất định nào đó thôi. Nếu trong nghị định không xác định rõ, cụ thể thì sau này khi có tranh chấp phát sinh sẽ rất phức tạp.<br  />Điều 13 của Nghị định quy định quản lý thiết bị, trò chơi điện tử giao cho Bộ Tài chính chịu trách nhiệm bảo đảm điều kiện kỹ thuật của các máy này không biết có phù hợp không hay là Bộ Công thương hay Bộ Khoa học và Công nghệ. Nếu bây giờ giao cho Bộ Tài chính xác định, kiểm định về điều kiện kỹ thuật các máy đó không biết có phù hợp không?<br  />Đối với việc xử phạt cũng phải làm rõ. Một là các loại hành vi này cố gắng quy định thật cụ thể từng loại vi phạm một, mỗi loại hành vi như thế gắn với mức phạt, khoảng cách đừng quá rộng ví dụ 50&nbsp; - 100 triệu hoặc từ 150 &nbsp;- 200 triệu trong cùng một hành vi thì sau này rất phức tạp ở chỗ người vận dụng, người đi áp dụng xử phạt. Nên đã là một hành vi cụ thể và không có tình tiết tăng nặng giảm nhẹ thì nên quy định mức cứng trong Nghị định sẽ hợp lý hơn.<br  />&nbsp;<br  /><strong><strong>Chủ tịch Hội đồng Dân tộc K’Sor Phước: Cần có quy định chặt chẽ về vấn đề an ninh, trật tự xã hội</strong></strong><br  />&nbsp;<br  />Về cơ bản tôi đồng tình với việc ban hành Nghị định này, tuy nhiên trong Báo cáo, đặc biệt là Báo cáo về tác động tôi thấy chưa nói nhiều đến tác động về an ninh trật tự. Nếu chúng ta phổ biến việc này thì sẽ như thế nào. Tôi có dịp đi Macao, Canada và Mỹ và tôi đã đến các casino, ở đây các loại hình chơi rất phong phú, có loại không chỉ người với máy mà người với người. Đối với người với máy thì có 2 cấp độ. Cấp độ giữa cá nhân người chơi với chính máy đó. Có một loại nữa đó là một tập thể khá đông, khoảng 3, 4 người thậm chí 5, 6 người cùng chơi với một máy và thường những cái này nó có đối tượng trung gian và lúc đó thường hay có những kỹ xảo để điều chỉnh máy để nhà hàng đạt được lợi ích. Ngoài ra, những chỗ này không chỉ có dịch vụ về đánh bạc mà còn các dịch vụ khác để hút tiền của khách hàng. Vấn đề này ta phải tính đến.<br  />Thứ ba là khách nước ngoài vào Việt Nam để tham gia trò chơi này cũng rất đa dạng, có những người rất đàng hoàng, chỉ giải trí nhưng có những người sang để cá cược, thậm chí có tội phạm và nghiện ma túy vào những khu vực này. Nên phải xác định rằng những điểm này cần phải có quy định rất chặt chẽ về vấn đề trật tự xã hội an ninh ở đây như thế nào.<br  />Một vấn đề nữa là ta chỉ nêu các khách sạn 5 sao, tôi cũng đồng ý như vậy, tuy nhiên bây giờ cũng có các resort, các sân golf, các sân golf làm khách sạn 5 sao rất nhiều do vậy phải nghiên cứu thật kỹ phần có thể lợi dụng việc này để lách luật và chống thất thu ngân sách. Về xử phạt hành chính, theo tôi không nên nói chung chung các chính quyền các cấp. Chính quyền cơ sở cấp phường, xã chỉ chịu trách nhiệm về mối quan hệ với việc bảo đảm trật tự xã hội ở các điểm này và xử lý người Việt Nam khi vi phạm. Còn lại tôi đề nghị giao cho chính quyền cấp quận, huyện phải chịu trách nhiệm trực tiếp.<br  />&nbsp;<br  /><strong>Chủ nhiệm Ủy ban Về các vấn đề xã hội Trương Thị Mai: Tạo nguồn thu ổn định và bền vững cho ngân sách không phải là mục tiêu lớn</strong><br  />&nbsp;<br  />&nbsp;<br  />Do phạm vi là dành cho người nước ngoài tại Việt Nam nên tác động xã hội cũng không quá phức tạp, tất nhiên vấn đề an ninh, trật tự trong đánh giá tác động cũng có nói rồi. Tôi đồng ý với ý kiến trong Báo cáo thẩm tra mà ghi tạo nguồn thu ổn định, bền vững cho ngân sách nhà nước thì cũng không phải là mục tiêu lớn.<br  />&nbsp;<br  />Phạm vi điều chỉnh của Nghị định là đối với người nước ngoài đến Việt Nam thì được tham gia vào hoạt động này còn tuyệt đối người Việt Nam không thuộc phạm vi điều chỉnh. Người Việt Nam đang sinh sống tại Việt Nam, quốc tịch Việt Nam, công dân Việt Nam tuyệt đối là không nằm trong phạm vi điều chỉnh của Nghị định này. Vì vậy, tôi đề nghị loại khỏi Nghị định này mấy điểm sau. Một là Khoản 10, Điều 4 có việc cấm tổ chức môi giới cung cấp dịch vụ đưa người Việt Nam đi chơi trò chơi điện tử có thưởng ở nước ngoài. Đối tượng này đâu có nằm trong phạm vi điều chỉnh của Nghị định này. Đưa người Việt Nam đi đánh bạc ở nước ngoài thì hoàn toàn không nằm trong phạm vi điều chỉnh của Nghị định. Thứ hai, Điểm a, Khoản 3, Điều 31 cũng ghi: &quot;Bộ Công an có trách nhiệm ngăn chặn người Việt Nam trong nước ra nước ngoài đánhh bạc&quot;. Việc này cũng không nằm trong phạm vi của Nghị định này, Bộ Công an sẽ có trách nhiệm ngăn chặn người Việt Nam đi đánh bạc ở nước ngoài vì vi phạm pháp luật, nhưng không nằm trong phạm vi điều chỉnh của Nghị định này. Thứ ba, Khoản 5, Điểm c trong Điều 31 giao cho Bộ Thông tin và Truyền thông phải làm công tác tuyên truyền phổ biến, nghiêm cấm người Việt Nam tham gia tổ chức đánh bạc trái phép là được, nhưng ra nước ngoài đánh bạc cũng không nằm trong phạm vi điều chỉnh của Nghị định này.<br  />&nbsp;<br  />Điều 31, Điểm a, Khoản 4, theo tôi nên giao cho Bộ VH, TT và DL phải phối hợp với Bộ Tài chính để bảo đảm các trò chơi điện tử có thưởng phù hợp thuần phong mỹ tục, thẩm mỹ người Việt Nam.<br  />&nbsp;<br  /><strong>Chủ nhiệm Ủy ban Quốc phòng và An ninh Nguyễn Kim Khoa: Chắc chắn sẽ có tác động đến tâm lý người Việt…</strong><br  />&nbsp;<br  />Đây là một loại hình kinh doanh khá đặc biệt và cũng là một loại hình kinh doanh có thể nói dù rằng người Việt Nam không tham gia nhưng chắc chắn là có yếu tố tác động đến tâm lý truyền thống và văn hóa của người Việt Nam ở khu vực có liên quan đến hoạt động này.<br  />Vấn đề thứ hai, đây là hoạt động kinh doanh có điều kiện mà chúng ta không khuyến khích nên phải quản lý chặt chẽ. Trong Tờ trình của Chính phủ và trong Nghị định đã có quản lý vấn đề này. Nhưng tôi băn khoăn nhất là sau khi Nghị định này được ban hành thì nó sẽ phát triển với số lượng như thế nào? Với điều kiện kinh doanh như thế này, tôi nghĩ rằng tình hình có thể sẽ phát triển tràn lan. Ví dụ như tất cả khách sạn, trong tất cả các tiêu chí thì tiêu chí quan trọng nhất là khách sạn 5 sao và cơ sở khách sạn cao cấp theo quy định của Bộ VH, TT và DL. Tới đây sẽ phát triển không những ở các trung tâm như TP Hồ Chí Minh, Hà Nội mà sẽ phát triển đến các địa phương và phát triển bao nhiêu khách sạn 5 sao, bao nhiêu khách sạn cao cấp thì sẽ có loại hình này, có phải vậy không. Trong nguyên tắc và kể cả các nội dung, tôi thấy không có quy định nào về quy hoạch hoạt động này. Vậy thì có theo đúng định hướng của chúng ta rằng đây là một loạt hình kinh doanh có điều kiện phải quản lý chặt chẽ và cũng không khuyến khích không? Đây là vấn đề cần phải nghiên cứu.<br  />&nbsp;<br  />Một vấn đề nữa là cần nghiên cứu để tránh những tác động tiêu cực. Trên thực tế người Việt Nam ra nước ngoài đánh bạc khá nhiều, đặc biệt là biên giới Việt Nam - Campuchia, nhất là cửa khẩu Mộc Bài - Tây Ninh. Để ngăn chặn việc này thì lại không thuộc phạm vi điều chỉnh của Nghị định nhưng chắc chắn nếu phát triển loại hình này thì chắc chắn sẽ tác động đến tâm lý của người Việt Nam. Cho nên tôi đề nghị điều kiện về địa điểm kinh doanh không chỉ là địa điểm tách rời các dịch vụ khác của khách sạn, của cơ sở kinh doanh du lịch, nên nghiên cứu tránh nơi gần khu dân cư, tập trung ở các khu dân cư.<br  />&nbsp;<br  /><strong>Chủ nhiệm Ủy ban Kinh tế Nguyễn Văn Giàu: Đây chỉ là loại hình dịch vụ góp phần phát triển du lịch</strong><br  />&nbsp;<br  />Trò chơi này chỉ dành cho người nước ngoài, ta khẳng định chắc chắn như thế. Loại hình kinh doanh này là loại hình không khuyến khích và có điều kiện. Từ tư tưởng này tôi nghĩ nên thể hiện bám vào tư tưởng và cách quản lý đó.<br  />&nbsp;<br  />Điều 7 và Điều 9 về số lượng máy và đối tượng được tham gia, tôi đề nghị phải chi tiết hơn, rõ ràng hơn. Bởi vì từ tư tưởng chính trị của chúng ta là không khuyến khích thì đừng biến nơi này thành nơi cờ bạc, mà nơi này cần dịch vụ này để phát triển ngành du lịch, trong quá trình hội nhập. Do vậy, tư tưởng Điều 9 rất quan trọng về phạm vi điều chỉnh.<br  />&nbsp;<br  />Điểm thứ hai, Nghị định này liên quan đến nước ngoài nên có 3 nội dung trong dự thảo Nghị định giao cho Bộ Tài chính hướng dẫn. Ta đã có quá trình tích lũy 20 năm và cũng đã ổn định rồi, nên đưa vào quy định trong Nghị định. Khoản 2 Điều 7 quy định về chủng loại, loại hình trò chơi, việc này đâu cần phải đợi Bộ Tài chính hướng dẫn, ta nên quy định thẳng trong Nghị định. Khoản 3, Điều 14 là đối tượng được mua máy thiết bị dự phòng để thay thế cần thiết cũng nên quy định luôn chứ không cần Bộ Tài chính hướng dẫn. Điểm c, Khoản 3, Điều 18 về điều kiện người quản lý và điều hành theo tôi đây là vấn đề rất quan trọng và phải quy định rõ trong Nghị định chứ không nên để hướng dẫn bởi vấn đề này đã rõ tiêu chuẩn, tiêu chí.<br  />&nbsp;<br  />Thứ ba, về phân cấp, nên phân cấp một cách rõ ràng hơn thì mới quản lý tốt được. Theo tôi nên phân cấp cho UBND ở địa phương để có người chịu trách nhiệm, còn nếu công tác thanh tra, giám sát, dẫn vào bộ trên này thì chúng ta không “dài tay” nổi.<br  /><br  /><em>(Nguồn: Báo điện tử Đại biểu nhân dân)</em>', '', 1, 0, 1, 1, 1),
(40, '<strong>Diễn biến phức tạp, thủ đoạn tinh vi.</strong> Trong bối cảnh kinh tế hiện nay, những tội phạm về buôn lậu, gian lận thương mại, trốn thuế, về mua bán và sử dụng các loại giấy tờ có giá giả được dự báo vẫn tiếp tục diễn biến khó lường với thủ đoạn tinh vi.<br  />&nbsp; &nbsp;Đây là một thách thức cho công tác phòng, chống các hành vi vi phạm và tội phạm về thuế. Quá trình hội nhập cũng đã xuất hiện nhiều loại tội phạm mới mà hệ thống pháp luật chưa theo kịp, đặc biệt là đối với các hành vi mua bán, sử dụng hóa đơn trái phép, trong đó nguy hiểm và nghiêm trọng nhất là tội phạm lập doanh nghiệp “ma” chỉ để mua bán hóa đơn.<br  />&nbsp; Tình trạng mua bán, sử dụng trái phép hóa đơn nhằm thu lợi bất chính đang là vấn đề bức xúc trên phạm vi rộng. Đấy là chưa kể nhiều loại tội phạm mới tiếp tục xuất hiện và sẽ xuất hiện như gian lận hoàn thuế xuất nhập khẩu ở khu kinh tế thương mại tự do, gian lận thuế trong các ngành kinh doanh bảo hiểm, thuế nhà thầu, kinh doanh thương mại điện tử, kinh doanh internet, kinh doanh tư vấn pháp luật…<br  />&nbsp; Cùng với tác động của cuộc khủng hoảng, tình hình vi phạm, tội phạm trong lĩnh vực tài chính, chủ yếu trong lĩnh vực ngân hàng, trong một vài năm vừa qua cũng diễn biến hết sức phức tạp. Số vụ án nghiêm trọng xảy ra ngày càng tăng về số vụ và mức thiệt hại.<br  />&nbsp; Nhiều vụ án có sự tham gia trực tiếp hoặc tiếp tay của cán bộ ngân hàng. Tổng số thiệt hại lên đến hàng chục nghìn tỷ đồng, trên 3.000 lượng vàng và mới thu hồi được gần 2.000 tỷ đồng. Chỉ tính riêng trong năm 2010 – 2011, các cơ quan chức năng đã phát hiện xác lập án điều tra 69 vụ, khởi tố 40 vụ và 70 cán bộ ngân hàng, thiệt hại hơn 8.000 tỷ đồng.<br  />&nbsp; Một số vụ nghiêm trong liên tiếp xảy ra như vụ vợ chồng Hồ Minh Hậu, Phạm Thị Ái Loan lừa đảo chiếm đoạt gần 400 tỷ đồng của 3 ngân hàng là Ngân hàng liên doanh Việt – Nga, Vietcombank chi nhánh Bình Dương, BIDV chi nhánh Phú Yên; vụ Công ty TNHH Xuất nhập khẩu Công Chính và Công ty TNHH Xuất nhập khẩu Thái Nguyên tại Lâm Đồng lừa đảo chiếm đoạt 600 tỷ đồng của Techcombank chi nhánh TP.HCM; vụ lợi dụng chức vụ, quyền hạn trong khi thi hành công vụ xảy ra tại Công ty Cho thuê tài chính II – Agribank gây thiệt hại ước tính 1.600 tỷ đồng; mới nhất là vụ Huỳnh Thị Huyền Như (Vietinbank chi nhánh TP.HCM) lừa đảo, chiếm đoạt 3.600 tỷ đồng của hơn 30 doanh nghiệp cùng 20 cá nhân và vụ bê bối tài chính tại Ngân hàng ACB…<br  />&nbsp; <strong>Bổ sung tội thiếu trách nhiệm của nhân hàng “tư”</strong><br  />&nbsp; Khi thực tiễn đấu tranh phòng, chống các tội phạm trong những lĩnh vực này đang gặp nhiều khó khăn đối với các cơ quan chức năng thì BLHS hiện hành lại quá thiếu các quy định để xử lý những hành vi như vậy và tạo ra “lỗ hổng” khá lớn để các đối tượng lợi dụng những kẽ hở của pháp luật thực hiện hành vi phạm tội.<br  />&nbsp; Đơn cử, trong lĩnh vực thuế, BLHS chỉ có duy nhất 1 điều quy định về trốn thuế, còn các hành vi khác như chây ỳ thuế hoặc liên quan đến việc gom hàng hóa trôi nổi trên thị trường, hàng nhập lậu để hợp thức hóa, lập hồ sơ hoàn thuế, khấu trừ thuế giá trị gia tăng đầu vào nhằm chiếm đoạt tiền thuế giá trị gia tăng của Nhà nước hoặc để hạch toán tăng giá vốn, tăng chi phí trốn thuế thu nhập doanh nghiệp… thì chưa hề được quy định. Các cơ quan tiến hành tố tụng đành phải giải quyết, xử lý các hành vi trên theo những quy định khác của BLHS.<br  />&nbsp; Mặt khác, các tội phạm về tài chính – kế toán cũng không được quy định một cách riêng rẽ và cụ thể mà chỉ được quy định chung chung trong Chương XVI. Thực tế điều tra, truy tố, xét xử các vụ án này cho thấy, đối với các tội phạm về kế toán thường bị xử lý về các tội như tham ô, lừa đảo chiếm đoạt tài sản, cố ý làm trái hoặc lợi dụng chức vụ, quyền hạn… bởi BLHS không có bất kỳ quy định riêng nào đối với tội phạm trong lĩnh vực kế toán. Hạn chế đáng kể ấy của pháp luật hình sự hiện hành cần sớm được khắc phục để tạo thuận lợi cho các cơ quan tiến hành tố tụng trong quá trình điều tra, xử lý các hành vi vi phạm. &nbsp;<br  />Xuất phát từ thực trạng trên, ông Nông Xuân Trường (Vụ 1, VKSNDTC) đề nghị hoàn thiện các quy định của BLHS theo hướng sau: Đối với tội trốn thuế, cần tăng mức phạt tiền lên mức tối đa, gấp đôi hoặc gấp ba quy định hiện hành nhằm tăng cường tính răn đe, giáo dục. Về tội in, phát hành, mua bán trái phép hóa đơn, chứng từ thu nộp ngân sách nhà nước, cần phân biệt rõ 2 loại hóa đơn là hóa đơn chưa ghi nội dung và hóa đơn có ghi nội dung giá trị hàng hóa, dịch vụ kèm theo.<br  />&nbsp; Có ý kiến thì cho rằng, nên bổ sung vào BLHS một điều luật mới quy định về hành vi thiếu trách nhiệm của nhân viên các ngân hàng thương mại cổ phần ngoài quốc doanh. Bởi lẽ có những nhân viên của các ngân hàng này thiếu trách nhiệm gây ra hậu quả rất nghiêm trọng nhưng các cơ quan tiến hành tố tụng rất lúng túng, thậm chí không xử lý được vì có thiệt hại thực tế về tài sản, song tài sản đó lại không phải là tài sản nhà nước và đối tượng phạm tội cũng không phải là chủ thể đặc biệt của tội thiếu tinh thần trách nhiệm.<br  />&nbsp;<br  /><br  />(<em>Nguồn: Báo Pháp luật Việt Nam)</em><br  />&nbsp;', '', 1, 0, 1, 1, 1);
INSERT INTO `nv3_vi_news_bodyhtml_1` (`id`, `bodyhtml`, `sourcetext`, `imgposition`, `copyright`, `allowed_send`, `allowed_print`, `allowed_save`) VALUES
(41, 'Tại cuộc tọa đàm với sự tham dự của gần 100 đại diện doanh nghiệp, diễn giả Nguyễn Hồng Hà, Phó giám đốc VCCI – chi nhánh TPHCM, dẫn chứng những điểm mới tích cực mà Nghị định 46 được kỳ vọng sẽ mang lại cho thị trường lao động, đó là rút ngắn thời gian xử lý thủ tục, đơn giản hóa thủ tục hành chính và linh hoạt hơn đối với lao động nước ngoài có trình độ. Tuy nhiên, bà Hà cũng nêu ra những vấn đề có thể gây e ngại nơi doanh nghiệp tuyển dụng lao động, đó là hiệu quả của sự phối hợp giữa các cơ quan ban ngành có liên quan trong việc thực thi nghị định này.<br  />Diễn giả Oliver Massmann, Tổng giám đốc công ty luật Duane Morris Vietnam, cũng nêu ra những điểm tích cực của nghị định mới, cụ thể trong vấn đề mở rộng diện người lao động nước ngoài được miễn giấy phép lao động tại Việt Nam. Tuy nhiên, theo ông, Nghị định 46 có khá nhiều điểm bất hợp lý và điều này có thể gây khó cho các doanh nghiệp.<br  />Ông dẫn chứng về yêu cầu thông báo công khai nhu cầu tuyển dụng người lao động Việt Nam vào các vị trí dự kiến tuyển lao động nước ngoài. Điều này được quy định trong Điều 1.3 và 1.9 của Nghị định 46. Cụ thể, doanh nghiệp trước khi tuyển lao động người nước ngoài, ít nhất 30 ngày, người sử dụng lao động phải thông báo nhu cầu tuyển người lao động Việt Nam vào các vị trí công việc dự kiến tuyển người nước ngoài trên cả báo trung ương và báo địa phương.<br  />Theo&nbsp;ông&nbsp;Massmann,&nbsp;điều này sẽ làm quá trình tuyển dụng của doanh nghiệp bị kéo dài bắt buộc phải áp dụng cho tất cả các nhân viên nước ngoài, bao gồm cả giám đốc điều hành và chuyên gia kỹ thuật hàng đầu. Còn nếu doanh nghiệp không thực sự muốn tốn thời gian cho quá trình tìm hiểu nghiên cứu hồ sơ, phỏng vấn để sàng lọc ứng viên sau khi đăng thông báo thì đối mặt với nguy cơ bị kiện từ các ứng viên là lao động Việt Nam.<br  />Một số đại diện doanh nghiệp và các hiệp hội doanh nghiệp cũng chia sẻ quan điểm của ông Massmann rằng quy định mới này có thể gây ảnh hưởng đến cả các doanh nghiệp Việt Nam đang muốn tuyển dụng lao động nước ngoài cấp cao nhằm tăng vị thế cạnh trang và phục vụ cho mục tiêu mở rộng ra thị trường nước ngoài.<br  />Bên cạnh đó, ông Massmann e ngại quy định này sẽ vi phạm điều khoản 8.2 trong hiệp định thương mại song phương Việt - Mỹ (BTA) về đảm bảo quyền của các công ty tham gia quản lý nhân viên hàng đầu của họ bất kể quốc tịch.<br  />Một quy định khác được đánh giá thiếu tính khả thi đó là Điều 1.13 của Nghị định 46 với nội dung khi gia hạn giấy phép cho người lao động nước ngoài, doanh nghiệp phải nộp bản sao hợp đồng học nghề với người lao động Việt Nam nhằm đào tạo người thay thế vị trí trên của người nước ngoài.<br  />Ông Massmann e ngại đã có sự lẫn lộn giữa “hợp đồng học nghề” (apprenticeship contract) và “hợp đồng đào tạo” (training contract) vì trên thực tế, hợp đồng học nghề có thể được ký bởi doanh nghiệp với một người sẽ được đào tạo trở thành công nhân, người thợ chứ không thể trở thành một giám đốc điều hành (CEO) hoặc giám đốc tài chính được (CFO).<br  />Trong khi đó, quy định này có thể không phù hợp với Điều 132 của Bộ luật Lao động – vốn chỉ yêu cầu “doanh nghiệp, tổ chức và cá nhân được tuyển người nước ngoài cho một thời hạn nhất định nhưng phải có kế hoạch, chương trình đào tạo để người Việt Nam có thể sớm làm được công việc đó và thay thế họ”.<br  />Nhiều đại điện doanh nghiệp cũng góp ý việc các cơ quan chức năng thực thi những quy định mới nên hướng đến mục tiêu chung là tạo điều kiện thuận lợi cho lao động có tay nghề được làm việc tại Việt Nam. Và khi đó, rất cần những chính sách linh hoạt phù hợp để thực hiện việc quản lý lao động nước ngoài tại Việt Nam có hiệu quả, có tác dụng thúc đẩy nền kinh tế phát triển và hài hòa lợi ích giữa nhà nước - doanh nghiệp - người lao động trong lĩnh vực này.<br  />Các doanh nghiệp cũng kỳ vọng sắp tới thông tư hướng dẫn thi hành sẽ thống nhất cách hiểu về các điều khoản của luật, nghị định để bảo đảm sự chặt chẽ bảo đảm quyền lợi lẫn nghĩa vụ cho người lao động và người sử dụng lao động<br  /><em>Nguồn: Thời báo Kinh tế Sài Gòn Online</em>', '', 1, 0, 1, 1, 1),
(42, '<strong>&nbsp; NGHỊ ĐỊNH</strong><strong>QUY ĐỊNH MỨC LƯƠNG TỐI THIỂU VÙNG ĐỐI VỚI NGƯỜI LAO ĐỘNG LÀM VIỆC Ở CÔNG TY, DOANH NGHIỆP, HỢP TÁC XÃ, TỔ HỢP TÁC, TRANG TRẠI, HỘ GIA ĐÌNH, CÁ NHÂN VÀ CÁC CƠ QUAN, TỔ CHỨC CÓ THUÊ MƯỚN LAO ĐỘNG</strong><br  /><strong>---------------------------</strong><br  />CHÍNH PHỦ<br  />&nbsp;<br  />&nbsp;<br  /><em>Căn cứ Luật Tổ chức Chính phủ ngày 25 tháng 12 năm 2001;</em><br  /><em>Căn cứ Bộ luật Lao động ngày 23 tháng 6 năm 1994; Luật sửa đổi, bổ sung một số điều của Bộ luật Lao động ngày 02 tháng 4 năm 2002; Luật sửa đổi, bổ sung một số điều của Bộ luật Lao động ngày 29 tháng 6 năm 2006;</em><br  /><em>Căn cứ Luật Doanh nghiệp ngày 29 tháng 11 năm 2005;</em><br  /><em>Xét đề nghị của Bộ trưởng Bộ Lao động - Thương binh và Xã hội,</em><br  />&nbsp;<br  />&nbsp;<br  /><strong>NGHỊ ĐỊNH:</strong><br  />&nbsp;<br  />&nbsp;<br  /><strong>Điều 1. Đối tượng và phạm vi áp dụng</strong><br  />Nghị định này quy định mức lương tối thiểu vùng áp dụng đối với người lao động làm việc ở công ty, doanh nghiệp, hợp tác xã, trang trại, hộ gia đình, cá nhân và các cơ quan, tổ chức có thuê mướn lao động, gồm:<br  />1. Doanh nghiệp thành lập, tổ chức quản lý và hoạt động theo Luật Doanh nghiệp (kể cả doanh nghiệp có vốn đầu tư nước ngoài tại Việt Nam).<br  />2. Hợp tác xã, liên hiệp hợp tác xã, tổ hợp tác, trang trại, hộ gia đình, cá nhân và các tổ chức khác của Việt Nam có thuê mướn lao động.<br  />3. Cơ quan, tổ chức nước ngoài, tổ chức quốc tế và cá nhân người nước ngoài tại Việt Nam có thuê mướn lao động (trừ trường hợp điều ước quốc tế mà Cộng hòa xã hội chủ nghĩa Việt Nam là thành viên có quy định khác với quy định của Nghị định này).<br  />Các công ty, doanh nghiệp, cơ quan, tổ chức và cá nhân quy định tại các khoản 1, 2 và 3 Điều này gọi chung là doanh nghiệp.<br  /><strong>Điều 2. Mức lương tối thiểu vùng</strong><br  />Quy định mức lương tối thiểu vùng áp dụng từ ngày 01 tháng 10 năm 2011 đến hết ngày 31 tháng 12 năm 2012 như sau:<br  />1. Mức 2.000.000 đồng/tháng áp dụng đối với doanh nghiệp hoạt động trên địa bàn thuộc vùng I.<br  />2. Mức 1.780.000 đồng/tháng áp dụng đối với doanh nghiệp hoạt động trên địa bàn thuộc vùng II.<br  />3. Mức 1.550.000 đồng/tháng áp dụng đối với doanh nghiệp hoạt động trên địa bàn thuộc vùng III.<br  />4. Mức 1.400.000 đồng/tháng áp dụng đối với doanh nghiệp hoạt động trên các địa bàn thuộc vùng IV.<br  />Địa bàn áp dụng mức lương tối thiểu vùng được quy định tại Phụ lục ban hành kèm theo Nghị định này.<br  /><strong>Điều 3. Áp dụng mức lương tối thiểu vùng</strong><br  />1. Mức lương tối thiểu vùng quy định tại Điều 2 Nghị định này là mức lương thấp nhất làm cơ sở để doanh nghiệp và người lao động thỏa thuận tiền lương trả cho người lao động.<br  />2. Mức tiền lương thấp nhất trả cho người lao động đã qua học nghề (kể cả lao động do doanh nghiệp tự dạy nghề) phải cao hơn ít nhất 7% so với mức lương tối thiểu vùng quy định tại Điều 2 Nghị định này.<br  />3. Mức lương tối thiểu vùng quy định tại Điều 2 Nghị định này được dùng làm căn cứ để xây dựng các mức lương trong thang lương, bảng lương, phụ cấp lương, tính các mức lương ghi trong hợp đồng lao động và thực hiện các chế độ khác do doanh nghiệp xây dựng và ban hành theo thẩm quyền do pháp luật lao động quy định.<br  />4. Căn cứ mức lương tối thiểu vùng quy định tại Điều 2 Nghị định này, doanh nghiệp điều chỉnh lại các mức lương trong thang lương, bảng lương do doanh nghiệp xây dựng và ban hành, tiền lương trong hợp đồng lao động cho phù hợp với các thỏa thuận và quy định của pháp luật lao động.<br  />5. Khuyến khích các doanh nghiệp trả lương cho người lao động cao hơn mức lương tối thiểu vùng quy định tại Điều 2 Nghị định này.<br  /><strong>Điều 4. Tổ chức thực hiện</strong><br  />1. Bộ Lao động - Thương binh và Xã hội chịu trách nhiệm hướng dẫn thi hành Nghị định này.<br  />2. Bộ Lao động - Thương binh và Xã hội chủ trì, phối hợp với Tổng Liên đoàn Lao động Việt Nam, Phòng Thương mại và Công nghiệp Việt Nam, các Bộ, cơ quan liên quan và Ủy ban nhân dân tỉnh, thành phố trực thuộc Trung ương tuyên truyền, phổ biến đến người lao động, người sử dụng lao động và kiểm tra, giám sát việc thực hiện mức lương tối thiểu vùng quy định tại Nghị định này; báo cáo Chính phủ xem xét, quyết định việc điều chỉnh mức lương tối thiểu vùng theo quy định.<br  /><strong>Điều 5. Hiệu lực thi hành</strong><br  />1. Nghị định này có hiệu lực thi hành từ ngày 05 tháng 10 năm 2011.<br  />2. Bãi bỏ Nghị định số 107/2010/NĐ-CP ngày 29 tháng 10 năm 2010 của Chính phủ quy định mức lương tối thiểu vùng đối với người lao động làm việc ở công ty, doanh nghiệp, hợp tác xã, tổ hợp tác, trang trại, hộ gia đình, cá nhân và các tổ chức khác của Việt Nam có thuê mướn lao động; Nghị định số 108/2010/NĐ-CP ngày 29 tháng 10 năm 2010 của Chính phủ quy định mức lương tối thiểu vùng đối với lao động Việt Nam làm việc cho doanh nghiệp có vốn đầu tư nước ngoài, cơ quan, tổ chức nước ngoài, tổ chức quốc tế và cá nhân người nước ngoài tại Việt Nam; khoản 3 Điều 7 Nghị định số 22/2011/NĐ-CP ngày 04 tháng 4 năm 2011 của Chính phủ quy định mức lương tối thiểu chung.<br  />3. Khuyến khích doanh nghiệp tổ chức ăn giữa ca cho người lao động. Mức tiền ăn giữa ca do doanh nghiệp, Ban Chấp hành công đoàn cơ sở hoặc Ban Chấp hành công đoàn lâm thời và người lao động thỏa thuận, để bảo đảm chất lượng bữa ăn giữa ca cho người lao động.<br  />4. Công ty trách nhiệm hữu hạn nhà nước một thành viên do Nhà nước làm chủ sở hữu, công ty mẹ - tập đoàn kinh tế nhà nước trong thời gian chưa xây dựng được thang lương, bảng lương theo quy định tại Nghị định số 101/2009/NĐ-CP ngày 05 tháng 11 năm 2009 của Chính phủ, công ty nhà nước chưa chuyển đổi thành công ty trách nhiệm hữu hạn hoặc công ty cổ phần, các tổ chức, đơn vị hiện đang áp dụng chế độ tiền lương như công ty nhà nước được lựa chọn mức lương tối thiểu cao hơn so với mức lương tối thiểu chung do Chính phủ quy định để xác định đơn giá tiền lương của người lao động và quỹ tiền lương của viên chức quản lý từ năm 2012 khi đủ các điều kiện theo quy định tại Nghị định số 206/2004/NĐ-CP ngày 14 tháng 12 năm 2004; Nghị định số 207/2004/NĐ-CP ngày 14 tháng 12 năm 2004; Nghị định số 86/2007/NĐ-CP ngày 28 tháng 5 năm 2007; Nghị định số 141/2007/NĐ-CP ngày 05 tháng 9 năm 2007 của Chính phủ và bảo đảm mức tăng tiền lương của viên chức quản lý không vượt quá mức tăng tiền lương của của người lao động. Trường hợp không bảo đảm đủ các điều kiện do Chính phủ quy định mà tiền lương tính theo chế độ của người lao động thấp hơn mức lương tối thiểu vùng quy định tại Điều 2 Nghị định này thì được tính bằng mức lương tối thiểu vùng quy định tại Điều 2 Nghị định này.<br  />5. Các Bộ trưởng, Thủ trưởng cơ quan ngang Bộ, Thủ trưởng cơ quan thuộc Chính phủ, Chủ tịch Ủy ban nhân dân tỉnh, thành phố trực thuộc Trung ương và các cơ quan, doanh nghiệp chịu trách nhiệm thi hành Nghị định này.<br  />&nbsp;<br  /><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TM. CHÍNH PHỦ<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; THỦ TƯỚNG<br  /><br  /><br  /><br  /><br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Nguyễn Tấn Dũng</strong><br  />&nbsp;', '', 1, 0, 1, 1, 1),
(43, 'Do vậy, từ nay đến cuối năm 2011, một trong những nhiệm vụ trong tâm của ngành Thuế là triển khai các giải pháp thực hiện đồng bộ và thống nhất thúc đẩy các doanh nghiệp nêu trên đặt in hoặc tự in hóa đơn để có hóa đơn sử dụng từ ngày 1/1/2012.<br  />&nbsp;<br  />Việc chuyển hết các doanh nghiệp siêu nhỏ, doanh nghiệp ở tại địa bàn kinh tế xã hội khó khăn và đặc biệt khó khăn từ cơ chế mua hóa đơn của cơ quan thuế sang cơ chế tự chủ đặt in, tự in hóa đơn có ý nghĩa quan trọng trong việc nâng cao tính tự chủ của các doanh nghiệp trong công tác tự chịu trách nhiệm về&nbsp; quản lý hóa đơn của doanh nghiệp, giảm chi phí quản lý của cơ quan thuế dùng vào việc bán hóa đơn, ấn chỉ cho các doanh nghiệp.<br  />&nbsp;<br  />Phấn đấu hết tháng 10/2011, doanh nghiệp siêu nhỏ có phương án sử dụng hóa đơn tự in<br  />Tổng cục Thuế đề nghị cơ quan Thuế các cấp cần tập trung các giải pháp phấn đấu hết tháng 10/2011, về cơ bản tất cả các doanh nghiệp trên địa bàn ký được hợp đồng đặt in hoá đơn hoặc đã có phương án sử dụng hoá đơn tự in.<br  />&nbsp;<br  />Đồng thời, cũng để tránh hiện tượng các doanh nghiệp đặt in hoá đơn dồn vào thời điểm cuối năm, Tổng cục Thuế giao chỉ tiêu cho các Cục thuế thực hiện đảm bảo đến hết ngày 31/10/2011, 100% số lượng doanh nghiệp siêu nhỏ, doanh nghiệp ở địa bàn khó khăn và đặc biệt khó khăn có hoá đơn đặt in hoặc ký được hợp đồng đặt in hoá đơn hoặc có phương án sử dụng hoá đơn tự in.<br  />&nbsp;<br  />Trường hợp doanh nghiệp gặp vướng mắc trong việc đặt in, tự in hóa đơn, Tổng cục Thuế đề nghị Cục thuế liên hệ trực tiếp, phối hợp với các nhà in, doanh nghiệp cung cấp phần mềm in hoá đơn để hỗ trợ giải quyết vướng mắc cho doanh nghiệp.<br  />&nbsp;<br  /><strong>Cơ quan thuế chỉ bán số lượng hóa đơn đủ dùng đến hết 31/12/2011</strong><br  />&nbsp;<br  />Bên cạnh đó, Tổng cục Thuế yêu cầu cần tiếp tục thực hiện công tác tuyên truyền để phổ biến và quán triệt sâu sắc đến từng doanh nghiệp hiện đang mua hóa đơn của cơ quan thuế để doanh nghiệp biết nội dung: Từ ngày 1/1/2012 cơ quan Thuế không bán hóa đơn cho doanh nghiệp. Tuỳ vào đặc điểm của từng địa phương, Cục thuế chủ động sử dụng các hình thức tuyên truyền khác nhau đảm bảo hiệu quả.<br  />&nbsp;<br  />Căn cứ số lượng hoá đơn còn tồn kỳ trước, trong quý IV/2011 cơ quan Thuế các cấp giảm dần số lượng hoá đơn bán cho các doanh nghiệp, chỉ bán với số lượng đủ dùng đến hết 31/12/2011. Cục Thuế thông báo đến từng doanh nghiệp về việc hoá đơn do Cục thuế đặt in bán cho doanh nghiệp đến ngày 31/12/2011 doanh nghiệp còn tồn sẽ hết giá trị sử dụng, doanh nghiệp phải nộp lại số còn tồn cho cơ quan Thuế để cơ quan Thuế huỷ theo quy định.<br  />&nbsp;<br  />Đồng thời với việc bán hoá đơn với số lượng đủ dùng này, cơ quan Thuế yêu cầu từng doanh nghiệp siêu nhỏ, doanh nghiệp ở tại địa bàn kinh tế xã hội khó khăn và đặc biệt khó khăn hiện đang mua hoá đơn cam kết với cơ quan Thuế về việc doanh nghiệp đã được cơ quan Thuế triển khai các quy định về hoá đơn và chịu trách nhiệm đảm bảo có hoá đơn để sử dụng từ 1/1/2012 theo quy định.<br  />&nbsp;<br  />Theo Chinhphu.vn', '', 1, 0, 1, 1, 1),
(44, '<strong>Vốn góp bao nhiêu là phù hợp?</strong><br  />Mức góp tối đa của một thành viên HTX được quy định tại Khoản 1 Điều 18. HTX là tổ chức được thành lập để đáp ứng các nhu cầu và nguyện vọng chung của các xã viên. Muốn thực hiện được nhiệm vụ này thì không HTX nào không cần đến vốn góp của các xã viên để xây dựng cơ sở vật chất – kỹ thuật cho việc thực hiện các hoạt động kinh tế có liên quan. Tuy nhiên, nếu như đối với doanh nghiệp, vấn đề hạn chế việc góp vốn không bao giờ phải đặt ra thì đối với HTX đây lại là vấn đề nóng. Vụ trưởng Vụ Pháp luật Dân sự - Kinh tế, Bộ Tư pháp Dương Đăng Huệ lý giải, nguyên nhân cơ bản của tình trạng này xuất phát từ tính chất đối nhân của HTX, đặc biệt là từ nguyên tắc bình đẳng trong quản lý của tất cả các xã viên. Tuy nhiên, về vấn đề này còn có hai ý kiến khác nhau. Ý kiến thứ nhất cho rằng, cần tiếp tục kế thừa quy định của Luật Hợp tác xã năm 2003, cụ thể “mức góp vốn tối đa của một thành viên HTX, Liên hiệp HTX không vượt quá 30% vốn điều lệ của HTX, Liên hiệp HTX”. Ý kiến thứ hai dựa trên khuyến cáo của Liên minh Hợp tác xã Quốc tế. Cụ thể, mức vốn góp tối đa của một thành viên HTX không được quá 20% vốn điều lệ của HTX và mức góp vốn tại Liên minh HTX là 30%. Đây cũng là quy định tại dự thảo Luật HTX (sửa đổi).<br  />Thực tế, việc quy định mức vốn góp tối đa cho thành viên nhằm ghi nhận sự khác biệt giữa HTX với các loại hình doanh nghiệp, đặc biệt là để đề cao và bảo đảm thực hiện sự bình đẳng trong quản lý HTX. Ngoài ra, nếu không khống chế số vốn góp tối đa thì thành viên có mức góp vốn cao hơn sẽ được chia lãi nhiều hơn theo tỷ lệ góp vốn. Ở góc độ khác, Chủ tịch HĐQT SaigonCoop Nguyễn Ngọc Hòa đặt vấn đề, HTX, Liên hiệp HTX là một pháp nhân nên cũng được quyền tham gia góp vốn vào một HTX khác. Trong trường hợp này có thể nghiên cứu cho phép góp vốn của pháp nhân là HTX, Liên hiệp HTX vào các HTX ở mức 30%. Điều này sẽ khuyến khích được các HTX, Liên hiệp HTX có điều kiện tham gia góp vốn để tương trợ giúp đỡ các HTX khác; đồng thời HTX, Liên hiệp HTX có cùng bản chất xã hội nên không sợ ảnh hưởng chi phối đến mục tiêu hoạt động của HTX<br  /><strong>Giới hạn quyền cung ứng sản phẩm, dịch vụ</strong><br  />Việc giới hạn sản phẩm, dịch vụ mà HTX được cung cấp cho thị&nbsp; trường bên ngoài cộng đồng thành viên quy định tại Khoản 1 Điều 9. Trên thực tế, trong nhiều trường hợp ngoài việc tập trung năng lực để đáp ứng nhu cầu, nguyện vọng chung của các xã viên thì HTX vẫn còn năng lực để phục vụ các nhu cầu của chủ thể khác không phải là thành viên của HTX. Vì vậy, vấn đề đặt ra là có nên cho phép HTX cung ứng sản phẩm, dịch vụ ra bên ngoài hay không và nếu cho phép thì nên ở mức độ nào là hợp lý? Về vấn đề này, quan điểm của ông Huệ là cần khống chế tỷ lệ sản phẩm dịch vụ HTX được phép cung cấp ra thị trường bên ngoài cộng đồng thành viên. Mức độ khống chế ở mỗi quốc gia không giống nhau, chẳng hạn ở bang Quebec, Canada, tỷ lệ này được xác định ngay trong luật là 50%, tức là tỷ lệ dịch vụ tối thiểu mà HTX phải giao dịch với xã viên là 50%. Trong điều kiện Việt Nam hiện nay, ông Huệ nhất trí với quy định của dự thảo Luật HTX (sửa đổi). Cụ thể, vấn đề này không được quy định cụ thể trong Luật HTX mà giao cho Điều lệ HTX xác định tỷ lệ cụ thể trên cơ sở hướng dẫn của Chính phủ. Tỷ lệ này được xác định phù hợp với từng HTX trong các ngành, lĩnh vực và phù hợp với từng giai đoạn nhất định. Thứ trưởng Bộ Kế hoạch và Đầu tư Đặng Huy Đông khẳng định, Luật HTX của nhiều quốc gia không quy định chính sách hỗ trợ của Nhà nước đối với HTX; còn dự thảo Luật HTX (sửa đổi) quy định chính sách hỗ trợ HTX hơn hẳn so với doanh nghiệp. Do vậy, để định hướng HTX hoạt động đúng bản chất, tránh tình trạng lách luật để thụ hưởng chính sách của Nhà nước dành cho HTX như tình trạng hiện nay, quy định của Luật cần bảo đảm HTX trước hết và chủ yếu tập trung phục vụ mang lại lợi ích cho các thành viên. Đồng thời, dự thảo luật có quy định mềm dẻo cho phép HTX có quyền cung ứng sản phẩm, dịch vụ và việc làm cho thị trường bên ngoài cộng đồng thành viên trên cơ sở bảo đảm thực hiện hợp đồng.&nbsp;&nbsp;<br  />(<em>Nguồn: daibieunhandan.vn) </em>', '', 1, 0, 1, 1, 1),
(45, 'Thực tế, cả hai phương án trên đều có yếu tố hợp lý nhưng cũng có những yếu tố chưa hợp lý. Theo dự thảo Luật, phạm vi hòa giải gồm 3 loại đối tượng đó là: <em>mâu thuẫn, vi phạm pháp luật</em> và <em>tranh chấp nhỏ</em> trong nhân dân. Mâu thuẫn là sự bất đồng quan điểm, đối lập về quyền, lợi ích. Từ mâu thuẫn có thể dẫn đến hành vi vi phạm pháp luật, có thể dẫn đến tranh chấp (nếu mâu thuẫn về quyền hoặc lợi ích), do đó mâu thuẫn đương nhiên cần được hòa giải kịp thời tại cơ sở để ngăn ngừa phát sinh tranh chấp, vi phạm pháp luật. Đối với hành vi vi phạm hành chính, hành vi phạm tội là những hành vi nguy hiểm cho xã hội nên tùy mức độ vi phạm để xử lý theo quy định của Luật Xử lý vi phạm hành chính hoặc pháp luật hình sự nên không được phép hòa giải. Do đó, chỉ hòa giải đối với những<em> vi phạm pháp luật nhỏ</em>, tức là những vi phạm chưa đến mức xử lý hành chính hoặc xử lý hình sự là phù hợp (tất nhiên những vi phạm này có ảnh hưởng đến quyền, lợi ích của cá nhân khác có thể trở thành nguyên nhân gây mâu thuẫn, tranh chấp hoặc hành vi vi phạm pháp luật nghiêm trọng hơn, còn đối với những vi phạm pháp luật nhỏ xâm phạm lợi ích chung không có chủ thể cụ thể có mâu thuẫn, lợi ích đối kháng nên không thể là đối tượng hòa giải). Đối với tranh chấp, theo dự thảo Luật quy định chỉ hòa giải đối với <em>tranh chấp nhỏ</em> trong nhân dân. Đây là quy định mang tính định tính mà không xác định cụ thể loại tranh chấp nào là <em>tranh chấp nhỏ,</em> không có định lượng giá trị <em>tranh chấp nhỏ</em> là bao nhiêu để được hòa giải tại cơ sở. Với quy định này sẽ rất khó xác định trong thực tiễn khi tiến hành hòa giải. Mặt khác, hoạt động hòa giải tại cơ sở là hoạt động tự nguyện, tự quyết định lựa chọn của nhân dân do tổ chức tự quản của nhân dân tiến hành không mang tính chất quyền lực nhà nước. Xuất phát từ bản chất tự quản, tự nguyện nên hoạt động hòa giải cơ sở phải kịp thời, linh hoạt và không thể căn cứ mức độ tranh chấp để xác định thẩm quyền như cơ quan nhà nước. Thậm chí trong trường hợp Tòa án đã thụ lý và đang giải quyết vụ án thì đương sự vẫn có quyền đề nghị Tổ hòa giải cơ sở tiến hành hòa giải; nếu hòa giải thành thì nguyên đơn rút đơn khởi kiện mà không có trở ngại, ràng buộc gì về mặt pháp lý. Tùy thuộc vào khả năng và sự quyết định lựa chọn để thực hiện mà không nên bó hẹp phạm vi mức độ tranh chấp. Thực tiễn cho thấy có những tranh chấp về lợi ích có giá trị lớn nhưng không phức tạp, nguyên nhân phát sinh đơn giản mà các Tổ hòa giải có thể hòa giải thành. Ngược lại, có những tranh chấp về lợi ích có giá trị nhỏ nhưng lại rất căng thẳng, phức tạp. Mục đích hòa giải là để các bên thỏa thuận được với nhau về giải quyết tranh chấp, tuy nhiên trong trường hợp hòa giải không thành nhưng nhờ hòa giải mà giảm bớt được mức độ căng thẳng, ngăn ngừa được hành vi vi phạm pháp luật thì vai trò của hòa giải vẫn được phát huy. Do đó, không nên đặt vấn đề là lựa chọn, giao những vụ việc đơn giản cho Tổ hòa giải cơ sở để hòa giải thành, bởi quan niệm như vậy là chưa thuyết phục.<br  />Một trong những lý do để Ban soạn thảo lựa chọn quy định theo phương án thứ nhất đó là, theo quy định tại Điều 127 Hiến pháp năm 1992: <em>“Ở cơ sở, thành lập các tổ chức thích hợp của nhân dân để giải quyết những việc vi phạm pháp luật và tranh chấp nhỏ trong nhân dân theo quy định của pháp luật”.</em> Về ràng buộc trong quy định của Hiến pháp không có trở ngại lớn vì hiện nay đang nghiên cứu sửa đổi Hiến pháp 1992, nếu xét thấy phạm vi hòa giải theo phương án nào là hợp lý thì sửa đổi quy định của Hiến pháp để bảo đảm tính thống nhất về hiệu lực pháp lý.<br  />Về mặt kỹ thuật lập pháp, điều luật quy định về phạm vi hòa giải trong dự thảo Luật kết cấu theo kiểu vừa liệt kê những vụ, việc được phép hòa giải lại vừa liệt kê những vụ, việc không được hòa giải nên trùng lặp và rườm rà, khó hiểu.<br  />Từ những lý do nêu trên, cần sửa đổi lại quy định này về cả nội dung và bố cục thể hiện theo hướng loại trừ: “Việc hòa giải được tiến hành đối với các <em>mâu thuẫn, vi phạm pháp luật nhỏ và tranh chấp</em> trong nhân dân; trừ các trường hợp sau: a) Tội phạm hình sự; b) Hành vi vi phạm pháp luật bị xử lý hành chính; c) Quan hệ hôn nhân trái pháp luật và các tranh chấp phát sinh từ giao dịch trái pháp luật…<br  /><em>(Trích nguồn; daibieunhandan.vn)</em>', '', 1, 0, 1, 1, 1),
(46, 'Theo thống kê, hiện tại có khoảng gần 40 doanh nghiệp nhà nước (DNNN) và tư nhân có sở hữu trên 5% tại các ngân hàng TMCP.<br  /><br  />Hầu hết tập đoàn kinh tế nhà nước đều có các công ty tài chính. Mối quan hệ giữa ngân hàng TMCP với các tập đoàn tư nhân ngày càng trở nên phức tạp.<br  /><br  /><strong>Nhiều ngân hàng có thể được sở hữu bởi rất nhiều công ty gia đình hoặc các thành viên gia đình vốn đồng thời lãnh đạo ở các DN khác.</strong><br  /><br  />Những hệ lụy mà hình thức sở hữu chéo mang lại ít nhiều thì cũng được khá nhiều chuyên gia phân tích, mổ xẻ. Tuy nhiên, cho đến nay vẫn chưa có một đánh giá cụ thể, chi tiết và chính xác nào từ phía các cơ quan có chức năng về tình trạng này tại Việt Nam. Phải chăng bức tranh này rất khó &quot;vẽ&quot; lại?<br  />Theo ông Vũ Thành Tự Anh - Giám đốc Nghiên cứu, Chương trình giảng dạy kinh tế Fulbright, mặt trái của sở hữu chéo đã được thể hiện qua những trục trặc ngày càng rõ của ngành ngân hàng vài năm trở lại đây, trong đó nghiêm trọng nhất là các NHTM đã dùng sở hữu chéo để lách các quy định bảo đảm an toàn hoạt động do NHNN ban hành.<br  />&nbsp;<br  />Thứ nhất là quy định về vốn. Theo quy định của Nghị định 141/2006/NĐ -CP, vốn điều lệ thực góp của các ngân hàng phải đạt 1.000 tỷ đồng vào năm 2008 và 3.000 tỷ đồng vào năm 2010.<br  /><br  />Thông qua sở hữu chéo, cổ đông ngân hàng A có thể vay tiền ngân hàng B để góp vốn vào ngân hàng A, và ngược lại. Hoạt động đi vay này tạo ra tình trạng tăng vốn ảo trong các ngân hàng.<br  /><br  />Thứ hai là giới hạn tín dụng theo quy định hiện hành đã bị sở hữu chéo làm vô hiệu hoá.<br  /><br  />Thứ ba là các quy định về phân loại nợ và trích lập dự phòng rủi ro của NHNN có thể bị làm sai lệch tinh thần bởi sở hữu chéo.<br  /><br  />Khi khách hàng không trả được nợ, thay vì xếp khoản vay thành nợ xấu và trích dự phòng rủi ro theo quy định, ngân hàng A có thể cho vay đảo nợ...<br  /><br  />Ông Võ Trí Thành - Phó Viện trưởng Viện Nghiên cứu quản lý kinh tế Trung ương (CIEM) cho rằng, sở hữu chéo là vấn đề khá bình thường trên thế giới, nhưng luật của các nước đều yêu cầu minh bạch để thị trường và cổ đông giám sát.<br  /><br  />Còn ở Việt Nam cũng đã có những quy định hạn chế sở hữu chéo và yêu cầu công khai việc này, nhưng lại bỏ ngỏ khâu giám sát và chế tài, dẫn đến việc sở hữu chéo ngày càng trở nên nghiêm trọng, làm lũng đoạn thị trường nhiều lĩnh vực trọng yếu của nền kinh tế, nhất là lĩnh vực tài chính - ngân hàng.<br  /><br  />Trong khi đó, Luật Các tổ chức tín dụng được thông qua, một trong những sai lầm &quot;chết người&quot; là xóa &quot;bức tường lửa&quot; của ngân hàng đầu tư và ngân hàng thương mại. Nhiều quy định trong Luật vẫn chưa chặt chẽ và rõ ràng phân biệt giữa ngân hàng đầu tư và ngân hàng thương mại truyền thống.<br  /><br  />&quot;Chính vì thế mới có sự &quot;lập lờ&quot; trong đầu tư và sở hữu giữa các cá nhân với ngân hàng, giữa ngân hàng này với ngân hàng kia. Việc lập lại &quot;bức tường lửa&quot; (quy định rạch ròi về hoạt động của ngân hàng đầu tư với ngân hàng thương mại) sẽ vô cùng cần thiết trong bối cảnh hiện nay&quot; - ông Thành nói.<br  /><br  />Ông Trương Đình Tuyển - Thành viên hội đồng Tư vấn tiền tệ Quốc gia thì bức xúc nói tại Diễn đàn kinh tế Việt Nam năm 2012 tổ chức vừa qua tại Hà Nội rằng: Đã là ngân hàng thì nhất quyết không được đầu tư vào bất kỳ một lĩnh vực kinh doanh nào khác. Dù đó chỉ là một đồng.<br  /><br  />Theo ông Tuyển ngân hàng là một lĩnh vực hoạt động có lợi nhuận cao nhưng lại khá nhạy cảm và mỗi biến động của nó đều có ảnh hưởng lớn đến nền kinh tế nói chung.<br  /><br  />Do đó, nếu cho phép các ngân hàng được phép đầu tư vào một số lĩnh vực khác (phi ngân hàng) cho dù luật có chặt đến đâu thì cá nhân hay tổ chức đó đều có &quot;cửa&quot; để lách.<br  />&nbsp;<br  />&nbsp;<br  /><em>(Theo TTXVN)</em>', '', 1, 0, 1, 1, 1),
(47, '<span class="sb_messagebody">Một anh chàng ngồi một mình trong góc quán rượu, uống tì tì suốt ba giờ liền. Đột nhiên, anh ta nhảy dựng lên và gào to cho cả quán cùng nghe:<br  />- &quot; Tất cả bọn luật sư đều là đồ chăn lừa&quot;.<br  />Anh ta ngồi xuống và định dốc hết chỗ rượu còn lại thì một anh chàng to cao vạm vỡ tiến đến gần rồi chẳng nói chẳng rằng đấm cho anh ta một trận túi bụi cho đến khi anh ta chỉ còn là một đống bùi nhùi. Một người phục vụ liền hỏi anh chàng cao to :<br  />- Tôi đoán ông là một luật sư?<br  />- Không - anh ta trả lời<br  />- Tôi là một người chăn lừa.</span>', '', 1, 0, 1, 1, 1),
(48, '<span class="sb_messagebody">Một luật sư đang biện hộ cho một người bị buộc tội ăn trộm. Luật sư nói với tòa... Kính thưa ngài tôi xin trình bày rằng thân chủ của tôi không hề đột nhập vào căn nhà đó. Anh ta thấy cửa sổ phòng khách mở trống và chỉ thọc cánh tay phải vào để lấy ra vài món đồ vặt vãnh. Đấy cánh tay thân chủ tôi đâu phải là chính anh ta. Tôi không hiểu sao ngài có thể trừng phạt cả một con người vì một sai phạm chỉ do một phần tứ chi của người ấy thực hiện.<br  /><br  />Quan toà cân nhắc lý luận này một hồi lâu rồi trả lời:<br  /><br  />- Lý luận của anh trình bày rất khéo. Xét theo lý lẽ đó tôi tuyên án cánh tay của bị cáo một năm tù giam, có đi theo cánh tay hay không là tùy ở bị cáo.<br  /><br  />Nghe quan toà phán xong, bị cáo mỉm cười và với sự giúp đỡ của luật sư, anh ta tháo rời cánh tay giả ra đặt nó lên trên ghế và ra về...</span>', '', 1, 0, 1, 1, 1),
(49, 'Một số bài báo trong vài tháng qua nêu lên những thực trạng về khả năng cung ứng USD của hệ thống thị trường chính thức thấp hơn nhu cầu về USD của người dân và doanh nghiệp. Những bài báo nêu ra hai thực trạng, thứ nhất, là người dân khó mua USD tại ngân hàng cho những mục đích như khám chữa bệnh, đi du học. Thứ hai, một số doanh nghiệp nhỏ cũng phản ánh trên báo chí là họ khó mua USD từ ngân hàng để phục vụ hoạt động kinh doanh vì không nằm trong diện ưu tiên. Một tình huống khác được phản ánh là sau khi thị trường tự do ngừng hoạt động, các doanh nghiệp có nhu cầu USD phải mua USD thông qua việc nhờ ngân hàng giới thiệu cho người có ngoại tệ với tỷ giá cao hơn hẳn tỷ giá niêm yết.<br  />&nbsp;<br  />Những tình huống kể trên chỉ ra rằng sự tồn tại của những kênh thị trường phi chính thức (nếu không còn thị trường tự do thì cũng còn thị trường dạng &quot;bắc cầu&quot;) xuất phát từ thực tế là nguồn USD cung ứng từ thị trường chính thức tại mức tỷ giá niêm yết, không đáp ứng được yêu cầu của tất cả người dân trong xã hội. Khi có nhu cầu mua USD mà không thể mua ở ngân hàng thì tất yếu sẽ xuất hiện thị trường phi chính thức đáp ứng yêu cầu này. Dù có nỗ lực dẹp bỏ thị trường tự do thì làm sao đảm bảo sẽ không xuất hiện những hình thức biến tướng khác? Khi đó, nó sẽ chỉ làm cho giá USD &quot;phi chính thức&quot; càng bị đẩy cao hơn mức tỷ giá chính thức vì sự khan hiếm của nguồn cung ứng dịch vụ này.<br  />Một trở ngại khác trong việc dẹp bỏ kênh thị trường tự do, là liệu các biện pháp chế tài hiện hành có thể tạo điều kiện để thật sự dẹp bỏ loại thị trường này? Theo phản ánh của phó giám đốc ngân hàng Nhà nước chi nhánh TP.HCM, có những cửa hàng USD tự do tại TP.HCM trước đó bị phạt tới gần 60 triệu đồng, nhưng giờ vẫn mua bán USD gần như công khai. Liệu mức phạt 60 triệu đồng đã đủ có thể răn đe để người kinh doanh mua bán USD tự do không &quot;phá rào&quot;?<br  />Sự tồn tại của thị trường phi chính thức vì vậy được tạo ra vì hai nguyên nhân cơ bản: một là nhu cầu chính đáng của người dân về USD không được đáp ứng thông qua kênh thị trường chính thức tại tỷ giá niêm yết hiện tại, và hai là các biện pháp chế tài đối với thị trường phi chính thức còn yếu. Nhưng nếu tập trung sửa chữa cái thứ hai, trong khi cái thứ nhất chưa thể điều tiết thì tình hình có thể còn tệ hơn. Chế tài càng mạnh, nguồn cung USD tự do càng khan hiếm mà nguồn cung chính thức không đáp ứng nổi khiến người dân và doanh nghiệp chuyển sang găm giữ và tích luỹ USD thì tình hình diễn biến tỷ giá tự do có thể sẽ càng tệ hại hơn.<br  />Thực trạng hiện nay phản ánh rằng, dù là thông qua kênh thị trường tự do hay kênh thị trường &quot;bắc cầu&quot; (tức là có sự tham gia &quot;giới thiệu&quot; của ngân hàng) thì nguồn cung USD chỉ đáp ứng nhu cầu ở tỷ giá cao hơn tỷ giá niêm yết. Phải chăng việc ngân hàng phải đứng ra làm trung gian &quot;bắc cầu&quot; như thế là vì họ không thể mua được USD theo tỷ giá niêm yết từ phía người có USD?<br  />&nbsp;<br  />&nbsp;<br  />Căn bệnh nhập siêu mãn tính của Việt Nam, sự suy yếu kinh niên của đồng VND, thị trường sản phẩm phòng ngừa rủi ro tỷ giá kém phát triển và nhu cầu tích trữ USD của người dân tạo ra kỳ vọng &quot;đồng USD sẽ tăng giá và bán bây giờ thì mai mốt không biết có mua lại được không&quot;. Mà nếu người có USD lo ngại rằng sau khi bán USD cho ngân hàng ở giá niêm yết rồi mà sau này khó mua lại, hoặc phải mua lại ở giá cao hơn nhiều so với giá niêm yết hiện tại thì họ đương nhiên sẽ muốn tiếp tục nắm giữ USD và chỉ bán khi &quot;được giá&quot;. Người có USD có tâm lý găm giữ &quot;chờ USD lên&quot; như vậy, thì dù có cấu trúc thị trường chính thức như thế nào, các đại lý mua bán USD chính thức hoạt động ra sao đi nữa, mà họ không mua được USD từ doanh nghiệp hay người dân với tỷ giá niêm yết thì lấy USD đâu ra mà bán.<br  />Nói cách khác, cái gút khiến thị trường chính thức không thể &quot;cạnh tranh&quot; thu hút đủ USD để cung ứng cho người dân là vì tỷ giá niêm yết chính thức bị kiềm chế thiếu linh hoạt so với tỷ giá tự do. Điều này liên quan đến cách điều hành chính sách tỷ giá hiện tại mà nhiều chuyên gia trong và ngoài nước đã có phân tích và nằm ngoài khuôn khổ bài viết này.<br  />Nhưng có một điều cần nhận thấy là nếu như Chính phủ muốn điều hành một tỷ giá chính thức như thế nào, thì tất yếu sẽ đi kèm với sản phẩm phụ như thế ấy. Tỷ giá chính thức biến động nhiều quá hay đồng tiền phá giá nhanh quá sẽ có những độ sốc nhất định. Và nếu Chính phủ không mong muốn để tỷ giá chính thức tạo ra những cú sốc như vậy thì tự nhiên sẽ có một thị trường tự do tồn tại song song với thị trường chính thức để đáp ứng nhu cầu USD trong xã hội ở một mức tỷ giá khác. Khi nhu cầu USD tăng mạnh (vì nhiều lý do, như nhu cầu găm giữ của người dân, nhu cầu USD nhập khẩu của doanh nghiệp chẳng hạn) mà sự biến động của tỷ giá chính thức không theo kịp và không phản ánh được quan hệ cung cầu thật sự thì tự nhiên người ta phải tìm đến thị trường phi chính thức.<br  />Mỗi mục tiêu chính sách sẽ phải trả một cái giá, và khó đòi hỏi một chính sách đạt được tất cả các mục tiêu. Cái gì cũng có mặt trái của nó. Sự tồn tại của hai loại tỷ giá trong nền kinh tế, hai loại thị trường ngoại hối chính thức và phi chính thức là sản phẩm phụ của chính sách tỷ giá hiện tại. Để xoá bỏ triệt để mặt trái này, về gốc rễ, phải là điều chỉnh chính sách tỷ giá cho linh hoạt hơn, khiến tỷ giá chính thức biến động nhiều hơn đủ để ngân hàng và các đại lý có thể đưa ra một cái giá cạnh tranh thu hút USD về thị trường chính thức. Nếu không muốn điều chỉnh chính sách tỷ giá, thì tốn sức người sức của tìm cách xoá bỏ sự tồn tại của thị trường ngoại hối phi chính thức có thể là một việc làm không hiệu quả mà nhiều người có thể đã nhìn thấy trước', '', 1, 0, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_bodytext`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_bodytext` (
  `id` int(11) unsigned NOT NULL,
  `bodytext` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv3_vi_news_bodytext`
--

INSERT INTO `nv3_vi_news_bodytext` (`id`, `bodytext`) VALUES
(19, 'Đối tượng bảo hộ bản quyền tác giả bao gồm: các tác phẩm văn học, khoa học, sách giáo khoa, giáo trình, chương trình máy tính, sưu tập dữ liệu và các tác phẩm khác được thể hiện dưới dạng chữ viết hoặc ký tự khác; các bài giảng, bài phát biểu và bài nói khác; tác phẩm báo chí; tác phẩm âm nhạc; tác phẩm sân khấu; tác phẩm điện ảnh và các tác phẩm được tạo ra theo phương pháp tương tự; tác phẩm tạo hình, mỹ thuật ứng dụng; tác phẩm nhiếp ảnh; tác phẩm kiến trúc; các bản họa đồ, sơ đồ, bản đồ, bản vẽ liên quan đến địa hình, công trình khoa học; tác phẩm văn học, nghệ thuật dân gian…Ý tưởng được thể hiện tác phẩm không cần phải đảm bảo tính mới, tuy nhiên, tác phẩm phải là sự sáng tạo nguyên gốc của tác giả. Việc bảo hộ bản quyền tác giả không phụ thuộc vào chất lượng hoặc giá trị của tác phẩm thậm chí cả mục đích mà tác phẩm hướng tới và việc sử dụng tác phẩm như thế nào. Tác giả không có nghĩa vụ chứng minh quyền tác giả, quyền liên quan thuộc về mình khi có tranh chấp trừ trường hợp có chứng cứ ngược lại.Tư vấn Luật Brandco là một tổ chức tư vấn, dịch vụ quyền tác giả, quyền liên quan có chức năng tư vấn và đại diện cho tác giả, chủ sở hữu tác phẩm và người có quyền liên quan thực hiện các dịch vụ sau:1. Tra cứu thông tin và tình trạng pháp lý các tác phẩm viết; bài giảng; bài phát biểu; tác phẩm điện ảnh; tác phẩm sẩn khấu; tác phẩm âm nhạc; tác phẩm báo chí; tác phẩm kiến trúc; tác phẩm tạo hình, mỹ thuật ứng dụng; Công trình khoa học, sách giáo khao, giáo trình; Các bức họa đồ, bản vẽ sơ đồ, bản đồ; Tác phẩm dịch, phóng tác, cải biên, chuyển thể, biên soạn, chú giải, tuyến tập, hợp tuyển…2. Nộp đơn đăng ký bản quyển tác giả cho tác giả, đồng tác giả, cho chủ sở hữu tác phẩm;3. Đại diện cho khách hàng đàm phán tiến hành việc chuyển nhượng, cho phép sử dụng, chuyển thể, sao chép tác phẩm …4. Đại diện cho khách hàng kết hợp với cơ quan Nhà nước có thẩm quyền tiến hành các thủ tục hành chính; Tham gia tố tụng Dân sự, Hình sự tại Toà án các cấp có thẩm quyền nhằm bảo vệ các đối tượng đã đăng ký, chống lại các hành vi xâm hại quyền đối với tác phẩm và tác giả;Mọi thông tin thắc mắc cần trao đổi liên quan đến các vấn đề trên, xin Quý khách hàng vui lòng liên lạc với Tư vấn Luật Brandco để được hướng dẫn chi tiết. '),
(18, ' Chặng đường đổi mới hơn 20 năm qua của Việt Nam thực tế là quá trình cơ cấu lại nền kinh tế và đã mạng lại thành quả tốt đẹp. Sau 20 năm, Việt Nam lại đứng trước yêu cầu tái cấu trúc để tiếp tục lộ trình đổi mới của đất nước, nâng những thành quả đã đạt được lên tầm cao hơn trong môi trường toàn cầu hóa và những biến đổi của thế giới thời hậu khủng hoảng. Thời điểm nhìn lại mình Trong một thời gian dài, Việt Nam được ca ngợi là một mẫu hình thành công, một ngôi sao đang lên và là điểm đến lý tưởng của các nhà đầu tư. Vào những năm trước 2008, điều đó đã phần nào thể hiện trên thực tế. Nhưng từ đó trở về sau, thu hút đầu tư bắt đầu khó khăn và năm 2011 đã đánh dấu một sự sụt giảm đáng kể. Đã có nhiều lý giải cho hiện tượng này, hầu hết đều cho rằng nó xuất phát từ khó khăn của chính các nhà đầu tư và những nền kinh tế của các quốc gia đó đang bất ổn. Lý giải đó có phần đúng. Tuy nhiên, theo nhiều chuyên gia về đầu tư nước ngoài thì cắt giảm hay chuyển hướng của các nhà đầu tư nước ngoài cũng chính là biểu hiện của qua trình tái cơ cấu mà các tập đoàn nước ngoài thực hiện trên phạm vi toàn cầu. Qua khó khăn, tất cả các tập đoàn lớn đều buộc phải tính toán lại các chiến lược và quyết định đầu tư của mình. Và nguyên lý đơn giản nhất là họ sẽ chọn những địa điểm đầu tư cạnh tranh nhất và hiệu quả nhất để triển khai các dự án. Các đầu tư trên toàn cầu buộc phải nhìn nhận lại mình, tái cơ cấu để đứng vững và phát triển trước khủng hoảng. Họ sẵn sàng từ bỏ những dự án đã dày công theo đuổi nhưng nay không còn phù hợp trong chiến lược phát triển mới. Và Việt Nam đang nằm trong tác động của xu hướng đó. Thực tế của quốc tế và diễn biến thu hút đầu tư buộc chúng ta phải nhìn lại mình để có những sự thay đổi. Câu chuyện khủng hoảng từ 2008 tác động vào Việt Nam cho chúng ta một nhận thức mới. Khủng hoảng thời toàn cầu hóa vượt ra ngoài khuôn khổ quốc gia và tất nhiên, tái cấu trúc cũng phải đặt trong không gian của toàn cầu hóa. Nhưng đến năm 2011, thì Việt Nam lại có thêm một thách thức nữa đó những khó khăn và bất ổn nội tại ngày càng bộc lộ. Để tránh những nguy cơ, Chính phủ đã buộc phải chuyển hướng trong chính sách từ tăng trưởng sang ổn định. Và như một lộ trình tất yếu, vấn đề tái cơ cấu đã một lần nữa được đặt ra và nhận được sự đồng thuận cao. Nó không chỉ là những đề xuất như những năm 2008 mà đã trở thành nghị quyết của Đảng và cụ thể hóa bằng chính sách của Chính phủ và hành động của mỗi thực thể kinh tế. Một điều đã được thừa nhận là khủng hoảng là hậu quả của mất bằng trong cấu trúc kinh tế nhưng đây cũng là thời điểm bắt buộc tính đến chuyện tái cấu trúc. Vì thế, bên cạnh những hậu quả nặng nề thì khủng hoảng cũng được nhắc đến là một cơ hội. Lịch sử thế giới đã có nhiều cuộc khủng hoảng kinh tế lớn và cũng ghi nhận, sau khủng hoảng các nước sẽ tái cơ cấu để phát triển lên mức cao hơn. Việt Nam đã tăng trưởng cao liên tục trong 20 năm qua, tạo ra một Việt Nammới được cả thế giới thừa nhận. Nhưng trong hơn 20 năm qua, mô hình của Việt Nam vẫn chủ yếu tăng trưởng theo chiều rộng bằng cách tăng vốn đầu tư, thâm dụng lớn tài nguyên và lao động giản đơn. Trong một giai đoạn đầu của quá trình phát triển, với một thị trường nội địa lớn, xuất khẩu rộng mở, tài nguyên sẵn có và chấp nhận bán sức lao động giá rẻ... với sự cộng hưởng của tài chính và kỹ thuật mà "mở cửa" thu hút đầu tư mang lại, Việt Nam dễ dàng đạt được sự tăng trưởng vượt bậc. Tuy nhiên, trong khi chúng ta đang say mê với những con số tăng trưởng và thậm chí, không ít người vẫn muốn tiếp tục mô hình càng đào tài nguyên, thêm nhiều vốn thì càng phát triển mạnh. Và điều đó khiến chúng ta đã vấp phải những thách thức mới từ quá trình phát triển của chính mình. Đáng lẽ đi cùng với quá trình đầu tư và thu hút vốn cần phải gia tăng công nghệ, nâng cao năng suất để tạo ra giá trị gia tăng lớn thì chúng ta lại bơm tiền ra nhiều để gánh lấy hậu họa lạm phát và những bất ổn của nền kinh tế. Sự lệnh hướng đó khiến hiệu quả của nền kinh tế ngày càng thấp nhưng bất ổn ngày càng lớn. Không thể phủ nhận mô hình tăng trưởng hiện nay đã đưa nền kinh tế thoát khỏi kinh tế tập trung, nông nghiệp lạc hậu. Nhưng sau 20 năm, thực lực và vị thế đất nước đã đổi khác. Chúng ta mạnh hơn những cũng đối mặt với canh tranh quốc tế gay gắt hơn. Vì thế, không thể chấp nhận mãi áp dụng một mô hình cũ mà phải tỉnh táo nhận ra rằng mô hình tăng trưởng này đã không còn phù hợp. Điều đó buộc chúng ta phải tính đến tái cơ cấu, đưa đất nước sang một giai đoạn phát triển mới Hơn hai mươi năm trước, chúng ta đã thực hiện cấu trúc lại nền kinh tế để tạo nên kỳ tích đổi mới. Bây giờ, đổi mới vẫn được tiếp tục nhưng cần được đặt trên một lộ trình mới. Tái cấu trúc nền kinh tế chính là tiếp tục thúc đẩy tiến trình đổi mới, để đạt được thành quả cao và hưởng lợi nhiều hơn từ đổi mới. Nhóm lợi ích và thách thức tái cơ cấu Một mô hình tăng trường có lợi ích trước mắt nhưng có thể gây hại về lâu dài. Mô hình tăng trưởng của Việt Nam, không chỉ đến khủng hoảng mới bộc lộ nguy cơ, mà những bấp cập trong quản trị, phân bổ nguồn lực... đã được cảnh báo từ lâu. Vì thế, điều quan trọng nhất của tái cấu trúc là làm sao phân bố và quản lý các nguồn lực một cách hợp lý. Theo đó, cần xúc tiến đột phá chiến lược và tái cơ cấu nền kinh tế, đổi mới mô hình tăng trưởng theo hướng nâng cao hiệu quả và khả năng cạnh tranh. Hoàn thiện cơ chế huy động các nguồn lực ưu tiên cho các lĩnh vực, dự án có hiệu tác động lan tỏa cao, tạo tiền đề tái cơ cấu nền kinh tế thay vì sự phân phối chủ quan và kém hiệu quả của thời gian qua. Nếu như từ trước đến nay, chúng ta phân bổ nguồn lực hường tập trung vào những khu vực DN nhà nước, hay những chương trình đầu tư duy ý chí mà quên đi những tính toán hiệu quả. Vì thế, điều cần thiết là một cơ chế mới để phân phối và điều tiết nguồn lực một cách công bàng và hiệu quả. Theo đó, một thị trường đồng bộ sẽ là hệ thống phân phối nguồn lực công bằng và minh bạch. Một hệ thống thị trường đồng bộ với các yếu tố canh tranh lành mạnh thì mọi quyết định đầu tư của DN hay nhà nước đều mang lại hiệu quả vì phải dựa trên những điều kiện đã được phân tích, so sánh lợi thế và hiệu quả không chỉ trong nước mà cả với thế giới. Với yêu cầu đó, nhiệm vụ của Nhà nước phải nâng cao khả năng quản trị là tạo ra môi trường canh tranh, lành mạnh, có định hướng tốt... để từ đó có sự công bằng và cạnh tranh trong tiếp cận nguồn lực. Đảm bảo những khu vực hiệu quả nhất sẽ được tiếp cận nguồn lực một cách tốt nhất. Tuy nhiên, sự thay đổi này sẽ kéo theo những ảnh hưởng quyền lợi của nhiều nhóm lợi ích vốn đã được hưởng lợi nhiều từ nguồn lực sẵn có, được phân bổ một cách dễ dãi và kiểm soát kém dẫn đến hiệu quả thấp nhưng vẫn tồn tại trong sự biện minh rằng đó là sự cần thiết tất yếu. Và tất nhiên, những người hưởng lợi sẽ không dễ dàng từ bỏ. Trong khi ủng hộ quyết tâm tái cơ cấu của chính phủ nhưng nhiều chuyên gia cũng không dấu được lo ngại về những cản trở từ vấn đề lợi ích nhóm. Một trong những ngành đã thực thi những bước đi tái cơ cấu đầu tiên là ngân hàng. Tuy nhiên, Thống đốc Ngân hàng Nhà nước đã cho rằng, việc tái cấu trúc, lợi ích nhóm sẽ nổi lên rất nhiều, nhưng phải lấy lợi ích quốc gia làm trọng. Điều đó đòi hỏi những hành động kiên quyết và mạnh mẽ thể hiện quyết tâm, bản lĩnh, sáng tạo trong một lộ trình tái cơ cấu còn kéo dài. Tuy nhiên, chúng ta có niềm tin vì thực tế phát triển của Việt Nam đã không ít lần chứng minh điều đó. http://vef.vn/2012-01-19-tai-co-cau-sang-tao-de-tiep-tuc-doi-moi Mọi thông tin thắc mắc cần trao đổi liên quan đến các vấn đề trên, xin Quý khách hàng vui lòng liên lạc với http://brandco.vn/service-view-1394/service-view-872/service-view-871/service-view-858/ Tư vấn Luật Brandco để được hướng dẫn chi tiết.'),
(17, 'Mặc dù chưa có quy chế pháp lý để thành lập các tập đoàn kinh tế tư nhân song thực tế, xu thế thành lập hệ thống http://brandco.vn/service-view-918/?do=service&mod=category&show=search&kw=t%E1%BA%ADp%20%C4%91o%C3%A0n doạnh nghiệp theo mô hình tập đoàn kinh tế đang diễn ra một cách sôi động ở nước ta và mang lại hiệu quả rất lớn. Những cái tên như http://brandco.vn/service-view-918/?do=service&mod=category&show=search&kw=t%E1%BA%ADp%20%C4%91o%C3%A0n Tập đoàn kinh tế HIPT, Tập đoàn Thái Tuấn, Tập đoàn Việt Á, Tập đoàn Mai Linh, Tập đoàn Hòa Phát… bắt đầu được biết đến một cách thuyết phục và ấn tượng. Với tư cách là nhà tư vấn cho hơn 3000 lượt doanh nghiệp tại Việt nam, Công ty luật Brandco xin chia sẻ với Quý khách hàng một số vấn đề cơ bản liên quan đến việc thành lập và quản lý điều hành một tổ hợp công ty theo mô hình http://brandco.vn/service-view-918/?do=service&mod=category&show=search&kw=t%E1%BA%ADp%20%C4%91o%C3%A0n Tập đoàn kinh tế: I. Những khái niệm cơ bản về tập đoàn kinh tế:1. http://brandco.vn/service-view-918/?do=service&mod=category&show=search&kw=t%E1%BA%ADp%20%C4%91o%C3%A0n Tập đoàn kinh tế bao gồm nhóm các http://brandco.vn/service-category-172/thanh-lap-doanh-nghiep/ Công ty có tư cách pháp nhân độc lập, được hình thành trên cơ sở tập hợp, liên kết thông qua đầu tư, góp vốn, sáp nhập, mua lại, tổ chức lại hoặc các hình thức liên kết khác; gắn bó lâu dài với nhau về lợi ích kinh tế, công nghệ, thị trường và các dịch vụ kinh doanh khác tạo thành tổ hợp kinh doanh có từ hai cấp công ty trở lên dưới hình thức http://brandco.vn/service-view-918/service-category-172/thanh-lap-doanh-nghiep/ Công ty mẹ - http://brandco.vn/service-view-918/service-category-172/thanh-lap-doanh-nghiep/ Công ty con.2. Tập đoàn kinh tế không có tư cách pháp nhân, không phải đăng ký kinh doanh theo quy định của Luật Doanh nghiệp. Việc tổ chức hoạt động của tập đoàn do các Công ty thành lập tập đoàn tự thỏa thuận quyết định.3. Công ty mẹ được tổ chức dưới hình thức Công ty cổ phần hoặc Công ty trách nhiệm hữu hạn, đáp ứng điều kiện nêu tại khoản 15 Điều 4 của Luật Doanh nghiệp. http://brandco.vn/service-view-918/service-category-172/thanh-lap-doanh-nghiep/ Công ty con được tổ chức dưới hình thức Công ty cổ phần hoặc Công ty trách nhiệm hữu hạn theo quy định của Luật Doanh nghiệp hoặc của pháp Luật liên quan. http://brandco.vn/service-view-918/service-category-172/thanh-lap-doanh-nghiep/ Công ty mẹ, Công ty con và các http://brandco.vn/service-view-918/service-category-172/thanh-lap-doanh-nghiep/ Công ty khác hợp thành tập đoàn kinh tế có các quyền, nghĩa vụ, cơ cấu tổ chức quản lý và hoạt động phù hợp với hình thức tổ chức Tập đoàn kinh tế theo quy định của Luật doanh nghiệp, Pháp luật liên quan và Điều lệ Tập đoàn kinh tế.4. Cụm từ "tập đoàn" có thể sử dụng như một thành tố phụ trợ cấu thành tên riêng của http://brandco.vn/service-view-918/service-category-172/thanh-lap-doanh-nghiep/ Công ty mẹ, phù hợp với các quy định từ Điều 31 đến Điều 34 của Luật Doanh nghiệp về đặt tên Doanh nghiệp.II. Dịch vụ tư vấn của Công ty luật Brandco: Với tư cách của một nhà tư vấn tận tâm của Quý khách hàng, Công ty luật Brandco sẽ có các hỗ trợ quan trọng dành cho Quý khách hàng, cụ thể: http://brandco.vn/service-view-918/service-view-6/service-list/ Tư vấn các vấn đề pháp lý liên quan đến quá trình thành lập, hoạt động, quản lý http://brandco.vn/service-view-918/?do=service&mod=category&show=search&kw=t%E1%BA%ADp%20%C4%91o%C3%A0n Tập đoàn kinh tế; http://brandco.vn/service-view-918/service-view-6/service-list/ Tư vấn xây dựng quy chế tổ chức, quản lý và hoạt động của http://brandco.vn/service-view-918/?do=service&mod=category&show=search&kw=t%E1%BA%ADp%20%C4%91o%C3%A0n Tập đoàn kinh tế; http://brandco.vn/service-view-918/service-view-6/service-list/ Tư vấn cơ cấu nhân sự trong http://brandco.vn/service-view-918/?do=service&mod=category&show=search&kw=t%E1%BA%ADp%20%C4%91o%C3%A0n Tập đoàn kinh tế; http://brandco.vn/service-view-918/service-view-6/service-list/ Tư vấn về việc thiết lập văn bản ràng buộc giữa các công ty thành viên trong Thttp://brandco.vn/service-view-918/?do=service&mod=category&show=search&kw=t%E1%BA%ADp%20%C4%91o%C3%A0n Tập đoàn kinh tế; http://brandco.vn/service-view-918/service-view-6/service-list/ Tư vấn cách phân chia lợi nhuận của các công ty thành viên; http://brandco.vn/service-view-918/service-view-6/service-list/ Tư vấn về vốn đầu tư, vốn pháp định, vốn điều lệ… của tập đoàn và các công ty thành viên. http://brandco.vn/service-view-918/service-view-6/service-list/ Tư vấn cách đặt tên http://brandco.vn/?do=service&mod=category&show=search&kw=t%E1%BA%ADp%20%C4%91o%C3%A0n Tập đoàn kinh tế, tên viết tắt phù hợp với nhu cầu và yêu cầu của hoạt động kinh doanh; http://brandco.vn/service-view-918/service-view-6/service-list/ Tư vấn chi tiết cho http://brandco.vn/service-view-918/?do=service&mod=category&show=search&kw=t%E1%BA%ADp%20%C4%91o%C3%A0n Tập đoàn kinh tế các vấn đề về thuế, các nghĩa vụ về tài chính sau khi thành lập và trong quá trình hoạt động sản xuất kinh doanh ; http://brandco.vn/service-view-918/service-view-6/service-list/ Tư vấn về cơ cấu nhân sự, quyền hạn, nghĩa vụ của các công ty thành viên trong tập đoàn kinh tế được xây dựng; Note: Đặc biệt các luật sư của công ty luật Brandco đã trực tiếp tham gia đàm pháp và tư vấn xây dựng thành công quy chế tổ chức, quản lý và hoạt động của nhiều tổ hợp doanh nghiệp theo mô hình http://brandco.vn/service-view-918/?do=service&mod=category&show=search&kw=t%E1%BA%ADp%20%C4%91o%C3%A0n Tập đoàn kinh tế taị Việt nam;Mọi thông tin thắc mắc cần trao đổi liên quan đến các vấn đề trên, xin Quý khách hàng vui lòng liên lạc với Công ty Luật Brandco để được hướng dẫn chi tiết.'),
(16, 'Theo Khoản 1, Ðiều 50 Luật Ðầu tư thì nhà đầu tư nước ngoài lần đầu tiên đầu tư vào Việt Nam phải có dự án đầu tư và làm thủ tục đăng ký đầu tư hoặc thẩm tra dự án đầu tư tại cơ quan Nhà nước quản lý đầu tư để được cấp Giấy chứng nhận đầu tư. Giấy chứng nhận đầu tư đồng thời là Giấy chứng nhận đăng ký kinh doanh. 1. Các văn bản pháp luật tham khảo:- Biểu Cam kết dịch vụ WTO của Việt Nam.- Quyết định 10/2007/QÐ-BTM của Bộ Thương Mại ngày 21/05/2007 về Quyết định công bố lộ trình thực hiện hoạt động mua bán hàng hóa và các hoạt động liên quan trực tiếp đến mua bán hàng hóa.- Thông tư 09/2007/TT-BTM của Bộ Thương Mại ngày 17/07/2007 về Hướng dẫn thi hành Nghị định số 23/2007/NÐ-CP ngày 12 tháng 02 năm 2007 quy định chi tiết Luật Thương mại về hoạt động mua bán hàng hóa và các hoạt động liên quan trực tiếp đến mua bán hàng hóa của doanh nghiệp có vốn đầu tư nước ngoài tại Việt Nam.2. Hồ sơ xin cấp giấy phép thành lập Công ty:a. Văn bản đề nghị cấp Giấy chứng nhận đầu tư - theo mẫu I-3 của Quyết định 1088/2006/QÐ-BKH.b. Báo cáo năng lực tài chính của nhà đầu tư (do nhà đầu tư lập và chịu trách nhiệm).c. Giải trình khả năng đáp ứng điều kiện mà dự án đầu tư phải đáp ứng theo quy định của pháp luật.d. Hồ sơ pháp lý liên quan đến địa chỉ trụ sở chính và địa điểm thực hiện dự án (Nhà đầu tư chỉ mang đến để chuyên viên tiếp nhận hồ sơ xem và đối chiếu).e. Dự thảo Ðiều lệ Công ty tương ứng với từng loại hình doanh nghiệp (Công ty TNHH 2 thành viên trở lên, Công ty Cổ phần) (được người đại diện theo pháp luật, các thành viên hoặc người đại diện theo uỷ quyền ký từng trang). Danh sách thành viên sáng lập/ cổ đông sáng lập.f. Văn bản xác nhận tư cách pháp lý của các thành viên sáng lập: Ðối với thành viên sáng lập là pháp nhân: Bản sao hợp lệ có hợp pháp hóa lãnh sự (không quá 3 tháng trước ngày nộp hồ sơ) của một trong các loại giấy tờ: Quyết định thành lập, Giấy chứng nhận Ðăng ký kinh doanh hoặc Giấy tờ tương đương khác, Ðiều lệ (đối với pháp nhân trong nước). Ðối với thành viên sáng lập là cá nhân: Bản sao hợp lệ có hợp pháp hóa lãnh sự (bản sao có công chứng không quá 3 tháng trước ngày nộp hồ sơ) của một trong các giấy tờ: Giấy chứng minh nhân dân, Hộ chiếu hoặc giấy tờ chứng thực cá nhân hợp pháp còn hiệu lực. g. Văn bản uỷ quyền của Chủ sở hữu cho người được uỷ quyền đối với trường hợp chủ sở hữu công ty là tổ chức và Bản sao hợp lệ (bản sao có công chứng) một trong các giấy tờ chứng thực cá nhân của người đại diện theo uỷ quyền. h. Hợp đồng liên doanh đối với hình thức đầu tư thành lập tổ chức kinh tế liên doanh giữa nhà đầu tư trong nước và nhà đầu tư nước ngoài. (Tham khảo Ðiều 54, 55 Nghị định 108/2006/NÐ-CP ngày 22/09/2006). i. Trường hợp dự án đầu tư liên doanh có sử dụng vốn Nhà nước thì phải có văn bản chấp thuận việc sử dụng vốn Nhà nước để đầu tư của cơ quan có thẩm quyền. j. Bản sao hợp lệ chứng chỉ hành nghề của Giám đốc (Tổng Giám đốc) và các cá nhân khác quy định tại K.13 Ðiều 4 Luật Doanh nghiệp. 3. Hồ sơ nộp tại :a. Sở Kế hoạch và Ðầu tư phòng doanh nghiệp nước ngoài Phòng Doanh nghiệp nước ngoàib. Số lượng hồ sơ nộp: 8 bộ (trong đó có 1 bộ gốc) Mọi vấn đề còn thắc mắc liên quan đến thủ tục nói trên, xin Quý khách hàng vui lòng liên lạc với công ty chúng tôi để được cung cấp http://brandco.vn/?do=service&mod=category&show=search&kw=ch%E1%BB%A9ng%20nh%E1%BA%ADn%20%C4%91%E1%BA%A7u%20t%C6%B0 dịch vụ tư vấn thành lập công ty có vốn đầu tư nước ngoài tại Việt nam.'),
(14, ' Là một nhà tư vấn chuyên nghiệp trong lĩnh vực tư vấn đầu tư, Công ty Luật Brandco hiện đang cung cấp nhiều các dịch vụ tư vấn đầu tư hỗ trợ Quý khách hàng, cụ thể: - Tư vấn đầu tư trong và ngoài nước: Tư vấn và giúp khách hàng lựa chọn các hình thức đầu tư tối ưu: đầu tư trực tiếp, đầu tư gián tiếp, thành lập các đơn vị sản xuất kinh doanh như : Thành lập Công ty Liên doanh; Thành lập Doanh nghiệp 100% vốn nước ngoài; Thành lập công ty cổ phần có vốn đầu tư nước ngoài; Hợp đồng hợp tác liên doanh; Lập dự án Đầu tư nước ngoài tại Việt Nam; Cung cấp thông tin về môi trường đầu tư tại Việt Nam; Điều tra vị trí đầu tư, đối tác, cung cấp dịch vụ Tư vấn chuyên nghiệp cho các Doanh nghiệp nước ngoài; Luật sư Đại diện tại Việt Nam cho doanh nghiệp đầu tư nước ngoài tại Việt Nam; Dự án đầu tư trong nước và đầu tư ra nước ngoài; Mở Văn phòng đại diện, chi nhánh công ty tại Việt nam và ở nước ngoài; Cơ cấu lại doanh nghiệp có vốn đầu tư nước ngoài tại Việt Nam; Giải thể, phá sản doanh nghiệp có vốn đầu tư nước ngoài tại ViệtNam; Hợp nhất, sáp nhập doanh nghiệp có vốn đầu tư nước ngoài tại ViệtNam;- Đại diện cho nhà đầu tư liên hệ với các cơ quan chức năng để triển khai Dự án; - Giới thiệu về những ưu đãi đầu tư trong các lĩnh vực, địa bàn đầu tư cũng như điều kiện để nhận được những ưu đãi đó. - Cung cấp các thông tin về các dự án gọi vốn đầu tư nước ngoài, bao gồm các thông tin chi tiết về các lĩnh vực, địa bàn đặc biệt khuyến khích đầu tư, các dự án có thể triển khai ngay. Những thông tin về những dự án quan trọng được cập nhật từ những cơ quan chức năng của Nhà nước Việt Nam. - Lập Hồ sơ xin đăng ký đầu tư và các ưu đãi đầu tư; - Lập Hồ sơ xin cấp Giấy phép đầu tư và các ưu đãi đầu tư; - Lập các Dự án chi tiết; - Dịch các tài liệu pháp lý liên quan đến Dự án đầu tư; - Tham gia đàm phán, xây dựng các Hợp đồng liên doanh, Hợp tác kinh doanh - Nhận sự uỷ quyền của các nhà đầu tư để liên hệ với các cơ quan chức năng Việt Nam hoàn thành các thủ tục đăng ký hoặc xin cấp phép đầu tư. Mọi thông tin thắc mắc cần trao đổi liên quan đến các vấn đề trên, xin Quý khách hàng vui lòng liên lạc với Tư vấn Luật Brandco để được hướng dẫn chi tiết. '),
(15, '1. Điều kiện cấp Giấy phép thành lập Văn phòng đại diện1. Thương nhân nước ngoài được cấp Giấy phép thành lập Văn phòng đại diện tại Việt Nam khi có đủ các điều kiện sau:a) Là thương nhân được pháp luật nước, vùng lãnh thổ (sau đây gọi chung là nước) nơi thương nhân đó thành lập hoặc đăng ký kinh doanh công nhận hợp pháp;b) Đã hoạt động không dưới 01 năm, kể từ khi được thành lập hoặc đăng ký kinh doanh hợp pháp ở nước của thương nhân.2. Hồ sơ thành lập VPDD:Hồ sơ xin cấp giấy phép thành lập VPDD của Quý khách hàng sẽ gồm các giấy tờ sau đây:1) Đơn đề nghị cấp Giấy phép thành lập văn phòng đại diện bằng tiếng Việt Nam (theo mẫu của Bộ Thương mại) do đại diện có thẩm quyền của thương nhân nước ngoài ký;2) Bản sao Giấy đăng ký kinh doanh hoặc giấy tờ có giá trị tương đương của thương nhân nước ngoài được cơ quan có thẩm quyền nơi thương nhân nước ngoài thành lập xác nhận. Trong trường hợp Giấy đăng ký kinh doanh hoặc giấy tờ có giá trị tương đương có quy định thời hạn hoạt động của thương nhân nước ngoài thì thời hạn đó phải còn ít nhất là một năm;3) Báo cáo tài chính có kiểm toán hoặc tài liệu khác có giá trị tương đương chứng minh được sự tồn tại và hoạt động thực sự của thương nhân nước ngoài trong năm tài chính gần nhất;4) Bản sao Điều lệ hoạt động của thương nhân đối với thương nhân nước ngoài là các tổ chức kinh tế.5) Bản sao hộ chiếu hoặc giấy chứng minh nhân dân (nếu là người ViệtNam); bản sao hộ chiếu (nếu là người nước ngoài) của người đứng đầu văn phòng đại diện;6) Bản sao hợp đồng thuê địa điểm đặt trụ sở văn phòng đại diện.Các giấy tờ quy định tại điểm 2 và 3 được lập bằng tiếng nước nơi thương nhân đăng ký và phải dịch ra tiếng Việt, được cơ quan đại diện ngoại giao, cơ quan lãnh sự của Việt Nam ở nước sở tại chứng nhận và thực hiện việc hợp pháp hóa lãnh sự theo quy định của pháp luật Việt Nam. Mọi thông tin thắc mắc cần trao đổi liên quan đến các vấn đề trên, xin Quý khách hàng vui lòng liên lạc với Tư vấn Luật Brandco để được hướng dẫn chi tiết. '),
(11, 'I- Lựa chọn ngành, nghề kinh doanh Doanh nghiệp có quyền kinh doanh tất cả các ngành mà pháp luật không cấm trừ kinh doanh các ngành, nghề gây phương hại đến quốc phòng, an ninh, trật tự, an toàn xã hội, truyền thống lịch sử, văn hóa, đạo đức, thuần phong mỹ tục Việt Nam và sức khỏe của nhân dân. Điều 7 của Luật Doanh nghiệp (Luật Doanh nghiệp năm 2005): 1. Doanh nghiệp thuộc mọi thành phần kinh tế có quyền kinh doanh các ngành, nghề mà pháp luật không cấm. 2. Đối với ngành, nghề mà pháp luật về đầu tư và pháp luật có liên quan quy định phải có điều kiện thì doanh nghiệp chỉ được kinh doanh ngành, nghề đó khi có đủ điều kiện theo quy định.Điều kiện kinh doanh là yêu cầu mà doanh nghiệp phải có hoặc phải thực hiện khi kinh doanh ngành, nghề cụ thể, được thể hiện bằng giấy phép kinh doanh, giấy chứng nhận đủ điều kiện kinh doanh, chứng chỉ hành nghề, chứng nhận bảo hiểm trách nhiệm nghề nghiệp, yêu cầu về vốn pháp định hoặc yêu cầu khác. 3. Cấm hoạt động kinh doanh gây phương hại đến quốc phòng, an ninh, trật tự, an toàn xã hội, truyền thống lịch sử, văn hoá, đạo đức, thuần phong mỹ tục Việt Nam và sức khoẻ của nhân dân, làm huỷ hoại tài nguyên, phá huỷ môi trường.Chính phủ quy định cụ thể danh mục ngành, nghề kinh doanh bị cấm. 4. Chính phủ định kỳ rà soát, đánh giá lại toàn bộ hoặc một phần các điều kiện kinh doanh; bãi bỏ hoặc kiến nghị bãi bỏ các điều kiện không còn phù hợp; sửa đổi hoặc kiến nghị sửa đổi các điều kiện bất hợp lý; ban hành hoặc kiến nghị ban hành điều kiện kinh doanh mới theo yêu cầu quản lý nhà nước. 5. Bộ, cơ quan ngang bộ, Hội đồng nhân dân và Uỷ ban nhân dân các cấp không được quy định về ngành, nghề kinh doanh có điều kiện và điều kiện kinh doanh. II- Quyền thành lập, góp vốn, mua cổ phần và quản lý doanh nghiệp: Điều 13 của Luật Doanh nghiệp (Luật Doanh nghiệp năm 2005): 1. Tổ chức, cá nhân Việt Nam, tổ chức, cá nhân nước ngoài có quyền thành lập và quản lý doanh nghiệp tại Việt Nam theo quy định của Luật này, trừ trường hợp quy định tại khoản 2 Điều này. 2. Tổ chức, cá nhân sau đây không được quyền thành lập và quản lý doanh nghiệp tại Việt Nam: a) Cơ quan nhà nước, đơn vị lực lượng vũ trang nhân dân Việt Nam sử dụng tài sản nhà nước để thành lập doanh nghiệp kinh doanh thu lợi riêng cho cơ quan, đơn vị mình; b) Cán bộ, công chức theo quy định của pháp luật về cán bộ, công chức; c) Sĩ quan, hạ sĩ quan, quân nhân chuyên nghiệp, công nhân quốc phòng trong các cơ quan, đơn vị thuộc Quân đội nhân dân Việt Nam; sĩ quan, hạ sĩ quan chuyên nghiệp trong các cơ quan, đơn vị thuộc Công an nhân dân Việt Nam; d) Cán bộ lãnh đạo, quản lý nghiệp vụ trong các doanh nghiệp 100% vốn sở hữu nhà nước, trừ những người được cử làm đại diện theo uỷ quyền để quản lý phần vốn góp của Nhà nước tại doanh nghiệp khác; đ) Người chưa thành niên; người bị hạn chế năng lực hành vi dân sự hoặc bị mất năng lực hành vi dân sự; e) Người đang chấp hành hình phạt tù hoặc đang bị Toà án cấm hành nghề kinh doanh; g) Các trường hợp khác theo quy định của pháp luật về phá sản. 3. Tổ chức, cá nhân có quyền mua cổ phần của công ty cổ phần, góp vốn vào công ty trách nhiệm hữu hạn, công ty hợp danh theo quy định của Luật này, trừ trường hợp quy định tại khoản 4 Điều này. 4. Tổ chức, cá nhân sau đây không được mua cổ phần của công ty cổ phần, góp vốn vào công ty trách nhiệm hữu hạn, công ty hợp danh theo quy định của Luật này: a) Cơ quan nhà nước, đơn vị lực lượng vũ trang nhân dân Việt Nam sử dụng tài sản nhà nước góp vốn vào doanh nghiệp để thu lợi riêng cho cơ quan, đơn vị mình; b) Các đối tượng không được góp vốn vào doanh nghiệp theo quy định của pháp luật về cán bộ, công chức.III- Cách đặt tên của doanh nghiệp:(Tên của doanh nghiệp phải bảo đảm theo quy định tại Điều 31, 32, 33, 34 - Luật Doanh nghiệp năm 2005) Điều 31. Tên doanh nghiệp 1. Tên doanh nghiệp phải viết được bằng tiếng Việt, có thể kèm theo chữ số và ký hiệu, phải phát âm được và có ít nhất hai thành tố sau đây: a) Loại hình doanh nghiệp; b) Tên riêng. 2. Tên doanh nghiệp phải được viết hoặc gắn tại trụ sở chính, chi nhánh, văn phòng đại diện của doanh nghiệp. Tên doanh nghiệp phải được in hoặc viết trên các giấy tờ giao dịch, hồ sơ tài liệu và ấn phẩm do doanh nghiệp phát hành. 3. Căn cứ vào quy định tại Điều này và các điều 32, 33 và 34 của Luật này, cơ quan đăng ký kinh doanh có quyền từ chối chấp thuận tên dự kiến đăng ký của doanh nghiệp. Quyết định của cơ quan đăng ký kinh doanh là quyết định cuối cùng. Điều 32. Những điều cấm trong đặt tên doanh nghiệp 1. Đặt tên trùng hoặc tên gây nhầm lẫn với tên của doanh nghiệp đã đăng ký. 2. Sử dụng tên cơ quan nhà nước, đơn vị lực lượng vũ trang nhân dân, tên của tổ chức chính trị, tổ chức chính trị - xã hội, tổ chức chính trị xã hội - nghề nghiệp, tổ chức xã hội, tổ chức xã hội - nghề nghiệp để làm toàn bộ hoặc một phần tên riêng của doanh nghiệp, trừ trường hợp có sự chấp thuận của cơ quan, đơn vị hoặc tổ chức đó. 3. Sử dụng từ ngữ, ký hiệu vi phạm truyền thống lịch sử, văn hoá, đạo đức và thuần phong mỹ tục của dân tộc. Điều 33. Tên doanh nghiệp viết bằng tiếng nước ngoài và tên viết tắt của doanh nghiệp 1. Tên doanh nghiệp viết bằng tiếng nước ngoài là tên được dịch từ tên bằng tiếng Việt sang tiếng nước ngoài tương ứng. Khi dịch sang tiếng nước ngoài, tên riêng của doanh nghiệp có thể giữ nguyên hoặc dịch theo nghĩa tương ứng sang tiếng nước ngoài. 2. Tên bằng tiếng nước ngoài của doanh nghiệp được in hoặc viết với khổ chữ nhỏ hơn tên bằng tiếng Việt của doanh nghiệp tại cơ sở của doanh nghiệp hoặc trên các giấy tờ giao dịch, hồ sơ tài liệu và ấn phẩm do doanh nghiệp phát hành. 3. Tên viết tắt của doanh nghiệp được viết tắt từ tên bằng tiếng Việt hoặc tên viết bằng tiếng nước ngoài. Điều 34. Tên trùng và tên gây nhầm lẫn 1. Tên trùng là tên của doanh nghiệp yêu cầu đăng ký được viết và đọc bằng tiếng Việt hoàn toàn giống với tên của doanh nghiệp đã đăng ký. 2. Các trường hợp sau đây được coi là tên gây nhầm lẫn với tên của doanh nghiệp đã đăng ký: a) Tên bằng tiếng Việt của doanh nghiệp yêu cầu đăng ký được đọc giống như tên doanh nghiệp đã đăng ký; b) Tên bằng tiếng Việt của doanh nghiệp yêu cầu đăng ký chỉ khác tên doanh nghiệp đã đăng ký bởi ký hiệu “&”; c) Tên viết tắt của doanh nghiệp yêu cầu đăng ký trùng với tên viết tắt của doanh nghiệp đã đăng ký; d) Tên bằng tiếng nước ngoài của doanh nghiệp yêu cầu đăng ký trùng với tên bằng tiếng nước ngoài của doanh nghiệp đã đăng ký; đ) Tên riêng của doanh nghiệp yêu cầu đăng ký khác với tên riêng của doanh nghiệp đã đăng ký bởi số tự nhiên, số thứ tự hoặc các chữ cái tiếng Việt ngay sau tên riêng của doanh nghiệp đó, trừ trường hợp doanh nghiệp yêu cầu đăng ký là công ty con của doanh nghiệp đã đăng ký; e) Tên riêng của doanh nghiệp yêu cầu đăng ký khác với tên riêng của doanh nghiệp đã đăng ký bởi từ “tân” ngay trước hoặc “mới” ngay sau tên riêng của doanh nghiệp đã đăng ký; g) Tên riêng của doanh nghiệp yêu cầu đăng ký chỉ khác tên riêng của doanh nghiệp đã đăng ký bằng các từ “miền bắc”, “miền nam”, “miền trung”, “miền tây”, “miền đông” hoặc các từ có ý nghĩa tương tự, trừ trường hợp doanh nghiệp yêu cầu đăng ký là công ty con của doanh nghiệp đã đăng ký. Mọi thông tin thắc mắc cần trao đổi liên quan đến các vấn đề trên, xin Quý khách hàng vui lòng liên lạc với Tư vấn Luật Brandco để được hướng dẫn chi tiết.'),
(12, 'A. Thủ tục thành lập doanh nghiệp: Để khởi sự kinh doanh theo quy định của pháp luật, các nhà đầu tư cần tiến hành thủ tục đăng ký kinh doanh để thành lập doanh nghiệp theo quy trình sau: 1. Đăng ký kinh doanh:Doanh nghiệp phải tiến hành nộp hồ sơ đăng ký kinh doanh của Công ty tạiSở kế hoạch và đầu tỉnh thành phố nơi doanh nghiệp đặt trụ sở chính; 2. Đăng ký con dấu pháp nhân:Sau khi có Giấy đăng ký kinh doanh Quý khách hàng phải tiến hành đăng ký sử dụng hợp pháp con dấu pháp nhân của doanh nghiệp tại cơ quan Công an tỉnh thành phố nơi doanh nghiệp đặt trụ sở chính; 3. Đăng ký mã số thuế:Quý khách hàng phải đăng ký sử dụng hợp pháp Mã số thuế, Mã số Hải quan của doanh nghiệp tại Cục Thuế tỉnh thành phố nơi doanh nghiệp đặt trụ sở chính; B. Các dịch vụ hỗ trợ của Công ty luật Brandco:Với tư cách của một nhà tư vấn tận tâm của Quý khách hàng, Công ty luật Brandco sẽ có các hỗ trợ quan trọng dành cho Quý khách hàng, cụ thể: I. Tư vấn, giải đáp các vướng mắc của nhà đầu tư: Tư vấn các vấn đề pháp lý liên quan đến quá trình thành lập, hoạt động, quản lý Doanh nghiệp; Tư vấn cơ cấu nhân sự trong công ty; Tư vấn về các hợp đồng trước khi đăng ký kinh doanh; Tư vấn về việc thiết lập văn bản ràng buộc giữa các thành viên/cổ đông trong công ty; Tư vấn hồ sơ, tài liệu chuẩn bị thành lập Doanh nghiệp; Tư vấn về chọn loại hình doanh nghiệp phù hợp với ngành nghề kinh doanh và quy mô của công ty; Tư vấn cách phân chia lợi nhuận của các thành viên; Tư vấn chi tiết về thủ tục mua hoá đơn lần đầu cho doanh nghiệp; Tư vấn về vốn đầu tư ban đầu, vốn pháp định, vốn điều lệ… Tư vấn cách đặt tên Doanh nghiệp, tên viết tắt phù hợp với nhu cầu và yêu cầu của hoạt động kinh doanh và tiến hành tra cứu tên doanh nghiệp; Tư vấn về đăng ký ngành nghề Đăng ký kinh doanh (lựa chọn, sắp xếp ngành nghề và dự tính ngành nghề kinh doanh sắp tới); Tư vấn những điều kiện trước khi thành lập, những điều kiện sau khi thành lập đối với nghành nghề đăng ký kinh doanh; Tư vấn chi tiết cho doanh nghiệp các vấn đề về thuế, các nghĩa vụ về tài chính sau khi đăng ký kinh doanh và quá trình hoạt động sản xuất kinh doanh ; Tư vấn về cơ cấu nhân sự, quyền hạn, nghĩa vụ của các thành viên/cổ đông trong công ty;II. Tư vấn, soạn thảo tài liệu hò sơ doanh nghiệp: Đơn đăng ký kinh doanh; Danh sách thành viên/cổ đông; Điều lệ công ty; Quyết định bổ nhiệm Kế toán trưởng; Sổ đăng ký thành viên/cổ dông sáng lập. Hợp đồng lao động_nếu có; Biên bản họp công ty về việc góp vốn của sáng lập viên; Giấy chứng nhận góp vốn cho các thành viên/cổ đông; Quyết định bổ nhiệm Giám đốc;III. Thực hiện dịch vụ tư vấn: Đại diện cho khách hàng trên phòng đăng ký kinh doanh của sở kế hoạch và đầu tư để nộp hồ sơ Thành lập Doanh nghiệp; Đại diện cho khách hàng để theo dõi hồ sơ của doanh nghiệp và nhận kết quả trả lời của Phòng đăng ký kinh doanh; Nhận kết quả là Giấy chứng nhận ĐKKD tại Phòng đăng ký kinh doanh; Đại diện tại cơ quan Công an để xin giấy phép sử dụng con dấu; Tiến hành thủ tục để làm con dấu cho Doanh nghiệp (dấu công ty, dấu chức danh, dấu đăng ký mã số thuế); Tiến hành thủ tục đăng ký mã số thuế và mã số hải quan cho doanh nghiệp; IV. Thời gian thực hiện dịch vụ:Thời gian để hoàn thiện thủ tục thành lập doanh nghiệp là 05 - 20 ngày làm việc. Tuy nhiên, thời gian nói trên có thể thay đổi theo yêu cầu của Quý khách hàng. Lưu ý: Trong quá trình thành lập Doanh nghiệp người đại diện theo pháp luật của doanh nghiệp phải 02 lần đến cơ quan đăng ký kinh doanh (1) để ký nhận giấy chứng nhận đăng ký kinh doanh (2) ký lấy dấu pháp nhân của doanh nghiệp)_khách hàng nhớ mang theo một trong hai giấy tờ: CMTND bản gốc hoặc Hộ Chiếu. C.Trách nhiệm của Công ty luật Brandco sau thành lập: Tư vấn chính sách thuế hiện hành liên quan đến hoạt động của doanh nghiệp; Tư vấn các vấn đề liên quan đến tổ chức và hoạt động của doanh nghiệp; Hướng dẫn thủ tục mua hóa đơn thuế Giá trị gia tăng; Tư vấn kê khai thuế; Tư vấn và hoàn thiện Bộ hồ sơ Nội bộ doanh nghiệp, bao gồm: Điều lệ Doanh nghiệp, Danh sách thành viên, Giấy chứng nhận Vốn góp, các Quyết định bổ nhiệm các chức danh quản lý của doanh nghiệp... Note: Đặc biệt, để đồng hành cùng sự phát triển của Cộng đồng doanh nhân Việt. Công ty Luật Brandco cam kết tư vấn miễn phí về chính sách pháp luật hiện hành liên quan đến hoạt động của Công ty 01 năm sau thành lập; Hãy để chúng tôi chuẩn hóa ý tưởng thành lập doanh nghiệp của bạn bằng cách cung cấp thông tin thành lập doanh nghiệp theo mẫu sau: http://www.camnangphapluat.com/Uploaded/admins/YEU%20CAU%20THONG%20TIN%20TL%20CA%20NHAN%20MOI.doc YEU CAU THONG TIN TL CA NHAN MOI.doc =========================Mọi thông tin thắc mắc cần trao đổi liên quan đến các vấn đề trên, xin Quý khách hàng vui lòng liên lạc với Công ty Luật Brandco để được hướng dẫn chi tiết.');
INSERT INTO `nv3_vi_news_bodytext` (`id`, `bodytext`) VALUES
(13, 'Việc lựa chọn hình thức doanh nghiệp trước khi bắt đầu công việc kinh doanh là rất quan trọng, nó có ảnh hưởng không nhỏ tới sự tồn tại và phát triển của doanh nghiệp. Về cơ bản, những sự khác biệt tạo ra bởi loại hình doanh nghiệp là: (i) uy tín doanh nghiệp do thói quen tiêu dùng; (ii) khả năng huy động vốn; (iii) rủi ro đầu tư; (iv) tính phức tạp của thủ tục và các chi phí thành lập doanh nghiệp; (v) tổ chức quản lý doanh nghiệp. 1. Công ty cổ phần:- Vốn điều lệ được chia thành nhiều phần bằng nhau gọi là cổ phần (Công ty cổ phần phải có cổ phần phổ thông và có thể có cổ phần ưu đãi. Cổ phần ưu đãi gồm các loại như cổ phần ưu đãi biểu quyết, cổ phần ưu đãi cổ tức, cổ phần ưu đãi hoàn lại và cổ phần ưu đãi khác do Điều lệ công ty quy định);- Cổ đông có thể là tổ chức, cá nhân; số lượng cổ đông tối thiểu là ba và không hạn chế số lượng tối đa;- Cổ đông chỉ chịu trách nhiệm về các khoản nợ và nghĩa vụ tài sản khác của doanh nghiệp trong phạm vi số vốn đã góp vào doanh nghiệp;- Cổ đông có quyền tự do chuyển nhượng cổ phần của mình cho người khác, trừ trường hợp (Cổ đông sở hữu cổ phần ưu đãi biểu quyết không được chuyển nhượng cổ phần đó cho người khác; Trong thời hạn ba năm, kể từ ngày công ty được cấp Giấy chứng nhận đăng ký kinh doanh, cổ đông sáng lập có quyền tự do chuyển nhượng cổ phần phổ thông của mình cho cổ đông sáng lập khác nhưng chỉ được chuyển nhượng cổ phần phổ thông của mình cho người không phải là cổ đông sáng lập nếu được sự chấp thuận của Đại hội đồng cổ đông sau 3 năm mọi hạn chế đối với cổ đông sáng lập bị bãi bỏ).- Công ty cổ phần có quyền phát hành chứng khoán các loại để huy động vốn.- Công ty cổ phần có tư cách pháp nhân kể từ ngày được cấp Giấy chứng nhận đăng ký kinh doanh.Ưu điểm:- Chế độ trách nhiệm của công ty cổ phần là trách nhiệm hữu hạn, các cổ đông chỉ chịu trách nhiệm về nợ và các nghĩa vụ tài sản khác của công ty trong phạm vi vốn góp nên mức độ rủi do của các cổ đông không cao;- Khả năng hoạt động của công ty cổ phần rất rộng, trong hầu hết các lịch vực, ngành nghề;- Cơ cấu vốn của công ty cổ phần hết sức linh hoạt tạo điều kiện nhiều người cùng góp vốn vào công ty;- Khả năng huy động vốn của công ty cổ phầnrất cao thông qua việc phát hành cổ phiếu ra công chúng, đây là đặc điểm riêng có của công ty cổ phần;- Việc chuyển nhượng vốn trong công ty cổ phần là tương đối dễ dàng, do vậy phạm vi đối tượng được tham gia công ty cổ phần là rất rộng, ngay cả các cán bộ công chức cũng có quyền mua cổ phiếu của công ty cổ phần.Nhược điểm:Bên cạnh những lợi thế nêu trên, loại hình công ty cổ phần cũng có những hạn chế nhất định như.- Việc quản lý và điều hành công ty cổ phần rất phức tạp do số lượng các cổ đông có thể rất lớn, có nhiều người không hề quen biết nhau và thậm chí có thể có sự phân hóa thành các nhóm cổ động đối kháng nhau về lợi ích;- Việc thành lập và quản lý công ty cổ phần cũng phức tạp hơn các loại hình công ty khác do bị ràng buộc chặt chẽ bởi các quy định của pháp luật, đặc biệt về chế độ tài chính, kế toán. 2. Công ty trách nhiệm hữu hạn 2 thành viên trở lên:- Thành viên có thể là tổ chức, cá nhân; số lượng thành viên không vượt quá năm mươi;- Thành viên chịu trách nhiệm về các khoản nợ và nghĩa vụ tài sản khác của doanh nghiệp trong phạm vi số vốn cam kết góp vào doanh nghiệp;- Phần vốn góp của thành viên được chuyển nhượng cho người khác (Phần vốn góp của thành viên được phép chuyển nhượng toàn bộ hoặc một phần cho các thành viên còn lại trong công ty hoặc cho người không phải là thành viên công ty nếu các thành viên còn lại của công ty không mua hoặc không mua hết. Thành viên công ty cũng có quyền yêu cầu công ty mua lại phần vốn góp của mình nếu không đồng ý với quyết định của Hội đồng thành viên về những vấn đề các vấn đề như sửa đổi, bổ sung Điều lệ công ty liên quan đến quyền và nghĩa vụ của thành viên, quyền và nhiệm vụ của Hội đồng thành viên; tổ chức lại công ty; và các trường hợp khác quy định tại Điều lệ công ty).- Công ty trách nhiệm hữu hạn không được quyền phát hành cổ phần.- Công ty trách nhiệm hữu hạn có tư cách pháp nhân kể từ ngày được cấp Giấy chứng nhận đăng ký kinh doanh. 3.Công ty trách nhiệm hữu hạn một thành viên:- Công ty trách nhiệm hữu hạn một thành viên là doanh nghiệp do một tổ chức hoặc một cá nhân làm chủ sở hữu (gọi là chủ sở hữu công ty); chủ sở hữu công ty chịu trách nhiệm về các khoản nợ và nghĩa vụ tài sản khác của công ty trong phạm vi số vốn điều lệ của công ty.- Công ty trách nhiệm hữu hạn một thành viên không được quyền phát hành cổ phần.- Công ty trách nhiệm hữu hạn một thành viên có tư cách pháp nhân kể từ ngày được cấp Giấy chứng nhận đăng ký kinh doanh.Ưu điểm- Do có tư cách pháp nhân nên các thành viên công ty chỉ trách nhiệm về các hoạt động của công ty trong phạm vi số vốn góp vào công ty nên ít gây rủi ro cho người góp vốn;- Số lượng thành viên công ty trách nhiệm không nhiều và các thành viên thường là người quen biết, tin cậy nhau, nên việc quản lý, điều hành công ty không quá phức tạp;- Chế độ chuyển nhượng vốn được điều chỉnh chặt chẽ nên nhà đầu tư dễ dàng kiểm soát được việc thay đổi các thành viên, hạn chế sự thâm nhập của người lạ vào công ty.Nhược điểm:- Do chế độ trách nhiệm hữu hạn nên uy tín của công ty trước đối tác, bạn hàng cũng phần nào bị ảnh hưởng;- Công ty trách nhiệm hữu hạn chịu sự điều chỉnh chặt chẽ của pháp luật hơn là doanh nghiệp tư nhân hay công ty hợp danh;- Việc huy động vốn của công ty trách nhiệm hữu hạn bị hạn chế do không có quyền phát hành cổ phiếu. 4. Công ty hợp danh:- Phải có ít nhất hai thành viên là chủ sở hữu chung của công ty, cùng nhau kinh doanh dưới một tên chung (gọi là thành viên hợp danh); ngoài các thành viên hợp danh có thể có thành viên góp vốn (thành viên góp vốn không được tham gia quản lý công ty và hoạt động kinh doanh nhân danh công ty);- Thành viên hợp danh phải là cá nhân, chịu trách nhiệm bằng toàn bộ tài sản của mình về các nghĩa vụ của công ty;- Thành viên góp vốn chỉ chịu trách nhiệm về các khoản nợ của công ty trong phạm vi số vốn đã góp vào công ty.- Công ty hợp danh không được phát hành bất kỳ loại chứng khoán nào.- Công ty hợp danh có tư cách pháp nhân kể từ ngày được cấp Giấy chứng nhận đăng ký kinh doanh.Ưu điểm:Ưu điểm của công ty hợp danh là kết hợp được uy tín cá nhân của nhiều người. Do chế độ liên đới chịu trách nhiệm vô hạn của các thành viên hợp danh mà công ty hợp danh dễ dàng tạo được sự tin cậy của các bạn hàng, đối tác kinh doanh. Việc điều hành quản lý công ty không quá phức tạp do số lượng các thành viên ít và là những người có uy tín, tuyệt đối tin tưởng nhau.Nhược điểm:Hạn chế của công ty hợp danh là do chế độ liên đới chịu trách nhiệm vô hạn nên mức độ rủi ro của các thành viên hợp danh là rất cao.Loại hình công ty hợp danh được quy định trong Luật doanh nghiệp năm 1999 và 2005 nhưng trên thực tế loại hình doanh nghiệp này chưa phổ biến. 5. Doanh nghiệp tư nhân:- Doanh nghiệp tư nhân là doanh nghiệp do một cá nhân làm chủ và tự chịu trách nhiệm bằng toàn bộ tài sản của mình về mọi hoạt động của doanh nghiệp.- Doanh nghiệp tư nhân không được phát hành bất kỳ loại chứng khoán nào.- Mỗi cá nhân chỉ được quyền thành lập một doanh nghiệp tư nhân.Ưu điểm:Do là chủ sở hữu duy nhất của doanh nghiệp nên doanh nghiệp tư nhân hoàn toàn chủ động trong việc quyết định các vấn đề liên quan đến hoạt động kinh doanh của Doanh nghiệp. Chế độ trách nhiệm vô hạn của chủ doanh nghiệp tư nhân tạo sự tin tưởng cho đối tác, khách hàng và giúp cho doanh nghiệp ít chịu sự ràng buộc chặt chẽ bởi pháp luật như các loại hình doanh nghiệp khác.Nhược điểm:Do không có tư cách pháp nhân nên mức độ rủi ro của chủ doanh tư nhân cao, chủ doanh nghiệp tư nhân phải chịu trách nhiệm bằng toàn bộ tài sản của doanh nghiệp và của chủ doanh nghiệp chứ không giới hạn số vốn mà chủ doanh nghiệp đã đầu tư vào doanh nghiệp.6. Hợp tác xã.- Hợp tác xã là tổ chức kinh tế tập thể do các cá nhân, hộ gia đình, pháp nhân (gọi chung là xã viên) có nhu cầu, lợi ích chung, tự nguyện góp vốn, góp sức lập ra theo quy định của Luật hợp tác xã để phát huy sức mạnh tập thể của từng xã viên tham gia hợp tác xã, cùng giúp nhau thực hiện có hiệu quả các hoạt động sản xuất, kinh doanh và nâng cao đời sống vật chất, tinh thần, góp phần phát triển kinh tế - xã hội của đất nước.- Hợp tác xã là một loại hình doanh nghiệp đặc biệt, có tư cách pháp nhân, tự chủ, tự chịu trách nhiệm về các nghĩa vụ tài chính trong phạm vi vốn điều lệ, vốn tích luỹ và các nguồn vốn khác của hợp tác xã theo quy định của pháp luật. Nhưng ưu điểm, nhược điểm của Hợp tác xã.Ưu điểm- Có thể thu hút được đông đảo người lao động tham gia;- Việc quản lý hợp tác xã thực hiện trên nguyên tắc dân chủ và bình đẳng nên mọi xã viên đều bình đẳng trong việc tham gia quyết định các vấn đề liên quan đến hoạt động của hợp tác xã không phân biệt nhiều vốn hay ít vốn;- Các xã viên tham gia hợp tác xã chỉ chịu trách nhiệm trước các hoạt động của hợp tác xã trong phạm vi vốn góp vào hợp tác xã.Nhược điểm:Hoạt động kinh doanh theo hình thức hợp tác xã cũng có những hạn chế nhất định như.- Không khuyến khích được người nhiều vốn;- Nhiều kinh nghiệm quản lý, kinh doanh tham gia hợp tác xã do nguyên tắc chia lợi nhuận kết hợp lợi ích của xã viên với sự phát triển của hợp tác xã;- Việc quản lý hợp tác xã phức tạp do số lượng xã viên đông;- Sở hữu manh mún của các xã viên đối tài sản của mình làm hạn chế các quyết định của Hợp tác xã. (Các quy định trên căn cứ theo Luật Doanh nghiệp được Quốc hội thông qua ngày 29/11/2005 có hiệu lực thi hành từ ngày 01/07/2006.)'),
(20, 'Là một doanh nghiệp hàng đầu trong lĩnh vực sản xuất hàng hóa trong xu thế hội nhập hiện nay, Quý khách hàng hãy giành một phần quan trọng trong quỹ thời gian quý báu của mình để thực hiện ngay các hoạt động xác lập quyền đối với các sáng chế mình đang sở hữu, tránh mọi hành vi xâm hại đáng tiếc có thể xảy ra với doanh nghiệp của mình.Công ty Luật Brandco, với tư cách là một chuyên gia hàng đầu về bảo hộ độc quyền sáng chế, xin được chia sẻ với các bạn một số kinh nghiệm liên quan để bảo vệ quyền hợp pháp của mình với loại tài sản đặc biệt này.1. Sáng chế là gì?Sáng chế là giải pháp kỹ thuật dưới dạng sản phẩm hoặc quy trình nhằm giải quyết một vấn đề xác định bằng việc ứng dụng các quy luật tự nhiên. 2. Căn cứ xác lập quyền sở hữu công nghiệp đối với sáng chế.Quyền sở hữu công nghiệp đối với sáng chế được xác lập trên cơ sở quyết định cấp văn bằng bảo hộ của Cơ quan Nhà nước có thẩm quyền theo thủ tục đăng ký quy định tại Luật Sở hữu trí tuệ hoặc công nhận đăng ký quốc tế theo quy định của điều ước quốc tế mà Cộng hoà xã hội chủ nghĩa Việt Nam là thành viên. 3. Quyền nộp đơn đăng ký sáng chế:Các đối tượng sau có quyền nộp đơn đăng ký bảo hộ độc quyền sáng chế tại cơ quan nhà nước có thẩm quyền:- Tác giả tạo ra sáng chế bằng công sức và chi phí của mình;- Tổ chức, cá nhân đầu tư kinh phí, phương tiện vật chất cho tác giả dưới hình thức giao việc, thuê việc, trừ trường hợp các bên có thoả thuận khác.- Đối với sáng chế được tạo ra do sử dụng cơ sở vật chất - kỹ thuật, kinh phí từ ngân sách nhà nước quyền đăng ký sang chế thuộc về Nhà nước. Tổ chức, cơ quan nhà nước được giao quyền chủ đầu tư có trách nhiệm đại diện Nhà nước thực hiện quyền đăng ký. Trong trường hợp sáng chế được tạo ra trên cơ sở Nhà nước góp vốn đầu tư thì tổ chức, cá nhân được nhà nước giao quyền đầu tư có trách nhiệm đại diện Nhà nước thực hiện quyền đăng ký- Trường hợp nhiều tổ chức, cá nhân cùng nhau tạo ra hoặc đầu tư để tạo ra sáng chế, kiểu dáng công nghiệp, thiết kế bố trí thì các tổ chức, cá nhân đó đều có quyền đăng ký và quyền đăng ký đó chỉ được thực hiện nếu được tất cả các tổ chức, cá nhân đó đồng ý. 4. Doanh nghiệp cần cân nhắc những điều gì trước khi làm đơn đăng ký sáng chế ?Sáng chế sẽ bị từ chối bảo hộ nếu thuộc một trong những trường hợp sau đây:- Phát minh, lý thuyết khoa học, phương pháp toán học;- Sơ đồ, kế hoạch, quy tắc và phương pháp để thực hiện các hoạt động trí óc, huấn luyện vật nuôi, thực hiện trò chơi, kinh doanh; chương trình máy tính;- Cách thức thể hiện thông tin;- Giải pháp chỉ mang đặc tính thẩm mỹ;- Giống thực vật, giống động vật;- Quy trình sản xuất thực vật, động vật chủ yếu mang bản chất sinh học mà không phải là quy trình vi sinh;- Phương pháp phòng ngừa, chẩn đoán và chữa bệnh cho người và động vật. 5. Sáng chế đảm bảo những điều kiện gì để được bảo hộ?Sáng chế được bảo hộ dưới hình thức cấp Bằng độc quyền sáng chế nếu đáp ứng các điều kiện sau đây:- Có tính mới;- Có trình độ sáng tạo;- Có khả năng áp dụng công nghiệp. 6. Hồ sơ đăng ký yêu cầu cấp bằng độc quyền đăng ký sáng chế.Hồ sơ đăng ký sáng chế được lập bằng tiếng Việt bao gồm những tài liệu tối thiểu sau đây:- Tờ khai đăng ký sáng chế (được lập theo mẫu);- Bản mô tả sáng chế;- Các tài liệu khác (Giấy uỷ quyền nếu nộp đơn thông qua đại diện; tài liệu chứng minh quyền ưu tiên, tài liệu chứng minh quyền đăng ký…);- Chứng từ phí/lệ phí ; 7. Quá trình xem xét đơn kéo dài trong bao lâu?Thời hạn thẩm định về hình thức đơn đăng ký sáng chế là 01 tháng kể từ ngày nộp đơn.Thẩm định hình thức đơn là việc kiểm tra việc tuân thủ các quy định về hình thức đối với đơn, từ đó đưa ra kết luận đơn có được coi là hợp lệ hay không.Việc thẩm định nội dung đơn đăng ký sáng chế chỉ có thể được tiến hành khi có yêu cầu của chủ đơn. Thời hạn thẩm định nội dung đơn đăng ký sáng chế là 12 tháng kể từ ngày công bố đơn nếu yêu cầu thẩm định nội dung được nộp trước ngày công bố đơn hoặc kể từ ngày nhận được yêu cầu thẩm định nội dung nếu yêu cầu đó được nộp sau ngày công bố đơnMục đích của việc thẩm định nội dung đơn là đánh giá khả năng được bảo hộ của đối tượng nêu trong đơn theo các điều kiện bảo hộ, xác định phạm vi (khối lượng) bảo hộ tương ứng. 8. Trước khi cấp văn bằng độc quyền, chủ đơn có quyền nào không?Trường hợp người nộp đơn đăng ký sáng chế/giải pháp hữu ích biết rằng sáng chế/giải pháp hữu ích đang được người khác sử dụng nhằm mục đích thương mại và người đó không có quyền sử dụng trước thì người nộp đơn có quyền thông báo bằng văn bản cho người sử dụng về việc mình đã nộp đơn đăng ký, trong đó chỉ rõ ngày nộp đơn và ngày công bố đơn trên Công báo sở hữu công nghiệp để người đó chấm dứt việc sử dụng hoặc tiếp tục sử dụng.Trong trường hợp đã được thông báo mà người được thông báo vẫn tiếp tục sử dụng sáng chế/giải pháp hữu ích thì khi Bằng độc quyền sáng chế/giải pháp hữu ích được cấp, chủ sở hữu sáng chế/giải pháp hữu íchcó quyền yêu cầu người đã sử dụng sáng chế/giải pháp hữu ích phải trả một khoản tiền đền bù tương đương với giá chuyển giao quyền sử dụng sáng chế/giải pháp hữu ích đó trong phạm vi và thời hạn sử dụng tương ứng. 9. Khai thác và bảo vệ sáng chế đã được cấp bằng độc quyền.Trường hợp được chấp nhận đăng ký, sáng chế được ghi nhận vào sổ đăng bạ (Sổ đăng ký quốc gia về sáng chế), chủ đơn được cấp Bằng độc quyền sáng chế và trở thành chủ sở hữu sáng chế.Chủ sở hữu sáng chế có các quyền sau đây:- Sản xuất sản phẩm theo giải pháp kỹ thuật được bảo hộ;- Áp dụng quy trình được bảo hộ;- Khai thác công dụng của sản phẩm được bảo hộ hoặc sản phẩm được sản xuất theo quy trình được bảo hộ;- Lưu thông, quảng cáo, chào hàng, tàng trữ để lưu thông sản phẩm được sản xuất theo quy trình được bảo hộ;- Nhập khẩu sản phẩm được sản xuất theo quy trình được bảo hộ- Tự mình sử dụng sáng chế hoặc cho phép người khác sử dụng sáng chế (để đổi lấy các lợi ích vật chất khác) hoặc ngăn cấm người khác sử dụng sáng chế;- Chuyển nhượng quyền sở hữu sáng chế cho người khác (để đổi lấy các lợi ích vật chất) 10. Chủ văn bằng độc quyền sáng chế/giải pháp hữu ích có nghĩa vụ gì không?Chủ văn bằng độc quyền sáng chế/ giải pháp hữu ích có nghĩa vụ sau đây:- Trả thù lao cho tác giả: tối thiểu 10% tiền làm lợi, 15% tiền chuyển giao quyền sử dụng sáng chế/giải pháp hữu ích trong suốt khoảng thời gian có hiệu lực của văn bằng bảo hộ;- Không được cấm chủ thể khác sử dụng sáng chế/giải pháp hữu ích trên cơ sở người đó có quyền sử dụng trước;- Cho phép sử dụng sáng chế cơ bản nhằm sử dụng sáng chế phụ thuộc;- Chuyển giao quyền sử dụng sáng chế theo quyết định của cơ quan Nhà nước về việc chuyển giao không tự nguyện ; 11. Chủ văn bằng độc quyền sáng chế/giải pháp hữu ích phải làm gì để bảo vệ quyền của mình? Để bảo vệ quyền của mình, chủ văn bằng cần theo dõi để phát hiện có chủ thể nào xâm phạm đến quyền của mình hay không, bao gồm những hành vi sau đây:- Sử dụng sáng chế/giải pháp hữu ích được bảo hộ, trong thời hạn hiệu lực của văn bằng bảo hộ mà không được phép của chủ sở hữu;- Sử dụng sáng chế/giải pháp hữu ích mà không trả tiền đền bù theo quy định về quyền tạm thời tại Luật sở hữu trí tuệ. Trong trường hợp có phát hiện có hành vi xâm hại, chủ văn bằngcó quyền yêu cầu cơ quan Nhà nước có thẩm quyền can thiệp để bảo vệ quyền của mình. Doanh nghiệp cũng cần phối hợp với các cơ quan bảo vệ pháp luật bằng cách cung cấp thông tin, chứng cứ về hành vi vi phạm. Hành vi xâm phạm quyền sở hữu sáng chế/giải pháp hữu ích phải bị chấm dứt trọng mọi trường hợp. Người có hành vi xâm phạm bị xử lý vi phạm hành chính. Chủ văn bằng cũng có thể kiện người xâm phạm ra toà theo thủ tục tố tụng dân sự yêu cầu bồi thường thiệt hại về những thiệt hại mà mình phải gánh chịu. 12. Các dịch vụ về sáng chế của Tư vấn Luật Brandco : Là nhà tư vấn chuyên nghiệp trong lĩnh vực tư vấn xác lập và bảo hộ độc quyền kiểu dáng công nghiệp, tư vấn luật Brandco cung cấp các dịch vụ tư vấn chuyên nghiệp sau cho khách hàng: - Tư vấn về khả năng bảo hộ sáng chế/giải pháp hữu ích;- Tra cứu và cung cấp các thông tin sáng chế/giải pháp hữu ích và Khoa học kỹ thuật ở Việt Nam và nước ngoài;- Hoàn thiện hồ sơ bao gồm dịch và/hoặc viết bản mô tả sáng chế, và tiến hành các thủ tục xin cấp Bằng độc quyền sáng chế và giải pháp hữu ích;- Tư vấn về hiệu lực của Bằng độc quyền;- Tư vấn bảo vệ quyền lợi khách hàng trước những hành vi xâm phạm quyền của chủ sở hữu Bằng độc quyền;- Thay mặt khách hàng khiếu kiện Quyết định của Cục sở hữu trí tuệ bao gồm phản đối, kiến nghị thay đổi quyết định;- Tư vấn và đại diện cho khách hàng trong việc đăng ký sáng chế ở các nước thành viên của Hiệp ước Hợp tác Patent (PCT) mà Việt Namlà một quốc gia thành viên. Mọi thông tin thắc mắc cần trao đổi liên quan đến các vấn đề trên, xin Quý khách hàng vui lòng liên lạc với Tư vấn Luật Brandco để được hướng dẫn chi tiết. '),
(21, 'Là một doanh nghiệp hàng đầu trong lĩnh vực sản xuất hàng hóa trong xu thế hội nhập hiện nay, Quý khách hàng hãy giành một phần quan trọng trong quỹ thời gian quý báu của mình để thực hiện ngay các hoạt động xác lập quyền đối với các kiểu dáng công nghiệp minh đang sở hữu, tránh mọi hành vi xâm hại đáng tiếc có thể xảy ra với doanh nghiệp của mình. Công ty Luật Brandco, với tư cách là một chuyên gia hàng đầu về bảo hộ độc quyền kiểu dáng công nghiệp, xin được chia sẻ với các bạn một số kinh nghiệm liên quan để bảo vệ quyền hợp pháp của mình với loại tài sản đặc biệt này. 1. Kiểu dáng công nghiệp là gì?Kiểu dáng công nghiệp là hình dáng bên ngoài của sản phẩm được thể hiện bằng hình khối, đường nét, màu sắc hoặc sự kết hợp những yếu tố này. 2. Căn cứ xác lập quyền sở hữu công nghiệp đối với kiểu dáng công nghiệp.Quyền sở hữu công nghiệp đối với kiểu dáng công nghiệp được xác lập trên cơ sở quyết định cấp văn bằng bảo hộ của Cơ quan Nhà nước có thẩm quyền theo thủ tục đăng ký quy định tại Luật Sở hữu trí tuệ hoặc công nhận đăng ký quốc tế theo quy định của điều ước quốc tế mà Cộng hoà xã hội chủ nghĩa Việt Nam là thành viên. 3. Quyền nộp đơn đăng ký kiểu dáng công nghiệp- Tác giả tạo ra kiểu dáng công nghiệp bằng công sức và chi phí của mình; - Tổ chức, cá nhân đầu tư kinh phí, phương tiện vật chất cho tác giả dưới hình thức giao việc, thuê việc, trừ trường hợp các bên có thoả thuận khác. - Đối với kiểu dáng công nghiệp được tạo ra do sử dụng cơ sở vật chất - kỹ thuật, kinh phí từ ngân sách nhà nước quyền đăng ký kiểu dáng công nghiệp thuộc về Nhà nước. Tổ chức, cơ quan nhà nước được giao quyền chủ đầu tư có trách nhiệm đại diện Nhà nước thực hiện quyền đăng ký. - Trường hợp nhiều tổ chức, cá nhân cùng nhau tạo ra hoặc đầu tư để tạo ra kiểu dáng công nghiệp, kiểu dáng công nghiệp, thì các tổ chức, cá nhân đó đều có quyền đăng ký và quyền đăng ký đó chỉ được thực hiện nếu được tất cả các tổ chức, cá nhân đó đồng ý. 4. Kiểu dáng công nghiệp đảm bảo những điều kiện gì để được bảo hộ?Kiểu dáng công nghiệp được bảo hộ dưới hình thức cấp Bằng độc quyền kiểu dáng công nghiệp nếu đáp ứng các điều kiện sau đây: - Có tính mới;- Có tính sáng tạo;- Có khả năng áp dụng công nghiệp.Kiểu dáng công nghiệp được coi là có khả năng áp dụng công nghiệp nếu có thể dùng làm mẫu để chế tạo hàng loạt sản phẩm có hình dáng bên ngoài là kiểu dáng công nghiệp đó bằng phương pháp công nghiệp hoặc thủ công nghiệp. 5. Hồ sơ đăng ký yêu cầu cấp bằng độc quyền đăng ký kiểu dáng công nghiệp.Hồ sơ đăng ký kiểu dáng công nghiệp được lập bằng tiếng Việt bao gồm những tài liệu tối thiểu sau đây:- Tờ khai đăng ký kiểu dáng công nghiệp (được lập theo mẫu);- Bản mô tả kiểu dáng công nghiệp;- Bộ ảnh chụp/bản vẽ kiểu dáng công nghiệp yêu cầu bảo hộ- Các tài liệu khác (Giấy uỷ quyền nếu nộp đơn thông qua đại diện; tài liệu chứng minh quyền ưu tiên, tài liệu chứng minh quyền đăng ký…);- Chứng từ phí/lệ phí; 6. Cách thức nộp và theo đuổi đơn đăng ký kiểu dáng công nghiệp. - Hồ sơ yêu cầu đăng ký kiểu dáng công nghiệp được nộp tại Cục sở hữu trí tuệ là Cơ quan quản lý nhà nước về kiểu dáng công nghiệp;- Chủ đơn có thể tự mình nộp đơn đăng ký kiểu dáng công nghiệp hoặc có thể nộp qua trung gian là các tổ chức dịch vụ đại diện sở hữu công nghiệp. Nếu chủ đơn chưa hiểu rõ cách thức làm và nộp đơn đăng ký kiểu dáng công nghiệp thì nên sử dụng các dịch vụ chuyên nghiệp – thay mặt mình làm và nộp đơn đăng ký kiểu dáng công nghiệp. 7. Quá trình xem xét đơn kéo dài trong bao lâu?- Thời hạn thẩm định về hình thức đơn đăng ký kiểu dáng công nghiệp là 01 tháng kể từ ngày nộp đơn.- Thẩm định hình thức đơn là việc kiểm tra việc tuân thủ các quy định về hình thức đối với đơn, từ đó đưa ra kết luận đơn có được coi là hợp lệ hay không.- Đơn đăng ký kiểu dáng công nghiệp được thẩm định nội dung trong thời hạn 6 tháng kể từ ngày công bố đơn. Mục đích của việc thẩm định nội dung đơn là đánh giá khả năng được bảo hộ của đối tượng nêu trong đơn theo các điều kiện bảo hộ, xác định phạm vi (khối lượng) bảo hộ tương ứng. 8. Trước khi cấp văn bằng độc quyền, chủ đơn có quyền nào?- Trường hợp người nộp đơn đăng ký kiểu dáng công nghiệp biết rằng kiểu dáng công nghiệp đang được người khác sử dụng nhằm mục đích thương mại và người đó không có quyền sử dụng trước thì người nộp đơn có quyền thông báo bằng văn bản cho người sử dụng về việc mình đã nộp đơn đăng ký, trong đó chỉ rõ ngày nộp đơn và ngày công bố đơn trên Công báo sở hữu công nghiệp để người đó chấm dứt việc sử dụng hoặc tiếp tục sử dụng.- Trong trường hợp đã được thông báo mà người được thông báo vẫn tiếp tục sử dụng kiểu dáng công nghiệp thì khi Bằng độc quyền kiểu dáng công nghiệp được cấp, chủ sở hữu kiểu dáng công nghiệpcó quyền yêu cầu người đã sử dụng kiểu dáng công nghiệp phải trả một khoản tiền đền bù tương đương với giá chuyển giao quyền sử dụng kiểu dáng công nghiệp đó trong phạm vi và thời hạn sử dụng tương ứng. 9. Khai thác và bảo vệ kiểu dáng công nghiệp đã được cấp bằng độc quyền. Trường hợp được chấp nhận đăng ký, kiểu dáng công nghiệp được ghi nhận vào sổ đăng bạ (Sổ đăng ký quốc gia về kiểu dáng công nghiệp), chủ đơn được cấp Bằng độc quyền kiểu dáng công nghiệp và trở thành chủ sở hữu kiểu dáng công nghiệp. Chủ sở hữu kiểu dáng công nghiệp có các quyền sau đây:- Sản xuất sản phẩm có hình dáng bên ngoài là kiểu dáng công nghiệp được bảo hộ;- Lưu thông, quảng cáo, chào hàng, tàng trữ để lưu thông sản phẩm quy định tại điểm a khoản này;- Nhập khẩu sản phẩm có hình dáng bên ngoài là kiểu dáng công nghiệp được bảo hộ- Tự mình sử dụng kiểu dáng công nghiệp hoặc cho phép người khác sử dụng kiểu dáng công nghiệp (để đổi lấy các lợi ích vật chất khác) hoặc ngăn cấm người khác sử dụng kiểu dáng công nghiệp;- Chuyển nhượng quyền sở hữu kiểu dáng công nghiệp cho người khác (để đổi lấy các lợi ích vật chất) ; 10. Chủ văn bằng độc quyền kiểu dáng công nghiệp phải làm gì để bảo vệ quyền của mình?Để bảo vệ quyền của mình, chủ văn bằng cần theo dõi để phát hiện có chủ thể nào xâm phạm đến quyền của mình hay không, bao gồm những hành vi sau đây:- Sử dụng kiểu dáng công nghiệp được bảo hộ, trong thời hạn hiệu lực của văn bằng bảo hộ mà không được phép của chủ sở hữu;- Sử dụng kiểu dáng công nghiệp mà không trả tiền đền bù theo quy định về quyền tạm thời tại Luật sở hữu trí tuệ.Trong trường hợp có phát hiện có hành vi xâm hại, chủ văn bằng có quyền yêu cầu cơ quan Nhà nước có thẩm quyền can thiệp để bảo vệ quyền của mình. Doanh nghiệp cũng cần phối hợp với các cơ quan bảo vệ pháp luật bằng cách cung cấp thông tin, chứng cứ về hành vi vi phạm.Hành vi xâm phạm quyền sở hữu kiểu dáng công nghiệp phải bị chấm dứt trọng mọi trường hợp. Người có hành vi xâm phạm bị xử lý vi phạm hành chính. Chủ văn bằng cũng có thể kiện người xâm phạm ra toà theo thủ tục tố tụng dân sự yêu cầu bồi thường thiệt hại về những thiệt hại mà mình phải gánh chịu. 11. Các dịch vụ về kiểu dáng công nghiệp do Tư vấn Luật Brandco cung cấp: Là nhà tư vấn chuyên nghiệp trong lĩnh vực tư vấn xác lập và bảo hộ độc quyền kiểu dáng công nghiệp, tư vấn luật Brandco cung cấp các dịch vụ tư vấn chuyên nghiệp sau cho khách hàng:- Tra cứu thông tin về đăng ký và sử dụng Kiểu dáng công nghiệp; - Đánh giá khả năng đăng ký và sử dụng Kiểu dáng công nghiệp; - Nộp đơn và tiến hành các thủ tục pháp lý đăng ký Kiểu dáng công nghiệp; - Tư vấn và tiến hành các thủ tục pháp lý ghi nhận chuyển giao đơn đăng ký KDCN;- Tư vấn và tiến hành các thủ tục pháp lý khiếu nại, phản đối cấp hay không cấp Kiểu dáng công nghiệp; - Ghi nhận sửa đổi liên quan đến đơn xin đăng ký KDCN, ví dụ như: tên, địa chỉ của người nộp đơn; - Tư vấn và tiến hành các thủ tục pháp lý ghi nhận sửa đổi liên quan đến Văn bằng bảo hộ KDCN trên cơ sở chuyển nhượng quyền sở hữu, sáp nhập công ty; ghi nhận đổi tên, địa chỉ chủ Văn bằng bảo hộ; - Duy trì, ra hạn hiệu lực bằng độc quyền kiểu dáng công nghiệp; - Tư vấn, thực hiện và phối kết hợp với các cơ quan chức năng tiến hành xử lý các vi phạm đến Độc quyền kiểu dáng công nghiệp theo trình tự thủ tục hành chính; - Tư vấn, đại diện và cử luật sư tố tụng dân sự, tố tụng hình sự tại Tòa án nhân dân các cấp. Mọi thông tin thắc mắc cần trao đổi liên quan đến các vấn đề trên, xin Quý khách hàng vui lòng liên lạc với Tư vấn Luật Brandco để được hướng dẫn chi tiết. '),
(22, 'Hãng luật Brandco là một hãng tư vấn luật thành công nhất ở Việt Nam trong việc phối hợp có hiệu quả với các cơ quan có thẩm quyền Việt Nam tiến hành các biện pháp thực thi quyền chống lại vi phạm quyền nhãn hiệu hàng hoá, kiểu dáng công nghiệp, bản quyền tác giả và sáng chế để đảm bảo rằng quyền sở hữu trí tuệ của Quý doanh nghiệp được bảo hộ, thực thi phù hợp với mục tiêu và chiến lược của họ trên thị trường. Liên quan đến hoạt động thực thi quyền SHTT, hãng luật Brandco cung cấp các dịch vụ tư vấn, đại diện sau: Tư vấn và đại diện cho khách hàng trong các vụ tranh chấp và kiếu nại liên quan đến việc xác lập quyền sở hữu trí tuệ, bao gồm: Khiếu nại các quyết định từ chối cấp văn bằng bảo hộ các đối tượng sở hữu trí tuệ; Phản đối đơn xin cấp Văn bằng bảo hộ các đối tượng sở hữu công nghiệp; Phản đối các quyết định cấp Văn bằng bảo hộ các đối tượng sở hữu công nghiệp của cơ quan Nhà nước có thẩm quyền; Tư vấn và đại diện cho khách hàng trong việc thực thi quyền sở hữu trí tuệ, bao gồm: Yêu cầu cơ quan Nhà nước có thẩm quyền thẩm định và kết luận về các hành vi vi phạm các đối tượng sở hữu trí tuệ; Yêu cầu người vi phạm chấm dứt hành vi vi phạm; Yêu cầu các cơ quan Nhà nước có thẩm quyền xử lý vi phạm; Tham gia tố tụng với tư cách luật sư bảo vệ quyền và lợi ích của khách hàng liên quan đến sở hữu trí tuệ tại Toà án có thẩm quyền.Trong thời gian qua, Hãng luật Brandco đã trợ giúp thành công các doanh nghiệp trong và ngoài nước trong nhiều vụ tranh chấp pháp lý quan trọng liên quan đến SHCN và thực thi quyền sở hữu trí tuệ.Mọi thông tin liên quan đến các hoạt động xử lý vi phạm quyền sở hữu trí tuệ, xin Quý khách hàng vui lòng liên lạc với Hãng luật Brandco để được hướng dẫn sử dụng dịch vụ.'),
(23, 'Bộ Luật Lao động và các văn bản hướng dẫn thi hành có rất nhiều quy định nhằm bảo vệ quyền và lợi ích của người lao động, tuy nhiên quá trình áp dụng pháp luật tại các doanh nghiệp, tổ chức nếu không xây dựng trên sự bình đẳng, đúng pháp Luật sẽ dễ dẫn đến sự vi phạm quyền lợi, gây nên sự bất đồng, tranh chấp. Là một tổ chức hành nghề luật sư có nhiều kinh nghiệm trong lĩnh vực tư vấn pháp luật lao động, Công ty Luật Brandco thực hiện tư vấn chuyên sâu cho khách hàng các lĩnh vực sau:1. Tư vấn nội dung Hợp đồng lao động nhằm đảm bảo tốt nhất quyền lợi của người sử dụng lao động và ràng buộc trách nhiệm của người lao động đối với doanh nghiệp;2. Tư vấn hoàn thiện hồ sơ lao động; hồ sơ bảo hiểm xã hội của người lao động làm việc tại doanh nghiệp của Bên yêu cầu tư vấn theo quy định của pháp luật lao động;3. Tư vấn xây dựng, hoàn thiện quy định về thang bảng lương, quy chế tăng lương... tại doanh nghiệp của Bên yêu cầu tư vấn theo quy định của pháp luật lao động;4. Tư vấn nội dung Bản Thỏa ước lao động tập thể giữa người lao động và doanh nghiệp của bên yêu cầu tư vấn theo quy định của pháp luật lao động;5. Tư vấn, xây dựng và hoàn thiện nội quy lao động trong doanh nghiệp phù hợp với quy định của pháp luật và đáp ứng nhu cầu của chủ sử dụng lao động.6. Tư vấn, chuẩn hóa toàn bộ hồ sơ quản lý lao động của doanh nghiệp theo quy định pháp luật lao động, bao gồm nhưng không giới hạn: các quyết định bổ nhiệm, các quyết định phân công công tác, phạm vi thẩm quyền của các cơ quan, bộ phận trong doanh nghiệp; tư vấn về thẩm quyền trong công tác quản lý doanh nghiệp...I. CĂN CỨ PHÁP LÝ:- Bộ luật Lao động (đã được sửa đổi, bổ sung năm 2002, 2006, 2007);- Các văn bản hướng dẫn thi hành Bộ luật lao động.- Luật doanh nghiệp và các văn bản hướng dẫn thi hành Luật doanh nghiệp;- Các văn bản quy phạm pháp luật liên quan khác; II. Ý KIẾN TƯ VẤN:1. Liên quan đến dịch vụ tư vấn pháp luật nói trên, công ty chúng tôi sẽ thực hiện các công việc sau:a) Giai đoạn thứ nhất:- Tư vấn các vấn đề pháp lý liên quan đến lao động tại Việt Nam;- Khảo sát thực trạng doanh nghiệp và các yêu cầu của Quý khách hàng về nội quy lao động, quy chế tổ chức, hoạt động trong doanh nghiệp;- Phân tích và tư vấn những nội dung chính liên quan đến các yêu cầu tư vấn của doanh nghiệp;b) Giai đoạn thứ hai:- Tư vấn và soạn thảo hợp đồng lao động và các thỏa thuận liên quan đến lao động.- Tư vấn và soạn thảo thỏa ước lao động tập thể;- Tư vấn, soạn thảo quy định về thang bảng lương doanh nghiệp theo quy định của pháp luật;- Tư vấn cấu trúc và các nội dung chính của một thỏa ước lao động tập thể phù hợp với hoạt động sản xuất kinh doanh và cơ cấu tổ chức của doanh nghiệp;- Đại diện đàm phán về nội dung của thỏa ước lao động tập thể;- Tư vấn cơ cấu và nội dung của nội quy lao động, quy chế tổ chức, hoạt động phù hợp với hoạt động sản xuất, kinh doanh và cơ cấu tổ chức của doanh nghiệp;- Soạn thảo nội quy lao động, quy chế tổ chức, hoạt động cho Quý khách hàng;- Tư vấn, chuẩn hóa toàn bộ hồ sơ quản lý lao động của doanh nghiệp theo quy định pháp luật lao động, bao gồm nhưng không giới hạn: các quyết định bổ nhiệm, các quyết định phân công công tác, phạm vi thẩm quyền của các cơ quan, bộ phận trong doanh nghiệp; tư vấn về thẩm quyền trong công tác quản lý doanh nghiệp.a) Giai đoạn thứ ba:- Họp thống nhất với quý khách hàng về các nội dung theo yêu cầu tư vấn của quý khách hàng;b) Giai đoạn thứ tư:- Thay mặt Quý khách hàng nộp hồ sơ đăng ký thỏa ước lao động tập thể với cơ quan lao động địa phương, bao gồm cả việc đại diện khách hàng thương thảo với cơ quan lao động địa phương về nội dung của thỏa ước lao động tập thể.- Thay mặt Quý khách hàng nộp hồ sơ đăng ký nội quy lao động với cơ quan lao động địa phương nếu doanh nghiệp thuộc diện phải đăng ký nội quy lao động theo quy định của pháp luật.'),
(24, 'Là Hãng luật hàng đầu trong lĩnh vực tư vấn đầu tư và tư vấn Sở hữu trí tuệ, hãng luật Brandco xin giới thiệu với Quý doanh nghiệp các dịch vụ pháp lý liên quan tới các hợp đồng, bao gồm việc chuẩn bị cơ sở pháp lý, đàm phán, soạn thảo và hiệu chỉnh các loại hợp đồng kinh tế, thương mại, đầu tư…. A.Phạm vi hợp đồng:- Hợp đồng kinh tế,- Hợp đồng thương mại,- Hợp đồng đầu tư,- Hợp đồng dân sự,- Hợp đồng lao động,- Hợp đồng hợp đồng hợp tác kinh doanh,- Hợp đồng hợp đồng liên doanh,- Hợp đồng hợp đồng mua bán hàng hóa,- Hợp đồng hợp đồng bảo đảm bí mật...- Hợp đồng li-xăng;- Hợp đồng mua bán;- Các loại hợp đồng khác... B.Nội dung tư vấn: - Hãng luật Brandco chuẩn bị các cơ sở pháp lý, các văn bản pháp luật điều chỉnh các vấn đề liên quan;- Hãng luật Brandco nghiên cứu tài liệu liên quan, tìm hiểu thông tin liên quan về các bên của hợp đồng trong các trường hợp cụ thể theo yêu cầu của doanh nghiệp từ đó đưa ra giải pháp tư vấn tối ưu cho việc soạn thảo và ký kết hợp đồng, đảm bảo lợi ích tối đa cho doanh nghiệp và cân bằng được lợi ích của các bên trong hợp đồng;- Hãng luật Brandco cử (các) Luật sư tham gia vào ban đàm phán hợp đồng;- Hãng luật Brandco đưa ra các ý kiến pháp lý để bên thuê Tư vấn đánh giá, quyết định trong việc đàm phán các nội dung hợp đồng;- Hãng luật Brandco thẩm định các nội dung, rà soát, chỉnh sửa các điều khoản hợp đồng do đối tác đưa ra; - Hãng luật Brandco soạn thảo các điều khỏan hợp đồng cần thiết, đàm phán với đối tác để bảo vệ các điều khỏan quan trọng, bảo đảm được quyền hợp pháp của bên thuê tư vấn;- Hãng luật Brandco soạn thảo và hiệu chỉnh các điều khỏan liên quan tới quyền và nghĩa vụ của các bên trong hợp đồng;- Hãng luật Brandco tư vấn và soạn thảo các nội dung khác trên cơ sở các qui định của pháp luật về hợp đồng như điều khỏan thanh toán, phạt hợp đồng, luật áp dụng, cơ quan tài phán... C.Thời gian thực hiện dịch vụ:Thời gian hoàn thành công việc tư vấn, soạn thảo hợp đồng từ 05 - 20 ngày làm việc, tùy theo yêu cầu tư vấn của Quý doanh nghiệp. Tuy nhiên, thời gian nói trên có thể thay đổi theo yêu cầu của Quý khách hàng. D.Phí dịch vụ tư vấn;Mức phí dịch vụ tư vấn được tính toán dựa trên sự phức tạp của yêu cầu công việc và khối lượng công việc thực tế. Phí dịch vụ tư vấn sẽ được thông báo sau khi đã làm rõ các yêu cầu của Quý doanh nghiệp.');
INSERT INTO `nv3_vi_news_bodytext` (`id`, `bodytext`) VALUES
(25, '1. Việc phân chia tài sản thừa kế theo quy định của pháp luật:- Pháp luật Việt nam khẳng định quyền được thừa kế của mọi cá nhân, tổ chức theo quy định tại Điều 631, Bộ luật Dân sự, cụ thể: “Cá nhân có quyền lập di chúc để định đoạt tài sản của mình; để lại tài sản của mình cho người thừa kế theo pháp luật; hưởng di sản theo di chúc hoặc theo pháp luật.”Theo quy định này: Mọi cá nhân, tổ chức đều được quyền để lại di sản của mình cho người thừa kế hoặc được nhận thừa kế do người khác để lại theo di chúc hoặc theo pháp luật. A. Thừa kế theo di chúc:Được quy định tại Điều 646, Bộ luật Dân sự: “Di chúc là sự thể hiện ý chí của cá nhân nhằm chuyển tài sản của mình cho người khác sau khi chết”. Quy định này được hiểu là việc người có tài sản có quyền để lại tài sản của mình cho người khác sau khi chết.- Hình thức của di chúc: Được quy định tại Điều 649, Bộ Luật Dân sự: “ Di chúc phải được lập thành văn bản; nếu không thể lập được di chúc bằng văn bản thì có thể di chúc miệng. Người thuộc dân tộc thiểu số có quyền lập di chúc bằng chữ viết hoặc tiếng nói của dân tộc mình.”- Nội dung của di chúc phải đáp ứng các điều kiện sau: Quy định tại Điều 652, Bộ luật Dân sự :a) Người lập di chúc minh mẫn, sáng suốt trong khi lập di chúc; không bị lừa dối, đe doạ hoặc cưỡng ép;b) Nội dung di chúc không trái pháp luật, đạo đức xã hội; hình thức di chúc không trái quy định của pháp luật.c) Người lập di chúc phải tự tay viết và ký vào bản di chúc.d) Trong trường hợp người lập di chúc không thể tự mình viết bản di chúc thì có thể nhờ người khác viết, nhưng phải có ít nhất là hai người làm chứng. Người lập di chúc phải ký hoặc điểm chỉ vào bản di chúc trước mặt những người làm chứng; những người làm chứng xác nhận chữ ký, điểm chỉ của người lập di chúc và ký vào bản di chúc.Nếu di chúc được lập đảm bảo tất cả các điều kiện tại mục a, b,c,d nói trên thì không cần thiết phải công chứng, chứng thực.Tuy nhiên, để đảm bảo giá trị của di chúc Người lập di chúc có thể yêu cầu công chứng hoặc chứng thực bản di chúc, tức là bạn có thể yêu cầu cơ quan công chứng hoặc ủy ban nhân dân xác nhận.Di chúc chỉ phát sinh hiệu lực khi người để lại di chúc chết. B. Thừa kế theo pháp luật:Trong trường hợp người để lại di sản thừa kế chết mà không để lại di chúc hoặc để lại di chúc không hợp pháp thì di sản thừa kế sẽ được chia theo quy định của pháp luật cho các người thừa kế theo pháp luật được quy định tại Điều 676, Bộ luật dân sự, cụ thể:1. Những người thừa kế theo pháp luật được quy định theo thứ tự sau đây:a) Hàng thừa kế thứ nhất gồm: vợ, chồng, cha đẻ, mẹ đẻ, cha nuôi, mẹ nuôi, con đẻ, con nuôi của người chết;b) Hàng thừa kế thứ hai gồm: ông nội, bà nội, ông ngoại, bà ngoại, anh ruột, chị ruột, em ruột của người chết; cháu ruột của người chết mà người chết là ông nội, bà nội, ông ngoại, bà ngoại;c) Hàng thừa kế thứ ba gồm: cụ nội, cụ ngoại của người chết; bác ruột, chú ruột, cậu ruột, cô ruột, dì ruột của người chết; cháu ruột của người chết mà người chết là bác ruột, chú ruột, cậu ruột, cô ruột, dì ruột, chắt ruột của người chết mà người chết là cụ nội, cụ ngoại.2. Những người thừa kế cùng hàng được hưởng phần di sản bằng nhau.3. Những người ở hàng thừa kế sau chỉ được hưởng thừa kế, nếu không còn ai ở hàng thừa kế trước do đã chết, không có quyền hưởng di sản, bị truất quyền hưởng di sản hoặc từ chối nhận di sản. 2. Việc phân chia tài sản thừa kế áp dụng đối với các loại tài sản khác nhau được thực hiện như thế nàoViệc chia tài sản thừa kế theo hai phương thức trên được áp dụng đối với mọi tài sản hợp pháp của người để lại di sản, bao gồm :- Tài sản là bất động sản : quyền sử dụng đất, quyền sở hữu nhà...- Tài sản là bất động sản : tiền, các giấy tờ trị giá được bằng tiền, các động sản khác : ô tô, xe máy....Các loại tài sản nói trên được chia thành hai loại chính :- Tài sản phải đăng ký quyền sở hữu, quyền sử dụng : Quyền sử dụng đất, quyền sở hữu nhà, ô tô, xe máy, cổ phiếu...- Tài sản không phải đăng ký : Tiền, vàng, kim khí quý, đá quý...Căn cứ vào việc phân chia nói trên, người để lại sản thừa kế và người nhận di sản thừa kế lại có phương thức để lại và nhận tài sản thừa kế khác nhau tương ứng :A. Đối với tài sản là bất động sản và tài sản phải đăng ký :Trường hợp này, để tạo điều kiện thuận lợi cho quá trình cho và nhận di sản cũng như xác lập quyền đối với di sản, người để lại di sản và người nhận di sản phải xác định cụ thể loại di sản để lại, ví dụ : tên tài sản, số đăng ký, cơ quan cấp đăng ký, vị trí tài sản.. và các đặc điểm khác theo quy định của pháp luật.Khuyến nghị :- Việc để lại di sản nên được lập thành di chúc bằng văn bản có luật sư làm chứng hoặc công chứng viên chứng nhận.- Khi phát sinh hiệu lực của việc nhận di sản, nên tiến hành đăng ký ngay theo quy định của pháp luật để xác lập quyền của người nhận di sản.B. Đối với tài sản là động sản và tài sản không phải đăng ký :Trường hợp này, để tạo điều kiện thuận lợi cho quá trình cho và nhận di sản cũng như xác lập quyền đối với di sản, người để lại di sản và người nhận di sản phải xác định cụ thể loại di sản để lại, ví dụ : tên tài sản, số lượng, giá trị, vị trí tài sản.. và các đặc điểm khác theo quy định của pháp luật.Khuyến nghị :- Việc để lại di sản nên được lập thành di chúc bằng văn bản có luật sư làm chứng hoặc công chứng viên chứng nhận để hạn chế tranh chấp xảy ra.'),
(26, '1. Điều kiện cấp phép:Là tổ chức, cá nhân có đăng ký kinh doanh, được thành lập và hoạt động theo quy định của pháp luật, gồmhttp://www.luatcongminh.com/ :· Doanh nghiệp thuộc mọi thành phần kinh tế được thành lập và hoạt động theo quy định của pháp luật;· Hợp tác xã được thành lập và hoạt động theo Luật Hợp tác xã;· Hộ kinh doanh, cá nhân có đăng ký kinh doanh theo quy định của pháp luật;· Các tổ chức khác được thành lập theo quy định của pháp luật.2. Thẩm quyền: Sở công nghiệp- Nay là Sở công thương.3. Thời hạn: 15 ngày làm việc kể từ ngày nộp đầy đủ hồ sơ hợp lệhttp://www.luatcongminh.com/ .4. Hồ sơ bao gồm:· Đơn xin cấp giấy phép sản xuất thuốc lá (Theo mẫu).· Biên bản kiểm tra kho hàng đáp ứng điều kiện phòng cháy chữa cháy.· Đề án sản xuất – kinh doanh:o Mô tã kho hàng.o Nguồn nguyên liệu.o Danh sách đơn vị cung cấp nguyên liệu.o Danh sách nhân lực lao động tại công ty.o Các điều kiện về kho bãi.· Sơ đồ thiết bị phòng cháy chữa cháy.· Sơ đồ kho bãi, khu nghỉ ngơi.· Bản sao danh sách các đơn vị cung cấp nguyên liệu.· Hợp đồng nguyên tắc cung cấp nguyên liệu với đại diện vùng nguyên liệu.· Bản sao chứng chỉ của các chức danh quản lýhttp://www.luatcongminh.com/ .5. Số lượng: 02 bộ'),
(27, '1. Tư vấn các quy định của pháp luật có liên quan đến việc xin giấy phép· Tư vấn Điều kiện về tư cách pháp lý của tổ chức xin cấp phép;· Tư vấn Điều kiện về năng lực thực hiện và nhân sự thực hiện;· Tư vấn Điều kiện về khả năng tài chính;· Tư vấn quy trình thực hiện xin giấy phép;· Tư vấn Các điều kiện khác có liên quan.2. Hoàn thiện hồ sơ xin giấy phép:· Văn bản đề nghị cấp, sửa đổi, bổ sung giấy phép hoạt động điện lực (theo mẫu).· Hồ sơ năng lực, hồ sơ pháp lý, sơ đồ bộ máy tổ chức quản lý điều hành, các đơn vị trực thuộchttp://www.luatcongminh.com/ .· Danh sách các cán bộ quản lý, chuyên gia tư vấn chủ trì các lĩnh vực tư vấn chính.· Danh sách các dự án tương tự mà tổ chức tư vấn đã thực hiện hoặc các chuyên gia chính của tổ chức tư vấn đã chủ trì, tham gia thực hiện.· Danh mục trang thiết bị, phương tiện, phần mềm ứng dụng phục vụ công tác tư vấn do tổ chức đề nghị cấp phéphttp://www.luatcongminh.com/ .3. Đại diện thực hiện các thủ tục:· Tiến hành nộp hồ sơ xin giấy phép tại cơ quan nhà nước có thẩm quyền;· Theo dõi tiến trình xử lý và thông báo kết qủa hồ sơ đã nộphttp://www.luatcongminh.com/ ;· Tiến hành thủ tục thanh toán chi phí cấp giấy phép;· Nhận giấy phép tại cơ quan cấp giấy phép; '),
(28, 'Phí bán đấu giá cổ phần quy định tại Thông tư này áp dụng đối với việc bán đấu giá cổ phần tại Sở giao dịch Chứng khoán, Trung tâm giao dịch Chứng khoán và các tổ chức được phép tổ chức bán đấu giá cổ phần theo quy định của pháp luật. Thông tư này quy định mức thu phí bán đấu giá cổ phần áp dụng tại Sở Giao dịch chứng khoán, Trung tâm giao dịch chứng khoán là 0,3% trên tổng giá trị cổ phần thực tế bán được và tối đa không vượt quá 300 triệu đồng/1 cuộc bán đấu giá cổ phần. Mức thu phí bán đấu giá cổ phần áp dụng tại các tổ chức được phép tổ chức bán đấu giá cổ phần theo quy định của pháp luật do các bên tự thỏa thuận nhưng mức thu không vượt quá 0,3% trên tổng giá trị cổ phần thực tế bán được. Phí từ hoạt động bán đấu giá cổ phần được thu bằng Việt Nam đồng. Các công ty đăng ký bán đấu giá cổ phần có trách nhiệm nộp toàn bộ phí bán đấu giá theo quy định cho Sở Giao dịch chứng khoán, Trung tâm giao dịch chứng khoán và các tổ chức được phép tổ chức bán đấu giá cổ phần sau khi hoàn tất đợt bán đấu giá. Phí bán đấu giá cổ phần thu được là khoản thu không thuộc Ngân sách nhà nước. Đơn vị thu phí có nghĩa vụ nộp thuế theo quy định của pháp luật đối với số phí thu được và có quyền quản lý, sử dụng số tiền thu phí sau khi đã nộp thuế theo quy định của pháp luật. Thông tư này có hiệu lực thi hành sau 45 ngày, kể từ ngày ký. ( Theo mof.gov.vn) '),
(29, 'Theo đó, người tham gia bảo hiểm y tế bị tai nạn giao thông, trong khi chưa có đủ căn cứ để xác định nguyên nhân xảy ra tai nạn giao thông là do hành vi vi phạm pháp luật về giao thông của người đó gây ra, khi đi khám bệnh, chữa bệnh được hưởng chế độ bảo hiểm y tế theo quy định. Khi có đủ căn cứ xác định nguyên nhân xảy ra tai nạn giao thông là do hành vi vi phạm pháp luật về giao thông của người bị tai nạn gây ra hoặc trường hợp bị tai nạn giao thông nhưng không thuộc phạm vi thanh toán của quỹ bảo hiểm y tế, người bị tai nạn không được hưởng chế độ bảo hiểm y tế và có trách nhiệm hoàn trả đầy đủ các khoản chi phí khám bệnh, chữa bệnh cho quỹ bảo hiểm y tế.Đối với người cao tuổi từ 80 tuổi trở lên và trẻ em dưới 14 tuổi thì vẫn được được hưởng chế độ khám bệnh, chữa bệnh bảo hiểm y tế theo quy định mà không phải thực hiện việc xác định hành vi vi phạm pháp luật về giao thông theo quy định.Cũng theo Thông tư, khi có đủ căn cứ xác định nguyên nhân xảy ra tai nạn giao thông là do hành vi vi phạm pháp luật về giao thông của người bị tai nạn gây ra, cơ quan Bảo hiểm xã hội thực hiện thanh toán như sau: Trường hợp người bị tai nạn còn đang điều trị tại cơ sở khám bệnh, chữa bệnh, cơ quan Bảo hiểm xã hội thông báo trực tiếp cho cho người bị tai nạn hoặc thân nhân của người bị tai nạn (cha, mẹ đẻ; vợ hoặc chồng; con đẻ từ 18 tuổi trở lên) biết về việc người bị tai nạn đã vi phạm pháp luật về giao thông và không được quỹ Bảo hiểm y tế thanh toán chi phí khám bệnh, chữa bệnh; Trường hợp người bị tai nạn đã ra viện, cơ quan Bảo hiểm xã hội thực hiện thu hồi chi phí khám bệnh, chữa bệnh mà quỹ Bảo hiểm y tế đã thanh toán theo quy định; Trường hợp người bị tai nạn tử vong, cơ quan Bảo hiểm xã hội thực hiện thanh quyết toán các khoản chi phí khám bệnh, chữa bệnh với cơ sở khám bệnh, chữa bệnh theo chế độ bảo hiểm y tế (không thu hồi chi phí khám bệnh, chữa bệnh đã thanh toán đối với trường hợp này).Ngoài ra, Thông tư cũng quy định về việc thu hồi chi phí khám bệnh, chữa bệnh do quỹ bảo hiểm y tế đã thanh toán: Cơ quan Bảo hiểm xã hội có trách nhiệm thông báo cho người bị tai nạn hoặc thân nhân người bị tai nạn biết kết quả xác định vi phạm pháp luật về giao thông của cơ quan công an và yêu cầu người bị tai nạn hoặc thân nhân người bị tai nạn có trách nhiệm hoàn trả cho quỹ bảo hiểm y tế các khoản chi phí khám bệnh, chữa bệnh mà cơ quan Bảo hiểm xã hội đã thanh toán; Sau 30 ngày, kể từ ngày gửi văn bản yêu cầu hoàn trả lần thứ nhất, nếu người bị tai nạn hoặc thân nhân người bị tai nạn không hoàn trả chi phí thì cơ quan Bảo hiểm xã hội tiếp tục có văn bản đôn đốc thực hiện; Trường hợp sau 03 tháng kể từ ngày gửi thông báo và đôn đốc theo quy định nhưng người bị tai nạn hoặc thân nhân người bị tai nạn vẫn không hoàn trả, cơ quan Bảo hiểm xã hội cấp dưới báo cáo Bảo hiểm xã hội cấp trên để tổng hợp báo cáo Bảo hiểm xã hội Việt Nam; Kết thúc năm tài chính, Bảo hiểm xã hội Việt Nam tổng hợp các khoản chi phí khám bệnh, chữa bệnh cho người tham gia bảo hiểm y tế bị tai nạn giao thông nhưng không thu hồi được báo cáo Bộ Y tế để chủ trì, phối hợp với Bộ Tài chính trình Thủ tướng Chính phủ cho phép quyết toán vào quỹ bảo hiểm y tế đối với các khoản không thu được này.Thông tư có hiệu lực thi hành kể từ ngày 26/12/2011./. (Trích nguồn: www.mof.gov.vn)'),
(30, 'Theo đó, kể từ ngày 15/4/2012, hồ sơ đề nghị cấp Giấy miễn thị thực phải được lập thành một bộ (trước đây chưa có quy định). Cơ quan có thẩm quyền cấp Giấy miễn thị thực trong thời hạn 5 ngày làm việc từ ngày nhận đủ hồ sơ hợp lệ.Quy định sửa đổi, bổ sung cũng quy định, người nhập cảnh Việt Nam bằng Giấy miễn thị thực, được tạm trú tại Việt Nam không quá 90 ngày cho mỗi lần nhập cảnh. Nếu có nhu cầu ở lại quá 90 ngày, được cơ quan, tổ chức, cá nhân tại Việt Nam bảo lãnh và có lý do chính đáng thì được xem xét, giải quyết gia hạn tạm trú, mỗi lần không quá 90 ngày.Người có nhu cầu gia hạn tạm trú phải làm thủ tục trước khi hết hạn 5 ngày.Trong đó, hồ sơ đề nghị gia hạn tạm trú gồm: Hộ chiếu của người xin gia hạn tạm trú và Tờ khai đề nghị cấp, bổ sung, sửa đổi thị thực, gia hạn tạm trú (mẫu N5), có xác nhận của Công an xã, phường nơi tạm trú; và yêu cầu nộp tại Cục Quản lý xuất nhập cảnh hoặc Phòng Quản lý xuất nhập cảnh công an tỉnh, thành phố nơi tạm trú...Mọi thông tin thắc mắc cần trao đổi liên quan đến các vấn đề trên, xin Quý khách hàng vui lòng liên lạc với http://brandco.vn/service-view-3323/service-view-3307/service-view-1394/service-view-872/service-view-871/service-view-858/ Tư vấn Luật Brandco để được hướng dẫn chi tiết. '),
(31, 'Theo đó, các tổ chức, cá nhân trả thu nhập phải khấu trừ thuế không phân biệt có phát sinh khấu trừ hay không khấu trừ thuế; Các cá nhân cư trú có thu nhập từ tiền lương, tiền công, thu nhập từ kinh doanh phải quyết toán thuế thu nhập cá nhân: Có số thuế phải nộp lớn hơn số thuế đã khấu trừ hoặc tạm nộp; Có yêu cầu hoàn số thuế nộp thừa hoặc bù trừ vào kỳ sau; Các cá nhân cư trú có thu nhập từ chuyển nhượng chứng khoán đã đăng ký nộp thuế Thu nhập cá nhân theo thuế suất 20% tính trên thu nhập tính thuế với cơ quan thuế phải quyết toán thuế trong các trường hợp: Số thuế phải nộp tính theo thuế suất 20% lớn hơn tổng số thuế đã tạm khấu trừ theo thuế suất 0,1% trong 7 tháng đầu năm và 0,05% trong 5 tháng cuối năm 2011; Có yêu cầu hoàn thuế nộp thừa; Các cá nhân cư trú là người nước ngoài khi kết thúc hợp đồng làm việc tại Việt Nam trước khi xuất cảnh phải thực hiện quyết toán thuế.Theo nội dung công văn, thu nhập chịu thuế từ tiền lương, tiền công được xác định bằng tổng số tiền lương, tiền công, tiền thù lao và các khoản thu nhập khác theo hướng dẫn tại Khoản 2, Mục II, Phần A Thông tư số 84/2008/TT-BTC ngày 30/9/2008; Điều 1 Thông tư số 62/2009/TT-BTC ngày 27/3/2009; Điều 1 Thông tư số 02/2010/TT-BTC ngày 11/01/2010 của Bộ Tài chính mà người nộp thuế nhận được trong năm 2011.Trường hợp tổ chức, cá nhân trả tiền ăn giữa ca cho từng người lao động thì mức ăn giữa ca không tính vào thu nhập chịu thuế tối đa không vượt mức tiền chi cho ăn giữa ca quy định tại Khoản 3, Điều 5 Thông tư số 12/2011/TT-BLĐTBXH ngày 26/4/2011 của Bộ Lao động, Thương binh và Xã hội về việc hướng dẫn thực hiện mức lương tối thiểu chung đối với công ty trách nhiệm hữu hạn một thành viên do Nhà nước làm chủ sở hữu.Thời điểm xác định thu nhập chịu thuế là thời điểm tổ chức, cá nhân trả thu nhập từ tiền lương, tiền công cho cá nhân. Trường hợp tiền lương, tiền công tháng 12/2010, tổ chức, cá nhân trả thu nhập cho đối tượng nộp thuế vào tháng 1/2011 thì tính vào thu nhập chịu thuế của năm 2011 để quyết toán thuế trong năm 2011.Đối với thu nhập chuyển nhượng chứng khoán, thu nhập chịu thuế từ chuyển nhượng chứng khoán được xác định bằng giá bán chứng khoán trừ giá mua và các chi phí liên quan đến chuyển nhượng.Về đối tượng giảm trừ gia cảnh và các khoản được giảm trừ để xác định thu nhập tính thuế được hướng dẫn tại Mục I, Phần B Thông tư số 84/2008/TT-BTC ngày 30/9/2009; Điều 2, Điều 3 Thông tư số 62/2009/TT-BTC ngày 27/3/2009.Cá nhân được giảm trừ cho người phụ thuộc từ tháng có nghĩa vụ nuôi dưỡng. Đối với người nước ngoài cư trú tại Việt Nam được tính giảm trừ gia cảnh cho bản thân từ tháng đến Việt Nam đến tháng rời khỏi Việt Nam.Đối với cá nhân cư trú có thu nhập từ tiền lương, tiền công, thu nhập từ kinh doanh: Số thuế phải nộp = Thu nhập tính thuế bình quân tháng x Thuế suất theo biểu thuế luỹ tiến từng phần tháng x 12 tháng Đối với cá nhân có thu nhập tính thuế từ tiền lương, tiền công, thu nhập từ kinh doanh đến mức phải chịu thuế Thu nhập cá nhân ở bậc 1 của Biểu thuế luỹ tiến từng phần (nhỏ hơn hoặc bằng 5 triệu đồng/tháng) thì được miễn thuế 5 tháng cuối năm 2011. Số thuế được miễn = Thuế phải nộp năm 2011 x 5 tháng _______________________ 12 tháng (Trích nguồn: www.mof.gov.vn)'),
(32, 'Theo thông tư số 180/2010/TT-BTC được Bộ Tài chính ban hành ngày 10 tháng 11 năm 2010 về hướng dẫn giao dịch điện tử trong lĩnh vực thuế, Doanh nghiệp và cá nhân sẽ sử dụng chữ ký số công công (CA) của mình khi thực hiện xác thực các giao dịch Kê khai và nộp tờ khai thuế qua mạng và các giao dịch thuế điện tử khác khi giao dịch với cơ quan thuế.Trong thời gian triển khai áp dụng vừa qua, còn nhiều Doanh nghiệp và các cá nhân vẫn chưa thực sự hiểu rõ và phân biệt chính xác về hai nội dung Đăng ký cấp phát chữ ký số công cộng và Đăng ký thực hiện kê khai thuế qua mạng mà ngành thuế dang triển khai, áp dụng. Còn có một số Doanh nghiệp khi mới chỉ thực hiện Đăng ký cấp phát chữ ký số công cộng và đã nghĩ rằng mình đã thực hiện Đăng ký kê khai thuế qua mạng. Để có thể giúp doanh nghiệp, cá nhân phân biệt và hiểu rõ hơn về ý nghĩa của các nội dung này, chúng tôi xin đưa ra một số định nghĩa, mô tả ngắn gọn về ý nghĩa, quy trình thực hiện của hai vấn đề này như sau:1. Chữ ký số và quy trình đăng ký cấp phát chữ ký số công cộng:Chữ ký số là chuỗi thông tin được đính kèm theo dữ liệu (văn bản: word, excel, pdf…; hình ảnh; video...) nhằm mục đích xác định người chủ của dữ liệu đó. Chữ ký số được hiểu và có ý nghĩa như con dấu điện tử của doanh nghiệp hay cá nhân. Vì vậy, chữ ký số không những chỉ dùng trong việc kê khai thuế, mà người sử dụng còn có thể sử dụng chữ ký số trong tất cả các giao dịch điện tử với mọi tổ chức và cá nhân khác nếu các tổ chức này đã chấp nhận các giao dịch điện tử với chữ ký số.Chữ ký số sẽ do một nhà cung cấp dịch vụ chứng thực chữ ký số công cộng cấp phát và được lưu trữ trong một thiết bị phần cứng chuyên dụng gọi là USB Token hoặc SmartCard.Hiện tại đã có 06 nhà cung cấp dịch vụ chữ ký số công cộng được phép cấp phát và chứng thực chữ ký số cho Doanh nghiệp và cá nhận là: VDC, Viettel, FPT, Nacencom, BKAV, CKKhi Doanh nghiệp, cá nhân đã thực hiện đăng ký cấp phát và sử dụng dịch vụ chữ ký số công cộng với các nhà cung cấp dịch vụ chữ ký số nêu trên có nghĩa là Doanh nghiệp, cá nhân vẫn chưa thực hiện thủ tục đăng ký sử dụng dịch vụ Kê khai và nộp tờ khai thuế qua mạng.Để đăng ký sử dụng hệ thống kê khai và nộp hồ sơ thuế qua mạng của ngành thuế thì Doanh nghiệp, cá nhân phải đăng ký với Cơ quan thuế hoặc đăng ký với các nhà cung cấp dịch vụ thuế điện tử (T-VAN) đã được Tổng cục thuế cấp phép hoạt động2. Kê khai và nộp tờ khai thuế qua mạng:Từ cuối năm 2009, ngành thuế đã ứng dụng và triển khai hệ thống phần mềm Kê khai và nộp tờ khai thuế qua mạng Internet cho đối tượng sử dụng là các Doanh nghiệp hoạt động tại Việt nam.Hệ thống này là một ứng dụng phần mềm tin học, cho phép các Doanh nghiệp đăng nhập vào hệ thống phần mềm qua mạng Internet và thực hiện các nghiệp vụ chính như sau- Kê khai các tờ khai thuế phát sinh của Doanh nghiệp theo nghĩa vụ kê khai thuế- Sử dụng chữ ký số công cộng đã tổ chức cung cấp chữ ký số công cộng cấp phát để ký xác nhận về nội dung thông tin trên tờ khai thuế đã kê khai- Gửi tờ khai thuế cho cơ quan thuế qua mạng Internet- Nhận và tra cứu các thông báo từ cơ quan thuế trả về.Doanh nghiệp muốn thực hiện Kê khai và nộp tờ khai thuế qua mạng với cơ quan thuế thì Doanh nghiệp phải có chữ ký số công cộng và phải đăng ký kê khai thuế qua mạng với Tổng cục thuế hoặc Đăng ký qua các công ty đã được Tổng cục thuế cấp phép cung cấp dịch vụ thuế điện tử (T-VAN).Một số nhà cung cấp dịch vụ thuế điện tử (T-VAN) hiện nay cũng đã phối hợp chặt chẽ với các nhà cung cấp dịch vụ chữ ký số công cộng để cung cấp dịch vụ trọn gói và làm toàn bộ các thủ tục đăng ký, cấp phát... cho Doanh nghiệp, cá nhân, tạo thuận tiện tối đa cho các Doanh nghiệp khai thuế qua mạng. Hiện nay tại Việt Nam đã có 06 nhà cung cấp được phép cung cấp dịch vụ thuế điện tử (T-VAN) là các tổ chức:- Công ty Seatech- Công ty Viettel- Công ty Thái Sơn- Công ty BKAV- Công ty FPT- Công ty TS24,Với các định nghĩa và nội dung mô tả như trên sẽ giúp Doanh nghiệp, cá nhân có thể phân biệt rõ về các nội dung dịch vụ cụ thể và hiểu rõ các quy trình đăng ký, cấp phát... khi làm việc với nhà cung cấp dịch vụ chữ ký số công cộng và nhà cung cấp dịch vụ kê khai thuế qua mạng.Mọi thông tin thắc mắc cần trao đổi liên quan đến các vấn đề trên, xin Quý khách hàng vui lòng liên lạc với http://brandco.vn/service-view-1394/service-view-872/service-view-871/service-view-858/ Tư vấn Luật Brandco để được hướng dẫn chi tiết. -'),
(33, 'Trong thời gian qua Bộ Tài chính đã nhận được phản ánh vướng mắc của một số Cục Thuế, doanh nghiệp về việc khấu trừ, hoàn thuế GTGT đối với trường hợp một cá nhân vừa làm giám đốc của Công ty cổ phần vừa làm giám đốc của doanh nghiệp (công ty) khác. Trên cơ sở đó, Bộ Tài chính vừa mới ban hành Công văn số 13238/BTC-TCT về việc khấu trừ, hoàn thuế GTGT đối với trường hợp Giám đốc hoặc Tổng giám đốc của Công ty không được đồng thời làm Giám đốc hoặc Tổng giám đốc của doanh nghiệp khác.Căn cứ Khoản 2 Điều 116 Chương IV (Công ty cổ phần) Luật Doanh nghiệp số 60/2005/QH11 ngày 29 tháng 11 năm 2005, quy định: “2. Giám đốc hoặc Tổng giám đốc của Công ty không được đồng thời làm Giám đốc hoặc Tổng giám đốc của doanh nghiệp khác”;Căn cứ Khoản 4 Điều 15 (hướng dẫn bổ sung về giám đốc (Tổng giám đốc) và Thành viên Hội đồng quản trị) Nghị định số 102/2010/NĐ-CP ngày 01/10/2010 của Chính phủ hướng dẫn chi tiết thi hành một số điều Luật Doanh nghiệp: “4. Nếu Điều lệ công ty không quy định khác thì Chủ tịch Hội đồng thành viên, Chủ tịch công ty, Chủ tịch Hội đồng quản trị và Giám đốc (Tổng giám đốc) của một công ty có thể kiêm Chủ tịch Hội đồng thành viên, Chủ tịch công ty, Chủ tịch Hội đồng quản trị hoặc Giám đốc (Tổng giám đốc) của công ty khác, trừ trường hợp Giám đốc (Tổng giám đốc) công ty cổ phần không được đồng thời làm Giám đốc (Tổng giám đốc) công ty khác theo Khoản 2 Điều 116 của Luật Doanh nghiệp”;Căn cứ Điểm 1.2 (c9) Mục III Phần B; Điểm 8 Phần C Thông tư số 129/2008/TT-BTC ngày 26/12/2008 của Bộ Tài chính hướng dẫn thi hành một số điều của Luật Thuế giá trị gia tăng và hướng dẫn thi hành Nghị định số 123/2008/NĐ-CP ngày 08 tháng 12 năm 2008 của Chính phủ quy định chi tiết và hướng dẫn thi hành một số điều của Luật Thuế giá trị gia tăng­­­­;Căn cứ Điểm 2 Mục IV Phần C Thông tư số 130/2008/TT-BTC ngày 26/12/2008 của Bộ Tài chính hướng dẫn thi hành một số điều của Luật Thuế thu nhập doanh nghiệp số 14/2008/QH12 và hướng dẫn thi hành Nghị định số 124/2008/NĐ-CP ngày 11 tháng 12 năm 2008 của Chính phủ quy định chi tiết thi hành một số điều của Luật Thuế thu nhập doanh nghiệp;Căn cứ công văn số 6347/BKHĐT-TCTT ngày 21/9/2011 của Bộ Kế hoạch và Đầu tư về việc khấu trừ, hoàn thuế GTGT đối với trường hợp vi phạm Luật Doanh nghiệp;Trường hợp trong cùng một thời gian mà một cá nhân vừa làm giám đốc (hoặc Tổng giám đốc) của Công ty cổ phần, vừa làm giám đốc (hoặc Tổng giám đốc) của doanh nghiệp (công ty) khác là vi phạm qui định của Khoản 2 Điều 116 của Luật doanh nghiệp và Khoản 4 Điều 15 Nghị định số 102/2010/NĐ-CP ngày 01/10/2010 của Chính phủ hướng dẫn thi hành một số điều Luật Doanh nghiệp và bị xử phạt hành chính theo Luật Doanh nghiệp.Trong trường hợp này, theo quyết định của Cơ quan đăng ký kinh doanh, sau khi khắc phục lỗi vi phạm doanh nghiệp vẫn được tiếp tục hoạt động mà chưa đến mức bị thu hồi Giấy chứng nhận đăng ký kinh doanh và làm thủ tục giải thể doanh nghiệp, nếu các tài liệu trong hồ sơ đề nghị hoàn thuế của công ty cổ phần vẫn đáp ứng đủ các điều kiện về kê khai khấu trừ, hoàn thuế GTGT theo quy định thì công ty cổ phần vẫn được kê khai khấu trừ, hoàn thuế đầu vào tương ứng.Trường hợp vi phạm qui định của Khoản 2 Điều 116 của Luật doanh nghiệp, Khoản 4 Điều 15 Nghị định số 102/2010/NĐ-CP ngày 01/10/2010 của Chính phủ nêu trên, bị thu hồi Giấy chứng nhận đăng ký kinh doanh và làm thủ tục giải thể doanh nghiệp thì các tài liệu trong hồ sơ đề nghị hoàn thuế của Công ty cổ phần không đảm bảo tính hợp pháp để kê khai khấu trừ, hoàn thuế GTGT.Mọi thông tin thắc mắc cần trao đổi liên quan đến các vấn đề trên, xin Quý khách hàng vui lòng liên lạc với http://brandco.vn/service-view-1394/service-view-872/service-view-871/service-view-858/ Tư vấn Luật Brandco để được hướng dẫn chi tiết.'),
(34, 'Tổng cục Thuế cho biết, triển khai Nghị định số 51/2010/NĐ-CP về hoá đơn (có hiệu lực thi hành từ 1/1/2011), tính đến hết ngày 30/4/2011, trên địa bàn cả nước đã có 145.693 doanh nghiệp đã tự in, đặt in hoá đơn. Tuy nhiên vẫn còn 188.421 doanh nghiệp siêu nhỏ, doanh nghiệp ở địa bàn kinh tế xã hội khó khăn và đặc biệt khó khăn đang thực hiện mua hóa đơn của cơ quan thuế.Do vậy, từ nay đến cuối năm 2011, một trong những nhiệm vụ trong tâm của ngành Thuế là triển khai các giải pháp thực hiện đồng bộ và thống nhất thúc đẩy các doanh nghiệp nêu trên đặt in hoặc tự in hóa đơn để có hóa đơn sử dụng từ ngày 1/1/2012. Việc chuyển hết các doanh nghiệp siêu nhỏ, doanh nghiệp ở tại địa bàn kinh tế xã hội khó khăn và đặc biệt khó khăn từ cơ chế mua hóa đơn của cơ quan thuế sang cơ chế tự chủ đặt in, tự in hóa đơn có ý nghĩa quan trọng trong việc nâng cao tính tự chủ của các doanh nghiệp trong công tác tự chịu trách nhiệm về quản lý hóa đơn của doanh nghiệp, giảm chi phí quản lý của cơ quan thuế dùng vào việc bán hóa đơn, ấn chỉ cho các doanh nghiệp. Phấn đấu hết tháng 10/2011, doanh nghiệp siêu nhỏ có phương án sử dụng hóa đơn tự inTổng cục Thuế đề nghị cơ quan Thuế các cấp cần tập trung các giải pháp phấn đấu hết tháng 10/2011, về cơ bản tất cả các doanh nghiệp trên địa bàn ký được hợp đồng đặt in hoá đơn hoặc đã có phương án sử dụng hoá đơn tự in.Đồng thời, cũng để tránh hiện tượng các doanh nghiệp đặt in hoá đơn dồn vào thời điểm cuối năm, Tổng cục Thuế giao chỉ tiêu cho các Cục thuế thực hiện đảm bảo đến hết ngày 31/10/2011, 100% số lượng doanh nghiệp siêu nhỏ, doanh nghiệp ở địa bàn khó khăn và đặc biệt khó khăn có hoá đơn đặt in hoặc ký được hợp đồng đặt in hoá đơn hoặc có phương án sử dụng hoá đơn tự in.Trường hợp doanh nghiệp gặp vướng mắc trong việc đặt in, tự in hóa đơn, Tổng cục Thuế đề nghị Cục thuế liên hệ trực tiếp, phối hợp với các nhà in, doanh nghiệp cung cấp phần mềm in hoá đơn để hỗ trợ giải quyết vướng mắc cho doanh nghiệp.Cơ quan thuế chỉ bán số lượng hóa đơn đủ dùng đến hết 31/12/2011Bên cạnh đó, Tổng cục Thuế yêu cầu cần tiếp tục thực hiện công tác tuyên truyền để phổ biến và quán triệt sâu sắc đến từng doanh nghiệp hiện đang mua hóa đơn của cơ quan thuế để doanh nghiệp biết nội dung: Từ ngày 1/1/2012 cơ quan Thuế không bán hóa đơn cho doanh nghiệp. Tuỳ vào đặc điểm của từng địa phương, Cục thuế chủ động sử dụng các hình thức tuyên truyền khác nhau đảm bảo hiệu quả.Căn cứ số lượng hoá đơn còn tồn kỳ trước, trong quý IV/2011 cơ quan Thuế các cấp giảm dần số lượng hoá đơn bán cho các doanh nghiệp, chỉ bán với số lượng đủ dùng đến hết 31/12/2011. Cục Thuế thông báo đến từng doanh nghiệp về việc hoá đơn do Cục thuế đặt in bán cho doanh nghiệp đến ngày 31/12/2011 doanh nghiệp còn tồn sẽ hết giá trị sử dụng, doanh nghiệp phải nộp lại số còn tồn cho cơ quan Thuế để cơ quan Thuế huỷ theo quy định. Đồng thời với việc bán hoá đơn với số lượng đủ dùng này, cơ quan Thuế yêu cầu từng doanh nghiệp siêu nhỏ, doanh nghiệp ở tại địa bàn kinh tế xã hội khó khăn và đặc biệt khó khăn hiện đang mua hoá đơn cam kết với cơ quan Thuế về việc doanh nghiệp đã được cơ quan Thuế triển khai các quy định về hoá đơn và chịu trách nhiệm đảm bảo có hoá đơn để sử dụng từ 1/1/2012 theo quy định.Mọi thông tin thắc mắc cần trao đổi liên quan đến các vấn đề trên, xin Quý khách hàng vui lòng liên lạc với http://brandco.vn/service-view-1394/service-view-872/service-view-871/service-view-858/ Tư vấn Luật Brandco để được hướng dẫn chi tiết.'),
(35, 'Trong dự thảo Nghị định về lương tối thiểu vùng công bố chiều 16/8, Bộ Lao động Thương binh và Xã hội đề xuất 2 phương án điều chỉnh. Với phương án thứ nhất, mức tối thiểu quy định cho các doanh nghiệp hoạt động trên địa bàn thuộc vùng I là 2,7 triệu đồng, tăng 700.000 đồng so với hiện hành. Các doanh nghiệp hoạt động ở vùng II, III và IV lần lượt áp dụng mức 2,4 - 2,13 - 1,93 triệu đồng một tháng.Ở phương án thứ hai, Bộ đề xuất mức cao nhất cho vùng một là 2,5 triệu đồng và thấp nhất là 1,8 triệu đồng cho vùng IV. Vùng Hiện hành (Đến hết 31/12/2012) Phương án 1 (Từ 1/1/2013) Phương án 2 (Từ 1/1/2013) I 2.000.000 2.700.000 2.500.000 II 1.780.000 2.400.000 2.250.000 III 1.550.000 2.130.000 1.950.000 IV 1.400.000 1.930.000 1.800.000 (Đồng/tháng)Nghị định này nếu được thông qua sẽ áp dụng từ 1/1/2013, cho các công ty, doanh nghiệp, hợp tác xã, trang trại, hộ gia đình, cá nhân và cơ quan, tổ chức có thuê mướn lao động.Lương tối thiểu vùng là mức sàn cho doanh nghiệp và người lao động căn cứ để thỏa thuận tiền lương. Dự thảo khuyến khích các doanh nghiệp trả lương cho người lao động cao hơn quy định. Đồng thời, dự thảo quy định tiền lương thấp nhất trả cho người lao động đã qua học nghề, kể cả lao động do doanh nghiệp tự dạy nghề, phải cao hơn ít nhất 7% so với mức lương tối thiểu vùng theo quy định.Trên thực tế, lương tối thiểu vùng chỉ mang tính chất tham chiếu để các doanh nghiệp xây dựng bảng lương và làm căn cứ tính bảo hiểm cho người lao động. Và thu nhập thực lĩnh của lao động tại nhiều doanh nghiệp đều cao hơn so với mức tối thiểu này.Bản thân mức lương tối thiểu cũng được cho là lạc hậu so với đời sống thực tế. Khảo sát năm 2011 của Tổng liên đoàn Lao động Việt Nam cho thấy, mức sống tối thiểu của người lao động từ vùng IV đến vùng I lần lượt là 2,47 - 2,66 - 2,86 và 3,04 triệu đồng mỗi tháng. Trong khi mức cao nhất áp dụng trước 1/10/2011 là 1,55 triệu đồng và sau mốc này cũng chỉ là 2 triệu đồng một tháng.Trong một hội thảo tổ chức tháng 5, ông Đặng Quang Điều, Viện trưởng Viện Nghiên cứu công nhân công đoàn (Tổng liên đoàn Lao động Việt Nam) phải thốt lên 20 năm qua lương tối thiểu chưa bao giờ đạt đến mức sống tối thiểu. Danh mục địa bàn áp dụng mức lương tối thiểu vùng 1. Vùng I, gồm các địa bàn:- Các quận và các huyện Gia Lâm, Đông Anh, Sóc Sơn, Thanh Trì, Từ Liêm, Thường Tín, Hoài Đức, Thạch Thất, Quốc Oai, Thanh Oai, Mê Linh, Chương Mỹ và thị xã Sơn Tây thuộc thành phố Hà Nội;- Các quận và các huyện Thủy Nguyên, An Dương, An Lão, Vĩnh Bảo thuộc thành phố Hải Phòng;- Các quận và các huyện Củ Chi, Hóc Môn, Bình Chánh, Nhà Bè thuộc thành phố Hồ Chí Minh;- Thành phố Biên Hòa và các huyện Nhơn Trạch, Long Thành, Vĩnh Cửu, Trảng Bom thuộc tỉnh Đồng Nai;- Thị xã Thủ Dầu Một và các huyện Thuận An, Dĩ An, Bến Cát, Tân Uyên thuộc tỉnh Bình Dương;- Thành phố Vũng Tàu thuộc tỉnh Bà Rịa - Vũng Tàu. 2. Vùng II, gồm các địa bàn:- Các huyện còn lại thuộc thành phố Hà Nội;- Các huyện còn lại thuộc thành phố Hải Phòng;- Thành phố Hải Dương thuộc tỉnh Hải Dương;- Thành phố Hưng Yên và các huyện Mỹ Hào, Văn Lâm, Văn Giang, Yên Mỹ thuộc tỉnh Hưng Yên;- Thành phố Vĩnh Yên, thị xã Phúc Yên và các huyện Bình Xuyên, Yên Lạc, thuộc tỉnh Vĩnh Phúc;- Thành phố Bắc Ninh, thị xã Từ Sơn và các huyện Quế Võ, Tiên Du, Yên Phong, Thuận Thành thuộc tỉnh Bắc Ninh;- Các thành phố Hạ Long, Móng Cái thuộc tỉnh Quảng Ninh;- Thành phố Thái Nguyên thuộc tỉnh Thái Nguyên;- Thành phố Việt Trì thuộc tỉnh Phú Thọ;- Thành phố Lào Cai thuộc tỉnh Lào Cai;- Thành phố Ninh Bình thuộc tỉnh Ninh Bình;- Thành phố Huế thuộc tỉnh Thửa Thiên Huế;- Các quận, huyện thuộc thành phố Đà Nẵng;- Thành phố Nha Trang và thị xã Cam Ranh thuộc tỉnh Khánh Hòa;- Các thành phố Đà Lạt, Bảo Lộc thuộc tỉnh Lâm Đồng;- Thành phố Phan Thiết thuộc tỉnh Bình Thuận;- Các huyện còn lại thuộc thành phố Hồ Chí Minh;- Thị xã Long Khánh và các huyện Định Quán, Xuân Lộc thuộc tỉnh Đồng Nai;- Các huyện Phú Giáo, Dầu Tiếng thuộc tỉnh Bình Dương;- Huyện Chơn Thành thuộc tỉnh Bình Phước;- Thị xã Bà Rịa và huyện Tân Thành thuộc tỉnh Bà Rịa - Vũng Tàu;- Thành phố Tân An và các huyện Đức Hòa, Bến Lực, Cần Đước, Cần Giuộc thuộc tỉnh Long An;- Thành phố Mỹ Tho thuộc tỉnh Tiền Giang;- Các quận thuộc thành phố Cần Thơ;- Thành phố Rạch Giá thuộc tỉnh Kiên Giang;- Thành phố Long Xuyên thuộc tỉnh An Giang;- Thành phố Cà Mau thuộc tỉnh Cà Mau. 3. Vùng III, gồm các địa bàn:- Các thành phố trực thuộc tỉnh còn lại (trừ các thành phố trực thuộc tỉnh nêu tại vùng II);- Thị xã Chí Linh và các huyện Cẩm Giàng, Nam Sách, Kim Thành, Kim Môn, Gia Lộc, Bình Giang, Tứ Kỳ thuộc tỉnh Hải Dương;- Các huyện Vĩnh Tường, Tam Đảo, Tam Dương, Lập Thạch, Sông Lô thuộc tỉnh Vĩnh Phúc;- Thị xã Phú Thọ và các huyện Phù Ninh, Lâm Thao, Thanh Ba, Tam Nông thuộc tỉnh Phú Thọ;- Các huyện Gia Bình, Lương Tài thuộc tỉnh Bắc Ninh;- Các huyện Việt Yên, Yên Dũng, Hiệp Hòa, Tân Yên, Lạng Giang thuộc tỉnh Bắc Giang;- Các thị xã Uông Bí, Cẩm Phả và các huyện Hoàng Bồ, Đông Triều thuộc tỉnh Quảng Ninh;- Các huyện Bảo Thắng, Sa Pa thuộc tỉnh Lào Cai;- Các huyện còn lại thuộc tỉnh Hưng Yên;- Các huyện Mỹ Hào, Văn Lâm, Văn Giang, Yên Mỹ thuộc tỉnh Hưng Yên;- Thị xã Sông Công và các huyện Phổ Yên, Phú Bình, Phú Lương, Đồng Hỷ, Đại Từ thuộc tỉnh Thái Nguyên;- Huyện Mỹ Lộc thuộc tỉnh Nam Định;- Các huyện Duy Tiên, Kim Bảng thuộc tỉnh Hà Nam;- Thị xã Tam Điệp và các huyện Gia Viễn, Yên Khánh, Hoa Lư thuộc tỉnh Ninh Bình;- Thị xã Bỉm Sơn và huyện Tĩnh Gia thuộc tỉnh Thanh Hóa;- Huyện Kỳ Anh thuộc tỉnh Hà Tĩnh;- Thị xã Hương Thủy và các huyện Hương Trà, Phú Lộc, Phong Điền, Quảng Điền, Phú Vang thuộc tỉnh Thừa Thiên-Huế;- Các huyện Điện Bàn, Đại Lộc, Duy Xuyên, Núi Thành thuộc tỉnh Quảng Nam;- Các huyện Bình Sơn, Sơn Tịnh thuộc tỉnh Quảng Ngãi;- Thị xã Sông Cầu thuộc tỉnh Phú Yên;- Các huyện Cam Lâm, Diên Khánh, Ninh Hòa, Vạn Ninh thuộc tỉnh Khánh Hòa;- Các huyện Ninh Hải, Thuận Bắc thuộc tỉnh Ninh Thuận;- Huyện Đăk Hà thuộc tỉnh Kon Tum;- Các huyện Đức Trọng, Di Linh thuộc tỉnh Lâm Đồng;- Thị xã La Gi và các huyện Hàm Thuận Bắc, Hàm Thuận Nam thuộc tỉnh Bình Thuận;- Các huyện Trảng Bàng, Gò Dầu thuộc tỉnh Tây Ninh;- Các thị xã Đồng Xoài, Phước Long, Bình Long và các huyện Đồng Phú, Hớn Quản thuộc tỉnh Bình Phước;- Các huyện còn lại thuộc tỉnh Đồng Nai;- Các huyện còn lại thuộc tỉnh Bình Dương;- Các huyện Long Điền, Đất Đỏ, Xuyên Mộc, Châu Đức, Côn Đảo thuộc tỉnh Bà Rịa - Vũng Tàu;- Các huyện Thủ Thừa, Đức Huệ, Châu Thành, Tân Trụ, Thạnh Hóa thuộc tỉnh Long An;- Thị xã Gò Công và huyện Châu Thành thuộc tỉnh Tiền Giang;- Huyện Châu Thành thuộc tỉnh Bến Tre;- Các huyện Bình Minh, Long Hồ thuộc tỉnh Vĩnh Long;- Các huyện thuộc thành phố Cần Thơ;- Thị xã Hà Tiên và các huyện Kiên Lương, Phú Quốc, Kiên Hải, Giang Thành, Châu Thành thuộc tỉnh Kiên Giang;- Các thị xã Châu Đốc, Tân Châu thuộc tỉnh An Giang;- Thị xã Ngã Bảy và các huyện Châu Thành, Châu Thành A thuộc tỉnh Hậu Giang;- Các huyện Năm Căn, Cái Nước, U Minh, Trần Văn Thời thuộc tỉnh Cà Mau. 4. Vùng IV, gồm các địa bàn còn lại.(Nguồn: Báo điện tử VnExpress) '),
(36, 'Theo đó, sẽ miễn thuế đối với đất ở trong hạn mức tại địa bàn có điều kiện kinh tế - xã hội đặc biệt khó khăn; Đất của dự án đầu tư thuộc lĩnh vực đặc biệt khuyến khích đầu tư (đặc biệt ưu đãi đầu tư); dự án đầu tư tại địa bàn có điều kiện kinh tế - xã hội đặc biệt khó khăn; dự án đầu tư thuộc lĩnh vực khuyến khích đầu tư (ưu đãi đầu tư) tại địa bàn có điều kiện kinh tế - xã hội khó khăn; đất của doanh nghiệp sử dụng trên 50% số lao động là thương binh, bệnh binh...Giảm 50% số thuế phải nộp đối với đất ở trong hạn mức tại địa bàn có điều kiện kinh tế - xã hội khó khăn; Đất của dự án đầu tư thuộc lĩnh vực ưu đãi đầu tư; dự án đầu tư tại địa bàn có điều kiện kinh tế - xã hội khó khăn; đất của DN sử dụng từ 20% đến 50% số lao động là thương binh, bệnh binh.Đất ở trong hạn mức của thương binh hạng 3/4, 4/4; người hưởng chính sách như thương binh hạng 3/4, 4/4; bệnh binh hạng 2/3, 3/3; con của liệt sỹ không được hưởng trợ cấp hàng tháng. Người nộp thuế gặp khó khăn do sự kiện bất khả kháng nếu giá trị thiệt hại về đất và nhà trên đất từ 20% đến 50% giá tính thuế nhưng phải có xác nhận của UBND cấp xã nơi có đất bị thiệt hại..Do vậy, nếu các xã thuộc danh mục các xã đặc biệt khó khăn quy định tại các Quyết định số 164/2006/QĐ-TTg ngày 11-7-2006, Quyết định số 113/2007/QĐ-TTg ngày 20-7-2007 và Quyết định số 69/2008/QĐ-TTg ngày 19-5-2008 của Thủ tướng Chính phủ nhưng không thuộc danh mục địa bàn có điều kiện kinh tế - xã hội khó khăn, đặc biệt khó khăn theo quy định tại Nghị định số 108/2006/NĐ-CP ngày 22-9-2006 của Chính phủ và các văn bản sửa đổi, bổ sung thì không thuộc diện được xét miễn, giảm thuế sử dụng đất phi nông nghiệp.Mai Ka(Trích nguồn: Báo Hải Quan)');
INSERT INTO `nv3_vi_news_bodytext` (`id`, `bodytext`) VALUES
(37, 'Theo TS. Nguyễn Xuân Sơn - Phó Ban Cải cách Tổng cục Thuế, DN thuộc diện chịu thuế thu nhập từ chuyển nhượng bất động sản bao gồm: DN thuộc mọi thành phần kinh tế, mọi ngành nghề có thu nhập từ hoạt động chuyển nhượng bất động sản; DN kinh doanh bất động sản có thu nhập từ hoạt động cho thuê lại đất.Thu nhập từ hoạt động chuyển nhượng bất động sản bao gồm: thu nhập từ chuyển nhượng quyền sử dụng đất, chuyển nhượng quyền thuê đất (gồm cả chuyển nhượng dự án gắn với chuyển nhượng quyền sử dụng đất, quyền thuê đất theo quy định của pháp luật); Thu nhập từ hoạt động cho thuê lại đất của doanh nghiệp kinh doanh bất động sản theo quy định của pháp luật về đất đai không phân biệt có hay không có kết cấu hạ tầng, công trình kiến trúc gắn liền với đất; Thu nhập từ chuyển nhượng nhà, công trình xây dựng gắn liền với đất, kể cả các tài sản gắn liền với nhà, công trình xây dựng đó nếu không tách riêng giá trị tài sản khi chuyển nhượng không phân biệt có hay không có chuyển nhượng quyền sử dụng đất, chuyển nhượng quyền thuê đất; Thu nhập từ chuyển nhượng các tài sản gắn liền với đất; Thu nhập từ chuyển nhượng quyền sở hữu hoặc quyền sử dụng nhà ở.Nếu so với các qui định trước đây thì qui định mới của Bộ Tài chính đã bổ sung thêm nhóm: Thu nhập từ chuyển nhượng nhà, công trình xây dựng gắn liền với đất, kể cả các tài sản gắn liền với nhà, công trình xây dựng đó nếu không tách riêng giá trị tài sản khi chuyển nhượng không phân biệt có hay không có chuyển nhượng quyền sử dụng đất, chuyển nhượng quyền thuê đất.Theo TS. Nguyễn Xuân Sơn, một trong những căn cứ tính thuế là doanh thu từ hoạt động chuyển nhượng bất động sản được xác định theo giá thực tế chuyển nhượng bất động sản theo hợp đồng chuyển nhượng, mua bán bất động sản phù hợp với quy định của pháp luật (bao gồm cả các khoản phụ thu và phí thu thêm nếu có).Trường hợp giá chuyển quyền sử dụng đất theo hợp đồng chuyển nhượng, mua bán bất động sản thấp hơn giá đất do UBND tỉnh, thành phố trực thuộc Trung ương quy định tại thời điểm ký hợp đồng chuyển nhượng bất động sản thì tính theo giá đất do UBND tỉnh, thành phố trực thuộc Trung ương quy định tại thời điểm ký hợp đồng chuyển nhượng bất động sản.Đối với, trường hợp DN được Nhà nước giao đất, cho thuê đất để thực hiện dự án đầu tư cơ sở hạ tầng, nhà để chuyển nhượng hoặc cho thuê, có thu tiền ứng trước của khách hàng theo tiến độ dưới mọi hình thức thì thời điểm xác định doanh thu tính thuế thu nhập DN tạm nộp là thời điểm thu tiền của khách hàng, cụ thể: Trường hợp DN có thu tiền của khách hàng mà chưa xác định được chi phí tương ứng với doanh thu thì DN kê khai tạm nộp thuế thu nhập doanh nghiệp theo tỷ lệ 1% trên doanh thu thu được tiền và doanh thu này chưa phải tính vào doanh thu tính thuế thu nhập DN trong năm.Trường hợp DN có cho thuê lại đất thì doanh thu để tính thu nhập chịu thuế là số tiền bên thuê trả từng kỳ theo hợp đồng thuê. Trường hợp bên thuê trả tiền thuê trước cho nhiều năm thì doanh thu để tính thu nhập chịu thuế được phân bổ cho số năm trả tiền trước hoặc được xác định theo doanh thu trả tiền một lần. Việc chọn hình thức doanh thu trả tiền một lần chỉ được xác định khi DN đã đảm bảo hoàn thành các trách nhiệm tài chính đối với Nhà nước, đảm bảo các nghĩa vụ đối với các bên thuê lại đất cho hết thời hạn cho thuê lại đất.Trường hợp DN đang trong thời gian hưởng ưu đãi thuế thu nhập DN lựa chọn phương pháp xác định doanh thu để tính thu nhập chịu thuế là toàn bộ số tiền thuê bên thuê trả trước cho nhiều năm thì việc xác định số thuế thu nhập doanh nghiệp từng năm miễn thuế, giảm thuế căn cứ vào tổng số thuế thu nhập DN của số năm trả tiền trước chia số năm bên thuê trả tiền trước.Trường hợp trước năm 2012, DN có cho thuê lại đất thu tiền trả trước cho nhiều năm và đã xác định doanh thu tính thuế theo hình thức phân bổ cho số năm trả tiền trước, nếu đến năm 2012 DN vẫn còn trong thời hạn cho thuê lại đất thì được lựa chọn xác định doanh thu tính thuế phân bổ hàng năm hoặc theo doanh thu trả tiền một lần cho số năm còn lại của thời hạn cho thuê lại đất. (Trích nguồn: Báo Hải Quan)'),
(38, ' Sự trở lại của hợp tác xã thời kỳ mới đã tạo động lực để đổi mới tư duy và đem lại hiệu quả kinh tế cho người nông dân. Cụ thể, trong giai đoạn từ 2002 – 2011 khu vực hợp tác xã đóng góp bình quân 6,38% tổng sản phẩm nội địa, trong khi chỉ chiếm 0,58% vốn đầu tư tài sản cố định và đầu tư tài chính dài hạn; tạo việc làm thường xuyên cho khoảng 300.000 lao động trong tổng số 14.500 hợp tác xã; đồng thời có tác động quan trọng đối với kinh tế hộ, cá thể xã viên; góp phần xây dựng hạ tầng cơ sở nông thôn, nông nghiệp. Với cơ chế chính sách và tổ chức thực hiện tốt, hợp tác xã đã thu hút được nhiều hộ nông dân tham gia. Người nông dân được hưởng nhiều lợi ích như được mua hàng hóa, sản phẩm với giá cả hợp lý; giảm chi phí sản xuất và các tầng nấc trung gian; góp phần tạo mối liên kết hợp tác giữa các hộ nông dân. Đồng thời, tạo điều kiện tốt để hình thành những cánh đồng mẫu lớn, từ đó tạo ra những sản phẩm có năng suất, chất lượng đồng nhất, nâng cao sức cạnh tranh của nông sản Việt Nam... Nhờ vậy, các chính sách của Nhà nước đến được đúng đối tượng yếu thế cần được hỗ trợ, góp phần lành mạnh hóa môi trường kinh doanh và phát triển bền vững của hợp tác xã. Có một thực tế trong phát triển hợp tác xã là trình độ công nghệ còn lạc hậu, năng lực đội ngũ cán bộ quản lý còn yếu, chất lượng hiệu quả hoạt động còn thấp; nhiều hợp tác xã vẫn còn lúng túng trong tổ chức hoạt động, không rõ hướng đi. Bên cạnh đó, Tổ chức đóng vai trò dẫn dắt, chỉ đường là Liên hiệp hợp tác xã chưa phát huy được hết khả năng, chưa hấp dẫn nhân dân, tổ chức tham gia tích cực, đông đảo. Số lượng hợp tác xã đang hoạt động giảm dần qua các năm, nếu năm 2007 có 14.500 hợp tác xã, thì đến năm 2009 chỉ còn 12.249; tốc độ tăng trưởng thấp, chỉ bằng ½ tốc độ tăng trưởng chung của nền kinh tế. Mặt khác, trong vòng 15 năm qua đóng góp của hợp tác xã vào GDP liên tục giảm, nếu năm 1995 là 11%, thì đến 2012 giảm xuống còn 5,22%. Như vậy, hiệu quả hoạt động của hợp tác xã có suy giảm. Đây là một thách thức không nhỏ với một nước có nền nông nghiệp là trọng tâm như Việt Nam . Nhận thức của người nông dân còn chưa đầy đủ, chưa thống nhất về tính ưu việt của tổ chức hợp tác xã chính là một trong các nguyên nhân chủ quan dẫn đến hoạt động của hợp tác xã thời gian qua chưa hiệu quả. Trong khi tâm lý xã hội còn bị ảnh hưởng của mô hình hợp tác xã kiểu cũ, hoài nghi về vai trò và hiệu quả của tổ chức hợp tác xã; một số cán bộ, xã viên còn nặng tính bao cấp, thụ động, trông chờ vào sự bao cấp của nhà nước. Các chuyên gia cho rằng đây là những nguyên nhân quan trọng nhất, ảnh hưởng trực tiếp tới hoạt động và sự phát triển của hợp tác xã; bản chất của hợp tác xã trong luật chưa được làm rõ dẫn đến cách hiểu khác nhau đã tác động đến nhận thức về quyền và nghĩa vụ của xã viên; còn xã viên thì chưa thực sự là chủ mà còn mang tính hình thức. .. Nhìn nhận về những tồn tại hoạt động trong hợp tác xã, Vụ trưởng Vụ Hợp tác xã, Bộ Kế hoạch và Đầu tư Nguyễn Minh Tú cho biết, nguyên nhân quan trọng nhất, nguyên nhân của mọi nguyên nhân là nhận thức của người nông dân chưa được đầy đủ và đi kèm theo với hợp tác xã chuyển đổi cũng không rõ; đồng thời công tác nghiên cứu lý luận còn chưa hiệu quả, công tác thông tin tuyên truyền do vậy cũng không theo kịp; ngoài ra, chưa có bộ máy tổ chức quản lý nhà nước chuyên ngành luật, để giám sát, kiểm tra, thay đổi luật và xử lý vi phạm. Dù chúng ta đang công nghiệp hóa hiện đại hóa mạnh mẽ đất nước. Nhưng rõ ràng nông nghiệp và kinh tế nông thôn vẫn đang đóng vai trò quan trọng của nền kinh tế ; nông dân là lực lượng chiếm đại đa số dân cư, là lực lượng không thế thiếu trong phát triển nông nghiệp, nông thôn. Và hợp tác xã có vai trò hỗ trợ kinh tế thành viên là nông dân, góp phần bảo đảm an ninh lương thực cho toàn xã hội. Chính vì vậy, việc xây dựng và tạo điều kiện thuận lợi cho hợp tác xã phát triển là điều rất cần thiết . Có nhiều giải pháp được đưa ra nhằm tháo gỡ khó khăn, tạo điều kiện cho hợp tác xã phát triển, trong đó vấn về nâng cao nhận thức của người dân về vai trò và hiệu quả của hợp tác xã đặc biệt được chú trọng. Đồng thời, xác định đúng vai trò của hợp tác xã trong thời kỳ mới. Ngay trong Luật Hợp tác xã (sửa đổi) cần phải làm rõ bản chất của tổ chức hợp tác xã; lãnh đạo các địa phương, các ngành và đặc biệt là người dân nhận thức đầy đủ về bản chất và tính ưu việt của tổ chức hợp tác xã; đưa hợp tác xã về hoạt động đúng bản chất và tạo điều kiện cho các hợp tác xã hoạt động hiệu quả. Một giải pháp cũng khá quan trọng mà các chuyên gia đưa ra là làm rõ bản chất tổ chức Liên minh hợp tác xã để liên kết nông dân theo quy mô lớn hơn; nâng cao tính minh bạch trong tài chính của hợp tác xã; cơ cấu lại chính sách hỗ trợ phù hợp với bản chất hợp tác xã, mang lại lợi ích trực tiếp cho xã viên; làm rõ chính sách hỗ trợ vốn, tăng cường năng lực qua đào tạo nguồn nhân lực. Ngoài ra, cần phân công cơ quan chuyên trách về hợp tác xã, từ đó quản lý, giám sát, hỗ trợ trong từng giai đoạn cho phù hợp với quá trình thực hiện tái cơ cấu nền kinh tế; huy động sự tham gia tích cực của đoàn thể, hội, hiệp hội; liên kết hợp tác các hợp tác xã, giữa hợp tác xã nông nghiệp với các loại hình hợp tác xã khác và với doanh nghiệp; sớm đưa ra những giải pháp hữu hiệu để đề xuất với cơ quan chức năng ban hành để hỗ trợ hợp tác xã ngày càng phát triển hơn. Hoa Lê(Nguồn: Báo đại biểu nhân dân)'),
(39, 'Phó chủ tịch QH Uông Chu Lưu: Sự khác biệt giữa casino và trò chơi có thưởng là gì? Theo tôi, nếu không làm rõ sự khác biệt giữa casino với trò chơi điện tử sẽ dẫn đến lẫn lộn. Bởi vì thực ra casino chỉ khác với trò chơi điện tử ở những đơn vị kinh doanh này là có bàn chơi, tức là tương tác giữa người với người. Còn đây là tương tác giữa người với máy. Như vậy trong casino có 2 kiểu để chơi: một là chơi với máy, hai là có bàn chơi. Vậy bây giờ xác định hai cái này có gì khác biệt? Trước đây tôi nhớ trong Nghị định số 108 năm 2006 của Chính phủ thì Thủ tướng Chính phủ đã có quyết định chấp nhận chủ trương đầu tư kinh doanh casino, bây giờ sự khác nhau giữa cái đó với cái này như thế nào. Nếu chỗ này không làm rõ thì sẽ dẫn đến giữa việc kinh doanh ở chỗ này và kinh doanh casino không có gì khác nhau, nếu chỉ trông vào phương tiện, hình thức chơi. Thứ hai, cơ chế giải quyết tranh chấp trong này không nêu ra sẽ rất phức tạp về sau. Trên thực tế, hiện nay đang có một vụ kiện từ tháng 6 của năm nay ở tại Tòa án quận 1, TP Hồ Chí Minh. Khi người ta chơi thì máy hiện lên số người ta trúng thưởng, đến khi người ta đề nghị với câu lạc bộ và đơn vị kinh doanh đó trả thưởng thì nói là lỗi của máy. Cho nên vấn đề tôi muốn đặt ra ở đây là những cơ chế giải quyết tranh chấp. Nếu không xác định thì sau này rất khó giải quyết những tranh chấp như vậy. Ở đây có đặt ra vấn đề là có xác định tỷ lệ phần trăm trả thưởng bình quân cho người chơi và có xác định giá trị cá cược của người chơi đối với trò chơi điện tử có thưởng này không, ví dụ chỉ chơi cá cược này đến một giá trị nhất định nào đó thôi. Nếu trong nghị định không xác định rõ, cụ thể thì sau này khi có tranh chấp phát sinh sẽ rất phức tạp.Điều 13 của Nghị định quy định quản lý thiết bị, trò chơi điện tử giao cho Bộ Tài chính chịu trách nhiệm bảo đảm điều kiện kỹ thuật của các máy này không biết có phù hợp không hay là Bộ Công thương hay Bộ Khoa học và Công nghệ. Nếu bây giờ giao cho Bộ Tài chính xác định, kiểm định về điều kiện kỹ thuật các máy đó không biết có phù hợp không?Đối với việc xử phạt cũng phải làm rõ. Một là các loại hành vi này cố gắng quy định thật cụ thể từng loại vi phạm một, mỗi loại hành vi như thế gắn với mức phạt, khoảng cách đừng quá rộng ví dụ 50 - 100 triệu hoặc từ 150 - 200 triệu trong cùng một hành vi thì sau này rất phức tạp ở chỗ người vận dụng, người đi áp dụng xử phạt. Nên đã là một hành vi cụ thể và không có tình tiết tăng nặng giảm nhẹ thì nên quy định mức cứng trong Nghị định sẽ hợp lý hơn. Chủ tịch Hội đồng Dân tộc K’Sor Phước: Cần có quy định chặt chẽ về vấn đề an ninh, trật tự xã hội Về cơ bản tôi đồng tình với việc ban hành Nghị định này, tuy nhiên trong Báo cáo, đặc biệt là Báo cáo về tác động tôi thấy chưa nói nhiều đến tác động về an ninh trật tự. Nếu chúng ta phổ biến việc này thì sẽ như thế nào. Tôi có dịp đi Macao, Canada và Mỹ và tôi đã đến các casino, ở đây các loại hình chơi rất phong phú, có loại không chỉ người với máy mà người với người. Đối với người với máy thì có 2 cấp độ. Cấp độ giữa cá nhân người chơi với chính máy đó. Có một loại nữa đó là một tập thể khá đông, khoảng 3, 4 người thậm chí 5, 6 người cùng chơi với một máy và thường những cái này nó có đối tượng trung gian và lúc đó thường hay có những kỹ xảo để điều chỉnh máy để nhà hàng đạt được lợi ích. Ngoài ra, những chỗ này không chỉ có dịch vụ về đánh bạc mà còn các dịch vụ khác để hút tiền của khách hàng. Vấn đề này ta phải tính đến.Thứ ba là khách nước ngoài vào Việt Nam để tham gia trò chơi này cũng rất đa dạng, có những người rất đàng hoàng, chỉ giải trí nhưng có những người sang để cá cược, thậm chí có tội phạm và nghiện ma túy vào những khu vực này. Nên phải xác định rằng những điểm này cần phải có quy định rất chặt chẽ về vấn đề trật tự xã hội an ninh ở đây như thế nào.Một vấn đề nữa là ta chỉ nêu các khách sạn 5 sao, tôi cũng đồng ý như vậy, tuy nhiên bây giờ cũng có các resort, các sân golf, các sân golf làm khách sạn 5 sao rất nhiều do vậy phải nghiên cứu thật kỹ phần có thể lợi dụng việc này để lách luật và chống thất thu ngân sách. Về xử phạt hành chính, theo tôi không nên nói chung chung các chính quyền các cấp. Chính quyền cơ sở cấp phường, xã chỉ chịu trách nhiệm về mối quan hệ với việc bảo đảm trật tự xã hội ở các điểm này và xử lý người Việt Nam khi vi phạm. Còn lại tôi đề nghị giao cho chính quyền cấp quận, huyện phải chịu trách nhiệm trực tiếp. Chủ nhiệm Ủy ban Về các vấn đề xã hội Trương Thị Mai: Tạo nguồn thu ổn định và bền vững cho ngân sách không phải là mục tiêu lớn Do phạm vi là dành cho người nước ngoài tại Việt Nam nên tác động xã hội cũng không quá phức tạp, tất nhiên vấn đề an ninh, trật tự trong đánh giá tác động cũng có nói rồi. Tôi đồng ý với ý kiến trong Báo cáo thẩm tra mà ghi tạo nguồn thu ổn định, bền vững cho ngân sách nhà nước thì cũng không phải là mục tiêu lớn. Phạm vi điều chỉnh của Nghị định là đối với người nước ngoài đến Việt Nam thì được tham gia vào hoạt động này còn tuyệt đối người Việt Nam không thuộc phạm vi điều chỉnh. Người Việt Nam đang sinh sống tại Việt Nam, quốc tịch Việt Nam, công dân Việt Nam tuyệt đối là không nằm trong phạm vi điều chỉnh của Nghị định này. Vì vậy, tôi đề nghị loại khỏi Nghị định này mấy điểm sau. Một là Khoản 10, Điều 4 có việc cấm tổ chức môi giới cung cấp dịch vụ đưa người Việt Nam đi chơi trò chơi điện tử có thưởng ở nước ngoài. Đối tượng này đâu có nằm trong phạm vi điều chỉnh của Nghị định này. Đưa người Việt Nam đi đánh bạc ở nước ngoài thì hoàn toàn không nằm trong phạm vi điều chỉnh của Nghị định. Thứ hai, Điểm a, Khoản 3, Điều 31 cũng ghi: "Bộ Công an có trách nhiệm ngăn chặn người Việt Nam trong nước ra nước ngoài đánhh bạc". Việc này cũng không nằm trong phạm vi của Nghị định này, Bộ Công an sẽ có trách nhiệm ngăn chặn người Việt Nam đi đánh bạc ở nước ngoài vì vi phạm pháp luật, nhưng không nằm trong phạm vi điều chỉnh của Nghị định này. Thứ ba, Khoản 5, Điểm c trong Điều 31 giao cho Bộ Thông tin và Truyền thông phải làm công tác tuyên truyền phổ biến, nghiêm cấm người Việt Nam tham gia tổ chức đánh bạc trái phép là được, nhưng ra nước ngoài đánh bạc cũng không nằm trong phạm vi điều chỉnh của Nghị định này. Điều 31, Điểm a, Khoản 4, theo tôi nên giao cho Bộ VH, TT và DL phải phối hợp với Bộ Tài chính để bảo đảm các trò chơi điện tử có thưởng phù hợp thuần phong mỹ tục, thẩm mỹ người Việt Nam. Chủ nhiệm Ủy ban Quốc phòng và An ninh Nguyễn Kim Khoa: Chắc chắn sẽ có tác động đến tâm lý người Việt… Đây là một loại hình kinh doanh khá đặc biệt và cũng là một loại hình kinh doanh có thể nói dù rằng người Việt Nam không tham gia nhưng chắc chắn là có yếu tố tác động đến tâm lý truyền thống và văn hóa của người Việt Nam ở khu vực có liên quan đến hoạt động này.Vấn đề thứ hai, đây là hoạt động kinh doanh có điều kiện mà chúng ta không khuyến khích nên phải quản lý chặt chẽ. Trong Tờ trình của Chính phủ và trong Nghị định đã có quản lý vấn đề này. Nhưng tôi băn khoăn nhất là sau khi Nghị định này được ban hành thì nó sẽ phát triển với số lượng như thế nào? Với điều kiện kinh doanh như thế này, tôi nghĩ rằng tình hình có thể sẽ phát triển tràn lan. Ví dụ như tất cả khách sạn, trong tất cả các tiêu chí thì tiêu chí quan trọng nhất là khách sạn 5 sao và cơ sở khách sạn cao cấp theo quy định của Bộ VH, TT và DL. Tới đây sẽ phát triển không những ở các trung tâm như TP Hồ Chí Minh, Hà Nội mà sẽ phát triển đến các địa phương và phát triển bao nhiêu khách sạn 5 sao, bao nhiêu khách sạn cao cấp thì sẽ có loại hình này, có phải vậy không. Trong nguyên tắc và kể cả các nội dung, tôi thấy không có quy định nào về quy hoạch hoạt động này. Vậy thì có theo đúng định hướng của chúng ta rằng đây là một loạt hình kinh doanh có điều kiện phải quản lý chặt chẽ và cũng không khuyến khích không? Đây là vấn đề cần phải nghiên cứu. Một vấn đề nữa là cần nghiên cứu để tránh những tác động tiêu cực. Trên thực tế người Việt Nam ra nước ngoài đánh bạc khá nhiều, đặc biệt là biên giới Việt Nam - Campuchia, nhất là cửa khẩu Mộc Bài - Tây Ninh. Để ngăn chặn việc này thì lại không thuộc phạm vi điều chỉnh của Nghị định nhưng chắc chắn nếu phát triển loại hình này thì chắc chắn sẽ tác động đến tâm lý của người Việt Nam. Cho nên tôi đề nghị điều kiện về địa điểm kinh doanh không chỉ là địa điểm tách rời các dịch vụ khác của khách sạn, của cơ sở kinh doanh du lịch, nên nghiên cứu tránh nơi gần khu dân cư, tập trung ở các khu dân cư. Chủ nhiệm Ủy ban Kinh tế Nguyễn Văn Giàu: Đây chỉ là loại hình dịch vụ góp phần phát triển du lịch Trò chơi này chỉ dành cho người nước ngoài, ta khẳng định chắc chắn như thế. Loại hình kinh doanh này là loại hình không khuyến khích và có điều kiện. Từ tư tưởng này tôi nghĩ nên thể hiện bám vào tư tưởng và cách quản lý đó. Điều 7 và Điều 9 về số lượng máy và đối tượng được tham gia, tôi đề nghị phải chi tiết hơn, rõ ràng hơn. Bởi vì từ tư tưởng chính trị của chúng ta là không khuyến khích thì đừng biến nơi này thành nơi cờ bạc, mà nơi này cần dịch vụ này để phát triển ngành du lịch, trong quá trình hội nhập. Do vậy, tư tưởng Điều 9 rất quan trọng về phạm vi điều chỉnh. Điểm thứ hai, Nghị định này liên quan đến nước ngoài nên có 3 nội dung trong dự thảo Nghị định giao cho Bộ Tài chính hướng dẫn. Ta đã có quá trình tích lũy 20 năm và cũng đã ổn định rồi, nên đưa vào quy định trong Nghị định. Khoản 2 Điều 7 quy định về chủng loại, loại hình trò chơi, việc này đâu cần phải đợi Bộ Tài chính hướng dẫn, ta nên quy định thẳng trong Nghị định. Khoản 3, Điều 14 là đối tượng được mua máy thiết bị dự phòng để thay thế cần thiết cũng nên quy định luôn chứ không cần Bộ Tài chính hướng dẫn. Điểm c, Khoản 3, Điều 18 về điều kiện người quản lý và điều hành theo tôi đây là vấn đề rất quan trọng và phải quy định rõ trong Nghị định chứ không nên để hướng dẫn bởi vấn đề này đã rõ tiêu chuẩn, tiêu chí. Thứ ba, về phân cấp, nên phân cấp một cách rõ ràng hơn thì mới quản lý tốt được. Theo tôi nên phân cấp cho UBND ở địa phương để có người chịu trách nhiệm, còn nếu công tác thanh tra, giám sát, dẫn vào bộ trên này thì chúng ta không “dài tay” nổi.(Nguồn: Báo điện tử Đại biểu nhân dân)'),
(40, 'Diễn biến phức tạp, thủ đoạn tinh vi. Trong bối cảnh kinh tế hiện nay, những tội phạm về buôn lậu, gian lận thương mại, trốn thuế, về mua bán và sử dụng các loại giấy tờ có giá giả được dự báo vẫn tiếp tục diễn biến khó lường với thủ đoạn tinh vi. Đây là một thách thức cho công tác phòng, chống các hành vi vi phạm và tội phạm về thuế. Quá trình hội nhập cũng đã xuất hiện nhiều loại tội phạm mới mà hệ thống pháp luật chưa theo kịp, đặc biệt là đối với các hành vi mua bán, sử dụng hóa đơn trái phép, trong đó nguy hiểm và nghiêm trọng nhất là tội phạm lập doanh nghiệp “ma” chỉ để mua bán hóa đơn. Tình trạng mua bán, sử dụng trái phép hóa đơn nhằm thu lợi bất chính đang là vấn đề bức xúc trên phạm vi rộng. Đấy là chưa kể nhiều loại tội phạm mới tiếp tục xuất hiện và sẽ xuất hiện như gian lận hoàn thuế xuất nhập khẩu ở khu kinh tế thương mại tự do, gian lận thuế trong các ngành kinh doanh bảo hiểm, thuế nhà thầu, kinh doanh thương mại điện tử, kinh doanh internet, kinh doanh tư vấn pháp luật… Cùng với tác động của cuộc khủng hoảng, tình hình vi phạm, tội phạm trong lĩnh vực tài chính, chủ yếu trong lĩnh vực ngân hàng, trong một vài năm vừa qua cũng diễn biến hết sức phức tạp. Số vụ án nghiêm trọng xảy ra ngày càng tăng về số vụ và mức thiệt hại. Nhiều vụ án có sự tham gia trực tiếp hoặc tiếp tay của cán bộ ngân hàng. Tổng số thiệt hại lên đến hàng chục nghìn tỷ đồng, trên 3.000 lượng vàng và mới thu hồi được gần 2.000 tỷ đồng. Chỉ tính riêng trong năm 2010 – 2011, các cơ quan chức năng đã phát hiện xác lập án điều tra 69 vụ, khởi tố 40 vụ và 70 cán bộ ngân hàng, thiệt hại hơn 8.000 tỷ đồng. Một số vụ nghiêm trong liên tiếp xảy ra như vụ vợ chồng Hồ Minh Hậu, Phạm Thị Ái Loan lừa đảo chiếm đoạt gần 400 tỷ đồng của 3 ngân hàng là Ngân hàng liên doanh Việt – Nga, Vietcombank chi nhánh Bình Dương, BIDV chi nhánh Phú Yên; vụ Công ty TNHH Xuất nhập khẩu Công Chính và Công ty TNHH Xuất nhập khẩu Thái Nguyên tại Lâm Đồng lừa đảo chiếm đoạt 600 tỷ đồng của Techcombank chi nhánh TP.HCM; vụ lợi dụng chức vụ, quyền hạn trong khi thi hành công vụ xảy ra tại Công ty Cho thuê tài chính II – Agribank gây thiệt hại ước tính 1.600 tỷ đồng; mới nhất là vụ Huỳnh Thị Huyền Như (Vietinbank chi nhánh TP.HCM) lừa đảo, chiếm đoạt 3.600 tỷ đồng của hơn 30 doanh nghiệp cùng 20 cá nhân và vụ bê bối tài chính tại Ngân hàng ACB… Bổ sung tội thiếu trách nhiệm của nhân hàng “tư” Khi thực tiễn đấu tranh phòng, chống các tội phạm trong những lĩnh vực này đang gặp nhiều khó khăn đối với các cơ quan chức năng thì BLHS hiện hành lại quá thiếu các quy định để xử lý những hành vi như vậy và tạo ra “lỗ hổng” khá lớn để các đối tượng lợi dụng những kẽ hở của pháp luật thực hiện hành vi phạm tội. Đơn cử, trong lĩnh vực thuế, BLHS chỉ có duy nhất 1 điều quy định về trốn thuế, còn các hành vi khác như chây ỳ thuế hoặc liên quan đến việc gom hàng hóa trôi nổi trên thị trường, hàng nhập lậu để hợp thức hóa, lập hồ sơ hoàn thuế, khấu trừ thuế giá trị gia tăng đầu vào nhằm chiếm đoạt tiền thuế giá trị gia tăng của Nhà nước hoặc để hạch toán tăng giá vốn, tăng chi phí trốn thuế thu nhập doanh nghiệp… thì chưa hề được quy định. Các cơ quan tiến hành tố tụng đành phải giải quyết, xử lý các hành vi trên theo những quy định khác của BLHS. Mặt khác, các tội phạm về tài chính – kế toán cũng không được quy định một cách riêng rẽ và cụ thể mà chỉ được quy định chung chung trong Chương XVI. Thực tế điều tra, truy tố, xét xử các vụ án này cho thấy, đối với các tội phạm về kế toán thường bị xử lý về các tội như tham ô, lừa đảo chiếm đoạt tài sản, cố ý làm trái hoặc lợi dụng chức vụ, quyền hạn… bởi BLHS không có bất kỳ quy định riêng nào đối với tội phạm trong lĩnh vực kế toán. Hạn chế đáng kể ấy của pháp luật hình sự hiện hành cần sớm được khắc phục để tạo thuận lợi cho các cơ quan tiến hành tố tụng trong quá trình điều tra, xử lý các hành vi vi phạm. Xuất phát từ thực trạng trên, ông Nông Xuân Trường (Vụ 1, VKSNDTC) đề nghị hoàn thiện các quy định của BLHS theo hướng sau: Đối với tội trốn thuế, cần tăng mức phạt tiền lên mức tối đa, gấp đôi hoặc gấp ba quy định hiện hành nhằm tăng cường tính răn đe, giáo dục. Về tội in, phát hành, mua bán trái phép hóa đơn, chứng từ thu nộp ngân sách nhà nước, cần phân biệt rõ 2 loại hóa đơn là hóa đơn chưa ghi nội dung và hóa đơn có ghi nội dung giá trị hàng hóa, dịch vụ kèm theo. Có ý kiến thì cho rằng, nên bổ sung vào BLHS một điều luật mới quy định về hành vi thiếu trách nhiệm của nhân viên các ngân hàng thương mại cổ phần ngoài quốc doanh. Bởi lẽ có những nhân viên của các ngân hàng này thiếu trách nhiệm gây ra hậu quả rất nghiêm trọng nhưng các cơ quan tiến hành tố tụng rất lúng túng, thậm chí không xử lý được vì có thiệt hại thực tế về tài sản, song tài sản đó lại không phải là tài sản nhà nước và đối tượng phạm tội cũng không phải là chủ thể đặc biệt của tội thiếu tinh thần trách nhiệm. (Nguồn: Báo Pháp luật Việt Nam) '),
(41, 'Tại cuộc tọa đàm với sự tham dự của gần 100 đại diện doanh nghiệp, diễn giả Nguyễn Hồng Hà, Phó giám đốc VCCI – chi nhánh TPHCM, dẫn chứng những điểm mới tích cực mà Nghị định 46 được kỳ vọng sẽ mang lại cho thị trường lao động, đó là rút ngắn thời gian xử lý thủ tục, đơn giản hóa thủ tục hành chính và linh hoạt hơn đối với lao động nước ngoài có trình độ. Tuy nhiên, bà Hà cũng nêu ra những vấn đề có thể gây e ngại nơi doanh nghiệp tuyển dụng lao động, đó là hiệu quả của sự phối hợp giữa các cơ quan ban ngành có liên quan trong việc thực thi nghị định này.Diễn giả Oliver Massmann, Tổng giám đốc công ty luật Duane Morris Vietnam, cũng nêu ra những điểm tích cực của nghị định mới, cụ thể trong vấn đề mở rộng diện người lao động nước ngoài được miễn giấy phép lao động tại Việt Nam. Tuy nhiên, theo ông, Nghị định 46 có khá nhiều điểm bất hợp lý và điều này có thể gây khó cho các doanh nghiệp.Ông dẫn chứng về yêu cầu thông báo công khai nhu cầu tuyển dụng người lao động Việt Nam vào các vị trí dự kiến tuyển lao động nước ngoài. Điều này được quy định trong Điều 1.3 và 1.9 của Nghị định 46. Cụ thể, doanh nghiệp trước khi tuyển lao động người nước ngoài, ít nhất 30 ngày, người sử dụng lao động phải thông báo nhu cầu tuyển người lao động Việt Nam vào các vị trí công việc dự kiến tuyển người nước ngoài trên cả báo trung ương và báo địa phương.Theo ông Massmann, điều này sẽ làm quá trình tuyển dụng của doanh nghiệp bị kéo dài bắt buộc phải áp dụng cho tất cả các nhân viên nước ngoài, bao gồm cả giám đốc điều hành và chuyên gia kỹ thuật hàng đầu. Còn nếu doanh nghiệp không thực sự muốn tốn thời gian cho quá trình tìm hiểu nghiên cứu hồ sơ, phỏng vấn để sàng lọc ứng viên sau khi đăng thông báo thì đối mặt với nguy cơ bị kiện từ các ứng viên là lao động Việt Nam.Một số đại diện doanh nghiệp và các hiệp hội doanh nghiệp cũng chia sẻ quan điểm của ông Massmann rằng quy định mới này có thể gây ảnh hưởng đến cả các doanh nghiệp Việt Nam đang muốn tuyển dụng lao động nước ngoài cấp cao nhằm tăng vị thế cạnh trang và phục vụ cho mục tiêu mở rộng ra thị trường nước ngoài.Bên cạnh đó, ông Massmann e ngại quy định này sẽ vi phạm điều khoản 8.2 trong hiệp định thương mại song phương Việt - Mỹ (BTA) về đảm bảo quyền của các công ty tham gia quản lý nhân viên hàng đầu của họ bất kể quốc tịch.Một quy định khác được đánh giá thiếu tính khả thi đó là Điều 1.13 của Nghị định 46 với nội dung khi gia hạn giấy phép cho người lao động nước ngoài, doanh nghiệp phải nộp bản sao hợp đồng học nghề với người lao động Việt Nam nhằm đào tạo người thay thế vị trí trên của người nước ngoài.Ông Massmann e ngại đã có sự lẫn lộn giữa “hợp đồng học nghề” (apprenticeship contract) và “hợp đồng đào tạo” (training contract) vì trên thực tế, hợp đồng học nghề có thể được ký bởi doanh nghiệp với một người sẽ được đào tạo trở thành công nhân, người thợ chứ không thể trở thành một giám đốc điều hành (CEO) hoặc giám đốc tài chính được (CFO).Trong khi đó, quy định này có thể không phù hợp với Điều 132 của Bộ luật Lao động – vốn chỉ yêu cầu “doanh nghiệp, tổ chức và cá nhân được tuyển người nước ngoài cho một thời hạn nhất định nhưng phải có kế hoạch, chương trình đào tạo để người Việt Nam có thể sớm làm được công việc đó và thay thế họ”.Nhiều đại điện doanh nghiệp cũng góp ý việc các cơ quan chức năng thực thi những quy định mới nên hướng đến mục tiêu chung là tạo điều kiện thuận lợi cho lao động có tay nghề được làm việc tại Việt Nam. Và khi đó, rất cần những chính sách linh hoạt phù hợp để thực hiện việc quản lý lao động nước ngoài tại Việt Nam có hiệu quả, có tác dụng thúc đẩy nền kinh tế phát triển và hài hòa lợi ích giữa nhà nước - doanh nghiệp - người lao động trong lĩnh vực này.Các doanh nghiệp cũng kỳ vọng sắp tới thông tư hướng dẫn thi hành sẽ thống nhất cách hiểu về các điều khoản của luật, nghị định để bảo đảm sự chặt chẽ bảo đảm quyền lợi lẫn nghĩa vụ cho người lao động và người sử dụng lao độngNguồn: Thời báo Kinh tế Sài Gòn Online'),
(42, ' NGHỊ ĐỊNHQUY ĐỊNH MỨC LƯƠNG TỐI THIỂU VÙNG ĐỐI VỚI NGƯỜI LAO ĐỘNG LÀM VIỆC Ở CÔNG TY, DOANH NGHIỆP, HỢP TÁC XÃ, TỔ HỢP TÁC, TRANG TRẠI, HỘ GIA ĐÌNH, CÁ NHÂN VÀ CÁC CƠ QUAN, TỔ CHỨC CÓ THUÊ MƯỚN LAO ĐỘNG---------------------------CHÍNH PHỦ Căn cứ Luật Tổ chức Chính phủ ngày 25 tháng 12 năm 2001;Căn cứ Bộ luật Lao động ngày 23 tháng 6 năm 1994; Luật sửa đổi, bổ sung một số điều của Bộ luật Lao động ngày 02 tháng 4 năm 2002; Luật sửa đổi, bổ sung một số điều của Bộ luật Lao động ngày 29 tháng 6 năm 2006;Căn cứ Luật Doanh nghiệp ngày 29 tháng 11 năm 2005;Xét đề nghị của Bộ trưởng Bộ Lao động - Thương binh và Xã hội, NGHỊ ĐỊNH: Điều 1. Đối tượng và phạm vi áp dụngNghị định này quy định mức lương tối thiểu vùng áp dụng đối với người lao động làm việc ở công ty, doanh nghiệp, hợp tác xã, trang trại, hộ gia đình, cá nhân và các cơ quan, tổ chức có thuê mướn lao động, gồm:1. Doanh nghiệp thành lập, tổ chức quản lý và hoạt động theo Luật Doanh nghiệp (kể cả doanh nghiệp có vốn đầu tư nước ngoài tại Việt Nam).2. Hợp tác xã, liên hiệp hợp tác xã, tổ hợp tác, trang trại, hộ gia đình, cá nhân và các tổ chức khác của Việt Nam có thuê mướn lao động.3. Cơ quan, tổ chức nước ngoài, tổ chức quốc tế và cá nhân người nước ngoài tại Việt Nam có thuê mướn lao động (trừ trường hợp điều ước quốc tế mà Cộng hòa xã hội chủ nghĩa Việt Nam là thành viên có quy định khác với quy định của Nghị định này).Các công ty, doanh nghiệp, cơ quan, tổ chức và cá nhân quy định tại các khoản 1, 2 và 3 Điều này gọi chung là doanh nghiệp.Điều 2. Mức lương tối thiểu vùngQuy định mức lương tối thiểu vùng áp dụng từ ngày 01 tháng 10 năm 2011 đến hết ngày 31 tháng 12 năm 2012 như sau:1. Mức 2.000.000 đồng/tháng áp dụng đối với doanh nghiệp hoạt động trên địa bàn thuộc vùng I.2. Mức 1.780.000 đồng/tháng áp dụng đối với doanh nghiệp hoạt động trên địa bàn thuộc vùng II.3. Mức 1.550.000 đồng/tháng áp dụng đối với doanh nghiệp hoạt động trên địa bàn thuộc vùng III.4. Mức 1.400.000 đồng/tháng áp dụng đối với doanh nghiệp hoạt động trên các địa bàn thuộc vùng IV.Địa bàn áp dụng mức lương tối thiểu vùng được quy định tại Phụ lục ban hành kèm theo Nghị định này.Điều 3. Áp dụng mức lương tối thiểu vùng1. Mức lương tối thiểu vùng quy định tại Điều 2 Nghị định này là mức lương thấp nhất làm cơ sở để doanh nghiệp và người lao động thỏa thuận tiền lương trả cho người lao động.2. Mức tiền lương thấp nhất trả cho người lao động đã qua học nghề (kể cả lao động do doanh nghiệp tự dạy nghề) phải cao hơn ít nhất 7% so với mức lương tối thiểu vùng quy định tại Điều 2 Nghị định này.3. Mức lương tối thiểu vùng quy định tại Điều 2 Nghị định này được dùng làm căn cứ để xây dựng các mức lương trong thang lương, bảng lương, phụ cấp lương, tính các mức lương ghi trong hợp đồng lao động và thực hiện các chế độ khác do doanh nghiệp xây dựng và ban hành theo thẩm quyền do pháp luật lao động quy định.4. Căn cứ mức lương tối thiểu vùng quy định tại Điều 2 Nghị định này, doanh nghiệp điều chỉnh lại các mức lương trong thang lương, bảng lương do doanh nghiệp xây dựng và ban hành, tiền lương trong hợp đồng lao động cho phù hợp với các thỏa thuận và quy định của pháp luật lao động.5. Khuyến khích các doanh nghiệp trả lương cho người lao động cao hơn mức lương tối thiểu vùng quy định tại Điều 2 Nghị định này.Điều 4. Tổ chức thực hiện1. Bộ Lao động - Thương binh và Xã hội chịu trách nhiệm hướng dẫn thi hành Nghị định này.2. Bộ Lao động - Thương binh và Xã hội chủ trì, phối hợp với Tổng Liên đoàn Lao động Việt Nam, Phòng Thương mại và Công nghiệp Việt Nam, các Bộ, cơ quan liên quan và Ủy ban nhân dân tỉnh, thành phố trực thuộc Trung ương tuyên truyền, phổ biến đến người lao động, người sử dụng lao động và kiểm tra, giám sát việc thực hiện mức lương tối thiểu vùng quy định tại Nghị định này; báo cáo Chính phủ xem xét, quyết định việc điều chỉnh mức lương tối thiểu vùng theo quy định.Điều 5. Hiệu lực thi hành1. Nghị định này có hiệu lực thi hành từ ngày 05 tháng 10 năm 2011.2. Bãi bỏ Nghị định số 107/2010/NĐ-CP ngày 29 tháng 10 năm 2010 của Chính phủ quy định mức lương tối thiểu vùng đối với người lao động làm việc ở công ty, doanh nghiệp, hợp tác xã, tổ hợp tác, trang trại, hộ gia đình, cá nhân và các tổ chức khác của Việt Nam có thuê mướn lao động; Nghị định số 108/2010/NĐ-CP ngày 29 tháng 10 năm 2010 của Chính phủ quy định mức lương tối thiểu vùng đối với lao động Việt Nam làm việc cho doanh nghiệp có vốn đầu tư nước ngoài, cơ quan, tổ chức nước ngoài, tổ chức quốc tế và cá nhân người nước ngoài tại Việt Nam; khoản 3 Điều 7 Nghị định số 22/2011/NĐ-CP ngày 04 tháng 4 năm 2011 của Chính phủ quy định mức lương tối thiểu chung.3. Khuyến khích doanh nghiệp tổ chức ăn giữa ca cho người lao động. Mức tiền ăn giữa ca do doanh nghiệp, Ban Chấp hành công đoàn cơ sở hoặc Ban Chấp hành công đoàn lâm thời và người lao động thỏa thuận, để bảo đảm chất lượng bữa ăn giữa ca cho người lao động.4. Công ty trách nhiệm hữu hạn nhà nước một thành viên do Nhà nước làm chủ sở hữu, công ty mẹ - tập đoàn kinh tế nhà nước trong thời gian chưa xây dựng được thang lương, bảng lương theo quy định tại Nghị định số 101/2009/NĐ-CP ngày 05 tháng 11 năm 2009 của Chính phủ, công ty nhà nước chưa chuyển đổi thành công ty trách nhiệm hữu hạn hoặc công ty cổ phần, các tổ chức, đơn vị hiện đang áp dụng chế độ tiền lương như công ty nhà nước được lựa chọn mức lương tối thiểu cao hơn so với mức lương tối thiểu chung do Chính phủ quy định để xác định đơn giá tiền lương của người lao động và quỹ tiền lương của viên chức quản lý từ năm 2012 khi đủ các điều kiện theo quy định tại Nghị định số 206/2004/NĐ-CP ngày 14 tháng 12 năm 2004; Nghị định số 207/2004/NĐ-CP ngày 14 tháng 12 năm 2004; Nghị định số 86/2007/NĐ-CP ngày 28 tháng 5 năm 2007; Nghị định số 141/2007/NĐ-CP ngày 05 tháng 9 năm 2007 của Chính phủ và bảo đảm mức tăng tiền lương của viên chức quản lý không vượt quá mức tăng tiền lương của của người lao động. Trường hợp không bảo đảm đủ các điều kiện do Chính phủ quy định mà tiền lương tính theo chế độ của người lao động thấp hơn mức lương tối thiểu vùng quy định tại Điều 2 Nghị định này thì được tính bằng mức lương tối thiểu vùng quy định tại Điều 2 Nghị định này.5. Các Bộ trưởng, Thủ trưởng cơ quan ngang Bộ, Thủ trưởng cơ quan thuộc Chính phủ, Chủ tịch Ủy ban nhân dân tỉnh, thành phố trực thuộc Trung ương và các cơ quan, doanh nghiệp chịu trách nhiệm thi hành Nghị định này. TM. CHÍNH PHỦ THỦ TƯỚNG Nguyễn Tấn Dũng ');
INSERT INTO `nv3_vi_news_bodytext` (`id`, `bodytext`) VALUES
(43, 'Do vậy, từ nay đến cuối năm 2011, một trong những nhiệm vụ trong tâm của ngành Thuế là triển khai các giải pháp thực hiện đồng bộ và thống nhất thúc đẩy các doanh nghiệp nêu trên đặt in hoặc tự in hóa đơn để có hóa đơn sử dụng từ ngày 1/1/2012. Việc chuyển hết các doanh nghiệp siêu nhỏ, doanh nghiệp ở tại địa bàn kinh tế xã hội khó khăn và đặc biệt khó khăn từ cơ chế mua hóa đơn của cơ quan thuế sang cơ chế tự chủ đặt in, tự in hóa đơn có ý nghĩa quan trọng trong việc nâng cao tính tự chủ của các doanh nghiệp trong công tác tự chịu trách nhiệm về quản lý hóa đơn của doanh nghiệp, giảm chi phí quản lý của cơ quan thuế dùng vào việc bán hóa đơn, ấn chỉ cho các doanh nghiệp. Phấn đấu hết tháng 10/2011, doanh nghiệp siêu nhỏ có phương án sử dụng hóa đơn tự inTổng cục Thuế đề nghị cơ quan Thuế các cấp cần tập trung các giải pháp phấn đấu hết tháng 10/2011, về cơ bản tất cả các doanh nghiệp trên địa bàn ký được hợp đồng đặt in hoá đơn hoặc đã có phương án sử dụng hoá đơn tự in. Đồng thời, cũng để tránh hiện tượng các doanh nghiệp đặt in hoá đơn dồn vào thời điểm cuối năm, Tổng cục Thuế giao chỉ tiêu cho các Cục thuế thực hiện đảm bảo đến hết ngày 31/10/2011, 100% số lượng doanh nghiệp siêu nhỏ, doanh nghiệp ở địa bàn khó khăn và đặc biệt khó khăn có hoá đơn đặt in hoặc ký được hợp đồng đặt in hoá đơn hoặc có phương án sử dụng hoá đơn tự in. Trường hợp doanh nghiệp gặp vướng mắc trong việc đặt in, tự in hóa đơn, Tổng cục Thuế đề nghị Cục thuế liên hệ trực tiếp, phối hợp với các nhà in, doanh nghiệp cung cấp phần mềm in hoá đơn để hỗ trợ giải quyết vướng mắc cho doanh nghiệp. Cơ quan thuế chỉ bán số lượng hóa đơn đủ dùng đến hết 31/12/2011 Bên cạnh đó, Tổng cục Thuế yêu cầu cần tiếp tục thực hiện công tác tuyên truyền để phổ biến và quán triệt sâu sắc đến từng doanh nghiệp hiện đang mua hóa đơn của cơ quan thuế để doanh nghiệp biết nội dung: Từ ngày 1/1/2012 cơ quan Thuế không bán hóa đơn cho doanh nghiệp. Tuỳ vào đặc điểm của từng địa phương, Cục thuế chủ động sử dụng các hình thức tuyên truyền khác nhau đảm bảo hiệu quả. Căn cứ số lượng hoá đơn còn tồn kỳ trước, trong quý IV/2011 cơ quan Thuế các cấp giảm dần số lượng hoá đơn bán cho các doanh nghiệp, chỉ bán với số lượng đủ dùng đến hết 31/12/2011. Cục Thuế thông báo đến từng doanh nghiệp về việc hoá đơn do Cục thuế đặt in bán cho doanh nghiệp đến ngày 31/12/2011 doanh nghiệp còn tồn sẽ hết giá trị sử dụng, doanh nghiệp phải nộp lại số còn tồn cho cơ quan Thuế để cơ quan Thuế huỷ theo quy định. Đồng thời với việc bán hoá đơn với số lượng đủ dùng này, cơ quan Thuế yêu cầu từng doanh nghiệp siêu nhỏ, doanh nghiệp ở tại địa bàn kinh tế xã hội khó khăn và đặc biệt khó khăn hiện đang mua hoá đơn cam kết với cơ quan Thuế về việc doanh nghiệp đã được cơ quan Thuế triển khai các quy định về hoá đơn và chịu trách nhiệm đảm bảo có hoá đơn để sử dụng từ 1/1/2012 theo quy định. Theo Chinhphu.vn'),
(44, 'Vốn góp bao nhiêu là phù hợp?Mức góp tối đa của một thành viên HTX được quy định tại Khoản 1 Điều 18. HTX là tổ chức được thành lập để đáp ứng các nhu cầu và nguyện vọng chung của các xã viên. Muốn thực hiện được nhiệm vụ này thì không HTX nào không cần đến vốn góp của các xã viên để xây dựng cơ sở vật chất – kỹ thuật cho việc thực hiện các hoạt động kinh tế có liên quan. Tuy nhiên, nếu như đối với doanh nghiệp, vấn đề hạn chế việc góp vốn không bao giờ phải đặt ra thì đối với HTX đây lại là vấn đề nóng. Vụ trưởng Vụ Pháp luật Dân sự - Kinh tế, Bộ Tư pháp Dương Đăng Huệ lý giải, nguyên nhân cơ bản của tình trạng này xuất phát từ tính chất đối nhân của HTX, đặc biệt là từ nguyên tắc bình đẳng trong quản lý của tất cả các xã viên. Tuy nhiên, về vấn đề này còn có hai ý kiến khác nhau. Ý kiến thứ nhất cho rằng, cần tiếp tục kế thừa quy định của Luật Hợp tác xã năm 2003, cụ thể “mức góp vốn tối đa của một thành viên HTX, Liên hiệp HTX không vượt quá 30% vốn điều lệ của HTX, Liên hiệp HTX”. Ý kiến thứ hai dựa trên khuyến cáo của Liên minh Hợp tác xã Quốc tế. Cụ thể, mức vốn góp tối đa của một thành viên HTX không được quá 20% vốn điều lệ của HTX và mức góp vốn tại Liên minh HTX là 30%. Đây cũng là quy định tại dự thảo Luật HTX (sửa đổi).Thực tế, việc quy định mức vốn góp tối đa cho thành viên nhằm ghi nhận sự khác biệt giữa HTX với các loại hình doanh nghiệp, đặc biệt là để đề cao và bảo đảm thực hiện sự bình đẳng trong quản lý HTX. Ngoài ra, nếu không khống chế số vốn góp tối đa thì thành viên có mức góp vốn cao hơn sẽ được chia lãi nhiều hơn theo tỷ lệ góp vốn. Ở góc độ khác, Chủ tịch HĐQT SaigonCoop Nguyễn Ngọc Hòa đặt vấn đề, HTX, Liên hiệp HTX là một pháp nhân nên cũng được quyền tham gia góp vốn vào một HTX khác. Trong trường hợp này có thể nghiên cứu cho phép góp vốn của pháp nhân là HTX, Liên hiệp HTX vào các HTX ở mức 30%. Điều này sẽ khuyến khích được các HTX, Liên hiệp HTX có điều kiện tham gia góp vốn để tương trợ giúp đỡ các HTX khác; đồng thời HTX, Liên hiệp HTX có cùng bản chất xã hội nên không sợ ảnh hưởng chi phối đến mục tiêu hoạt động của HTXGiới hạn quyền cung ứng sản phẩm, dịch vụViệc giới hạn sản phẩm, dịch vụ mà HTX được cung cấp cho thị trường bên ngoài cộng đồng thành viên quy định tại Khoản 1 Điều 9. Trên thực tế, trong nhiều trường hợp ngoài việc tập trung năng lực để đáp ứng nhu cầu, nguyện vọng chung của các xã viên thì HTX vẫn còn năng lực để phục vụ các nhu cầu của chủ thể khác không phải là thành viên của HTX. Vì vậy, vấn đề đặt ra là có nên cho phép HTX cung ứng sản phẩm, dịch vụ ra bên ngoài hay không và nếu cho phép thì nên ở mức độ nào là hợp lý? Về vấn đề này, quan điểm của ông Huệ là cần khống chế tỷ lệ sản phẩm dịch vụ HTX được phép cung cấp ra thị trường bên ngoài cộng đồng thành viên. Mức độ khống chế ở mỗi quốc gia không giống nhau, chẳng hạn ở bang Quebec, Canada, tỷ lệ này được xác định ngay trong luật là 50%, tức là tỷ lệ dịch vụ tối thiểu mà HTX phải giao dịch với xã viên là 50%. Trong điều kiện Việt Nam hiện nay, ông Huệ nhất trí với quy định của dự thảo Luật HTX (sửa đổi). Cụ thể, vấn đề này không được quy định cụ thể trong Luật HTX mà giao cho Điều lệ HTX xác định tỷ lệ cụ thể trên cơ sở hướng dẫn của Chính phủ. Tỷ lệ này được xác định phù hợp với từng HTX trong các ngành, lĩnh vực và phù hợp với từng giai đoạn nhất định. Thứ trưởng Bộ Kế hoạch và Đầu tư Đặng Huy Đông khẳng định, Luật HTX của nhiều quốc gia không quy định chính sách hỗ trợ của Nhà nước đối với HTX; còn dự thảo Luật HTX (sửa đổi) quy định chính sách hỗ trợ HTX hơn hẳn so với doanh nghiệp. Do vậy, để định hướng HTX hoạt động đúng bản chất, tránh tình trạng lách luật để thụ hưởng chính sách của Nhà nước dành cho HTX như tình trạng hiện nay, quy định của Luật cần bảo đảm HTX trước hết và chủ yếu tập trung phục vụ mang lại lợi ích cho các thành viên. Đồng thời, dự thảo luật có quy định mềm dẻo cho phép HTX có quyền cung ứng sản phẩm, dịch vụ và việc làm cho thị trường bên ngoài cộng đồng thành viên trên cơ sở bảo đảm thực hiện hợp đồng. (Nguồn: daibieunhandan.vn) '),
(45, 'Thực tế, cả hai phương án trên đều có yếu tố hợp lý nhưng cũng có những yếu tố chưa hợp lý. Theo dự thảo Luật, phạm vi hòa giải gồm 3 loại đối tượng đó là: mâu thuẫn, vi phạm pháp luật và tranh chấp nhỏ trong nhân dân. Mâu thuẫn là sự bất đồng quan điểm, đối lập về quyền, lợi ích. Từ mâu thuẫn có thể dẫn đến hành vi vi phạm pháp luật, có thể dẫn đến tranh chấp (nếu mâu thuẫn về quyền hoặc lợi ích), do đó mâu thuẫn đương nhiên cần được hòa giải kịp thời tại cơ sở để ngăn ngừa phát sinh tranh chấp, vi phạm pháp luật. Đối với hành vi vi phạm hành chính, hành vi phạm tội là những hành vi nguy hiểm cho xã hội nên tùy mức độ vi phạm để xử lý theo quy định của Luật Xử lý vi phạm hành chính hoặc pháp luật hình sự nên không được phép hòa giải. Do đó, chỉ hòa giải đối với những vi phạm pháp luật nhỏ, tức là những vi phạm chưa đến mức xử lý hành chính hoặc xử lý hình sự là phù hợp (tất nhiên những vi phạm này có ảnh hưởng đến quyền, lợi ích của cá nhân khác có thể trở thành nguyên nhân gây mâu thuẫn, tranh chấp hoặc hành vi vi phạm pháp luật nghiêm trọng hơn, còn đối với những vi phạm pháp luật nhỏ xâm phạm lợi ích chung không có chủ thể cụ thể có mâu thuẫn, lợi ích đối kháng nên không thể là đối tượng hòa giải). Đối với tranh chấp, theo dự thảo Luật quy định chỉ hòa giải đối với tranh chấp nhỏ trong nhân dân. Đây là quy định mang tính định tính mà không xác định cụ thể loại tranh chấp nào là tranh chấp nhỏ, không có định lượng giá trị tranh chấp nhỏ là bao nhiêu để được hòa giải tại cơ sở. Với quy định này sẽ rất khó xác định trong thực tiễn khi tiến hành hòa giải. Mặt khác, hoạt động hòa giải tại cơ sở là hoạt động tự nguyện, tự quyết định lựa chọn của nhân dân do tổ chức tự quản của nhân dân tiến hành không mang tính chất quyền lực nhà nước. Xuất phát từ bản chất tự quản, tự nguyện nên hoạt động hòa giải cơ sở phải kịp thời, linh hoạt và không thể căn cứ mức độ tranh chấp để xác định thẩm quyền như cơ quan nhà nước. Thậm chí trong trường hợp Tòa án đã thụ lý và đang giải quyết vụ án thì đương sự vẫn có quyền đề nghị Tổ hòa giải cơ sở tiến hành hòa giải; nếu hòa giải thành thì nguyên đơn rút đơn khởi kiện mà không có trở ngại, ràng buộc gì về mặt pháp lý. Tùy thuộc vào khả năng và sự quyết định lựa chọn để thực hiện mà không nên bó hẹp phạm vi mức độ tranh chấp. Thực tiễn cho thấy có những tranh chấp về lợi ích có giá trị lớn nhưng không phức tạp, nguyên nhân phát sinh đơn giản mà các Tổ hòa giải có thể hòa giải thành. Ngược lại, có những tranh chấp về lợi ích có giá trị nhỏ nhưng lại rất căng thẳng, phức tạp. Mục đích hòa giải là để các bên thỏa thuận được với nhau về giải quyết tranh chấp, tuy nhiên trong trường hợp hòa giải không thành nhưng nhờ hòa giải mà giảm bớt được mức độ căng thẳng, ngăn ngừa được hành vi vi phạm pháp luật thì vai trò của hòa giải vẫn được phát huy. Do đó, không nên đặt vấn đề là lựa chọn, giao những vụ việc đơn giản cho Tổ hòa giải cơ sở để hòa giải thành, bởi quan niệm như vậy là chưa thuyết phục.Một trong những lý do để Ban soạn thảo lựa chọn quy định theo phương án thứ nhất đó là, theo quy định tại Điều 127 Hiến pháp năm 1992: “Ở cơ sở, thành lập các tổ chức thích hợp của nhân dân để giải quyết những việc vi phạm pháp luật và tranh chấp nhỏ trong nhân dân theo quy định của pháp luật”. Về ràng buộc trong quy định của Hiến pháp không có trở ngại lớn vì hiện nay đang nghiên cứu sửa đổi Hiến pháp 1992, nếu xét thấy phạm vi hòa giải theo phương án nào là hợp lý thì sửa đổi quy định của Hiến pháp để bảo đảm tính thống nhất về hiệu lực pháp lý.Về mặt kỹ thuật lập pháp, điều luật quy định về phạm vi hòa giải trong dự thảo Luật kết cấu theo kiểu vừa liệt kê những vụ, việc được phép hòa giải lại vừa liệt kê những vụ, việc không được hòa giải nên trùng lặp và rườm rà, khó hiểu.Từ những lý do nêu trên, cần sửa đổi lại quy định này về cả nội dung và bố cục thể hiện theo hướng loại trừ: “Việc hòa giải được tiến hành đối với các mâu thuẫn, vi phạm pháp luật nhỏ và tranh chấp trong nhân dân; trừ các trường hợp sau: a) Tội phạm hình sự; b) Hành vi vi phạm pháp luật bị xử lý hành chính; c) Quan hệ hôn nhân trái pháp luật và các tranh chấp phát sinh từ giao dịch trái pháp luật…(Trích nguồn; daibieunhandan.vn)'),
(46, 'Theo thống kê, hiện tại có khoảng gần 40 doanh nghiệp nhà nước (DNNN) và tư nhân có sở hữu trên 5% tại các ngân hàng TMCP.Hầu hết tập đoàn kinh tế nhà nước đều có các công ty tài chính. Mối quan hệ giữa ngân hàng TMCP với các tập đoàn tư nhân ngày càng trở nên phức tạp.Nhiều ngân hàng có thể được sở hữu bởi rất nhiều công ty gia đình hoặc các thành viên gia đình vốn đồng thời lãnh đạo ở các DN khác.Những hệ lụy mà hình thức sở hữu chéo mang lại ít nhiều thì cũng được khá nhiều chuyên gia phân tích, mổ xẻ. Tuy nhiên, cho đến nay vẫn chưa có một đánh giá cụ thể, chi tiết và chính xác nào từ phía các cơ quan có chức năng về tình trạng này tại Việt Nam. Phải chăng bức tranh này rất khó "vẽ" lại?Theo ông Vũ Thành Tự Anh - Giám đốc Nghiên cứu, Chương trình giảng dạy kinh tế Fulbright, mặt trái của sở hữu chéo đã được thể hiện qua những trục trặc ngày càng rõ của ngành ngân hàng vài năm trở lại đây, trong đó nghiêm trọng nhất là các NHTM đã dùng sở hữu chéo để lách các quy định bảo đảm an toàn hoạt động do NHNN ban hành. Thứ nhất là quy định về vốn. Theo quy định của Nghị định 141/2006/NĐ -CP, vốn điều lệ thực góp của các ngân hàng phải đạt 1.000 tỷ đồng vào năm 2008 và 3.000 tỷ đồng vào năm 2010.Thông qua sở hữu chéo, cổ đông ngân hàng A có thể vay tiền ngân hàng B để góp vốn vào ngân hàng A, và ngược lại. Hoạt động đi vay này tạo ra tình trạng tăng vốn ảo trong các ngân hàng.Thứ hai là giới hạn tín dụng theo quy định hiện hành đã bị sở hữu chéo làm vô hiệu hoá.Thứ ba là các quy định về phân loại nợ và trích lập dự phòng rủi ro của NHNN có thể bị làm sai lệch tinh thần bởi sở hữu chéo.Khi khách hàng không trả được nợ, thay vì xếp khoản vay thành nợ xấu và trích dự phòng rủi ro theo quy định, ngân hàng A có thể cho vay đảo nợ...Ông Võ Trí Thành - Phó Viện trưởng Viện Nghiên cứu quản lý kinh tế Trung ương (CIEM) cho rằng, sở hữu chéo là vấn đề khá bình thường trên thế giới, nhưng luật của các nước đều yêu cầu minh bạch để thị trường và cổ đông giám sát.Còn ở Việt Nam cũng đã có những quy định hạn chế sở hữu chéo và yêu cầu công khai việc này, nhưng lại bỏ ngỏ khâu giám sát và chế tài, dẫn đến việc sở hữu chéo ngày càng trở nên nghiêm trọng, làm lũng đoạn thị trường nhiều lĩnh vực trọng yếu của nền kinh tế, nhất là lĩnh vực tài chính - ngân hàng.Trong khi đó, Luật Các tổ chức tín dụng được thông qua, một trong những sai lầm "chết người" là xóa "bức tường lửa" của ngân hàng đầu tư và ngân hàng thương mại. Nhiều quy định trong Luật vẫn chưa chặt chẽ và rõ ràng phân biệt giữa ngân hàng đầu tư và ngân hàng thương mại truyền thống."Chính vì thế mới có sự "lập lờ" trong đầu tư và sở hữu giữa các cá nhân với ngân hàng, giữa ngân hàng này với ngân hàng kia. Việc lập lại "bức tường lửa" (quy định rạch ròi về hoạt động của ngân hàng đầu tư với ngân hàng thương mại) sẽ vô cùng cần thiết trong bối cảnh hiện nay" - ông Thành nói.Ông Trương Đình Tuyển - Thành viên hội đồng Tư vấn tiền tệ Quốc gia thì bức xúc nói tại Diễn đàn kinh tế Việt Nam năm 2012 tổ chức vừa qua tại Hà Nội rằng: Đã là ngân hàng thì nhất quyết không được đầu tư vào bất kỳ một lĩnh vực kinh doanh nào khác. Dù đó chỉ là một đồng.Theo ông Tuyển ngân hàng là một lĩnh vực hoạt động có lợi nhuận cao nhưng lại khá nhạy cảm và mỗi biến động của nó đều có ảnh hưởng lớn đến nền kinh tế nói chung.Do đó, nếu cho phép các ngân hàng được phép đầu tư vào một số lĩnh vực khác (phi ngân hàng) cho dù luật có chặt đến đâu thì cá nhân hay tổ chức đó đều có "cửa" để lách. (Theo TTXVN)'),
(47, 'Một anh chàng ngồi một mình trong góc quán rượu, uống tì tì suốt ba giờ liền. Đột nhiên, anh ta nhảy dựng lên và gào to cho cả quán cùng nghe:- " Tất cả bọn luật sư đều là đồ chăn lừa".Anh ta ngồi xuống và định dốc hết chỗ rượu còn lại thì một anh chàng to cao vạm vỡ tiến đến gần rồi chẳng nói chẳng rằng đấm cho anh ta một trận túi bụi cho đến khi anh ta chỉ còn là một đống bùi nhùi. Một người phục vụ liền hỏi anh chàng cao to :- Tôi đoán ông là một luật sư?- Không - anh ta trả lời- Tôi là một người chăn lừa.'),
(48, 'Một luật sư đang biện hộ cho một người bị buộc tội ăn trộm. Luật sư nói với tòa... Kính thưa ngài tôi xin trình bày rằng thân chủ của tôi không hề đột nhập vào căn nhà đó. Anh ta thấy cửa sổ phòng khách mở trống và chỉ thọc cánh tay phải vào để lấy ra vài món đồ vặt vãnh. Đấy cánh tay thân chủ tôi đâu phải là chính anh ta. Tôi không hiểu sao ngài có thể trừng phạt cả một con người vì một sai phạm chỉ do một phần tứ chi của người ấy thực hiện.Quan toà cân nhắc lý luận này một hồi lâu rồi trả lời:- Lý luận của anh trình bày rất khéo. Xét theo lý lẽ đó tôi tuyên án cánh tay của bị cáo một năm tù giam, có đi theo cánh tay hay không là tùy ở bị cáo.Nghe quan toà phán xong, bị cáo mỉm cười và với sự giúp đỡ của luật sư, anh ta tháo rời cánh tay giả ra đặt nó lên trên ghế và ra về...'),
(49, 'Một số bài báo trong vài tháng qua nêu lên những thực trạng về khả năng cung ứng USD của hệ thống thị trường chính thức thấp hơn nhu cầu về USD của người dân và doanh nghiệp. Những bài báo nêu ra hai thực trạng, thứ nhất, là người dân khó mua USD tại ngân hàng cho những mục đích như khám chữa bệnh, đi du học. Thứ hai, một số doanh nghiệp nhỏ cũng phản ánh trên báo chí là họ khó mua USD từ ngân hàng để phục vụ hoạt động kinh doanh vì không nằm trong diện ưu tiên. Một tình huống khác được phản ánh là sau khi thị trường tự do ngừng hoạt động, các doanh nghiệp có nhu cầu USD phải mua USD thông qua việc nhờ ngân hàng giới thiệu cho người có ngoại tệ với tỷ giá cao hơn hẳn tỷ giá niêm yết. Những tình huống kể trên chỉ ra rằng sự tồn tại của những kênh thị trường phi chính thức (nếu không còn thị trường tự do thì cũng còn thị trường dạng "bắc cầu") xuất phát từ thực tế là nguồn USD cung ứng từ thị trường chính thức tại mức tỷ giá niêm yết, không đáp ứng được yêu cầu của tất cả người dân trong xã hội. Khi có nhu cầu mua USD mà không thể mua ở ngân hàng thì tất yếu sẽ xuất hiện thị trường phi chính thức đáp ứng yêu cầu này. Dù có nỗ lực dẹp bỏ thị trường tự do thì làm sao đảm bảo sẽ không xuất hiện những hình thức biến tướng khác? Khi đó, nó sẽ chỉ làm cho giá USD "phi chính thức" càng bị đẩy cao hơn mức tỷ giá chính thức vì sự khan hiếm của nguồn cung ứng dịch vụ này.Một trở ngại khác trong việc dẹp bỏ kênh thị trường tự do, là liệu các biện pháp chế tài hiện hành có thể tạo điều kiện để thật sự dẹp bỏ loại thị trường này? Theo phản ánh của phó giám đốc ngân hàng Nhà nước chi nhánh TP.HCM, có những cửa hàng USD tự do tại TP.HCM trước đó bị phạt tới gần 60 triệu đồng, nhưng giờ vẫn mua bán USD gần như công khai. Liệu mức phạt 60 triệu đồng đã đủ có thể răn đe để người kinh doanh mua bán USD tự do không "phá rào"?Sự tồn tại của thị trường phi chính thức vì vậy được tạo ra vì hai nguyên nhân cơ bản: một là nhu cầu chính đáng của người dân về USD không được đáp ứng thông qua kênh thị trường chính thức tại tỷ giá niêm yết hiện tại, và hai là các biện pháp chế tài đối với thị trường phi chính thức còn yếu. Nhưng nếu tập trung sửa chữa cái thứ hai, trong khi cái thứ nhất chưa thể điều tiết thì tình hình có thể còn tệ hơn. Chế tài càng mạnh, nguồn cung USD tự do càng khan hiếm mà nguồn cung chính thức không đáp ứng nổi khiến người dân và doanh nghiệp chuyển sang găm giữ và tích luỹ USD thì tình hình diễn biến tỷ giá tự do có thể sẽ càng tệ hại hơn.Thực trạng hiện nay phản ánh rằng, dù là thông qua kênh thị trường tự do hay kênh thị trường "bắc cầu" (tức là có sự tham gia "giới thiệu" của ngân hàng) thì nguồn cung USD chỉ đáp ứng nhu cầu ở tỷ giá cao hơn tỷ giá niêm yết. Phải chăng việc ngân hàng phải đứng ra làm trung gian "bắc cầu" như thế là vì họ không thể mua được USD theo tỷ giá niêm yết từ phía người có USD? Căn bệnh nhập siêu mãn tính của Việt Nam, sự suy yếu kinh niên của đồng VND, thị trường sản phẩm phòng ngừa rủi ro tỷ giá kém phát triển và nhu cầu tích trữ USD của người dân tạo ra kỳ vọng "đồng USD sẽ tăng giá và bán bây giờ thì mai mốt không biết có mua lại được không". Mà nếu người có USD lo ngại rằng sau khi bán USD cho ngân hàng ở giá niêm yết rồi mà sau này khó mua lại, hoặc phải mua lại ở giá cao hơn nhiều so với giá niêm yết hiện tại thì họ đương nhiên sẽ muốn tiếp tục nắm giữ USD và chỉ bán khi "được giá". Người có USD có tâm lý găm giữ "chờ USD lên" như vậy, thì dù có cấu trúc thị trường chính thức như thế nào, các đại lý mua bán USD chính thức hoạt động ra sao đi nữa, mà họ không mua được USD từ doanh nghiệp hay người dân với tỷ giá niêm yết thì lấy USD đâu ra mà bán.Nói cách khác, cái gút khiến thị trường chính thức không thể "cạnh tranh" thu hút đủ USD để cung ứng cho người dân là vì tỷ giá niêm yết chính thức bị kiềm chế thiếu linh hoạt so với tỷ giá tự do. Điều này liên quan đến cách điều hành chính sách tỷ giá hiện tại mà nhiều chuyên gia trong và ngoài nước đã có phân tích và nằm ngoài khuôn khổ bài viết này.Nhưng có một điều cần nhận thấy là nếu như Chính phủ muốn điều hành một tỷ giá chính thức như thế nào, thì tất yếu sẽ đi kèm với sản phẩm phụ như thế ấy. Tỷ giá chính thức biến động nhiều quá hay đồng tiền phá giá nhanh quá sẽ có những độ sốc nhất định. Và nếu Chính phủ không mong muốn để tỷ giá chính thức tạo ra những cú sốc như vậy thì tự nhiên sẽ có một thị trường tự do tồn tại song song với thị trường chính thức để đáp ứng nhu cầu USD trong xã hội ở một mức tỷ giá khác. Khi nhu cầu USD tăng mạnh (vì nhiều lý do, như nhu cầu găm giữ của người dân, nhu cầu USD nhập khẩu của doanh nghiệp chẳng hạn) mà sự biến động của tỷ giá chính thức không theo kịp và không phản ánh được quan hệ cung cầu thật sự thì tự nhiên người ta phải tìm đến thị trường phi chính thức.Mỗi mục tiêu chính sách sẽ phải trả một cái giá, và khó đòi hỏi một chính sách đạt được tất cả các mục tiêu. Cái gì cũng có mặt trái của nó. Sự tồn tại của hai loại tỷ giá trong nền kinh tế, hai loại thị trường ngoại hối chính thức và phi chính thức là sản phẩm phụ của chính sách tỷ giá hiện tại. Để xoá bỏ triệt để mặt trái này, về gốc rễ, phải là điều chỉnh chính sách tỷ giá cho linh hoạt hơn, khiến tỷ giá chính thức biến động nhiều hơn đủ để ngân hàng và các đại lý có thể đưa ra một cái giá cạnh tranh thu hút USD về thị trường chính thức. Nếu không muốn điều chỉnh chính sách tỷ giá, thì tốn sức người sức của tìm cách xoá bỏ sự tồn tại của thị trường ngoại hối phi chính thức có thể là một việc làm không hiệu quả mà nhiều người có thể đã nhìn thấy trước');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_cat`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_cat` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `titlesite` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '',
  `thumbnail` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `order` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `keywords` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `who_view` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `nv3_vi_news_cat`
--

INSERT INTO `nv3_vi_news_cat` (`catid`, `parentid`, `title`, `titlesite`, `alias`, `description`, `image`, `thumbnail`, `weight`, `order`, `lev`, `viewcat`, `numsubcat`, `subcatid`, `inhome`, `numlinks`, `keywords`, `admins`, `add_time`, `edit_time`, `who_view`, `groups_view`) VALUES
(23, 0, 'Dịch vụ doanh nghiệp', '', 'Dich-vu-doanh-nghiep', '', '', '', 1, 1, 0, 'viewcat_page_new', 3, '31,32,33', 1, 3, '', '', 1351406131, 1351406131, 0, ''),
(24, 0, 'Sở hữu trí tuệ', '', 'So-huu-tri-tue', '', '', '', 2, 5, 0, 'viewcat_page_new', 3, '34,35,36', 1, 3, '', '', 1351406152, 1351406152, 0, ''),
(25, 0, 'Dịch vụ tư vấn', '', 'Dich-vu-tu-van', '', '', '', 3, 9, 0, 'viewcat_page_new', 3, '37,38,39', 1, 3, '', '', 1351406167, 1351406167, 0, ''),
(26, 0, 'Dịch vụ tài chính', '', 'Dich-vu-tai-chinh', '', '', '', 4, 13, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406212, 1351406212, 0, ''),
(27, 0, 'Thông tin pháp luật', '', 'Thong-tin-phap-luat', '', '', '', 5, 14, 0, 'viewcat_page_new', 2, '40,41', 1, 3, '', '', 1351406250, 1351406250, 0, ''),
(28, 0, 'Hỏi đáp pháp luật', '', 'Hoi-dap-phap-luat', '', '', '', 6, 17, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406268, 1351406268, 0, ''),
(29, 0, 'Kiến thức', '', 'Kien-thuc', '', '', '', 7, 18, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406338, 1351406338, 0, ''),
(30, 0, 'Thư giãn', '', 'Thu-gian', '', '', '', 8, 19, 0, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406349, 1351406349, 0, ''),
(31, 23, 'Đăng ký kinh doanh', '', 'Dang-ky-kinh-doanh', '', '', '', 1, 2, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406442, 1351406442, 0, ''),
(32, 23, 'Đăng ký đầu tư', '', 'Dang-ky-dau-tu', '', '', '', 2, 3, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406477, 1351406477, 0, ''),
(33, 23, 'Tổ chức doanh nghệp', '', 'To-chuc-doanh-nghep', '', '', '', 3, 4, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406501, 1351406501, 0, ''),
(34, 24, 'Dịch vụ đăng ký bảo hộ', '', 'Dich-vu-dang-ky-bao-ho', '', '', '', 1, 6, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406546, 1351406546, 0, ''),
(35, 24, 'Dịch vụ xử lý vi phạm SHTT', '', 'Dich-vu-xu-ly-vi-pham-SHTT', '', '', '', 2, 7, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406577, 1351406577, 0, ''),
(36, 24, 'Li xăng và nhượng quyền', '', 'Li-xang-va-nhuong-quyen', '', '', '', 3, 8, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406625, 1351406625, 0, ''),
(37, 25, 'Dịch vụ luật sư', '', 'Dich-vu-luat-su', '', '', '', 1, 10, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406749, 1351406749, 0, ''),
(38, 25, 'Dịch vụ xin giấy phép', '', 'Dich-vu-xin-giay-phep', '', '', '', 2, 11, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406775, 1351406775, 0, ''),
(39, 25, 'Hướng dẫn thủ tục', '', 'Huong-dan-thu-tuc', '', '', '', 3, 12, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406794, 1351406794, 0, ''),
(40, 27, 'Văn bản mới', '', 'Van-ban-moi', '', '', '', 1, 15, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406829, 1351406829, 0, ''),
(41, 27, 'Tin tức pháp luật', '', 'Tin-tuc-phap-luat', '', '', '', 2, 16, 1, 'viewcat_page_new', 0, '', 1, 3, '', '', 1351406850, 1351406850, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_comments`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_comments` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `post_name` varchar(100) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `post_time` (`post_time`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_config_post`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_config_post` (
  `pid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `member` tinyint(4) NOT NULL,
  `group_id` mediumint(9) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `member` (`member`,`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `nv3_vi_news_config_post`
--

INSERT INTO `nv3_vi_news_config_post` (`pid`, `member`, `group_id`, `addcontent`, `postcontent`, `editcontent`, `delcontent`) VALUES
(1, 0, 0, 0, 0, 0, 0),
(2, 1, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_rows`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgalt` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `keywords` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=50 ;

--
-- Dumping data for table `nv3_vi_news_rows`
--

INSERT INTO `nv3_vi_news_rows` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`, `keywords`) VALUES
(18, 23, '23,33', 0, 1, '', 0, 1351436786, 1351436889, 1, 1351436786, 0, 2, 'Tái cơ cấu&#x3A; Sáng tạo để tiếp tục đổi mới', 'Tai-co-cau-Sang-tao-de-tiep-tuc-doi-moi', 'BRANDCO LAWFIRM  - Hơn hai mươi năm trước, chúng ta đã thực hiện cấu trúc lại nền kinh tế để tạo nên kỳ tích đổi mới. Bây giờ, đổi mới vẫn được tiếp tục nhưng cần được đặt trên một lộ trình mới. Tái cấu trúc nền kinh tế chính là tiếp tục thúc đẩy tiến trình đổi mới, để đạt được thành quả cao và hưởng lợi nhiều hơn từ đổi mới.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'thực hiện,kinh tế,kỳ tích,bây giờ,tiếp tục,lộ trình,thúc đẩy,tiến trình,thành quả'),
(17, 33, '23,33', 0, 1, '', 0, 1351436724, 1351436724, 1, 1351436724, 0, 2, 'Tư vấn thành lập, tổ chức, quản lý doanh nghiệp theo mô hình tập đoàn kinh tế', 'Tu-van-thanh-lap-to-chuc-quan-ly-doanh-nghiep-theo-mo-hinh-tap-doan-kinh-te', 'BRANDCO LAWFIRM - Pháp luật hiện hành đã quy định rất cụ thể về việc thành lập ra các tập đoàn kinh tế nhà nước, cụ thể nhất là quy định tại Số: 101/2009/NĐ-CP ngày 05/11/2009 của chính phủ. Tuy nhiên, việc thành lập các tập đoàn kinh tế theo mô hình &quot; Công ty mẹ - Công ty con&quot; đối với khối Doanh nghiệp dân doanh lại chưa được ghi nhận.', '2012_10/to-chuc-doanh-nghiep.jpg', '', 'thumb/to-chuc-doanh-nghiep.jpg|block/to-chuc-doanh-nghiep.jpg', 1, 2, 1, 1, 0, 0, 0, 'pháp luật,hiện hành,quy định,cụ thể,thành lập,tập đoàn,kinh tế,nhà nước,nhất là,tuy nhiên,mô hình,công ty,doanh nghiệp'),
(16, 23, '23,32', 0, 1, '', 0, 1351421861, 1351438317, 1, 1351438200, 0, 2, 'Tư vấn xin chứng nhận đầu tư thành lập công ty liên doanh, công ty 100&#x25; vốn đầu tư nước ngoài về phân phối', 'Tu-van-xin-chung-nhan-dau-tu-thanh-lap-cong-ty-lien-doanh-cong-ty-100-von-dau-tu-nuoc-ngoai-ve-phan-phoi', 'BRANDCO LAWFIRM - Công ty Luật Brandco  tự hào là công ty hàng đầu trong lĩnh vực tư vấn đầu tư và cung cấp các dịch vụ hỗ trợ các nhà đầu tư tại việt nam như: tư vấn thành lập doanh nghiệp liên doanh, công ty 100% vốn nước ngoài, tư vấn lập dự án đầu tư (dự án tiền khả thi và dự án khả thi), tư vấn thủ tục xin ưu đãi đầu tư....', '2012_10/dau-tu.jpeg', '', 'thumb/dau-tu.jpeg.jpg|block/dau-tu.jpeg.jpg', 1, 2, 1, 2, 0, 0, 0, 'công ty,tự hào,hàng đầu,lĩnh vực,tư vấn,hỗ trợ,thành lập,doanh nghiệp,liên doanh,dự án,khả thi,thủ tục'),
(15, 32, '23,32', 0, 1, '', 0, 1351421742, 1351421742, 1, 1351421742, 0, 2, 'Thành lập văn phòng đại diên của doanh nghiệp nước ngoài&#33;&#33;&#33;', 'Thanh-lap-van-phong-dai-dien-cua-doanh-nghiep-nuoc-ngoai', 'BRANDCO -  Sau sự kiện Việt Nam tham gia vào WTO ngày càng có nhiều thương nhân nước ngoài đến Việt Nam để tìm hiểu môi trường đầu tư, xúc tiến các hoạt động kinh doanh. Là nhà tư vấn chuyên nghiệp trong lĩnh vực doanh nghiệp – thương mại – kinh tế, công ty luật  Brandco xin cung cấp tới quý khách hàng  về điều kiện cấp phép thành lập văn phòng đại diện của thương nhân nước ngoài tại Việt Nam.', '2012_10/vanphongdaidien.jpg', '', 'thumb/vanphongdaidien.jpg|block/vanphongdaidien.jpg', 1, 2, 1, 1, 0, 0, 0, 'sự kiện,tham gia,ngày càng,tìm hiểu,môi trường,xúc tiến,hoạt động,kinh doanh,tư vấn,lĩnh vực,doanh nghiệp,thương mại,kinh tế,công ty,quý khách,thành lập,văn phòng,đại diện'),
(14, 32, '23,32', 0, 1, '', 0, 1351421497, 1351421554, 1, 1351421497, 0, 2, 'Công ty luật Brandco&#x3A; Xin giấy phép đầu tư&#33;', 'Cong-ty-luat-Brandco-Xin-giay-phep-dau-tu', 'BRANDCO - Công ty Luật Brandco  tự hào là công ty hàng đầu trong lĩnh vực tư vấn đầu tư và cung cấp các dịch vụ hỗ trợ các nhà đầu tư tại việt nam như: tư vấn thành lập doanh nghiệp liên doanh, công ty 100% vốn nước ngoài, tư vấn lập dự án đầu tư (dự án tiền khả thi và dự án khả thi), tư vấn thủ tục xin ưu đãi đầu tư....', '2012_10/dau-tu.jpg', '', 'thumb/dau-tu.jpg|block/dau-tu.jpg', 1, 2, 1, 0, 0, 0, 0, 'công ty,tự hào,hàng đầu,lĩnh vực,tư vấn,hỗ trợ,thành lập,doanh nghiệp,liên doanh,dự án,khả thi,thủ tục'),
(12, 31, '23,31', 0, 1, '', 0, 1351421031, 1351437155, 1, 1351421031, 0, 2, 'Công ty luật Brandco&#x3A; Dịch vụ thành lập doanh nghiệp&#33;', 'Cong-ty-luat-Brandco-Dich-vu-thanh-lap-doanh-nghiep', 'BRANDCO -  Là nhà tư vấn chuyên nghiệp trong lĩnh vực tư vấn đầu tư và tư vấn sở hữu trí tuệ, với nhiều năm kinh nghiệm phục vụ khách hàng, Công ty luật Brandco xin được giới thiệu tới rộng rãi các nhà đầu tư dịch vụ tư vấn thành lập doanh nghiệp do Công ty luật Brandco cung cấp.', '2012_10/thanhlapdoanhnghiep.jpeg', '', 'thumb/thanhlapdoanhnghiep.jpeg.jpg|block/thanhlapdoanhnghiep.jpeg.jpg', 1, 2, 1, 0, 0, 0, 0, 'tư vấn,lĩnh vực,sở hữu,trí tuệ,kinh nghiệm,phục vụ,khách hàng,công ty,giới thiệu,rộng rãi,thành lập,doanh nghiệp'),
(13, 31, '23,31', 0, 1, '', 0, 1351421252, 1351421641, 1, 1351421252, 0, 2, 'Công ty luật Brandco&#x3A; Đặc điểm của các loại hình các loại hình doanh nghiệp&#33;', 'Cong-ty-luat-Brandco-Dac-diem-cua-cac-loai-hinh-cac-loai-hinh-doanh-nghiep', 'BRANDCO - Để giúp các bạn khởi sự kinh doanh nhanh chóng và thuận lợi. Brandco xin cung cấp cho quý khách hàng một số kiến thức về sự khác nhau giữa các loại hình doanh nghiệp, để quý khách có được sự lựa chọn tốt nhất', '2012_10/doanh-nghiep.jpeg', '', 'thumb/doanh-nghiep.jpeg.jpg|block/doanh-nghiep.jpeg.jpg', 1, 2, 1, 1, 0, 0, 0, 'khởi sự,kinh doanh,nhanh chóng,thuận lợi,quý khách,kiến thức,loại hình,doanh nghiệp'),
(11, 31, '23,31', 0, 1, '', 0, 1351408478, 1351436954, 1, 1351408478, 0, 2, 'Những vấn đề cần lưu ý khi thực hiện thủ tục đăng ký kinh doanh', 'Nhung-van-de-can-luu-y-khi-thuc-hien-thu-tuc-dang-ky-kinh-doanh', 'BRANDCO - Để giúp các bạn khởi sự kinh doanh nhanh chóng và thuận lợi. Brandco xin cung cấp cho quý khách hàng một số vấn đề cần lưu ý khi thực hiện thủ tục đăng ký doanh nghiệp theo Luật Doanh nghiệp năm 2005.', '2012_10/dkkd.jpeg', '', 'thumb/dkkd.jpeg.jpg|block/dkkd.jpeg.jpg', 1, 2, 1, 1, 0, 5, 1, 'khởi sự,kinh doanh,nhanh chóng,thuận lợi,quý khách,vấn đề,lưu ý,thực hiện,thủ tục,đăng ký,doanh nghiệp'),
(19, 34, '24,34', 0, 1, '', 0, 1351437291, 1351437291, 1, 1351437291, 0, 2, 'Công ty luật Brandco&#x3A; Dịch vụ đăng ký bảo hộ quyền tác giả.', 'Cong-ty-luat-Brandco-Dich-vu-dang-ky-bao-ho-quyen-tac-gia', 'BRANDCO - Bảo hộ quyền tác giả là một trong những phương thức hiệu quả để thúc đẩy và phổ biến trí thức quốc gia. Sự phát triển của một đất nước phụ thuộc chủ yếu vào hoạt động sáng tạo của người dân và việc khuyến khích sáng tạo cá nhân và phổ biến cập nhật các sáng tạo đó sẽ là tiền đề đối với quá trính phát triển.', '2012_10/hanggia.jpg', '', 'thumb/hanggia.jpg|block/hanggia.jpg', 1, 2, 1, 1, 0, 0, 0, 'bảo hộ,tác giả,phương thức,hiệu quả,thúc đẩy,phổ biến,trí thức,quốc gia,phát triển,phụ thuộc,chủ yếu,hoạt động,sáng tạo,khuyến khích,cá nhân,tiền đề'),
(20, 34, '24,34', 0, 1, '', 0, 1351437427, 1351437427, 1, 1351437427, 0, 2, 'Công ty luật Brandco&#x3A; Đăng ký bảo hộ độc quyền sáng chế&#33;', 'Cong-ty-luat-Brandco-Dang-ky-bao-ho-doc-quyen-sang-che', 'BRANDCO – Sáng chế, một đối tượng quan trọng cơ bản của quyền sở hữu trí tuệ, một tài sản vô hình vô cùng quan trọng đối với mỗi doanh nghiệp. Tuy nhiên, ở Việt nam hiện nay vấn đề bảo hộ độc quyền các ý tưởng sáng tạo đối với sáng chế đang bị coi nhẹ. Công ty Luật Brandco, với tư cách là một chuyên gia hàng đầu về bảo hộ độc quyền sáng chế, xin được chia sẻ với các bạn một số kinh nghiệm liên quan để bảo vệ quyền hợp pháp của mình với loại tài sản đặc biệt này', '2012_10/sang-che.jpg', '', 'thumb/sang-che.jpg|block/sang-che.jpg', 1, 2, 1, 1, 0, 0, 0, 'sáng chế,quan trọng,cơ bản,sở hữu,trí tuệ,tài sản,vô hình,doanh nghiệp,tuy nhiên,hiện nay,vấn đề,bảo hộ,ý tưởng,sáng tạo,công ty,tư cách,chuyên gia,hàng đầu,kinh nghiệm,liên quan,bảo vệ'),
(21, 34, '24,34', 0, 1, '', 0, 1351437554, 1351437554, 1, 1351437554, 0, 2, 'Công ty luật Brandco&#x3A; Dịch vụ Bảo hộ Kiểu dáng công nghiệp', 'Cong-ty-luat-Brandco-Dich-vu-Bao-ho-Kieu-dang-cong-nghiep', 'BRANDCO - Kiểu dáng công nghiệp, một đối tượng quan trọng cơ bản của quyền sở hữu trí tuệ, một tài sản vô hình vô cùng quan trọng đối với mỗi doanh nghiệp sản xuất. Công ty Luật Brandco, với tư cách là một chuyên gia hàng đầu về bảo hộ độc quyền kiểu dáng công nghiệp, xin được chia sẻ với các bạn một số kinh nghiệm liên quan để bảo vệ quyền hợp pháp của mình với loại tài sản đặc biệt này.', '2012_10/xemay.jpg', '', 'thumb/xemay.jpg|block/xemay.jpg', 1, 2, 1, 1, 0, 0, 0, 'công nghiệp,quan trọng,cơ bản,sở hữu,trí tuệ,tài sản,vô hình,doanh nghiệp,sản xuất,công ty,tư cách,chuyên gia,hàng đầu,bảo hộ,kinh nghiệm,liên quan,bảo vệ,hợp pháp,đặc biệt'),
(22, 35, '24,35', 0, 1, '', 0, 1351437917, 1351437917, 1, 1351437917, 0, 2, 'Khiếu nại &amp; xử lý vi phạm quyền sở hữu trí tuệ', 'Khieu-nai-xu-ly-vi-pham-quyen-so-huu-tri-tue', 'BRANDCO - Hãng luật Brandco là một hãng tư vấn luật thành công nhất ở Việt Nam trong việc phối hợp có hiệu quả với các cơ quan có thẩm quyền Việt Nam tiến hành các biện pháp thực thi quyền chống lại vi phạm quyền nhãn hiệu hàng hoá, kiểu dáng công nghiệp, bản quyền tác giả và sáng chế để đảm bảo rằng quyền sở hữu trí tuệ của Quý doanh nghiệp được bảo hộ, thực thi phù hợp với mục tiêu và chiến lược của họ trên thị trường.', '2012_10/xulyviphamshtt.jpg', '', 'thumb/xulyviphamshtt.jpg|block/xulyviphamshtt.jpg', 1, 2, 1, 1, 0, 0, 0, 'tư vấn,thành công,phối hợp,hiệu quả,cơ quan,thẩm quyền,tiến hành,biện pháp,vi phạm,nhãn hiệu,công nghiệp,bản quyền,tác giả,sáng chế,đảm bảo,sở hữu,trí tuệ,doanh nghiệp,bảo hộ,phù hợp,mục tiêu'),
(23, 37, '25,37', 0, 1, '', 0, 1351438502, 1351438502, 1, 1351438502, 0, 2, 'Tư vấn soạn thảo quy chế, nội quy lao động của doanh nghiệp', 'Tu-van-soan-thao-quy-che-noi-quy-lao-dong-cua-doanh-nghiep', 'BRANDCO LAW FIRM - Ngày nay, kinh tế của Việt Nam ngày càng phát triển, các doanh nghiệp nước ngoài vào Việt Nam và các doanh nghiệp trong nước được thành lập ngày càng nhiều do đó mối qua hệ giữa người lao động và người sử dụng lao động ngày càng phức tạp, nảy sinh những trang chấp trong quan hệ lao động giữa người sử dụng lao động và người lao động.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'ngày nay,kinh tế,ngày càng,phát triển,doanh nghiệp,thành lập,lao động,sử dụng,phức tạp,nảy sinh,quan hệ'),
(24, 37, '25,37', 0, 1, '', 0, 1351484608, 1351484608, 1, 1351484608, 0, 2, 'Công ty Luật Brandco&#x3A; Dịch vụ tư vấn hợp đồng', 'Cong-ty-Luat-Brandco-Dich-vu-tu-van-hop-dong', 'BRANDCO - Là Hãng luật hàng đầu trong lĩnh vực tư vấn đầu tư và tư vấn Sở hữu trí tuệ, hãng luật Brandco xin giới thiệu với Quý doanh nghiệp các dịch vụ pháp lý liên quan tới các hợp đồng, bao gồm việc chuẩn bị cơ sở pháp lý, đàm phán, soạn thảo và hiệu chỉnh các loại hợp đồng kinh tế, thương mại, đầu tư….', '2012_10/tu-van-hop-dong.jpeg', '', 'thumb/tu-van-hop-dong.jpeg.jpg|block/tu-van-hop-dong.jpeg.jpg', 1, 2, 1, 0, 0, 0, 0, 'hàng đầu,lĩnh vực,tư vấn,sở hữu,trí tuệ,giới thiệu,doanh nghiệp,pháp lý,liên quan,hợp đồng,bao gồm,chuẩn bị,cơ sở,đàm phán,soạn thảo,kinh tế,thương mại'),
(25, 37, '25,37', 0, 1, '', 0, 1351484700, 1351484700, 1, 1351484700, 0, 2, 'Tư vấn về thừa kế tài sản theo quy định của bộ luật dân sự', 'Tu-van-ve-thua-ke-tai-san-theo-quy-dinh-cua-bo-luat-dan-su', 'BRANDCO LAW FIRM - Pháp luật Việt nam khẳng định quyền được thừa kế của mọi cá nhân, tổ chức theo quy định tại Điều 631, Bộ luật Dân sự, cụ thể: “Cá nhân có quyền lập di chúc để định đoạt tài sản của mình; để lại tài sản của mình cho người thừa kế theo pháp luật; hưởng di sản theo di chúc hoặc theo pháp luật&quot; - Luật sư Nguyễn Văn Thi', '2012_10/dich-vu-thua-ke.jpg', '', 'thumb/dich-vu-thua-ke.jpg|block/dich-vu-thua-ke.jpg', 1, 2, 1, 0, 0, 0, 0, 'pháp luật,khẳng định,thừa kế,cá nhân,tổ chức,quy định,dân sự,cụ thể,di chúc,tài sản,di sản,luật sư'),
(26, 38, '25,38', 0, 1, '', 0, 1351484820, 1351484820, 1, 1351484820, 0, 2, 'Tư vấn xin giấy phép sản xuất thuốc lá', 'Tu-van-xin-giay-phep-san-xuat-thuoc-la', 'BRANDCO - Trình tự thủ tục và thẩm quyền cấp giấy phép trong lĩnh vực sản xuất thuốc lá.', '2012_10/thuocla.jpg', '', 'thumb/thuocla.jpg|block/thuocla.jpg', 1, 2, 1, 0, 0, 0, 0, 'trình tự,thủ tục,thẩm quyền,giấy phép,lĩnh vực,sản xuất'),
(27, 38, '25,38', 0, 1, '', 0, 1351484905, 1351485526, 1, 1351484905, 0, 2, 'Tư vấn xin giấy phép hoạt động điện lực', 'Tu-van-xin-giay-phep-hoat-dong-dien-luc', 'BRANDCO - Nội dung công việc các luật sư của chúng tôi cam kết tiến hành:', '2012_10/dien1.jpg', '', 'thumb/dien1.jpg|block/dien1.jpg', 1, 2, 1, 0, 0, 0, 0, 'nội dung,luật sư,cam kết'),
(28, 38, '25,38', 0, 1, '', 0, 1351485646, 1351485646, 1, 1351485646, 0, 2, 'Quy định về việc thu, nộp, quản lý và sử dụng phí bán đấu giá cổ phần', 'Quy-dinh-ve-viec-thu-nop-quan-ly-va-su-dung-phi-ban-dau-gia-co-phan', 'BRANDCO - Ngày 27/4/2009, Bộ Tài chính đã ban hành Thông tư số 82/2009/TT-BTC Quy định về mức thu, chế độ thu, nộp, quản lý và sử dụng phí bán đấu giá cổ phần', '', '', '', 1, 2, 1, 1, 0, 0, 0, 'tài chính,ban hành,thông tư,quy định,chế độ,quản lý,sử dụng,đấu giá'),
(29, 39, '25,39', 0, 1, '', 0, 1351485834, 1351485834, 1, 1351485834, 0, 2, 'Thủ tục thanh toán chi phí khám bệnh, chữa bệnh đối với người tham gia bảo hiểm y tế bị tai nạn giao thông', 'Thu-tuc-thanh-toan-chi-phi-kham-benh-chua-benh-doi-voi-nguoi-tham-gia-bao-hiem-y-te-bi-tai-nan-giao-thong', 'BRANDCO LAWFIRM - Liên Bộ Tài chính, Bộ Y tế vừa ban hành Thông tư liên tịch số 39/2011/TTLT-BYT-BTC hướng dẫn thủ tục thanh toán chi phí khám bệnh, chữa bệnh đối với người tham gia bảo hiểm y tế bị tai nạn giao thông.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'liên bộ,tài chính,y tế,ban hành,thông tư,liên tịch,hướng dẫn,thủ tục,thanh toán,chi phí,khám bệnh,tham gia,bảo hiểm,tai nạn'),
(30, 39, '25,39', 0, 1, '', 0, 1351485905, 1351485905, 1, 1351485905, 0, 2, 'Rút ngắn thời gian cấp Giấy miễn thị thực xuống 5 ngày', 'Rut-ngan-thoi-gian-cap-Giay-mien-thi-thuc-xuong-5-ngay', 'BRANDCO LAWFIRM - Thủ tướng Chính phủ vừa ban hành Quyết định sửa đổi, bổ sung một số điều Quy chế về miễn thị thực cho người Việt Nam định cư ở nước ngoài (Quyết định số 10/2012/QĐ-TTg).', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'thủ tướng,ban hành,quyết định,sửa đổi,bổ sung,quy chế,thị thực,định cư'),
(31, 39, '25,39', 0, 1, '', 0, 1351485981, 1351485981, 1, 1351485981, 0, 2, 'Hướng dẫn quyết toán thuế thu nhập cá nhân năm 2011', 'Huong-dan-quyet-toan-thue-thu-nhap-ca-nhan-nam-2011', 'BRANDCO LAWFIRM - Tổng cục Thuế vừa có Công văn hướng dẫn một số điểm về quyết toán thuế Thu nhập cá nhân năm 2011.', '2012_10/1394335.jpg', '', 'thumb/1394335.jpg|block/1394335.jpg', 1, 2, 1, 1, 0, 0, 0, 'tổng cục,công văn,hướng dẫn,quyết toán,thu nhập,cá nhân'),
(32, 26, '26', 0, 1, '', 0, 1351486200, 1351486200, 1, 1351486200, 0, 2, 'Phân biệt về dịch vụ Kê khai thuế qua mạng và Chữ ký số', 'Phan-biet-ve-dich-vu-Ke-khai-thue-qua-mang-va-Chu-ky-so', 'BRANDCO LAWFIRM - Công ty Luật Brandco là công ty tư vấn hàng đầu trong lĩnh vực tư vấn đầu tư, tư vấn tài chính kế toán, hoàn thiện tờ khai, dọn dẹp sổ sách kế toán và báo cáo tài chính kế toán năm ….cho hàng ngàn lượt doanh nghiệp tại Việt nam', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'công ty,tư vấn,hàng đầu,lĩnh vực,tài chính,kế toán,hoàn thiện,sổ sách,báo cáo,doanh nghiệp'),
(33, 26, '26', 0, 1, '', 0, 1351486248, 1351486248, 1, 1351486248, 0, 2, 'Khấu trừ, hoàn thuế GTGT đối với trường hợp Gđốc hoặc Tổng gđốc của Cty không được đồng thời làm Gđốc hoặc Tổng gđốc của DN khác', 'Khau-tru-hoan-thue-GTGT-doi-voi-truong-hop-Gdoc-hoac-Tong-gdoc-cua-Cty-khong-duoc-dong-thoi-lam-Gdoc-hoac-Tong-gdoc-cua-DN-khac', 'BRANDCO LAWFIRM - Công ty Luật Brandco là công ty tư vấn hàng đầu trong lĩnh vực tư vấn đầu tư, tư vấn tài chính kế toán, hoàn thiện tờ khai, dọn dẹp sổ sách kế toán và báo cáo tài chính kế toán năm ….cho hàng ngàn lượt doanh nghiệp tại Việt nam.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'công ty,tư vấn,hàng đầu,lĩnh vực,tài chính,kế toán,hoàn thiện,sổ sách,báo cáo,doanh nghiệp'),
(34, 26, '26', 0, 1, '', 0, 1351486288, 1351486288, 1, 1351486288, 0, 2, 'Từ 1&#x002F;1&#x002F;2012&#x3A; Cơ quan Thuế không bán hóa đơn cho doanh nghiệp', 'Tu-1-1-2012-Co-quan-Thue-khong-ban-hoa-don-cho-doanh-nghiep', 'BRANDCO LAWFIRM - Công ty Luật Brandco là công ty tư vấn hàng đầu trong lĩnh vực tư vấn đầu tư, tư vấn tài chính kế toán, hoàn thiện tờ khai, dọn dẹp sổ sách kế toán và báo cáo tài chính kế toán năm ….cho hàng ngàn lượt doanh nghiệp tại Việt nam.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'công ty,tư vấn,hàng đầu,lĩnh vực,tài chính,kế toán,hoàn thiện,sổ sách,báo cáo,doanh nghiệp'),
(35, 40, '27,40', 0, 1, '', 0, 1351498289, 1351498289, 1, 1351498289, 0, 2, 'Lương tối thiểu dự kiến tăng 35&#x25;', 'Luong-toi-thieu-du-kien-tang-35', 'BRANDCO LAWFIRM - Lương tối thiểu dự kiến tăng 35% Từ 1/1/2013, lương tối thiểu vùng tại mọi loại hình doanh nghiệp có thể tăng 700.000 đồng lên mức cao nhất 2,7 triệu đồng một tháng, theo đề xuất của Bộ Lao động Thương binh và Xã hội.', '2012_10/luongtoithieu.jpg', '', 'thumb/luongtoithieu.jpg|block/luongtoithieu.jpg', 1, 2, 1, 0, 0, 0, 0, 'tối thiểu,loại hình,doanh nghiệp,có thể,lao động,thương binh'),
(36, 40, '27,40', 0, 1, '', 0, 1351498364, 1351498364, 1, 1351498364, 0, 2, 'Miễn, giảm thuế sử dụng đất phi nông nghiệp', 'Mien-giam-thue-su-dung-dat-phi-nong-nghiep', 'BRANDCO LAWFIRM - Bộ Tài chính vừa ban hành văn bản số 11850/BTC-TCT tháo gỡ những vướng mắc cho cơ quan Thuế địa phương trong việc thực hiện chính sách miễn, giảm tiền thuế sử dụng đất phi nông nghiệp.', '2012_10/03_dool_tt_091203_p4_1.jpg', '', 'thumb/03_dool_tt_091203_p4_1.jpg|block/03_dool_tt_091203_p4_1.jpg', 1, 2, 1, 0, 0, 0, 0, 'tài chính,ban hành,cơ quan,thực hiện,sử dụng'),
(37, 40, '27,40', 0, 1, '', 0, 1351498432, 1351498432, 1, 1351498432, 0, 2, 'Thuế TNDN từ chuyển nhượng bất động sản được xác định theo giá hợp đồng', 'Thue-TNDN-tu-chuyen-nhuong-bat-dong-san-duoc-xac-dinh-theo-gia-hop-dong', 'BRANDCO LAWFIRM - Theo quy định của Bộ Tài chính, bắt đầu từ ngày 10-9-2012 sẽ thực hiện đánh thuế thu nhập DN đối với một số DN có thu nhập từ chuyển nhượng bất động sản.', '2012_10/bat_dong_.jpg', '', 'thumb/bat_dong_.jpg|block/bat_dong_.jpg', 1, 2, 1, 0, 0, 0, 0, 'quy định,tài chính,bắt đầu,thực hiện,đánh thuế,thu nhập,bất động'),
(38, 41, '27,41', 0, 1, '', 0, 1351499047, 1351499047, 1, 1351499047, 0, 2, 'Không biến hợp tác xã thành mô hình tự cung tự cấp', 'Khong-bien-hop-tac-xa-thanh-mo-hinh-tu-cung-tu-cap', 'BRANDCO LAWFIRM -  Hợp tác xã được tổ chức hoạt động không chỉ vì lợi ích kinh tế mà còn có cả lợi ích xã hội. Do đó, cần tăng cường quan hệ kinh tế trong hợp tác xã, không biến hợp tác xã trở thành mô hình tự cung tự cấp. Điều này đòi hỏi cần minh bạch hóa các nguồn vốn, xác lập lại cổ phần xã viên, tư cách xã viên và chú trọng hơn đến công nghiệp chế biến và dịch vụ tiêu thụ sản phẩm, khuyến khích phát triển mới những hợp tác xã thương mại, dịch vụ đa ngành.', '2012_10/htx.jpg', '', 'thumb/htx.jpg|block/htx.jpg', 1, 2, 1, 0, 0, 0, 0, 'hợp tác xã,tổ chức,hoạt động,lợi ích,kinh tế,xã hội,tăng cường,quan hệ,trở thành,mô hình,tự cung,tự cấp,minh bạch,cổ phần,tư cách,công nghiệp,chế biến,tiêu thụ,sản phẩm,khuyến khích,phát triển'),
(39, 41, '27,41', 0, 1, '', 0, 1351499127, 1351499127, 1, 1351499127, 0, 2, 'Cơ chế giải quyết tranh chấp không rõ sẽ rất phức tạp', 'Co-che-giai-quyet-tranh-chap-khong-ro-se-rat-phuc-tap', 'BRANDCO LAWFIRM -  Cho ý kiến về việc ban hành Nghị định về kinh doanh trò chơi điện tử có thưởng dành cho người nước ngoài, các Ủy viên UBTVQH đều tán thành về sự cần thiết phải ban hành Nghị định nhằm kịp thời khắc phục những hạn chế trong lĩnh vực này, từng bước nâng cao hiệu quả quản lý, khai thác hợp lý nguồn thu cho ngân sách Nhà nước. Tuy nhiên, việc ban hành Nghị định cần chú trọng đến mục tiêu tạo công cụ pháp lý để tăng cường sự quản lý của Nhà nước với lĩnh vực kinh doanh có điều kiện này, tạo điều kiện để hoạt động kinh doanh trò chơi điện tử có thưởng trở thành kênh góp phần thúc đẩy phát triển dịch vụ du lịch đồng thời bảo đảm quyền và lợi ích hợp pháp của người tham gia…', '2012_10/imagesca8lezqn.jpg', '', 'thumb/imagesca8lezqn.jpg|block/imagesca8lezqn.jpg', 1, 2, 1, 0, 0, 0, 0, 'ý kiến,ban hành,nghị định,kinh doanh,trò chơi,ủy viên,tán thành,cần thiết,kịp thời,khắc phục,hạn chế,lĩnh vực,nâng cao,hiệu quả,quản lý,khai thác,hợp lý,ngân sách,nhà nước,tuy nhiên,mục tiêu'),
(40, 41, '27,41', 0, 1, '', 0, 1351499221, 1351499221, 1, 1351499221, 0, 2, 'Lấp “lỗ hổng” lớn trong xử lý tội phạm thuế, tài chính', 'Lap-lo-hong-lon-trong-xu-ly-toi-pham-thue-tai-chinh', 'BRANDCO LAWFIRM -  Bộ luật Hình sự (BLHS) hiện hành còn quá thiếu các quy định để xử lý những hành vi vi phạm pháp luật liên quan đến lĩnh vực thuế, tài chính – kế toán, đòi hỏi phải được “lấp đầy” trong quá trình sửa đổi, bổ sung BLHS tới đây.', '2012_10/images663125_ngan_hang_480.jpg', '', 'thumb/images663125_ngan_hang_480.jpg|block/images663125_ngan_hang_480.jpg', 1, 2, 1, 1, 0, 0, 0, 'luật hình,hiện hành,quy định,xử lý,hành vi,vi phạm,pháp luật,liên quan,lĩnh vực,tài chính,kế toán,quá trình,sửa đổi,bổ sung'),
(41, 28, '28', 0, 1, '', 0, 1351499374, 1351499374, 1, 1351499374, 0, 2, 'Doanh nghiệp nước ngoài tiếp tục than phiền về Nghị định 46', 'Doanh-nghiep-nuoc-ngoai-tiep-tuc-than-phien-ve-Nghi-dinh-46', 'BRANDCO LAWFIRM  - Các thành viên thuộc Hiệp hội Doanh nghiệp châu Âu ở Việt Nam (Eurocham) lại tiếp tục nêu ra những điểm mà họ cho là bất hợp lý của Nghị định 46/2011/NĐ-CP (sửa đổi, bổ sung Nghị định 34/2008/NĐ-CP về tuyển dụng lao động nước ngoài) tại cuộc tọa đàm ngày 24-8 ở TPHCM do Eurocham và Phòng Thương mại và Công nghiệp Việt Nam (VCCI) cùng tổ chức.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'thành viên,hiệp hội,doanh nghiệp,tiếp tục,hợp lý,nghị định,sửa đổi,bổ sung,tuyển dụng,lao động,tọa đàm,thương mại,công nghiệp'),
(42, 28, '28', 0, 1, '', 0, 1351499425, 1351499425, 1, 1351499425, 0, 2, 'Nghị định 70&#x002F;2011&#x002F;NĐ-CP quy định mức lương tối thiểu vùng đối với người lao động', 'Nghi-dinh-70-2011-ND-CP-quy-dinh-muc-luong-toi-thieu-vung-doi-voi-nguoi-lao-dong', 'BRANDCO LAWFIRM  - Ngày 22/08/2011, Chính phủ đã ban hành Nghị định 70/2011/NĐ-CP quy định mức lương tối thiểu vùng đối với người lao động làm việc ở công ty, doanh nghiệp, hợp tác xã, tổ hợp tác, trang trại, hộ gia đình, cá nhân và các cơ quan, tổ chức có thuê mướn lao động, có hiệu lực từ ngày 05/10/2011 và thay thế 02 Nghị định số 107/2010/NĐ-CP; 108/2010/NĐ-CP ngày 29/10/2010.', '', '', '', 1, 2, 1, 1, 0, 0, 0, 'ban hành,nghị định,quy định,tối thiểu,lao động,làm việc,công ty,doanh nghiệp,hợp tác xã,tổ hợp tác,trang trại,gia đình,cá nhân,cơ quan,tổ chức,thuê mướn,hiệu lực,thay thế'),
(43, 28, '28', 0, 1, '', 0, 1351499616, 1351499616, 1, 1351499616, 0, 2, 'Cơ quan Thuế không bán hóa đơn cho doanh nghiệp', 'Co-quan-Thue-khong-ban-hoa-don-cho-doanh-nghiep', 'BRANDCO LAWFIRM  - Từ 1/1/2012: Tổng cục Thuế cho biết, triển khai Nghị định số 51/2010/NĐ-CP về hoá đơn (có hiệu lực thi hành từ 1/1/2011), tính đến hết ngày 30/4/2011, trên địa bàn cả nước đã có 145.693 doanh nghiệp đã tự in, đặt in hoá đơn. Tuy nhiên vẫn còn 188.421 doanh nghiệp siêu nhỏ, doanh nghiệp ở địa bàn kinh tế xã hội khó khăn và đặc biệt khó khăn đang thực hiện mua hóa đơn của cơ quan thuế.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'tổng cục,cho biết,triển khai,nghị định,hiệu lực,thi hành,doanh nghiệp,tuy nhiên,kinh tế,xã hội,khó khăn,đặc biệt,thực hiện,hóa đơn,cơ quan'),
(44, 29, '29', 0, 1, '', 0, 1351499674, 1351499674, 1, 1351499674, 0, 2, 'Dự thảo Luật Hợp tác xã &#40;sửa đổi&#41; - Băn khoăn về mức góp vốn và giới hạn quyền cung ứng sản phẩm, dịch vụ', 'Du-thao-Luat-Hop-tac-xa-sua-doi-Ban-khoan-ve-muc-gop-von-va-gioi-han-quyen-cung-ung-san-pham-dich-vu', 'BRANDCO LAWFIRM - Tiếp tục có những tranh luận sôi nổi về dự thảo Luật Hợp tác xã (sửa đổi) với những vấn đề có tính chất sống còn của hợp tác xã (HTX) như mức góp vốn tối đa của một thành viên bao nhiêu là phù hợp, vừa bảo đảm lợi ích của người góp vốn vừa bảo đảm quyền của các thành viên khác; nên hay không nên hạn chế việc cung cấp dịch vụ, sản phẩm của HTX ra thị trường… Một lần nữa, dự thảo đã được mổ xẻ dưới góc pháp lý trước khi trình QH xem xét, thông qua.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'tiếp tục,tranh luận,sôi nổi,hợp tác xã,sửa đổi,vấn đề,tính chất,sống còn,góp vốn,tối đa,thành viên,bao nhiêu,phù hợp,bảo đảm,lợi ích,hạn chế,sản phẩm,thị trường,mổ xẻ,pháp lý,trước khi'),
(45, 29, '29', 0, 1, '', 0, 1351499772, 1351499772, 1, 1351499772, 0, 2, 'Trao đổi về phạm vi hòa giải ở cơ sở', 'Trao-doi-ve-pham-vi-hoa-giai-o-co-so', 'BRANDCO LAWFIRM - Hiện có hai ý kiến không giống nhau xung quanh quy định về phạm vi hòa giải ở cơ sở được quy định tại dự thảo Luật Hòa giải cơ sở. Ý kiến thứ nhất, giữ nguyên như quy định tại Pháp lệnh về tổ chức và hoạt động hòa giải ở cơ sở đó là, việc hòa giải được tiến hành đối với các mâu thuẫn, vi phạm pháp luật và tranh chấp nhỏ trong cộng đồng dân cư. ý kiến thứ hai cho rằng, cần mở rộng phạm vi hòa giải, không chỉ giới hạn ở những vi phạm pháp luật và tranh chấp nhỏ. Việc lựa chọn ý kiến thứ nhất của Ban soạn thảo có hợp lý không?', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'ý kiến,quy định,phạm vi,hòa giải,cơ sở,pháp lệnh,tổ chức,hoạt động,tiến hành,mâu thuẫn,vi phạm,pháp luật,tranh chấp,dân cư,thứ hai,giới hạn,soạn thảo,hợp lý'),
(46, 29, '29', 0, 1, '', 0, 1351499846, 1351499846, 1, 1351499846, 0, 2, 'Dựng lại tường lửa ngăn sở hữu chéo ngân hàng', 'Dung-lai-tuong-lua-ngan-so-huu-cheo-ngan-hang', 'BRANDCO LAWFIRM - Luật Các tổ chức tín dụng được thông qua, một trong những sai lầm chết người là xóa bức tường lửa của ngân hàng đầu tư và ngân hàng thương mại. Ông Võ Trí Thành Phó Viện trưởng Viện Nghiên cứu quản lý kinh tế Trung ương đã nhận định như vậy.', '2012_10/hang-20f1d.jpg', '', 'thumb/hang-20f1d.jpg|block/hang-20f1d.jpg', 1, 2, 1, 1, 0, 0, 0, 'tổ chức,tín dụng,thông qua,sai lầm,ngân hàng,thương mại,nghiên cứu,quản lý,kinh tế,trung ương,nhận định'),
(47, 30, '30', 0, 1, '', 0, 1351501275, 1351501275, 1, 1351501275, 0, 2, 'Luật sư và người chăn lừa', 'Luat-su-va-nguoi-chan-lua', 'BRANDCO - Một anh chàng ngồi một mình trong góc quán rượu, uống tì tì suốt ba giờ liền.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'tì tì'),
(48, 30, '30', 0, 1, '', 0, 1351501314, 1351501314, 1, 1351501314, 0, 2, 'Lý luận của luật sư', 'Ly-luan-cua-luat-su', 'BRANDCO - Một luật sư đang biện hộ cho một người bị buộc tội ăn trộm. Luật sư nói với tòa... Kính thưa ngài tôi xin trình bày rằng thân chủ của tôi không hề đột nhập vào căn nhà đó.', '', '', '', 1, 2, 1, 0, 0, 0, 0, 'luật sư,biện hộ,buộc tội,ăn trộm,trình bày,không hề'),
(49, 30, '30', 0, 1, '', 0, 1351501355, 1351501355, 1, 1351501355, 0, 2, 'Từ thị trường USD tự do nghĩ về chính sách tỷ giá', 'Tu-thi-truong-USD-tu-do-nghi-ve-chinh-sach-ty-gia', 'BRANDCO LAWFIRM - Sau một thời gian tạm dừng hoạt động để nghe ngóng, thị trường USD tự do tại Hà Nội lại hoạt động trở lại. Nguyên nhân cơ bản là vì nhu cầu mua USD vì những mục đích chính đáng của người dân và doanh nghiệp vượt quá khả năng cung ứng của thị trường chính thức tại mức tỷ giá được công bố chính thức hiện tại.', '', '', '', 1, 2, 1, 1, 0, 0, 0, 'thời gian,hoạt động,nghe ngóng,thị trường,tự do,hà nội,trở lại,nguyên nhân,cơ bản,nhu cầu,mục đích,doanh nghiệp,khả năng,tỷ giá,công bố');

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_sources`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `logo` varchar(255) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `nv3_vi_news_sources`
--

INSERT INTO `nv3_vi_news_sources` (`sourceid`, `title`, `link`, `logo`, `weight`, `add_time`, `edit_time`) VALUES
(1, 'Báo Hà Nội Mới', 'http://hanoimoi.com.vn', '', 1, 1274989177, 1274989177),
(2, 'VINADES.,JSC', '', 'http://vinades.vn', 2, 1274989787, 1274989787),
(3, 'NukeViet', '', 'http://nukeviet.vn', 2, 1274989787, 1274989787),
(4, 'Báo điện tử Dân Trí', 'http://dantri.com.vn', '', 3, 1322685396, 1322685396);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_news_topics`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_news_topics` (
  `topicid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `keywords` mediumtext NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_referer_stats`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_referer_stats` (
  `host` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `month01` int(11) NOT NULL DEFAULT '0',
  `month02` int(11) NOT NULL DEFAULT '0',
  `month03` int(11) NOT NULL DEFAULT '0',
  `month04` int(11) NOT NULL DEFAULT '0',
  `month05` int(11) NOT NULL DEFAULT '0',
  `month06` int(11) NOT NULL DEFAULT '0',
  `month07` int(11) NOT NULL DEFAULT '0',
  `month08` int(11) NOT NULL DEFAULT '0',
  `month09` int(11) NOT NULL DEFAULT '0',
  `month10` int(11) NOT NULL DEFAULT '0',
  `month11` int(11) NOT NULL DEFAULT '0',
  `month12` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `host` (`host`),
  KEY `total` (`total`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_searchkeys`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_searchkeys` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `keys` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `search_engine` varchar(50) NOT NULL,
  KEY `id` (`id`),
  KEY `keys` (`keys`),
  KEY `search_engine` (`search_engine`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_voting`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_voting` (
  `vid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL DEFAULT '',
  `acceptcm` int(2) NOT NULL DEFAULT '1',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `who_view` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL,
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `question` (`question`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `nv3_vi_voting`
--

INSERT INTO `nv3_vi_voting` (`vid`, `question`, `link`, `acceptcm`, `admin_id`, `who_view`, `groups_view`, `publ_time`, `exp_time`, `act`) VALUES
(2, 'Bạn biết gì về NukeViet 3?', '', 1, 1, 0, '0', 1275318563, 0, 1),
(3, 'Bạn quan tâm gì nhất ở mã nguồn mở?', '', 1, 1, 0, '0', 1275318589, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `nv3_vi_voting_rows`
--

CREATE TABLE IF NOT EXISTS `nv3_vi_voting_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `hitstotal` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`,`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `nv3_vi_voting_rows`
--

INSERT INTO `nv3_vi_voting_rows` (`id`, `vid`, `title`, `url`, `hitstotal`) VALUES
(5, 2, 'Một bộ sourcecode cho web hoàn toàn mới.', '', 0),
(6, 2, 'Mã nguồn mở, sử dụng miễn phí.', '', 0),
(7, 2, 'Sử dụng xHTML, CSS và hỗ trợ Ajax', '', 0),
(8, 2, 'Tất cả các ý kiến trên', '', 0),
(9, 3, 'Liên tục được cải tiến, sửa đổi bởi cả thế giới.', '', 1),
(10, 3, 'Được sử dụng miễn phí không mất tiền.', '', 0),
(11, 3, 'Được tự do khám phá, sửa đổi theo ý thích.', '', 0),
(12, 3, 'Phù hợp để học tập, nghiên cứu vì được tự do sửa đổi theo ý thích.', '', 0),
(13, 3, 'Tất cả các ý kiến trên', '', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
