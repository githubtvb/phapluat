<?php

/**
 * @Project NUKEVIET 3.4
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2010 - 2012 VINADES.,JSC. All rights reserved
 * @Createdate Sun, 08 Apr 2012 00:00:00 GMT GMT
 */

if(!defined('NV_MAINFILE')){die('Stop!!!');}$cache='a:26:{s:10:"/CJzip.php";s:1:"0";s:7:"/admin/";s:1:"0";s:7:"/cache/";s:1:"0";s:11:"/config.php";s:1:"1";s:6:"/data/";s:1:"0";s:9:"/editors/";s:1:"0";s:12:"/favicon.ico";s:1:"1";s:7:"/files/";s:1:"1";s:8:"/images/";s:1:"1";s:10:"/includes/";s:1:"0";s:10:"/index.php";s:1:"1";s:9:"/install/";s:1:"0";s:4:"/js/";s:1:"1";s:10:"/language/";s:1:"0";s:6:"/logs/";s:1:"0";s:13:"/mainfile.php";s:1:"0";s:9:"/modules/";s:1:"0";s:11:"/robots.php";s:1:"0";s:11:"/robots.txt";s:1:"1";s:28:"/service_shops_nganluong.php";s:1:"1";s:6:"/sess/";s:1:"0";s:8:"/themes/";s:1:"1";s:5:"/tmp/";s:1:"0";s:20:"/update_revision.php";s:1:"1";s:9:"/uploads/";s:1:"1";s:11:"/web.config";s:1:"0";}';

?>