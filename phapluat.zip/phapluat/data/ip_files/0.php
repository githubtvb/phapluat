<?php

$ranges = array();

?>